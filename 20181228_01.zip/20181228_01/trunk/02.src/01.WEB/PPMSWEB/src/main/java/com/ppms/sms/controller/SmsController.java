package com.ppms.sms.controller;


import com.constants.Constants;
import com.ppms.entity.SmsRecEntity;
import com.ppms.sms.service.SmsService;
import com.ppms.utils.DataReturn;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.exception.BusinessException;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.jeecgframework.web.system.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;

/**
 * Created by yangyong on 2018/5/22.
 */
@Controller
@RequestMapping("/smsController")
public class SmsController extends BaseController {
    private static final Logger logger = Logger.getLogger(SmsController.class);

    @Autowired
    private SmsService smsService;
    @Autowired
    private SystemService systemService;

    /**
     * 短息信息查询，跳转到短信信息列表
     * @param request
     * @return
     */
    @RequestMapping(params = "smsQueryList")
    public ModelAndView customerInfoQueryList(HttpServletRequest request) {
        return new ModelAndView("ppms/sms/smsView");
    }

    /**
     * ajax获取短信信息列表
     * @param smsRecEntity
     * @param request
     * @param response
     * @param dataGrid
     * @throws ParseException
     */
    @RequestMapping(params = "datagrid")
    public void datagrid(SmsRecEntity smsRecEntity , HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) throws ParseException {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.SMS_QUERY.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            DataReturn dataReturn = this.smsService.getAllEntities(smsRecEntity,dataGrid.getPage(),dataGrid.getRows(),request);
            dataGrid.setResults(dataReturn.getRows());
            dataGrid.setTotal((int)dataReturn.getTotal());

            TagUtil.datagrid(response, dataGrid);
        }

    }
}
