package com.ppms.dayendRecon.controller;

import com.alibaba.fastjson.JSONObject;
import com.constants.Constants;
import com.ppms.creditTopup.dao.TopupDao;
import com.ppms.dayendRecon.RolesCheck;
import com.ppms.dayendRecon.dao.DayendReconDao;
import com.ppms.dayendRecon.service.DayendReconServiceI;
import com.ppms.entity.CounterEntity;
import com.ppms.entity.TerminalEntity;
import com.ppms.ldapLogin.util.ResourceUtils;
import com.ppms.tstypeQuery.service.TstypeServiceI;
import com.ppms.utils.Db2Page;
import com.ppms.utils.GetClientIPUtil;
import com.ppms.utils.PersDateUtils;
import com.ppms.vo.SpTopupRecordVo;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.util.StringUtil;
import org.jeecgframework.web.system.pojo.base.TSType;
import org.jeecgframework.web.system.pojo.base.TSTypegroup;
import org.jeecgframework.web.system.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by yadongliang on 2018/5/29 0029.
 */
@Controller
@RequestMapping("/dayendReconController")
public class DayendReconController extends BaseController {

    @Autowired
    private DayendReconServiceI dayendReconService;
    @Autowired
    private TopupDao topupDao;
    @Autowired
    private SystemService systemService;

    /**
     * Day end主界面
     */
    @RequestMapping(params = "dayendRecon")
    public ModelAndView dayendRecon(HttpServletRequest request) {
        ModelAndView modelAndView = new ModelAndView("ppms/dayendRecon/dayend_recon");
        String roleCode = getRoleCode();
        if(RolesCheck.isCashier(roleCode)||RolesCheck.isCounter(roleCode)){
            String countermapList = initCounter(request);
            modelAndView.addObject("counterList",countermapList);
            String centermapList = initCenter(request);
            modelAndView.addObject("terminalList",centermapList);
        }else if(RolesCheck.isExecs(roleCode)){
            modelAndView.addObject("counterList",getSelectCounter2(request));
            String centermapList = initCenter2(request);
            modelAndView.addObject("terminalList",centermapList);
        }else{
            String countermapList = initCounter(request);
            modelAndView.addObject("counterList",countermapList);
            String centermapList = initCenter(request);
            modelAndView.addObject("terminalList",centermapList);
        }
        String payModeList = getPayModeList("PAY_MODE");
        modelAndView.addObject("payModeList",payModeList);

        String txnTypeList = getTypeCodeAndNameByGroupId2(getGroupIdByGroupCode("PAYMENT_TYPE"));
        modelAndView.addObject("txnTypeList",txnTypeList);

        return modelAndView;
    }

    /**
     * 根据所选dayend日期,动态加载counter
     */
    @RequestMapping(params = "dynamicLoadCounter")
    @ResponseBody
    public String dynamicLoadCounter(HttpServletRequest request){
        String countermapList = initCounter(request);
        return countermapList;
    }

    /**
     * dayend查询各类交易及汇总信息
     */
    @RequestMapping(params = "getDayendAll")
    @ResponseBody
    public Map<String, Object> getDayendAll(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid){
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.DAY_END_RECON.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            String roleCode = getRoleCode();
            String curLoginName = "";
            //如果当前登录人为supervisor,curLoginName置为""
            if(RolesCheck.isExecs(roleCode)){

            }else if(RolesCheck.isCashier(roleCode)||RolesCheck.isCounter(roleCode)){
                curLoginName = ResourceUtils.getSessionUser().getName();
            }
            JSONObject topupJsonObject = this.dayendReconService.getTotalTopupInfo(request, response, dataGrid.getPage(), dataGrid.getRows(), curLoginName);
            JSONObject reverseJsonObject = this.dayendReconService.getTotalReverseInfo(request, response, dataGrid.getPage(), dataGrid.getRows(), curLoginName);
            JSONObject cardfeeJsonObject = this.dayendReconService.getTotalCardFeeInfo(request, response, dataGrid.getPage(), dataGrid.getRows(), curLoginName);
    //        JSONObject refundJsonObject = this.dayendReconService.getTotalRefundInfo(request, response, dataGrid.getPage(), dataGrid.getRows(), curLoginName);
            JSONObject dayendallJsonObject = this.dayendReconService.getDayendAll(request, response, dataGrid.getPage(), dataGrid.getRows(), curLoginName);

            Map<String, Object> resultmap = new HashMap<>();
            resultmap.put("topup",topupJsonObject);
            resultmap.put("reverse",reverseJsonObject);
            resultmap.put("cardfee",cardfeeJsonObject);
    //        resultmap.put("refund",refundJsonObject);
            resultmap.put("dayendall",dayendallJsonObject);

            return resultmap;
        }

        return null;
    }

    /**
     * 点击合计中的超链接查询对应交易类别的detail
     */
    @RequestMapping(params = "dayendReconDetail")
    @ResponseBody
    public void dayendReconDetail(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.DAY_END_RECON.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            String roleCode = getRoleCode();
            String curLoginName = "";
            //如果当前登录人为supervisor,curLoginName置为""
            if(RolesCheck.isExecs(roleCode)){

            }else if(RolesCheck.isCashier(roleCode)||RolesCheck.isCounter(roleCode)){
                curLoginName = ResourceUtils.getSessionUser().getName();
            }
            int page = Integer.valueOf(request.getParameter("page"));
            int rows = Integer.valueOf(request.getParameter("rows"));
            JSONObject detailJsonObject = this.dayendReconService.getDayendDetail(request, response, page, rows, curLoginName);
            Db2Page.responseDatagrid(response,detailJsonObject);
        }
    }

    /**
     * DAYEND SETTLE
     */
    @RequestMapping(params = "doSettle")
    @ResponseBody
    public AjaxJson doSettle(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.ACCOUNT_ACTIVATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            String message = "";
            AjaxJson j = new AjaxJson();
            String roleCode = getRoleCode();
            String curLoginName = ResourceUtils.getSessionUser().getName();
            //1.参数非空校验
            String dayendDate = request.getParameter("dayendDate");
            String terminal = request.getParameter("terminal");
            String counter = request.getParameter("counter");
            if(StringUtil.isEmpty(dayendDate)){
                message = "Please Select Date.";
                j.setMsg(message);
                return j;
            }else if(StringUtil.isEmpty(terminal)){
                message = "Please Select Terminal.";
                j.setMsg(message);
                return j;
            }

            //2.执行settle
            if(RolesCheck.isCashier(roleCode)||RolesCheck.isCounter(roleCode)){//当前登录人为cashier或counter时
                if(StringUtil.isEmpty(counter)){
                    message = "Please Select Counter.";
                    j.setMsg(message);
                    return j;
                }
                //Settle状态校验(是否已执行过settle)
                boolean b = this.dayendReconService.checkSettleStatus(dayendDate, terminal, counter, curLoginName, "");
                if(b==true){
                    message = "This counter has been reconciled and no reconciliation is allowed.";
                    j.setMsg(message);
                    return j;
                }
                //更新对账状态
                message = this.dayendReconService.doUpdateReconStatus(request, curLoginName);
                //新增dayendRecon记录
                message = this.dayendReconService.insertDayendRecon(request, curLoginName);
            }else if(RolesCheck.isExecs(roleCode)){//当前登录人为supervisor时,过滤条件参数校验,center为空不允许执行settle
                //校验是否有未对账信息,有则提示不能settlement(查询的为SP_TOPUP_REC)
                Map<String, Object> dayendAll = dayendReconService.getDayendAllSettlement(request, null, 1, 10, null);
                String stotal = dayendAll.get("total").toString();
                if(Integer.valueOf(stotal) > 0){
                    message = "There are still counters in this site that have not been reconciled, and Settlement is not allowed.";
                    j.setMsg(message);
                    return j;
                }
                //校验是否已进行过对账,有则提示不允许重复对账
                boolean b = this.dayendReconService.checkSettleStatus(dayendDate, terminal, "", "", curLoginName);
                if(b==true){
                    message = "This site has been reconciled and no reconciliation is allowed.";
                    j.setMsg(message);
                    return j;
                }
                //执行settlement
                message = dayendReconService.serviceSettlement(request, curLoginName);
            }else{
                message = "Permission denied.";
            }

            j.setMsg(message);
            return j;
        }

        return null;
    }

    /**
     * @description: 更新payMode
     * @auther: liangyadong
     * @date: 2018/10/10 0010 下午 3:22
     */
    @RequestMapping(params = "goUpdatePayMode")
    public ModelAndView goUpdatePayMode(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.ACCOUNT_ACTIVATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            SpTopupRecordVo recordVo = this.dayendReconService.updatePayMode(request);
            ModelAndView modelAndView = new ModelAndView("ppms/dayendRecon/dayend_editpaymode");
            String payModeList = getPayModeList("PAY_MODE");
            modelAndView.addObject("payModeList",payModeList);
            modelAndView.addObject("recordVo", recordVo);
            return modelAndView;
        }
        return null;
    }

    /**
     * @description: 修改paymentMode
     * @auther: liangyadong
     * @date: 2018/10/10 0010 下午 3:21
     */
    @RequestMapping(params = "doUpdatePaymode")
    @ResponseBody
    public AjaxJson doUpdatePaymode(HttpServletRequest request){
        String message = "";
        AjaxJson j = new AjaxJson();
        message = this.dayendReconService.doUpdatePaymode(request);
        j.setMsg(message);
        return j;
    }

    /**
     * supervisor初始化counter信息
     */
    private String getSelectCounter2(HttpServletRequest request){
        List<Map<String, String>> counterList = this.dayendReconService.getCounterList(request);
        return JSONObject.toJSONString(counterList);
    }

    /**
     * 查询payMode
     */
    public String getPayModeList(String payMode){
        String groupId = getGroupIdByGroupCode(payMode);
        String typeCodeAndName = getTypeCodeAndNameByGroupId3(groupId);
        return typeCodeAndName;
    }

    /**
     * 根据groupName查询groupId
     */
    public String getGroupIdByGroupCode(String typegroupcode){
        String typeGroupId = "";
        CriteriaQuery criteriaQuery = new CriteriaQuery(TSTypegroup.class);
        criteriaQuery.eq("typegroupcode",typegroupcode);
        criteriaQuery.add();
        List<TSTypegroup> tsTypegroupList = this.dayendReconService.getTstypeGroupList(criteriaQuery);
        if (tsTypegroupList!=null&&tsTypegroupList.size()>0){
            TSTypegroup tsTypegroup = tsTypegroupList.get(0);
            typeGroupId = tsTypegroup.getId();
        }

        return typeGroupId;
    }

    /**
     * 根据groupId查询groupCode和groupName(多个)
     */
    public String getTypeCodeAndNameByGroupId(String typeGroupId) {
        CriteriaQuery criteriaQuery = new CriteriaQuery(TSType.class);
        criteriaQuery.eq("TSTypegroup.id", typeGroupId);
        criteriaQuery.add();
        List<TSType> tsTypeList = this.dayendReconService.getTstypeList(criteriaQuery);
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        if (tsTypeList != null && tsTypeList.size() > 0) {
            for (TSType tsType : tsTypeList) {
                Map map = new HashMap();
                String typecode = tsType.getTypecode();
                String typename = tsType.getTypename();
                map.put("code",typecode);
                map.put("name",typename);
                list.add(map);
            }
        }

        return JSONObject.toJSONString(list);
    }

    /**
     * 根据groupId查询groupCode和groupName(多个) day end 初始化txn_type
     */
    public String getTypeCodeAndNameByGroupId2(String typeGroupId) {
        CriteriaQuery criteriaQuery = new CriteriaQuery(TSType.class);
        criteriaQuery.eq("TSTypegroup.id", typeGroupId);
        criteriaQuery.add();
        List<TSType> tsTypeList = this.dayendReconService.getTstypeList(criteriaQuery);
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        if (tsTypeList != null && tsTypeList.size() > 0) {
            for (TSType tsType : tsTypeList) {
                Map map = new HashMap();
                String typecode = tsType.getTypecode();
                String typename = tsType.getTypename();
                if(typecode.equals("01")||typecode.equals("02")||typecode.equals("03")||typecode.equals("06")||typecode.equals("10")){
                    map.put("code",typecode);
                    map.put("name",typename);
                    list.add(map);
                }
            }
        }

        return JSONObject.toJSONString(list);
    }

    /**
     * 根据groupId查询groupCode和groupName(多个) 初始化paymode
     */
    public String getTypeCodeAndNameByGroupId3(String typeGroupId) {
        CriteriaQuery criteriaQuery = new CriteriaQuery(TSType.class);
        criteriaQuery.eq("TSTypegroup.id", typeGroupId);
        criteriaQuery.add();
        List<TSType> tsTypeList = this.dayendReconService.getTstypeList(criteriaQuery);
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        if (tsTypeList != null && tsTypeList.size() > 0) {
            for (TSType tsType : tsTypeList) {
                Map map = new HashMap();
                String typecode = tsType.getTypecode();
                String typename = tsType.getTypename();
                if(typecode.equals("01")||typecode.equals("02")||typecode.equals("03")||typecode.equals("04")||typecode.equals("05")||typecode.equals("06")){
                    map.put("code",typecode);
                    map.put("name",typename);
                    list.add(map);
                }
            }
        }

        return JSONObject.toJSONString(list);
    }

    /**
     * 根据groupId查询typecode(单个)
     */
    public String getTypeCodeByGroupId(String typeGroupId){
        CriteriaQuery criteriaQuery = new CriteriaQuery(TSType.class);
        criteriaQuery.eq("TSTypegroup.id", typeGroupId);
        criteriaQuery.add();
        String typecode = "";
        List<TSType> tsTypeList = this.dayendReconService.getTstypeList(criteriaQuery);
        if(tsTypeList!=null&&tsTypeList.size()>0){
            TSType tsType = tsTypeList.get(0);
            typecode = tsType.getTypecode();
        }

        return typecode;
    }

    /**
     * 获取当前登录用户角色的rolecode
     */
    public String getRoleCode(){
        String currentUserRole = ResourceUtils.getCurrentUserRole();

        return currentUserRole;
    }

    /**
     * 查询当前登录人所在center,即terminal表中的code字段(暂时作废)
     * 2018-09-06 20:56:00
     */
    public String getCurentCenter(HttpServletRequest request){
        String clientIp = GetClientIPUtil.getIpAddr(request);
        CounterEntity counterEntity = topupDao.getCounterByIP(clientIp);
        TerminalEntity terminalEntity = topupDao.getTerminalInfo(counterEntity.getTerminalEntity().getId());
        String terminalCode = terminalEntity.getCode();
        String terminalName = terminalEntity.getName();

        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        Map map = new HashMap();
        map.put("code",terminalCode);
        map.put("name",terminalName);
        list.add(map);

        return JSONObject.toJSONString(list);
    }

    /**
     * supervisor登录后初始化center信息加载登录时所选terminal下的所有已激活counter
     */
    public String initCenter2(HttpServletRequest request){
        List<Map<String, String>> centerList = dayendReconService.generateCenterList(request);

        return JSONObject.toJSONString(centerList);
    }

    /**
     * 初始化counter下拉框信息,根据登录人用户名,日期查询
     */
    public String initCounter(HttpServletRequest request){
        String dayendDate = request.getParameter("dayendDate");
        if(StringUtil.isEmpty(dayendDate)){
            SimpleDateFormat sdf = PersDateUtils.getSdf(PersDateUtils.FORMAT_DATE_SPLIT);
            dayendDate = sdf.format(new Date());
        }
        String curLoginName = ResourceUtils.getSessionUser().getName();
        List<Map<String, String>> counterList = dayendReconService.getCounterCodeList(dayendDate, curLoginName);

        return JSONObject.toJSONString(counterList);
    }

    /**
     * 初始化center下拉框信息,根据登录clientIp,查询counter,再查询center(counter和cashier)
     */
    public String initCenter(HttpServletRequest request){
        String clientIp = GetClientIPUtil.getIpAddr(request);
        List<Map<String, String>> counterList = dayendReconService.getCenterCodeList(clientIp);

        return JSONObject.toJSONString(counterList);
    }

    /**
     * 查询counter信息(激活状态的counter) 暂时不用了.
     */
//    private String getSelectCounter(HttpServletRequest request){
//        CriteriaQuery cq = new CriteriaQuery(CounterEntity.class);
//        cq.eq("status", SiteStatus.ACTIVE.getStatus());
//        cq.add();
//        List<CounterEntity> counterEntityList = this.dayendReconService.getListByCriteriaQuery(cq, false);
//        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
//        if (counterEntityList != null && counterEntityList.size() > 0) {
//            for (CounterEntity counterEntity : counterEntityList) {
//                Map map = new HashMap();
//                String counterCode = counterEntity.getCode();
//                String counterName = counterEntity.getName();
//                map.put("code",counterCode);
//                map.put("name",counterName);
//                list.add(map);
//            }
//        }
//
//        return JSONObject.toJSONString(list);
//    }

    /**
     * 查询terminal信息(激活状态的terminal)
     */
//    private String getSelectTerminal(){
//        CriteriaQuery cq = new CriteriaQuery(TerminalEntity.class);
//        cq.eq("status", SiteStatus.ACTIVE.getStatus());
//        cq.add();
//        List<TerminalEntity> terminalEntityList = this.dayendReconService.getListByCriteriaQuery(cq, false);
//        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
//        if (terminalEntityList != null && terminalEntityList.size() > 0) {
//            for (TerminalEntity terminalEntity : terminalEntityList) {
//                Map map = new HashMap();
//                String terminalCode = terminalEntity.getCode();
//                String terminalName = terminalEntity.getName();
//                map.put("code",terminalCode);
//                map.put("name",terminalName);
//                list.add(map);
//            }
//        }
//
//        return JSONObject.toJSONString(list);
//    }

}
