package com.ppms.caRecon.controller;

import com.alibaba.fastjson.JSONObject;
import com.constants.Constants;
import com.constants.SiteStatus;
import com.constants.CAReconConstants;
import com.ppms.entity.*;
import com.ppms.tstypeQuery.service.TstypeServiceI;
import com.ppms.vo.CAReconAbnVo;
import com.ppms.caRecon.service.CAReconServiceI;
import com.ppms.ldapLogin.util.ResourceUtils;
import com.ppms.utils.DataReturn;
import com.ppms.vo.CaReconResultInfoVo;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.util.MyBeanUtils;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.poi.excel.entity.ExportParams;
import org.jeecgframework.poi.excel.entity.vo.NormalExcelConstants;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.jeecgframework.web.system.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by yadongliang on 2018/5/29 0029.
 */
@Controller
@RequestMapping("/caReconController")
public class CAReconController extends BaseController {
    /**
     * Logger for this class
     */
    private static final Logger logger = Logger.getLogger(CAReconController.class);

    @Autowired
    private CAReconServiceI caReconService;
    @Autowired
    private TstypeServiceI tstypeService;
    @Autowired
    private SystemService systemService;

    /**
     * @description: ca reconciliation主页面
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:20
     */
    @RequestMapping(params = "caReconResult")
    public ModelAndView caReconResult(HttpServletRequest request) {
        return new ModelAndView("ppms/caReconciliation/ca_recon_result");
    }

    /**
     * @description: 主页面mianlist Datagrid
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:20
     */
    @RequestMapping(params = "mainlist")
    public ModelAndView mainlist(HttpServletRequest request) {
        ModelAndView modelAndView = new ModelAndView("ppms/caReconciliation/ca_recon_result_main");
        modelAndView.addObject("caList",getCACodeAndName());
        String reconList = getReconStatusList();
        modelAndView.addObject("reconList",reconList);
        return modelAndView;
    }

    private String getReconStatusList() {
        String reconstatus = tstypeService.getGroupIdByGroupCode("CA_RECON_RESULT_STATUS");
        List<Map<String, Object>> reconstatusList = tstypeService.getTypeCodeAndNameByGroupId(reconstatus);
        return JSONObject.toJSONString(reconstatusList);
    }

    /**
     * @description: 主页面abnormallist Datagrid
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:27
     */
    @RequestMapping(params = "abnlist")
    public ModelAndView abnlist(HttpServletRequest request) {
        return new ModelAndView("ppms/caReconciliation/ca_recon_result_abn");
    }

    /**
     * @description: 申请删除页面
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:27
     */
    @RequestMapping(params = "applydelete")
    public ModelAndView applydelete(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("ppms/caReconciliation/ca_recon_applydelete");
        String id = request.getParameter("id");
        mv.addObject("id",id);
        return mv;
    }

    /**
     * @description: 审批页面
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:27
     */
    @RequestMapping(params = "reconApproval")
    public ModelAndView reconApproval(HttpServletRequest request) {
        ModelAndView modelAndView = new ModelAndView("ppms/caReconciliation/ca_recon_approval");
        modelAndView.addObject("caList",getCACodeAndName());
        return modelAndView;
    }

    /**
     * @description: 审计页面
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:27
     */
    @RequestMapping(params = "caReconAudit")
    public ModelAndView caReconAudit(HttpServletRequest request) {
        ModelAndView modelAndView = new ModelAndView("ppms/caReconciliation/ca_recon_audit");
        modelAndView.addObject("caList",getCACodeAndName());
        return modelAndView;
    }

    /**
     * @description: 查询caMainDatagrid
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:27
     */
    @RequestMapping(params = "caMainDatagrid")
    public void caMainDatagrid(CaReconResultInfoVo caReconResultInfoVo, HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.COLLECTION_AGENT_RECONCILIATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            CAReconResultInfoEntity caReconResultInfoEntity = new CAReconResultInfoEntity();
            try {
                MyBeanUtils.copyBeanNotNull2Bean(caReconResultInfoVo, caReconResultInfoEntity);
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
            DataReturn dataReturn = this.caReconService.getCAReconResult(caReconResultInfoEntity,dataGrid.getPage(),dataGrid.getRows(),request);
            dataGrid.setResults(dataReturn.getRows());
            dataGrid.setTotal((int)dataReturn.getTotal());
            TagUtil.datagrid(response, dataGrid);
        }
    }

    /**
     * @description: 查询caAbnList
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:28
     */
    @RequestMapping(params = "caAbnList")
    public void caAbnList(CAReconAbnVo caReconAbnVo, HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.COLLECTION_AGENT_RECONCILIATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            CAReconAbnRecEntity caReconAbnRecEntity = new CAReconAbnRecEntity();
            try {
                MyBeanUtils.copyBeanNotNull2Bean(caReconAbnVo, caReconAbnRecEntity);
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
            DataReturn dataReturn = this.caReconService.getCAReconAbnList(caReconAbnRecEntity,dataGrid.getPage(),dataGrid.getRows(),request);
            dataGrid.setResults(dataReturn.getRows());
            dataGrid.setTotal((int)dataReturn.getTotal());
            TagUtil.datagrid(response, dataGrid);
        }
    }

    /**
     * @description: 查询CaReconApprovalList
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:28
     */
    @RequestMapping(params = "caReconApprovalList")
    public void caReconApprovalList(CAReconAbnVo caReconAbnVo, HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.COLLECTION_AGENT_RECONCILIATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            CAReconAbnRecEntity caReconAbnRecEntity = new CAReconAbnRecEntity();
            try {
                MyBeanUtils.copyBeanNotNull2Bean(caReconAbnVo, caReconAbnRecEntity);
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
            DataReturn dataReturn = this.caReconService.getCaReconApprovalList(caReconAbnRecEntity,dataGrid.getPage(),dataGrid.getRows(),request);
            dataGrid.setResults(dataReturn.getRows());
            dataGrid.setTotal((int)dataReturn.getTotal());
            TagUtil.datagrid(response, dataGrid);
        }
    }

    /**
     * @description: 查询abn详情
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:26
     */
    @RequestMapping(params = "getAbnDetail")
    public void getAbnDetail(CAReconAbnVo caReconAbnVo, HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.COLLECTION_AGENT_RECONCILIATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            CAReconAbnRecEntity caReconAbnRecEntity = new CAReconAbnRecEntity();
            try {
                MyBeanUtils.copyBeanNotNull2Bean(caReconAbnVo, caReconAbnRecEntity);
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
            DataReturn dataReturn = this.caReconService.getCaAbnDetail(caReconAbnRecEntity,dataGrid.getPage(),dataGrid.getRows(),request);
            dataGrid.setResults(dataReturn.getRows());//field=null
            dataGrid.setTotal((int)dataReturn.getTotal());
            TagUtil.datagrid(response, dataGrid);
        }
    }

    /**
     * @description: 申请删除
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:19
     */
    @RequestMapping(params = "doApplyDelete")
    @ResponseBody
    public AjaxJson doApplyDelete(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.COLLECTION_AGENT_RECONCILIATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            String message = "";
            AjaxJson j = new AjaxJson();

            message = this.caReconService.doApplyDelete(request);
            j.setMsg(message);
            return j;
        }
        return null;
    }

    /**
     * @description: 执行审批 删除PPMS表中多出CA的记录
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:19
     */
    @RequestMapping(params = "doApproval")
    @ResponseBody
    public String doApproval(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.COLLECTION_AGENT_RECONCILIATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            String message = "";
            String refNos = request.getParameter("refNos");
            if (oConvertUtils.isEmpty(refNos)){
                message = CAReconConstants.CA_RECON_TIP_MESSAGE.PLEASE_SELECT_ITEM.getMessage();
                return message;
            }
            String[] refNosArray = refNos.split(",");
            String apprStatus = request.getParameter("apprStatus");
            String remark = request.getParameter("remark");
            if (refNosArray.length > 0){
                message = this.caReconService.doApproval(refNosArray,apprStatus,remark);
            }

            return message;
        }
        return null;
    }

    /**
     * @description: 查看详情可下载附件
     * @auther: liangyadong
     * @date: 2018/10/30 0030 下午 2:01
     */
    @RequestMapping(params = "viewApplyFile")
    @ResponseBody
    public ModelAndView viewApplyFile(HttpServletRequest request) {
        CaApprFileEntity caApprFileEntity = this.caReconService.getFilePath(request);
        ModelAndView mv = new ModelAndView("ppms/caReconciliation/ca_recon_apply_file");
        mv.addObject("caApprFileEntity", caApprFileEntity);
        return mv;
    }

//    @RequestMapping("showImage")
//    @ResponseBody
//    public void showImage(HttpServletResponse response) throws Exception{
//        //读取本地图片输入流
//        FileInputStream inputStream = new FileInputStream("D:/upFiles/tianya.jpg");
//        int i = inputStream.available();
//        //byte数组用于存放图片字节数据
//        byte[] buff = new byte[i];
//        inputStream.read(buff);
//        //记得关闭输入流
//        inputStream.close();
//        //设置发送到客户端的响应内容类型
//        response.setContentType("image/*");
//        OutputStream out = response.getOutputStream();
//        out.write(buff);
//        //关闭响应输出流
//        out.close();
//    }

    /**
     * @description: 查询无法匹配的记录 表CA_RECON_ABN_REC
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:20
     */
    @RequestMapping(params = "caAuditList")
    public void caAuditList(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.COLLECTION_AGENT_RECONCILIATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            DataReturn dataReturn = this.caReconService.getCaAuditList(dataGrid.getPage(),dataGrid.getRows(),request);
            dataGrid.setResults(dataReturn.getRows());
            dataGrid.setTotal((int)dataReturn.getTotal());
            TagUtil.datagrid(response, dataGrid);
        }
    }

    /**
     * @description: 导出caAuditList
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:20
     */
    @RequestMapping(params = "exportXls")
    public String exportXls(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid,ModelMap modelMap) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.COLLECTION_AGENT_RECONCILIATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            DataReturn dataReturn = this.caReconService.getCaAuditList(dataGrid.getPage(),dataGrid.getRows(),request);
            String curLoginName = ResourceUtils.getSessionUser().getName();//获得当前登录人的id
            List<CAReconAbnVo> caAuditList = (List<CAReconAbnVo>) dataReturn.getRows();
            modelMap.put(NormalExcelConstants.FILE_NAME,"caAuditList");
            modelMap.put(NormalExcelConstants.CLASS,CAReconAbnVo.class);
            modelMap.put(NormalExcelConstants.PARAMS,new ExportParams("CA Audit List", "Export Auther:"+curLoginName,"Export Information"));
            modelMap.put(NormalExcelConstants.DATA_LIST,caAuditList);
            return NormalExcelConstants.JEECG_EXCEL_VIEW;
        }
        return null;
    }

    /**
     * 查询对账状态
     * @return
     */
   /* private String getSelectCounter(){
        CriteriaQuery cq = new CriteriaQuery(CounterEntity.class);
        cq.eq("status", SiteStatus.ACTIVE.getStatus());
        cq.add();
        List<CounterEntity> counterEntityList = this.dayendReconService.getListByCriteriaQuery(cq, false);
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        if (counterEntityList != null && counterEntityList.size() > 0) {
            for (CounterEntity counterEntity : counterEntityList) {
                Map map = new HashMap();
                String counterCode = counterEntity.getCode();
                String counterName = counterEntity.getName();
                map.put("code",counterCode);
                map.put("name",counterName);
                list.add(map);
            }
        }

        return JSONObject.toJSONString(list);
    }
*/

    /**
     * @description: 查询CA(channelCode和channelName)
     * @auther: liangyadong
     * @date: 2018/9/29 0029 下午 4:20
     */
    private String getCACodeAndName(){
        CriteriaQuery cq = new CriteriaQuery(ChannelEntity.class);
        cq.eq("status", SiteStatus.ACTIVE.getStatus());
        cq.eq("isAuto","02");//02-自动对账
        cq.add();
        List<ChannelEntity> channelEntityList = this.caReconService.getListByCriteriaQuery(cq, false);
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        if (channelEntityList != null && channelEntityList.size() > 0) {
            for (ChannelEntity channelEntity : channelEntityList) {
                Map map = new HashMap();
                String channelCode = channelEntity.getCode();
                String channelName = channelEntity.getName();
                map.put("code",channelCode);
                map.put("name",channelName);
                list.add(map);
            }
        }

        return JSONObject.toJSONString(list);
    }

}
