package com.ppms.customerInfo.service.impl;

import com.constants.AccountStatusEnum;
import com.constants.Constants;
import com.ppms.creditTopup.bean.EBSInterfaceBean;
import com.ppms.creditTopup.bean.TopupConstants;
import com.ppms.creditTopup.dao.TopupDao;
import com.ppms.customerInfo.CustInfoManConstants;
import com.ppms.customerInfo.bean.EBSArrearsInfoBean;
import com.ppms.customerInfo.dao.CustomerManageDao;
import com.ppms.customerInfo.service.CustomerInfoServiceI;
import com.ppms.customerInfo.vo.ClosingDetailVo;
import com.ppms.customerInfo.vo.ResultVo;
import com.ppms.dict.CacheDao;
import com.ppms.entity.*;
import com.ppms.ldapLogin.util.ResourceUtils;
import com.ppms.sms.service.SmsService;
import com.ppms.tstypeQuery.service.TstypeServiceI;
import com.ppms.utils.*;
import com.ppms.vo.CustomerInfoDTO;
import org.apache.commons.httpclient.ConnectTimeoutException;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.common.service.impl.CommonServiceImpl;
import org.jeecgframework.core.extend.datasource.DataSourceType;
import org.jeecgframework.core.util.DateUtils;
import org.jeecgframework.core.util.MyBeanUtils;
import org.jeecgframework.core.util.StringUtil;
import org.jeecgframework.p3.core.util.oConvertUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static java.math.BigDecimal.ZERO;

@Service("customerInfoService")
@DataSourceValue(DataSourceType.dataSource_ppms)
public class CustomerInfoServiceImpl extends CommonServiceImpl implements CustomerInfoServiceI {
    private static final Logger logger = Logger.getLogger(CustomerInfoServiceImpl.class);

    @Autowired
    private CustomerManageDao customerManageDao;
    @Autowired
    private TopupDao topupDao;
    @Autowired
    private TstypeServiceI tstypeService;
    @Autowired
    private SmsService smsService;
    @Autowired
    private CacheDao cacheDao;

    private String batchNoSuffix = "01";

    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ, rollbackForClassName = {"Exception.class"})
    public void saveOrUpdate(CustomerInfoEntity entity) {
        super.save(entity);
    }

    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ, rollbackForClassName = {"Exception.class"})
    public CustomerInfoEntity saveQ(CustomerInfoEntity entity, String id) throws Exception {
        return (CustomerInfoEntity) this.get(CustomerInfoEntity.class, id);
    }

    //自定义查询
    @Override
    public DataReturn getAllEntities(ResultVo resultVo, int page, int rows, HttpServletRequest request) {
        return customerManageDao.getAllEntities(resultVo, page, rows, request);
    }

    //查询客户信息 销户申请主页面
    @Override
    public DataReturn getCustomerInfo(int page, int rows, HttpServletRequest request) {
        return customerManageDao.getCustomerInfo(page, rows, request);
    }

    /*执行销户申请*/
    @Override
    public String goApplyClosing(HttpServletRequest request) {
        String message = "";
        String accNo = request.getParameter("accNo");
        String meterId = request.getParameter("meterId");

        //提交申请记录额外数据
        String sDate = PersDateUtils.getPatternDate(PersDateUtils.FORMAT_FULL_DATE_TIME, new Date());
        Date currentTime = PersDateUtils.str2Date(sDate, PersDateUtils.getSdf(PersDateUtils.FORMAT_FULL_DATE_TIME));
        String readingType = "01";//ODR
        String closingStatus = "01";//applied
        String operationStatus = "01";//创建

        AClosingRecordEntity aClosingRecordEntity = new AClosingRecordEntity();
        aClosingRecordEntity.setAccNo(accNo);
        aClosingRecordEntity.setMeterId(meterId);
        aClosingRecordEntity.setApplyTime(currentTime);
        aClosingRecordEntity.setReadingType(readingType);
        aClosingRecordEntity.setClosingStatus(closingStatus);
        aClosingRecordEntity.setOperationStatus(operationStatus);
        aClosingRecordEntity.setUpdateTime(currentTime);

        try {
            save(aClosingRecordEntity);
            message = CustInfoManConstants.ACCOUNT_CLOSING_APPLY_MESSAGE.ACCOUNT_CLOSING_APPLY_SUCCESS.getMessage();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            message = CustInfoManConstants.ACCOUNT_CLOSING_APPLY_MESSAGE.ACCOUNT_CLOSING_APPLY_FAILED.getMessage();
            return message;
        }

        return message;
    }

    /**
     * 请求EBS接口查询arrearInfo
     *
     * @param accNo
     * @return
     */
    public EBSInterfaceBean getArrearInfoFromEBS(String accNo) {
        Properties properties = PropertiesUtil.readProperties("ebs_interface_url.properties");
        String requestUrl = properties.getProperty("getArrearInfoFromEBSUrl");
        int index = accNo.toUpperCase().indexOf("P");
        if (index > 0)
            accNo = accNo.substring(0, index);
        String requestParamJson = JSONUtils.stringToJsonByFastjson("ACCOUNTNO", accNo);
        try {
//        {"Y_CREDIT_AMNT":"2","Y_OPEN_AMNT":"2","Y_OVERDUE_AMNT":"2"}
            String responseJsonStr = HttpClientUtils.httpRequest(requestUrl, "POST", requestParamJson);
            logger.info("******QUERY ARREARS RESPONSE FROM EBS :[" + responseJsonStr + "]**********");
            if (responseJsonStr != null && !responseJsonStr.equals("")) {
                Map<String, Object> responseMap = JSONUtils.jsonToMap(responseJsonStr);
                if (responseMap != null) {
                    String creditAmnt = responseMap.get("Y_CREDIT_AMNT") + "";
                    String openAmnt = responseMap.get("Y_OPEN_AMNT") + "";
                    String overdueAmnt = responseMap.get("Y_OVERDUE_AMNT") + "";
                    logger.info("---creditAmnt:" + creditAmnt + ",openAmnt:" + openAmnt + ",overdueAmnt:" + overdueAmnt);

                    EBSInterfaceBean ebsInterfaceBean = new EBSInterfaceBean();
                    ebsInterfaceBean.setY_CREDIT_AMNT(creditAmnt);
                    ebsInterfaceBean.setY_OPEN_AMNT(openAmnt);
                    ebsInterfaceBean.setY_OVERDUE_AMNT(overdueAmnt);
                    logger.info("******Account Closing : get Customer Arrear Information from EBS Success*****");
                    return ebsInterfaceBean;
                }
            }
        } catch (ConnectTimeoutException e) {
            String errorMsg = "Account Closing : Connection failed due to timeout.";
            logger.error(errorMsg);
            throw new RuntimeException(errorMsg);
        } catch (IOException e) {
            String errorMsg = "Account Closing : Internal Server Error.";
            logger.error(errorMsg);
            throw new RuntimeException(errorMsg);
        }
        return null;
    }

    //销户申请记录查询
    @Override
    public AClosingRecordEntity getClosingRecord(String accNo) {
        return customerManageDao.getClosingRecord(accNo);
    }

    //销户查看销户详情
    @Override
    public ClosingDetailVo lookClosingDetail(HttpServletRequest request) {
        return customerManageDao.getClosingDetail(request);
    }

    //更新操作增强业务
    private void doUpdateBus(CustomerInfoEntity t) throws Exception {
    }

    //开户
    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ)
    public String accountOpening(CustomerInfoEntity databaseEntity, HttpServletRequest request) {
        String message = "";
        Date date = new Date();
        String curLoginName = ResourceUtils.getSessionUser().getName();
        String accountType = CustInfoManConstants.ACCOUNT_OPENING_TYPE.ACCOUNT_EBS.getType();
        String opening = TopupConstants.TXN_STATUS.ACCOUNT_OPENING.getTxnStatus();
        String reOpening = TopupConstants.TXN_STATUS.ACCOUNT_REOPENING.getTxnStatus();
        String txnStatus = "";
        String openingUpdateFlag = TopupConstants.UPDATE_FLAG.ACCOUNT_OPENING.getUpdateFlag();
        String reOopeningUpdateFlag = TopupConstants.UPDATE_FLAG.ACCOUNT_REOPEN.getUpdateFlag();
        String updateFlag = "";

        BigDecimal arrearAmt = new BigDecimal(0);
        BigDecimal lastBal = new BigDecimal(0);
        BigDecimal presetCredit = new BigDecimal(0);
        BigDecimal gstAmt = new BigDecimal(0);
        BigDecimal grossAmt = new BigDecimal(0);

        //accNo校验
        String accNo = request.getParameter("accNo");//accNo
        if (accNo.equals("")) {
            message = "Cannot obtain account info. Please synchronize from EBS.";
            return message;
        }
        //登录名校验
        if (curLoginName.length() > 64) {
            message = "Current login name is too long, operate failed.";
            return message;
        }
        //校验mac地址(柜台信息是否存在), 已改为ip
        String clientIP = GetClientIPUtil.getIpAddr(request);
        CounterEntity counterInfo = null;
        String counterCode = "";
        int terminalId = 0;
        String terminalCode = "";
        int channelId = 0;
        String channelCode = "";
        try {
            counterInfo = topupDao.getCounterByIP(clientIP);
            if (counterInfo != null) {
                counterCode = counterInfo.getCode();//counterCode
                terminalId = counterInfo.getTerminalEntity().getId();//外键
            } else {
                message = TopupConstants.getTopupMacNotMatch();//库中无该mac地址,counter信息不存在
                return message;
            }
            TerminalEntity terminalInfo = topupDao.getTerminalInfo(terminalId);
            if (terminalInfo != null) {
                terminalCode = terminalInfo.getCode();//terminalCode
                channelId = terminalInfo.getChannelEntity().getId();//外键
            }
            ChannelEntity channelInfo = topupDao.getChannelInfo(channelId);
            if (channelInfo != null) {
                channelCode = channelInfo.getCode();//channelCode
            }
        } catch (Exception e) {
            logger.error("********** account opening : get counter info failed **********" + e);
            message = "account opening : get counter info failed";
            return message;
        }

        CustomerInfoEntity getCustomerEntity = this.get(CustomerInfoEntity.class, accNo);
        if (getCustomerEntity == null) {//从未开过户
            String spresetCredit = request.getParameter("presetCredit");
            presetCredit = new BigDecimal(spresetCredit);
            //GSTAMT , GROSSAMT
            GSTEntity gstEntity = this.cacheDao.getCurrentGst(databaseEntity.getGstCode());
            //gstAmt gst_amt=(prepaid_amt/1+gst rate)*gst rate
            BigDecimal tempAmt = presetCredit.divide(new BigDecimal(1).add(gstEntity.getRate()), 8, BigDecimal.ROUND_DOWN);
            gstAmt = tempAmt.multiply(gstEntity.getRate()).setScale(8, BigDecimal.ROUND_DOWN);
            // grossAmt gross_amt= prepaid_amt-gst_amt
            grossAmt = presetCredit.subtract(gstAmt);

            /**
             * A_CUSTOMER_INFO
             */
            saveCustomerInfo(databaseEntity, date, accountType);

            txnStatus = opening;

            updateFlag = openingUpdateFlag;

        } else if (getCustomerEntity != null && getCustomerEntity.getAccountStatus().equals(AccountStatusEnum.CLOSED.getStatus())) {
            try {
                MyBeanUtils.copyBeanNotNull2Bean(databaseEntity, getCustomerEntity);
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
            getCustomerEntity.setPresetCredit(presetCredit);
            getCustomerEntity.setInstallationNumber(null);
            getCustomerEntity.setSalutation(null);
            getCustomerEntity.setActivationDate(null);
            getCustomerEntity.setCloseDate(null);
            getCustomerEntity.setInitReads(null);
            getCustomerEntity.setFinalReads(null);
            getCustomerEntity.setEbsActivationNotify(null);
            /**
             * A_CUSTOMER_INFO
             */
            //super.getSession().evict(databaseEntity);
            saveCustomerInfo(getCustomerEntity, date, accountType);

            txnStatus = reOpening;

            updateFlag = reOopeningUpdateFlag;

        } else {//账户已存在,拒绝重复开户
            return CustInfoManConstants.OPENING_TIP_MESSAGE.OPENING_ALREADY_EXIST.getMessage();
        }
        try {
            /**
             * 保存SP_TOPUP_REC
             */
            String refNo = getRefNo(clientIP);//生成流水号refNo
            String message1 = refNoCheck(refNo);
            if (message1 != null) return message1;
            SpTopUpRecEntity topupRecordEntity = saveSpTopupRec(txnStatus, date, presetCredit, curLoginName, arrearAmt, lastBal, gstAmt, grossAmt, accNo, counterCode, terminalCode, channelCode, refNo);
            /**
             * A_BALANCE_REC
             */
            saveBalanceRec(updateFlag, date, curLoginName, presetCredit, lastBal, accNo, getCustomerEntity, topupRecordEntity);
            /**
             * A_ACCT_BAL
             */
            saveAccountBalance(accNo, presetCredit, date);
            /**
             * A_ACCOUNT_LOGINFO
             */
            saveAccountLoginfo(curLoginName, accNo, counterCode, terminalCode);
            message = CustInfoManConstants.OPENING_TIP_MESSAGE.OPENING_SUCCESS.getMessage();//开户成功
        } catch (Exception e) {
            message = CustInfoManConstants.OPENING_TIP_MESSAGE.OPENING_FAILURE.getMessage();//开户失败
            logger.error("********** account opening : account opening failed **********" + e);
            return message;
        }

        return message;
    }

    private SpTopUpRecEntity saveSpTopupRec(String txnStatus, Date date, BigDecimal presetCredit, String curLoginName, BigDecimal arrearAmt, BigDecimal lastBal, BigDecimal gstAmt, BigDecimal grossAmt, String accNo, String counterCode, String terminalCode, String channelCode, String refNo) {
        String patternDate = PersDateUtils.getPatternDate(PersDateUtils.FORMAT_DATE_NONE, date);
        String batchNo = patternDate + batchNoSuffix;//批次号
        SpTopUpRecEntity topupRecordEntity = new SpTopUpRecEntity();
        topupRecordEntity.setAccNo(accNo);//账户号
        topupRecordEntity.setTxnDate(date);//交易日期
        topupRecordEntity.setBatchNo(batchNo);//批次号
        topupRecordEntity.setTopupAmt(presetCredit);//充值金额
        topupRecordEntity.setArrearAmt(arrearAmt);//赠费不扣除arrears
        topupRecordEntity.setPayMode(TopupConstants.PAYMENT_MODE.OPENING_PREST_CREDIT.getPaymentMode());//充值类型90 - 系统开户赠费preset credit
        topupRecordEntity.setPrepaidAmt(presetCredit);//开户赠费全部充值为prepaidAmt
        topupRecordEntity.setLastBal(lastBal);//开户充值前金额为0
        topupRecordEntity.setCurBal(presetCredit);//当前余额即预置金额
        topupRecordEntity.setCounterId(counterCode);//counterCode
        topupRecordEntity.setTmnlCode(terminalCode);//terminalCode
        topupRecordEntity.setChannelCode(channelCode);//channelCode
        topupRecordEntity.setCashierId(curLoginName);//操作员用户名
        topupRecordEntity.setReconStatus(TopupConstants.RECON_STATUS.UNRECON.getReconStatus());//对账状态
        topupRecordEntity.setGstAmt(gstAmt);
        topupRecordEntity.setGrosssAmt(grossAmt);
        topupRecordEntity.setRefNo(refNo);//充值记录主键不允许为空
        topupRecordEntity.setTxnStatus(txnStatus);//交易类型
        super.save(topupRecordEntity);
        return topupRecordEntity;
    }

    private String refNoCheck(String refNo) {
        String message;
        if (refNo.equals("")) {
            message = "Generate referenceNumber failed.";
            return message;
        }
        return null;
    }

    private void saveCustomerInfo(CustomerInfoEntity databaseEntity, Date date, String accountType) {
        databaseEntity.setOpenDate(date);//开户日期
        databaseEntity.setAccountStatus(CustInfoManConstants.ACCOUNT_STATUS.ACCOUNT_OPENING.getStatus());//账户状态
        databaseEntity.setType(accountType);//账户类型EBS与PAYU不同
        //查询holidayList
        List holidayList = getHolidayList();
        //获取计划激活日期
        Date activeDate = null;
        try {
            activeDate = HolidayUtils.getScheduleActiveDate(date, holidayList, 10);
            String sscheduleDate = PersDateUtils.getSdf(PersDateUtils.FORMAT_DATE_SPLIT).format(activeDate);
            Date scheduleActiveDate = PersDateUtils.getSdf(PersDateUtils.FORMAT_DATE_SPLIT).parse(sscheduleDate);//YYYY-MM-DD
            databaseEntity.setSheduledActivationDate(scheduleActiveDate);
            databaseEntity.setPrintCardTimes(0);//刚开户打印次数为0,点击打印电卡后打印次数改为1,当为1时不允许再在此页面打印电卡
            databaseEntity.setName("");
            databaseEntity.setNric("");
            super.save(databaseEntity);
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
        }
    }

    //payu开户 保存档案信息
    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ, rollbackForClassName = {"Exception.class"})
    public String payuAccountOpening(CustomerInfoEntity databaseEntity, HttpServletRequest request) {
        String message = "";
        Date date = new Date();
        String curLoginName = ResourceUtils.getSessionUser().getName();
        String accountType = CustInfoManConstants.ACCOUNT_OPENING_TYPE.ACCOUNT_PAYU.getType();
        String opening = TopupConstants.TXN_STATUS.ACCOUNT_OPENING.getTxnStatus();
        String reOpening = TopupConstants.TXN_STATUS.ACCOUNT_REOPENING.getTxnStatus();
        String txnStatus = "";
        String payuOpeningUpdateFlag = TopupConstants.UPDATE_FLAG.ACCOUNT_PAYU_CONVERT.getUpdateFlag();
        String reOopeningUpdateFlag = TopupConstants.UPDATE_FLAG.ACCOUNT_REOPEN.getUpdateFlag();
        String updateFlag = "";

        BigDecimal presetCredit = new BigDecimal(0);
        BigDecimal arrearAmt = new BigDecimal(0);
        BigDecimal lastBal = new BigDecimal(0);
        BigDecimal gstAmt = new BigDecimal(0);
        BigDecimal grossAmt = new BigDecimal(0);

        //校验前台传来的accNo是否为空
        String accNo = request.getParameter("accNo");//accNo
        if (accNo.equals("")) {
            message = "Cannot obtain account info. Please synchronize from EBS.";
            return message;
        }
        //登录名校验
        if (curLoginName.length() > 64) {
            message = "Current login name is too long, operate failed.";
            return message;
        }
        //校验mac地址(柜台信息是否存在),改为ip
        String clientIP = GetClientIPUtil.getIpAddr(request);
        CounterEntity counterInfo = null;
        String counterCode = "";
        int terminalId = 0;
        String terminalCode = "";
        int channelId = 0;
        String channelCode = "";
        try {
            counterInfo = topupDao.getCounterByIP(clientIP);
            if (counterInfo != null) {
                counterCode = counterInfo.getCode();//counterCode
                terminalId = counterInfo.getTerminalEntity().getId();//外键
            } else {
                message = TopupConstants.getTopupMacNotMatch();//库中无该mac地址,counter信息不存在
                return message;
            }
            TerminalEntity terminalInfo = topupDao.getTerminalInfo(terminalId);
            if (terminalInfo != null) {
                terminalCode = terminalInfo.getCode();//terminalCode
                channelId = terminalInfo.getChannelEntity().getId();//外键
            }
            ChannelEntity channelInfo = topupDao.getChannelInfo(channelId);
            if (channelInfo != null) {
                channelCode = channelInfo.getCode();//channelCode
            }
        } catch (Exception e) {
            logger.error("********** account opening : get counter info failed **********" + e);
            message = "account opening : get counter info failed";
            return message;
        }

        CustomerInfoEntity getCustomerEntity = this.get(CustomerInfoEntity.class, accNo);
        if (getCustomerEntity == null) {//从未开过户
            /**
             * A_CUSTOMER_INFO
             */
            saveCustomerInfo(databaseEntity, date, accountType);

            txnStatus = opening;

            updateFlag = payuOpeningUpdateFlag;

        } else if (getCustomerEntity != null && getCustomerEntity.getAccountStatus().equals(AccountStatusEnum.CLOSED.getStatus())) {
            try {
                MyBeanUtils.copyBeanNotNull2Bean(databaseEntity, getCustomerEntity);
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
            getCustomerEntity.setPresetCredit(presetCredit);
            getCustomerEntity.setInstallationNumber(null);
            getCustomerEntity.setSalutation(null);
            getCustomerEntity.setActivationDate(null);
            getCustomerEntity.setCloseDate(null);
            getCustomerEntity.setInitReads(null);
            getCustomerEntity.setFinalReads(null);
            getCustomerEntity.setEbsActivationNotify(null);
            /**
             * A_CUSTOMER_INFO
             */
            //super.getSession().evict(databaseEntity);
            saveCustomerInfo(getCustomerEntity, date, accountType);

            txnStatus = reOpening;

            updateFlag = reOopeningUpdateFlag;

        } else {
            return CustInfoManConstants.OPENING_TIP_MESSAGE.OPENING_ALREADY_EXIST.getMessage();//账户已存在,拒绝重复开户
        }
        try {
            /**
             * SP_TOPUP_REC
             */
            String refNo = getRefNo(clientIP);//生成流水号refNo
            String message1 = refNoCheck(refNo);
            if (message1 != null) return message1;
            SpTopUpRecEntity topupRecordEntity = saveSpTopupRec(txnStatus, date, presetCredit, curLoginName, arrearAmt, lastBal, gstAmt, grossAmt, accNo, counterCode, terminalCode, channelCode, refNo);
            /**
             * A_BALANCE_REC
             */
            saveBalanceRec(updateFlag, date, curLoginName, presetCredit, lastBal, accNo, getCustomerEntity, topupRecordEntity);
            /**
             * A_ACCT_BAL
             */
            saveAccountBalance(accNo, presetCredit, date);
            /**
             * A_ACCOUNT_LOGINFO
             */
            saveAccountLoginfo(curLoginName, accNo, counterCode, terminalCode);

            message = CustInfoManConstants.OPENING_TIP_MESSAGE.OPENING_SUCCESS.getMessage();//开户成功
        } catch (Exception e) {
            message = CustInfoManConstants.OPENING_TIP_MESSAGE.OPENING_FAILURE.getMessage();//开户失败
            logger.error("********** account opening : account opening failed **********" + e);
            return message;
        }

        return message;
    }

    private void saveBalanceRec(String updateFlag, Date date, String curLoginName, BigDecimal presetCredit, BigDecimal lastBal, String accNo, CustomerInfoEntity getCustomerEntity, SpTopUpRecEntity topupRecordEntity) {
        BalanceRecEntity balanceRecEntity = new BalanceRecEntity();
        balanceRecEntity.setUpdateTime(date);//更新日期即开户日期
        balanceRecEntity.setAccNo(accNo);//账户号
        balanceRecEntity.setUpdateFlag(updateFlag);
        balanceRecEntity.setTxnNo(accNo);//交易号 新开户为accNo
        balanceRecEntity.setLastBal(lastBal);//上次余额
        balanceRecEntity.setCurBal(presetCredit);//当前余额
        balanceRecEntity.setOperId(curLoginName);//当前登录用户名
        //生成短信
        try {
            String smsNo = this.generateSmsRec(topupRecordEntity, getCustomerEntity);
            if (!(StringUtil.isEmpty(smsNo) && Integer.valueOf(smsNo) > 0)) {
                balanceRecEntity.setSmsNo(smsNo);
            }
        } catch (Exception e) {
            logger.error("********生成短信记录失败" + e.getMessage(), e);
        }
        super.save(balanceRecEntity);
    }

    private void saveAccountBalance(String accNo, BigDecimal presetCredit, Date date) {
        AcctBalEntity acctBalEntity = this.get(AcctBalEntity.class, accNo);
        if (acctBalEntity == null) {
            acctBalEntity = new AcctBalEntity();
            acctBalEntity.setAccNo(accNo);
        }
        acctBalEntity.setBalance(presetCredit);
        acctBalEntity.setUpdateTime(date);

        super.save(acctBalEntity);
    }

    private void saveAccountLoginfo(String curLoginName, String accNo, String counterCode, String terminalCode) {
        AccountLogInfoEntity accountLogInfoEntity = new AccountLogInfoEntity();
        accountLogInfoEntity.setAccNo(accNo);
        accountLogInfoEntity.setOperId(curLoginName);
        accountLogInfoEntity.setCounterId(counterCode);
        accountLogInfoEntity.setTmnlCode(terminalCode);
        accountLogInfoEntity.setType(CustInfoManConstants.ACCOUNT_TYPE.ACCOUNT_OPENING.getType());
        super.saveOrUpdate(accountLogInfoEntity);
    }

    //查询jeecg库
    @Override
    @DataSourceValue(DataSourceType.dataSource_jeecg)
    public List getTstTypeList(CriteriaQuery cq) {
        return super.getListByCriteriaQuery(cq, false);
    }

    //账户激活-修改档案信息
    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ, rollbackForClassName = {"Exception.class"})
    public String doUpdateCustomerEntity(CustomerInfoEntity customerInfoEntity, HttpServletRequest request) {
        String curLoginName = ResourceUtils.getSessionUser().getName();
        Date date = new Date();
        String message = "";
        BigDecimal balance = new BigDecimal(0);
        String sbalance = request.getParameter("balance");
        if (!sbalance.equals("")) {
            balance = new BigDecimal(sbalance);
        }
        try {
            Date sheduledActivationDate = customerInfoEntity.getSheduledActivationDate();
            CustomerInfoEntity databaseEntity = this.get(CustomerInfoEntity.class, customerInfoEntity.getAccNo());
            databaseEntity.setSheduledActivationDate(sheduledActivationDate);
            AcctBalEntity accttBalEntity = this.get(AcctBalEntity.class, customerInfoEntity.getAccNo());
            accttBalEntity.setBalance(balance);
            accttBalEntity.setUpdateTime(date);
            super.getSession().evict(customerInfoEntity);
            super.save(databaseEntity);//客户信息
            super.save(accttBalEntity);//最新余额

            BalanceRecEntity balanceRecEntity = new BalanceRecEntity();
            balanceRecEntity.setAccNo(customerInfoEntity.getAccNo());
            balanceRecEntity.setOperId(curLoginName);
            balanceRecEntity.setUpdateFlag(CustInfoManConstants.UPDATE_FLAG.ACCOUNT_OPENING_PAYU.getUpdateFlag());
            balanceRecEntity.setTxnNo(customerInfoEntity.getAccNo());
            balanceRecEntity.setUpdateTime(date);
            balanceRecEntity.setLastBal(new BigDecimal(0));
            balanceRecEntity.setCurBal(balance);
            super.save(balanceRecEntity);//余额变更记录

            message = CustInfoManConstants.SAVE_ACCOUNT_INFO.SAVE_ACCOUNT_INFO_SUCCESS.getMessage();
        } catch (Exception e) {
            logger.error(e);
            message = CustInfoManConstants.SAVE_ACCOUNT_INFO.SAVE_ACCOUNT_INFO_FAILED.getMessage();
            return message;
        }

        return message;
    }

    /**
     * 当前日期加上天数后的日期
     *
     * @param num 为增加的天数
     * @return
     */
    public Date plusDay(int num) {
        Date d = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Calendar ca = Calendar.getInstance();
        ca.add(Calendar.DATE, num);// num为增加的天数,可变
        d = ca.getTime();
        String enddate = format.format(d);

        Date plusDate = new Date();
        try {
            plusDate = format.parse(enddate);
        } catch (ParseException e) {
            logger.info(e);
        }
        return plusDate;
    }

    //生成refNo,改为通过ip查询counter信息
    public String getRefNo(String clientIP) {
        //获取交易日期时间
        Date date = PersDateUtils.getDate();
        String sFullTime = PersDateUtils.getPatternDate(PersDateUtils.FORMAT_FULL_DATE_TIME, date);//yyyyMMddHHmmssSSS
        // 获取当前登录的MAC地址并校验
        String counterCode = "";
        Integer terminalId = 0;
        String terminalCode = "";
        Integer channelId = 0;
        String channelCode = "";
        try {
            CounterEntity counterInfo = topupDao.getCounterByIP(clientIP);

            if (counterInfo != null) {
                counterCode = counterInfo.getCode();//counterCode
                terminalId = counterInfo.getTerminalEntity().getId();//外键
            }
            TerminalEntity terminalInfo = topupDao.getTerminalInfo(terminalId);
            if (terminalInfo != null) {
                terminalCode = terminalInfo.getCode();//terminalCode
                channelId = terminalInfo.getChannelEntity().getId();//外键
            }
            ChannelEntity channelInfo = topupDao.getChannelInfo(channelId);
            if (channelInfo != null) {
                channelCode = channelInfo.getCode();//channelCode
            }
        } catch (Exception e) {
            logger.error("=========获取counter/terminal/channel信息失败=========" + e);
            return sFullTime;
        }
        //生成refNo = channelCode + terminalCode + counterCode + sFullTime
        String refNo = channelCode + terminalCode + counterCode + sFullTime;

        return refNo;
    }

    //查询holiday列表
    public List getHolidayList() {
        List holidayList = new ArrayList();
        List<HolidayInfoEntity> list = customerManageDao.getHolidayList();
        if (list != null && list.size() > 0) {
            for (HolidayInfoEntity holidayInfoEntity : list) {
                Date startTime = holidayInfoEntity.getStartTime();
                Date endTime = holidayInfoEntity.getEndTime();

                SimpleDateFormat sdf = PersDateUtils.getSdf(PersDateUtils.FORMAT_DATE_SPLIT);
                String sstartTime = sdf.format(startTime);
                String sendTime = sdf.format(endTime);

                Date tomorrow = HolidayUtils.getTomorrow(startTime);
                if (!sstartTime.equals(sendTime)) {
                    holidayList.add(sstartTime);
                    while (!sdf.format(tomorrow).equals(sendTime)) {
                        tomorrow = HolidayUtils.getTomorrow(startTime);
                        holidayList.add(sdf.format(tomorrow));
                        startTime = tomorrow;
                    }
                    holidayList.add(sendTime);//测试后新加的,否则边界日期会漏掉(逻辑不严谨)
                } else {
                    holidayList.add(sstartTime);
                }
            }
        }

        return holidayList;
    }

    //查询tariffcode
    @Override
    public List getTarifCode(Date date) {
        List tariffList = customerManageDao.getTariffInfo(new Date());
        List<String> list = new ArrayList();
        if (tariffList != null && tariffList.size() > 0) {
            for (int i = 0; i < tariffList.size(); i++) {
                Map<String, Object> map = new HashMap();
                Object[] obj = (Object[]) tariffList.get(i);
                map.put("code", obj[0] == null ? "" : obj[0].toString());
                list.add(obj[0] == null ? "" : obj[0].toString());
            }
        }

        return list;
    }

    //由tariffCode查询tariffrate
    @Override
    public String getTariffInfoGroupByCode(Date date, String tariffCode) {
        List tariffList = customerManageDao.getTariffInfo(new Date());
        String tariffRate = "";
        List<Map<String, Object>> list = new ArrayList();
        if (tariffList != null && tariffList.size() > 0) {
            for (int i = 0; i < tariffList.size(); i++) {
                Map<String, Object> map = new HashMap();
                Object[] obj = (Object[]) tariffList.get(i);
                map.put("code", obj[0] == null ? "" : obj[0].toString());
                map.put("rate", obj[1] == null ? "" : obj[1]);
                list.add(map);//多余
                if (tariffCode.equals(obj[0] == null ? "" : obj[0].toString())) {
                    tariffRate = obj[1] == null ? "" : obj[1].toString();
                }
            }
        }

        return tariffRate;
    }

    //查询gst code和value
    @Override
    public List getGstCodeAndValue(Date date) {
        List gstList = customerManageDao.getGstInfo(new Date());
        List<Map<String, Object>> list = new ArrayList();
        if (gstList != null && gstList.size() > 0) {
            for (int i = 0; i < gstList.size(); i++) {
                Map<String, Object> map = new HashMap();
                Object[] obj = (Object[]) gstList.get(i);
                map.put("code", obj[0] == null ? "" : obj[0].toString());
                map.put("rate", obj[1] == null ? "" : new BigDecimal(obj[1].toString()).multiply(new BigDecimal(100)));//转为*100的值
                list.add(map);
            }
        }

        return list;
    }

    //generateTariffList
    @Override
    @DataSourceValue(DataSourceType.dataSource_jeecg)
    public List generateTariffList(List list) {
        List<Map<String, Object>> tariffList = new ArrayList();
        //查询字典表,根据groupId查询code和name的列表,遍历该列表,根据传入的tariffcode查name
        List<Map<String, Object>> mapList = tstypeService.getTypeCodeAndNameByGroupId(tstypeService.getGroupIdByGroupCode("TARIFF"));
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                Map<String, Object> map = new HashMap();
                String tariffCode = list.get(i).toString();
                if (mapList != null && mapList.size() > 0) {
                    for (int j = 0; j < mapList.size(); j++) {
                        Map<String, Object> stringObjectMap = mapList.get(j);
                        String code = stringObjectMap.get("code").toString();
                        if (code.equals(tariffCode)) {
                            String tariffName = stringObjectMap.get("name").toString();
                            map.put("code", code);//tariffCode
                            map.put("name", tariffName);//tariffName
                            tariffList.add(map);
                        }
                    }
                }

            }
        }
        return tariffList;
    }

    private String generateSmsRec(SpTopUpRecEntity topupRecordEntity, CustomerInfoEntity customerInfoEntity) {
        StringBuffer stringBuffer = new StringBuffer();
        String smsId = "";
        //生成缴费短信
        smsId = generateAccountOpeningSmsRec(topupRecordEntity);
        stringBuffer.append(smsId).append(Constants.COMMA);
        return stringBuffer.toString();
    }

    private String generateAccountOpeningSmsRec(SpTopUpRecEntity topupRecordEntity) {
        Map<String, String> smsParams = new HashMap<String, String>();
        String smsType = Constants.SMS_TYPE.ACCOUNT_OPENING.getType();
        //AccountNo, OpenDate,
        String accountNo = topupRecordEntity.getAccNo();
        String openDate = DateUtils.formatDate(topupRecordEntity.getTxnDate(), Constants.DD_MM_YYYY_HH_MM_SS_DOT);
        smsParams.put(Constants.SMS_TEMPLATE_PARAMS.ACCOUNT_NO.getValue(), accountNo);
        smsParams.put(Constants.SMS_TEMPLATE_PARAMS.OPEN_DATE.getValue(), openDate);
        return this.smsService.generateSmsRecord(accountNo, smsType, smsParams);
    }

    /**
     * @param dataGrid
     * @author shenchen
     */
    @Override
    public void queryCustomerForCreditTransfer(String accno, DataGrid dataGrid) {
        CriteriaQuery cq = new CriteriaQuery(CustomerInfoEntity.class, dataGrid);
        if (oConvertUtils.isNotEmpty(dataGrid.getSqlbuilder())) {
            if (dataGrid.getSqlbuilder().indexOf("≤") > 0) {
                dataGrid.setSqlbuilder(dataGrid.getSqlbuilder().replace("≤", "<="));
            }
        }
        if (oConvertUtils.isNotEmpty(accno)) {
            if (accno.length() == 11) {
                cq.eq("accNo", accno);
            } else if(accno.length() == 10) {
                cq.eq("accNo", accno + "P");
            }
        }
//        cq.eq("type", CustInfoManConstants.ACCOUNT_OPENING_TYPE.ACCOUNT_EBS.getType());
        cq.eq("accountStatus", AccountStatusEnum.ACTIVATED.getStatus());
        cq.add();
        super.getDataGridReturn(cq, true);
        //对手机号进行xxx处理
        List<CustomerInfoDTO> dtoList = new ArrayList<>();
        if (null != dataGrid.getResults() && dataGrid.getResults().size() > 0) {
            List<CustomerInfoEntity> customerInfoEntityList = dataGrid.getResults();
            for (CustomerInfoEntity customerInfoEntity : customerInfoEntityList) {
                CustomerInfoDTO dto = new CustomerInfoDTO();
//                String mobileNum = customerInfoEntity.getMobileNumber();
//                if (oConvertUtils.isNotEmpty(mobileNum)) {
//                    dto.setMobileNumber(ResourceUtils.encryptPhoneNumber(mobileNum));
//                }
                Set<MeterInfoEntity> meterInfoEntitySet = customerInfoEntity.getMeterInfoEntitySet().stream().filter(meterInfoEntity -> Constants.METER_STATUS.RUN.getStatus().equals(meterInfoEntity.getMeterStatus())).collect(Collectors.toSet());
                if (meterInfoEntitySet != null && meterInfoEntitySet.size() > 0) {
                    MeterInfoEntity entity = (MeterInfoEntity) meterInfoEntitySet.toArray()[0];
                    dto.setMeterId(entity.getMeterId() + "");
                }
                dto.setBalance(customerInfoEntity.getAcctBalEntity().getBalance().setScale(2, BigDecimal.ROUND_DOWN).toString());
                try {
                    MyBeanUtils.copyBeanNotNull2Bean(customerInfoEntity, dto);
                } catch (Exception e) {
                    logger.error(e);
                }
                dtoList.add(dto);
            }
        }
        dataGrid.setResults(dtoList);
    }

    @Override
    public void queryCustomerInfoForActivation(HttpServletRequest request, DataGrid dataGrid, String accountType) {
        customerManageDao.queryCustomerInfoForActivation(request, dataGrid, accountType);
        List list = dataGrid.getResults();
        List resultList = new ArrayList();
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                ResultVo resultVo = new ResultVo();
                Object[] objects = (Object[]) list.get(i);
                resultVo.setAccNo(oConvertUtils.isEmpty(objects[0]) ? "--" : objects[0].toString());
                resultVo.setSheduledActivationDate((Date) objects[1]);
                resultVo.setAccountStatus(oConvertUtils.isEmpty(objects[2]) ? "--" : objects[2].toString());
                resultVo.setMeterId(oConvertUtils.isEmpty(objects[3]) ? "--" : objects[3].toString());
                resultVo.setAddress(oConvertUtils.isEmpty(objects[4]) ? "--" : objects[4].toString());
                resultList.add(resultVo);
            }
        }
        dataGrid.setResults(resultList);
    }

    @Override
    public EBSArrearsInfoBean EBSArrearsInfo(HttpServletRequest request) {
        String accNo = request.getParameter("accNo");
        EBSInterfaceBean arrearInfoFromEBS = getArrearInfoFromEBS(accNo);
        EBSArrearsInfoBean ebsArrearsInfoBean = new EBSArrearsInfoBean();
        ebsArrearsInfoBean.setAccNo(accNo);
        if (oConvertUtils.isNotEmpty(arrearInfoFromEBS)) {
            String y_open_amnt = arrearInfoFromEBS.getY_OPEN_AMNT();
            String y_overdue_amnt = arrearInfoFromEBS.getY_OVERDUE_AMNT();
            String y_credit_amnt = arrearInfoFromEBS.getY_CREDIT_AMNT();
            ebsArrearsInfoBean.setOpenAmt(oConvertUtils.isEmpty(y_open_amnt) ? "" : new BigDecimal(y_open_amnt).setScale(2, BigDecimal.ROUND_DOWN).toString());
            ebsArrearsInfoBean.setOverdueAmt(oConvertUtils.isEmpty(y_overdue_amnt) ? "" : new BigDecimal(y_overdue_amnt).setScale(2, BigDecimal.ROUND_DOWN).toString());
            ebsArrearsInfoBean.setCreditAmt(oConvertUtils.isEmpty(y_credit_amnt) ? "" : new BigDecimal(y_credit_amnt).setScale(2, BigDecimal.ROUND_DOWN).toString());
        }

        return ebsArrearsInfoBean;
    }

    /*校验账户是否已存在系统中,并且是否从未打印过*/
    @Override
    public boolean validPrintCardTimes(String accno) {
        CustomerInfoEntity entity = this.getEntity(CustomerInfoEntity.class, accno);
        if (oConvertUtils.isNotEmpty(entity)) {
            Integer printCardTimes = entity.getPrintCardTimes();
            if (oConvertUtils.isEmpty(printCardTimes) || printCardTimes < 1) {
                return true;
            }
        }
        return false;
    }

    /*保存电卡打印次数*/
    @Override
    public void updatePrintCardTimes(String accno) {
        CustomerInfoEntity entity = this.getEntity(CustomerInfoEntity.class, accno);
        if (oConvertUtils.isNotEmpty(entity)) {
            entity.setPrintCardTimes(1);
            super.save(entity);
        }
    }
}