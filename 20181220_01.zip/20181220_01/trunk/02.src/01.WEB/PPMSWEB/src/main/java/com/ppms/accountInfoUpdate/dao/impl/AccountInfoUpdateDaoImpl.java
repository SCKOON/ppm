package com.ppms.accountInfoUpdate.dao.impl;

import com.ppms.accountInfoUpdate.dao.AccountInfoUpdateDaoI;
import org.hibernate.Query;
import org.jeecgframework.core.common.dao.impl.GenericBaseCommonDao;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.stereotype.Repository;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Auther: liangyadong
 * @Date: 2018/11/19 0019 17:17
 * @Description:
 */
@Repository
public class AccountInfoUpdateDaoImpl extends GenericBaseCommonDao implements AccountInfoUpdateDaoI {

    @Override
    public void queryInfoForUpdateMobilephone(HttpServletRequest request, DataGrid dataGrid) {
        StringBuilder sql = new StringBuilder(
                " SELECT " +
                " a.acc_no, " +
                " a.telephone_number, " +
                " a.account_status, " +
                " a.address, " +
                " m.meter_id " +
                " FROM " +
                " A_CUSTOMER_INFO a " +
                " LEFT JOIN A_METER_INFO m ON a.acc_no = m.acc_no " +
                " WHERE " +
                " 1 = 1 "
        );

        StringBuilder condition = new StringBuilder();
        Map<String, String> map = new HashMap();
        String accNo = request.getParameter("accNo");
        if (oConvertUtils.isNotEmpty(accNo)) {
            condition.append(" and a.acc_no = :accNo ");
            map.put("accNo", accNo);
        }

        String telephoneNumber = request.getParameter("telephoneNumber");
        if (oConvertUtils.isNotEmpty(telephoneNumber)) {
            condition.append(" and a.telephone_number = :telephoneNumber ");
            map.put("telephoneNumber", telephoneNumber);
        }

        String sqlQuery = sql.append(condition).toString();
        Query query = getSession().createSQLQuery(sqlQuery);
        query.setProperties(map);

        List list = query.list();

        super.paginateDataGrid(list, dataGrid, query);
    }

    @Override
    public void queryInfoForUpdatePercentage(HttpServletRequest request, DataGrid dataGrid) {
        StringBuilder sql = new StringBuilder(
               " SELECT " +
               " a.acc_no, " +
               " a.telephone_number, " +
               " a.account_status, " +
               " a.arrear_pct, " +
               " m.meter_id, " +
               " a.address " +
               " FROM " +
               " A_CUSTOMER_INFO a " +
               " LEFT JOIN A_METER_INFO m ON a.acc_no = m.acc_no " +
               " WHERE " +
               " 1 = 1 "
        );

        StringBuilder condition = new StringBuilder();
        Map<String, String> map = new HashMap();
        String accNo = request.getParameter("accNo");
        if (oConvertUtils.isNotEmpty(accNo)) {
            condition.append(" and a.acc_no = :accNo ");
            map.put("accNo", accNo);
        }

        String sqlQuery = sql.append(condition).toString();
        Query query = getSession().createSQLQuery(sqlQuery);
        query.setProperties(map);

        List list = query.list();

        super.paginateDataGrid(list, dataGrid, query);
    }

    @Override
    public void queryInfoForUpdateAccountStatus(HttpServletRequest request, DataGrid dataGrid) {
        StringBuilder sql = new StringBuilder(
               " SELECT " +
               " a.acc_no, " +
               " a.telephone_number, " +
               " a.account_status, " +
               " m.meter_id, " +
               " m.z3_notif_no, " +
               " a.open_date, " +
               " a.activation_date, " +
               " a.address " +
               " FROM " +
               " A_CUSTOMER_INFO a " +
               " LEFT JOIN A_METER_INFO m ON a.acc_no = m.acc_no " +
               " WHERE " +
               " 1 = 1 "
        );

        StringBuilder condition = new StringBuilder();
        Map<String, String> map = new HashMap();
        String accNo = request.getParameter("accNo");
        if (oConvertUtils.isNotEmpty(accNo)) {
            condition.append(" and a.acc_no = :accNo ");
            map.put("accNo", accNo);
        }

        String sqlQuery = sql.append(condition).toString();
        Query query = getSession().createSQLQuery(sqlQuery);
        query.setProperties(map);

        List list = query.list();

        super.paginateDataGrid(list, dataGrid, query);
    }
}
