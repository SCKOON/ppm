package com.ppms.meterEventQuery.controller;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.constants.Constants;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.jeecgframework.web.system.service.SystemService;


import com.ppms.meterEventQuery.service.MeterEventServiceI;
import com.ppms.vo.MeterEventResultVo;
import com.ppms.utils.DataReturn;


import javax.validation.Validator;


/**   
 * @Title: Controller
 * @Description: M_METER_EVENT
 * @author zhangdaihao
 * @date 2018-06-20 09:03:50
 * @version V1.0   
 *
 */
@Controller
@RequestMapping("/meterEventController")
public class MeterEventController extends BaseController {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = Logger.getLogger(MeterEventController.class);

	@Autowired
	private MeterEventServiceI meterEventService;
	@Autowired
	private SystemService systemService;

	/**
	 * M_METER_EVENT列表 页面跳转
	 * 
	 * @return
	 */
	@RequestMapping(params = "list")
	public ModelAndView list(HttpServletRequest request) {
		return new ModelAndView("ppms/meterEventQuery/meterEventList");
	}

	/**
	 * easyui AJAX请求数据
	 * 
	 * @param request
	 * @param response
	 * @param dataGrid
	 * @param
	 */
	@RequestMapping(params = "datagrid")
	public void datagrid(MeterEventResultVo resultVo,HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
		try{
			if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.METER_EVENT_INFORMATION.getStatus())){
				request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
			}else{
				DataReturn dataReturn;
				try {
					dataReturn = this.meterEventService.getAllEntities(resultVo,dataGrid.getPage(),dataGrid.getRows(),request);
					dataGrid.setResults(dataReturn.getRows());
					dataGrid.setTotal((int)dataReturn.getTotal());
				} catch (ParseException e) {
					logger.error(e.getMessage(),e);
				}
				TagUtil.datagrid(response, dataGrid);
			}
		}catch (Exception e){
			logger.error(e.getMessage(),e);
		}

	}
	
	
	
}