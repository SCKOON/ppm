package com.ppms.topupRecordQuery.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;
import com.constants.Constants;
import com.constants.SiteStatus;
import com.ppms.entity.ChannelEntity;
import com.ppms.entity.CounterEntity;
import com.ppms.entity.TerminalEntity;
import com.ppms.tstypeQuery.service.TstypeServiceI;
import com.ppms.terminalManagement.service.TerminalServiceI;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;


import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.jeecgframework.web.system.service.SystemService;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.util.oConvertUtils;


import com.ppms.topupRecordQuery.service.SpTopUpRecServiceI;
import com.ppms.vo.SpTopupRecResultVo;
import com.ppms.utils.DataReturn;

import javax.validation.Validator;

/**
 * @author zhangdaihao
 * @version V1.0
 * @Title: Controller
 * @Description:
 * @date 2018-05-10 15:21:05
 */
@Controller
@RequestMapping("/spTopUpRecController")
public class SpTopUpRecController extends BaseController {
    /**
     * Logger for this class
     */
    private static final Logger logger = Logger.getLogger(SpTopUpRecController.class);

    @Autowired
    private SpTopUpRecServiceI spTopUpRecService;
    @Autowired
    private TstypeServiceI tstypeService;
    @Autowired
    private TerminalServiceI terminalService;
    @Autowired
    private SystemService systemService;

    /**
     * SP_TOPUP_REC列表 页面跳转
     *
     * @return
     */
    @RequestMapping(params = "list")
    public ModelAndView list(HttpServletRequest request) {
        ModelAndView modelAndView = new ModelAndView("ppms/topuprecordQuery/spTopUpRecList");
        //ModelAndView modelAndView = new ModelAndView("ppms/paymentCollection/topuprecord_query");
        modelAndView.addObject("channelList", getSelectChannel());
        modelAndView.addObject("terminalList", getSelectTerminal());
        String paymentType = tstypeService.getGroupIdByGroupCode("PAYMENT_TYPE");
        List<Map<String, Object>> paymentTypeList = tstypeService.getTypeCodeAndNameByGroupId(paymentType);
        String txnStatusList = JSONObject.toJSONString(paymentTypeList);
        modelAndView.addObject("txnStatusList", txnStatusList);
        return modelAndView;
    }

    /**
     * easyui AJAX请求数据
     *
     * @param request
     * @param response
     * @param dataGrid
     * @param
     */

    @RequestMapping(params = "datagrid")
    public void datagrid(SpTopupRecResultVo resultVo, HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        try{
            if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.TOPUP_RECORD_QUERY.getStatus())){

                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
            }else{
                DataReturn dataReturn;
                try {
                    dataReturn = this.spTopUpRecService.getAllEntities(resultVo, dataGrid.getPage(), dataGrid.getRows(), request);
                    dataGrid.setResults(dataReturn.getRows());
                    dataGrid.setTotal((int) dataReturn.getTotal());
                } catch (ParseException e) {
                    logger.error(e.getMessage(), e);
                }
                TagUtil.datagrid(response, dataGrid);
            }
        }catch (Exception e){
            logger.error(e.getMessage(),e);
        }

    }


    /**
     * 详情查询页面 弹出
     *
     * @param request
     * @return
     */
    @RequestMapping(params = "detailQuery")
    public ModelAndView detailQuery(HttpServletRequest request) {
        String accountNo = request.getParameter("accNo");
        ModelAndView mv = new ModelAndView("ppms/paymentCollection/search_condition");
        mv.addObject("accNo", accountNo);
        return mv;
    }


    /**
     * 查询channel信息(激活状态的channel信息)
     */
    private String getSelectChannel() {
        CriteriaQuery cq = new CriteriaQuery(ChannelEntity.class);
        cq.eq("status", SiteStatus.ACTIVE.getStatus());
        cq.add();
        List<ChannelEntity> channelEntityList = this.spTopUpRecService.getListByCriteriaQuery(cq, false);
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        if (channelEntityList != null && channelEntityList.size() > 0) {
            for (ChannelEntity channelEntity : channelEntityList) {
                Map map = new HashMap();
                String channelCode = channelEntity.getCode();
                String channelName = channelEntity.getName();
                map.put("code", channelCode);
                map.put("name", channelName);
                list.add(map);
            }
        }

        return JSONObject.toJSONString(list);
    }


    /**
     * 查询terminal信息(激活状态的terminal信息)
     */
    private String getSelectTerminal() {
        CriteriaQuery cq = new CriteriaQuery(TerminalEntity.class);
        cq.eq("status", SiteStatus.ACTIVE.getStatus());
        cq.add();
        List<TerminalEntity> terminalEntityList = this.spTopUpRecService.getListByCriteriaQuery(cq, false);
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        if (terminalEntityList != null && terminalEntityList.size() > 0) {
            for (TerminalEntity terminalEntity : terminalEntityList) {
                Map map = new HashMap();
                String terminalCode = terminalEntity.getCode();
                String terminalName = terminalEntity.getName();
                map.put("code", terminalCode);
                map.put("name", terminalName);
                list.add(map);
            }
        }
        return JSONObject.toJSONString(list);
    }


    @RequestMapping(params = "getTerminalList")
    @ResponseBody
    public AjaxJson getTerminalList(HttpServletRequest request, HttpServletResponse response) {
        AjaxJson json = new AjaxJson();
        json.setSuccess(false);
        String channelCode = request.getParameter("code");
        if (oConvertUtils.isNotEmpty(channelCode)) {
            Map<String, Object> map = new HashMap();
            try {
                map.put("terminalList", JSONObject.toJSONString(terminalService.queryAllTerminalCodeAndName(channelCode)));
                json.setSuccess(true);
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
            json.setAttributes(map);
        }
        return json;
    }


}

	
