package com.ppms.meterDataQuery.controller;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;
import com.constants.Constants;
import com.ppms.tstypeQuery.service.TstypeServiceI;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.jeecgframework.web.system.service.SystemService;

import com.ppms.meterDataQuery.service.MeterDataServiceI;
import com.ppms.vo.MeterDataResultVo;
import com.ppms.utils.DataReturn;

import javax.validation.Validator;

/**   
 * @Title: Controller
 * @Description: M_METER_DATA
 * @author zhangdaihao
 * @date 2018-05-15 15:04:46
 * @version V1.0   
 *
 */
@Controller
@RequestMapping("/meterDataController")
public class MeterDataController extends BaseController {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = Logger.getLogger(MeterDataController.class);

	@Autowired
	private MeterDataServiceI meterDataService;
	@Autowired
	private TstypeServiceI tstypeService;
	@Autowired
	private SystemService systemService;

	/**
	 * M_METER_DATA列表 页面跳转
	 * 
	 * @return
	 */
	@RequestMapping(params = "list")
	public ModelAndView list(HttpServletRequest request) {
		//return new ModelAndView("ppms/meterDataQuery/meterDataQueryList");
		ModelAndView modelAndView = new ModelAndView("ppms/meterDataQuery/meterDataQueryList");
		String ddSrc = tstypeService.getGroupIdByGroupCode("METER_DATA_SRC");
		List<Map<String, Object>> ddSourceList = tstypeService.getTypeCodeAndNameByGroupId(ddSrc);
		String ddSrcList = JSONObject.toJSONString(ddSourceList);
		modelAndView.addObject("ddSrcList",ddSrcList);
		return modelAndView;
	}

	/**
	 * easyui AJAX请求数据
	 * 
	 * @param request
	 * @param response
	 * @param dataGrid
	 * @param
	 */

	@RequestMapping(params = "datagrid")
	public void datagrid(MeterDataResultVo resultVo,HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
		try{
			if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.METER_DATA_QUERY.getStatus())){
				request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
			}else{
				DataReturn dataReturn;
				try {
					dataReturn = this.meterDataService.getAllEntities(resultVo,dataGrid.getPage(),dataGrid.getRows(),request);
					dataGrid.setResults(dataReturn.getRows());
					dataGrid.setTotal((int)dataReturn.getTotal());
				} catch (ParseException e) {
					logger.error(e.getMessage(),e);
				}
				TagUtil.datagrid(response, dataGrid);
			}
		}catch (Exception e){
			logger.error(e.getMessage(),e);
		}

	}
	
	
	
}
