package com.ppms.connection.service.impl;

import com.constants.Constants;
import com.ppms.connection.controller.RemoteReconRecController;
import com.ppms.connection.dao.ConnectionDao;
import com.ppms.entity.AcctBalEntity;
import com.ppms.entity.RemoteReconRecEntity;
import com.ppms.utils.DataSourceValue;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.exception.BusinessException;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.extend.datasource.DataSourceType;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ppms.connection.service.RemoteReconRecServiceI;
import org.jeecgframework.core.common.service.impl.CommonServiceImpl;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;

@Service("remoteReconRecService")
@Transactional
@DataSourceValue(DataSourceType.dataSource_ppms)
public class RemoteReconRecServiceImpl extends CommonServiceImpl implements RemoteReconRecServiceI {

    private static final Logger logger = Logger.getLogger(RemoteReconRecServiceImpl.class);

    @Autowired
    private ConnectionDao connectionDao;

    @Override
    public void queryReconRecord(DataGrid dataGrid, HttpServletRequest request) {
        connectionDao.getResultCount(dataGrid, request);
        if (dataGrid.getTotal() > 0) {
            connectionDao.queryReconRecord(dataGrid, request);
        }
    }

    /**
     * 合闸
     * 业务逻辑：将需要合闸的记录的操作状态修改为pending，并且将合闸次数加1
     *
     * @param entity
     */
    @Override
    public void markReconnect(RemoteReconRecEntity entity) {
        logger.info("entity id:"+entity.getId());
        RemoteReconRecEntity reconRecEntity = super.getEntity(RemoteReconRecEntity.class, entity.getId());
        logger.info("recon rec:"+reconRecEntity.toString());
        logger.info("accno:"+reconRecEntity.getCustomerInfoEntity().getAccNo());
        String accNo = reconRecEntity.getCustomerInfoEntity().getAccNo();
        logger.info("control status"+reconRecEntity.getCtlStatus());
        logger.info("dict control status"+Constants.REMOTER_METER_CTRL_STATUS.FAILURE.getType());
        if(oConvertUtils.isEmpty(reconRecEntity.getCtlStatus()) || !reconRecEntity.getCtlStatus().equals(Constants.REMOTER_METER_CTRL_STATUS.FAILURE.getType())) {
            logger.info("control status");
            throw new BusinessException("Control status should be complete.");
        }
        logger.info("operate status"+reconRecEntity.getOperStatus());
        if(!Constants.REMOTER_OPER_STATUS.COMPLETED.getType().equals(reconRecEntity.getOperStatus())){
            logger.info("operate status");
            throw new BusinessException("Operate status should be complete.");
        }
        logger.info("query account balance");
        AcctBalEntity balEntity = super.getEntity(AcctBalEntity.class, accNo);
        logger.info("bal entity"+balEntity.getBalance());
        if(balEntity.getBalance().compareTo(BigDecimal.ZERO)<0){
            throw new BusinessException("Account balance is not insufficient.");
        }
        reconRecEntity.setOperStatus(Constants.REMOTER_OPER_STATUS.PENDING.getType());
        Integer times = 1;
        if (reconRecEntity.getOperTimes() != null) {
            times = reconRecEntity.getOperTimes() + 1;
        }
        reconRecEntity.setOperTimes(times);
        logger.info(reconRecEntity.toString());
        logger.info(reconRecEntity.getCustomerInfoEntity().getAccNo());
        super.saveOrUpdate(reconRecEntity);
        logger.info("execute sucess");
    }
}