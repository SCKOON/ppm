package com.ppms.reprintCard.controller;

import com.alibaba.fastjson.JSONObject;
import com.constants.Constants;
import com.filter.xssfilter.TxtUtils;
import com.ppms.creditTopup.bean.ReceiptPrintObj;
import com.ppms.customerInfo.generateCode.BarCodeUtil;
import com.ppms.dictionary.service.DictServiceI;
import com.ppms.entity.CustomerInfoEntity;
import com.ppms.entity.SpTopUpRecEntity;
import com.ppms.ldapLogin.util.ResourceUtils;
import com.ppms.reprintCard.dto.TopUpCustomerDTO;
import com.ppms.reprintCard.service.CardReprintServiceI;
import com.ppms.utils.GetClientIPUtil;
import com.ppms.utils.PropertiesUtil;
import com.zebra.sdk.comm.ConnectionException;
import com.zebra.sdk.common.card.containers.GraphicsInfo;
import com.zebra.sdk.common.card.containers.JobStatusInfo;
import com.zebra.sdk.common.card.enumerations.CardSide;
import com.zebra.sdk.common.card.enumerations.GraphicType;
import com.zebra.sdk.common.card.enumerations.OrientationType;
import com.zebra.sdk.common.card.enumerations.PrintType;
import com.zebra.sdk.common.card.exceptions.ZebraCardException;
import com.zebra.sdk.common.card.graphics.ZebraCardGraphics;
import com.zebra.sdk.common.card.graphics.enumerations.RotationType;
import com.zebra.sdk.common.card.printer.ZebraCardPrinter;
import com.zebra.sdk.device.ZebraIllegalArgumentException;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.exception.BusinessException;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.p3.core.util.oConvertUtils;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Controller
@RequestMapping("/reprintCardController")
public class ReprintCardController extends BaseController {

    private static final Logger logger = Logger.getLogger(ReprintCardController.class);

    //打印电卡费字段对应数据库的属性名
    private static final String DICT_NAME = "CARD_FEE";

    private static final String PAY_MODE = "PAYMENT_MODE";

    @Autowired
    private CardReprintServiceI cardReprintServiceI;

    @Autowired
    private DictServiceI dictServiceI;

    @RequestMapping(params = {"toPage"})
    public ModelAndView toReprintCard() {
        ModelAndView mv = new ModelAndView("/ppms/cardPrint/printTopUpCard");
        mv.addObject("payType", JSONObject.toJSONString(searchTypeForView(PAY_MODE)));

        return mv;
    }

    private List<Map<String, String>> searchTypeForView(String typeGroupName) {
        Map<String, String> map = new HashMap<>();
        try {
            map = this.dictServiceI.queryForOptions(typeGroupName, null);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
        List<Map<String, String>> maplist = new ArrayList();
        if (map.size() > 0) {
            //清除历史列表，刷新,防止多个用户同时查询造成map出现问题
            Set<Map.Entry<String, String>> entrySet = map.entrySet();
            for (Map.Entry<String, String> m : entrySet) {
                Map<String, String> stringMap = new HashMap();
                stringMap.put("code", m.getKey());
                stringMap.put("name", m.getValue());
                maplist.add(stringMap);
            }

        }
        return maplist;
    }

    /**
     * @param request
     * @param response
     * @param dataGrid
     * @Description 查询数据到页面显示  同时查询卡费
     */
    @RequestMapping(params = {"datagrid"})
    public void getCustomerInfo(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        cardReprintServiceI.queryListByCondition(dataGrid, request);
        List<CustomerInfoEntity> list = dataGrid.getResults();
        List<TopUpCustomerDTO> dtoList = new ArrayList();
        if (list != null && list.size() > 0) {
            TopUpCustomerDTO dto;
            String amount = "";
            Map<String, String> map = this.dictServiceI.queryForOptions(DICT_NAME, null);
            if (map.size() > 0) {
                amount = map.keySet().iterator().next();
            }
            for (CustomerInfoEntity customerInfoEntity : list) {
                dto = new TopUpCustomerDTO();
                dto.setAccNo(customerInfoEntity.getAccNo());
                dto.setAddress(customerInfoEntity.getAddress());
                dto.setBlockNumber(customerInfoEntity.getBlockNumber());
                dto.setInstallationNumber(customerInfoEntity.getInstallationNumber());
                dto.setSalutation(customerInfoEntity.getSalutation());
                dto.setStreetName(customerInfoEntity.getStreetName());
                dto.setPrintCardTimes(customerInfoEntity.getPrintCardTimes() != null ? customerInfoEntity.getPrintCardTimes() : 0);
                String mobileNum = customerInfoEntity.getMobileNumber();
                if (oConvertUtils.isNotEmpty(mobileNum)) {
                    dto.setMobileNumber(ResourceUtils.encryptPhoneNumber(mobileNum));
                }
                if (oConvertUtils.isEmpty(customerInfoEntity.getPrintCardTimes()) || customerInfoEntity.getPrintCardTimes() == 0) {
                    dto.setCardFee(Constants.INITIAL_CARD_FEE);
                } else {
                    dto.setCardFee(amount);
                }
                dtoList.add(dto);
            }
        }
        dataGrid.setResults(dtoList);
        TagUtil.datagrid(response, dataGrid);
    }


    @RequestMapping(params = "print")
    public ModelAndView print(HttpServletRequest request, ModelMap map) throws Exception {
        String accNo = request.getParameter("accno");
        map.addAttribute("accNo", accNo);
        String realPath = request.getSession().getServletContext().getRealPath("/") + "webpage\\ppms\\customerManagement\\tempCodePng\\temp_code" + accNo + ".png";
        TxtUtils.file_filter(accNo);
        File file = new File(realPath);
        if (!file.exists()) {
            if (file.createNewFile())
                BarCodeUtil.generateFile(accNo, realPath);
        }
        return new ModelAndView("ppms/customerManagement/topupCard_print", map);
    }

    @RequestMapping(params = "topUpCardFee")
    @ResponseBody
    public AjaxJson topUpCardFee(HttpServletRequest request) {
        AjaxJson json = new AjaxJson();
        SpTopUpRecEntity topupRecordEntity = new SpTopUpRecEntity();
        String accno = request.getParameter("accNo");
        String payModel = request.getParameter("payMode");
        if (oConvertUtils.isEmpty(payModel)) {
            json.setMsg("payMode should be filled in!");
            return json;
        }
        topupRecordEntity.setPayMode(payModel);
        topupRecordEntity.setAccNo(accno);
        try {
            topupRecordEntity.setTopupAmt(new BigDecimal(oConvertUtils.getString(request.getParameter("topupAmt"))));
        } catch (Exception e) {
            json.setMsg("Amount is not valid!");
            return json;
        }
        try {
            String ip = GetClientIPUtil.getIpAddr(request);
            logger.info("current ip:" + ip);
            if (oConvertUtils.isNotEmpty(ip)) {
                String ipv4Reg = "^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})$";
                String ipv6Reg = "^\\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:)))(%.+)?\\s*$";
                if (match(ipv4Reg, ip) || match(ipv6Reg, ip)) {
                    //保存电卡打印次数
                    cardReprintServiceI.saveTopUpRecord(ip, topupRecordEntity);
                    json.setSuccess(true);
                } else {
                    json.setMsg("current counter is not in the ppms system!");
                }
            }
        } catch (BusinessException e) {
            json.setMsg(e.getMessage());
        } catch (Exception e) {
            logger.error(e);
        }
        return json;
    }

    private List<GraphicsInfo> getGraphicsInfos(HttpServletRequest request, String accno, ZebraCardPrinter zebraCardPrinter) throws ConnectionException, ZebraCardException, IOException {
        ZebraCardGraphics graphics;
        GraphicsInfo grInfo;
        BufferedImage image;
        ByteArrayOutputStream baos;
        List<GraphicsInfo> graphicsData = new ArrayList<GraphicsInfo>();
        graphics = new ZebraCardGraphics(zebraCardPrinter);
        graphics.initialize(0, 0, OrientationType.Landscape, PrintType.MonoK, Color.WHITE);

        grInfo = new GraphicsInfo();
        grInfo.side = CardSide.Front;
        grInfo.printType = PrintType.MonoK;
        grInfo.graphicType = GraphicType.BMP;

        //获取BufferedImage对象
        String filepath = request.getSession().getServletContext().getRealPath("/") + "webpage\\ppms\\customerManagement\\tempCodePng\\temp_code" + accno + ".png";
        image = ImageIO.read(new File(filepath));
        baos = new ByteArrayOutputStream();
        ImageIO.write(image, "bmp", baos);

        //设置image参数x,y,w,h
        Properties properties = PropertiesUtil.readProperties("graphicsPosition.properties");
        String x = properties.getProperty("barcode.x");
        String y = properties.getProperty("barcode.y");
        String w = properties.getProperty("barcode.w");
        String h = properties.getProperty("barcode.h");
        Integer ix = Integer.valueOf(x);
        Integer iy = Integer.valueOf(y);
        Integer iw = Integer.valueOf(w);
        Integer ih = Integer.valueOf(h);

        graphics.drawImage(baos.toByteArray(), ix, iy, iw, ih, RotationType.RotateNoneFlipNone);//drawImage(byte[] imageData, int x, int y, int width, int height, RotationType rotation)
        grInfo.graphicData = graphics.createImage(null);
        graphics.clear();
        graphicsData.add(grInfo);

        return graphicsData;
    }

    public static boolean pollJobStatus(ZebraCardPrinter device, int actionID) throws ConnectionException, ZebraCardException, ZebraIllegalArgumentException {
        boolean success = false;
        long dropDeadTime = System.currentTimeMillis() + 40000;
        long pollInterval = 500;
        JobStatusInfo jStatus = null;
        do {
            jStatus = device.getJobStatus(actionID);
            logger.info(String.format("Job %d, Status:%s, Card Position:%s, " + "ReadyForNextJob:%s, Mag Status:%s, Contact Status:%s, Contactless Status:%s, " + "Error Code:%d, Alarm Code:%d",
                    actionID, jStatus.printStatus, jStatus.cardPosition, jStatus.readyForNextJob, jStatus.magneticEncoding, jStatus.contactSmartCard, jStatus.contactlessSmartCard,
                    jStatus.errorInfo.value, jStatus.alarmInfo.value));

            if (jStatus.contactSmartCard.contains("station")) {
                success = true;
                break;
            } else if (jStatus.contactlessSmartCard.contains("station")) {
                success = true;
                break;
            } else if (jStatus.printStatus.contains("done_ok")) {
                success = true;
                break;
            } else if (jStatus.printStatus.contains("alarm_handling")) {
                System.out.println("Error Dectected: " + jStatus.alarmInfo.description);
                success = false;
            } else if (jStatus.printStatus.contains("error") || jStatus.printStatus.contains("cancelled")) {
                success = false;
                break;
            }
            if (System.currentTimeMillis() > dropDeadTime) {
                success = false;
                break;
            }
            try {
                Thread.sleep(pollInterval);
            } catch (InterruptedException e) {
                logger.error(e.getMessage(), e);
            }

        } while (true);

        return success;
    }

    /**
     * @param regex 正则表达式字符串
     * @param str   要匹配的字符串
     * @return 如果str 符合 regex的正则表达式格式,返回true, 否则返回 false;
     */
    private static boolean match(String regex, String str) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        return matcher.matches();
    }

    /**
     * 凭证打印
     *
     * @param request
     * @return
     */
    @RequestMapping(params = "receiptPrint")
    public ModelAndView receiptPrint(HttpServletRequest request) {
        String accNo = request.getParameter("accno");
        String ip = GetClientIPUtil.getIpAddr(request);
        ReceiptPrintObj printObj = new ReceiptPrintObj();
        Map<String, String> strMap = new HashMap<>();
        try {
            strMap = dictServiceI.queryForOptions(PAY_MODE, null);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        ModelAndView mv = new ModelAndView("ppms/cardPrint/cardReceipt");
        try {
            printObj = this.cardReprintServiceI.toPrintReceipt(ip, accNo, strMap);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        mv.addObject("printObj", printObj);
        return mv;
    }

}
