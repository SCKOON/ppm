function showCenter(value){
    var value = $("#groupId").val();
    if(value==null||value==''){
        return;
    }else{
        if(value.lastIndexOf('EXECS')>0||value.lastIndexOf('COUNTER')>0||value.lastIndexOf('CASHIER')>0){
            $("tr.terminal").show();
            $("#terminalId").attr("datatype", "select1");
            $("#counterId").attr("datatype", "select1");
        }else{
            $("tr.terminal").hide();
            $("#terminalId").removeAttr("datatype");
        }
    }
}

function changeCounter(terminalId){
    $("#counterId").empty();
    $("#counterId").append("<option value='' selected>---please select Item---</option>");
    var url = "loginController.do?getCounterList&terminalId=" + terminalId;
    $.ajax({
        url: url,
        type: "post",
        dataType: "json",
        success: function (data) {
            if (data.success) {
                var result = data.attributes;
                if (result) {
                    var counters = $.parseJSON(result['counterList']);
                    for (var i = 0; i < counters.length; i++) {
                        $("#counterId").append("<option value='" + counters[i].code + "'>" + counters[i].name + "</option>");
                    }
                }
            }
        }
    })
}