package com.ppms.ldapLogin.util;

import com.ppms.vo.Client;

import java.util.Collection;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.jeecgframework.core.util.ContextHolderUtils;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

public class ResourceUtils {
    public static final Authentication getSessionUser() {
        Authentication authentication = null;
        HttpSession session = ContextHolderUtils.getSession();
        if ((session != null) && (session.getAttribute(session.getId()) != null)) {
            authentication = (Authentication) session.getAttribute(session.getId());
        }
        return authentication;
    }

    public static final Client getClient() {
        HttpSession session = ContextHolderUtils.getSession();
        return (Client) session.getAttribute(session.getId());
    }

    public static String getCurrentUserRole() {
        Authentication authentication = getSessionUser();
        if ((authentication != null) &&
                ((authentication instanceof UsernamePasswordAuthenticationToken))) {
            UsernamePasswordAuthenticationToken token = (UsernamePasswordAuthenticationToken) authentication;
            Object role = authentication.getDetails();
            if ((role != null) && ((role instanceof String))) {
                return (String) role;
            }
        }
        return null;
    }

    public static String encryptPhoneNumber(String phoneNum) {
        if (StringUtils.isEmpty(phoneNum)) {
            return "";
        }
        if (phoneNum.length() < 4) {
            return phoneNum;
        }
        int phoneNumLen = phoneNum.length();
        int triplyLength = phoneNumLen / 3;
        int remain = phoneNumLen - (triplyLength * 2 + 1);
        int lastIndex = triplyLength + remain;
        String mask = "";
        for (int i = 0; (remain > 0) && (i < remain); i++) {
            mask = mask + "*";
        }
        phoneNum = phoneNum.substring(0, triplyLength).concat(mask).concat(phoneNum.substring(lastIndex));
        return phoneNum;
    }
}
