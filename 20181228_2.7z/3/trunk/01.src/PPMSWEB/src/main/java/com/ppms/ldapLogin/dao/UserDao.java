package com.ppms.ldapLogin.dao;

import com.ppms.entity.LoginLogEntity;
import com.ppms.entity.TerminalEntity;

import java.util.Date;
import java.util.List;

public interface UserDao {

    public int queryFailedCountAfterBeginTime(String username, Date beginDate);

    /**
     * @Description 删除用户对应角色关系
     * @param username
     */
    public void deleteUserRole(String username);

    public List<TerminalEntity> querySPActivatiedTerminal();

    public LoginLogEntity queryByCounterCode(String counterCode);
}
