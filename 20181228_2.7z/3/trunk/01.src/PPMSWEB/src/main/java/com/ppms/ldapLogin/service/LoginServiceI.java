package com.ppms.ldapLogin.service;

import com.ppms.entity.LoginLogEntity;
import com.ppms.entity.TerminalEntity;
import org.jeecgframework.core.common.service.CommonService;
import org.jeecgframework.web.system.pojo.base.TSFunction;
import org.springframework.security.core.Authentication;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface LoginServiceI extends CommonService{

    public int queryFailCountForLogin(LoginLogEntity entity, int intervalTime);

    /**
     * 登录成功之后，保存登入日志，同时保存登录人名称和角色的关联关系
     * @param entity
     * @param authentication
     * @return
     */
    public Serializable save(LoginLogEntity entity, Authentication authentication);

    public int getRecordCount(String username);

    public boolean isUserLogin(String username);

    /**
     * @Description 用户登录维护用户和角色关系时，不能判断用户角色是否更改，所以需要先清除该用户以前的角色关联关系
     * @param username
     */
//    public void deleteUserRole(String username);

    /**
     * @description 通过rolecode查询对应角色的权限信息
     * @param authentication
     */
    public Map<Integer, List<TSFunction>> queryUserAuthentication(Authentication authentication);

    public List<TerminalEntity> queryActivedSPTerminal();

    public LoginLogEntity queryByCounterCode(String counterCode);
}
