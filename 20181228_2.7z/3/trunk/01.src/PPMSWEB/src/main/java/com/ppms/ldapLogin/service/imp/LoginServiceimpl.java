package com.ppms.ldapLogin.service.imp;

import com.constants.FailIgnoreEnum;
import com.constants.LoginStatusEnum;
import com.ppms.dict.CacheDao;
import com.ppms.entity.LoginLogEntity;
import com.ppms.entity.TerminalEntity;
import com.ppms.ldapLogin.dao.UserDao;
import com.ppms.entity.LoginBlackListEntity;
import com.ppms.ldapLogin.service.LoginServiceI;

import com.ppms.ldapLogin.util.ResourceUtils;
import com.ppms.utils.DataSourceValue;
import org.hibernate.criterion.Restrictions;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.service.impl.CommonServiceImpl;
import org.jeecgframework.core.constant.Globals;
import org.jeecgframework.core.extend.datasource.DataSourceType;
import org.jeecgframework.core.util.NumberComparator;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.tag.vo.datatable.SortDirection;
import org.jeecgframework.web.system.pojo.base.TSFunction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.session.Session;
import org.springframework.session.SessionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.*;

@Service
@DataSourceValue(DataSourceType.dataSource_jeecg)
@Transactional
public class LoginServiceimpl extends CommonServiceImpl implements LoginServiceI {

    @Autowired
    private SessionRepository jdbcSessionRepository;

    @Autowired
    private UserDao userDao;

    @Autowired
    private CacheDao cacheDao;

    /**
     * 往登录日志存入一条登录失败日志，再查询当前时间往前一段时间该用户登录失败次数
     *
     * @param entity
     * @return
     */
    @Override
    public int queryFailCountForLogin(LoginLogEntity entity, int intervalTime) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(entity.getCreatetime());
        calendar.add(Calendar.MINUTE, (0 - intervalTime));
        CriteriaQuery criteriaQuery = new CriteriaQuery(LoginLogEntity.class);
        criteriaQuery.eq("username", entity.getUsername());
        criteriaQuery.ge("createtime", calendar.getTime());
        criteriaQuery.eq("status", LoginStatusEnum.FAILED.getStatus());
        criteriaQuery.eq("ignore", FailIgnoreEnum.NOIGNORE.getStatus());
        criteriaQuery.add();
        List list = super.getListByCriteriaQuery(criteriaQuery, false);
        int i = 0;
        if (list != null && list.size() > 0) {
            i = list.size();
        }
        return i;
    }

    /**
     * 登录成功之后，需要同时保存登录日志，并且维护登陆人的用户角色关系。
     *
     * @param entity         登录日志
     * @param authentication 登录成功的用户信息
     * @return
     */
    @Override
    public Serializable save(LoginLogEntity entity, Authentication authentication) {
        return super.save(entity);
    }

    @Override
    public int getRecordCount(String username) {
        CriteriaQuery criteriaQuery = new CriteriaQuery(LoginBlackListEntity.class);
        criteriaQuery.eq("username", username);
        criteriaQuery.add();
        return super.getListByCriteriaQuery(criteriaQuery, false).size();
    }

    /**
     * 根据登录日志的最新的用户登录记录判断用户是否在登录（根据记录的sessionId）
     *
     * @param username
     * @return
     */
    @Override
    public boolean isUserLogin(String username) {
        CriteriaQuery criteriaQuery = new CriteriaQuery(LoginLogEntity.class);
        criteriaQuery.eq("username", username);
        //只查看登录成功或者登出的记录
        criteriaQuery.or(Restrictions.eq("status", LoginStatusEnum.SUCCESS.getStatus()), Restrictions.eq("status", LoginStatusEnum.LOGOUT.getStatus()));
        Map<String, Object> map = new HashMap<>();
        map.put("createtime", SortDirection.desc);
        criteriaQuery.setOrder(map);
        criteriaQuery.add();
        List<LoginLogEntity> list = super.getListByCriteriaQuery(criteriaQuery, false);
        if (list != null && list.size() > 0) {
            LoginLogEntity loginLogEntity = list.get(0);
            if (loginLogEntity.getStatus() != null && LoginStatusEnum.SUCCESS.getStatus().equals(loginLogEntity.getStatus())) {
                //根据session判断
                if (!oConvertUtils.isEmpty(loginLogEntity.getSessionid())) {
                    Session session = jdbcSessionRepository.getSession(loginLogEntity.getSessionid());
                    if (session != null) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public Map<Integer, List<TSFunction>> queryUserAuthentication(Authentication authentication) {
        Map<Integer, List<TSFunction>> functionMap = new HashMap<>();
        if (authentication != null) {
            String rolecode = ResourceUtils.getCurrentUserRole();
            Map<String, Object> map = cacheDao.getAllFunctionByRole(rolecode);
            if (map != null && map.size() > 0) {
                Collection<Object> allFunctions = map.values();
                for (Object function : allFunctions) {
                    if (((TSFunction) function).getFunctionType().intValue() == Globals.Function_TYPE_FROM.intValue()) {
                        //如果为表单或者弹出 不显示在系统菜单里面
                        continue;
                    }
                    if (!functionMap.containsKey(((TSFunction) function).getFunctionLevel() + 0)) {
                        functionMap.put(((TSFunction) function).getFunctionLevel() + 0,
                                new ArrayList<TSFunction>());
                    }
                    functionMap.get(((TSFunction) function).getFunctionLevel() + 0).add(((TSFunction) function));
                }
                // 菜单栏排序
                Collection<List<TSFunction>> c = functionMap.values();
                for (List<TSFunction> list : c) {

                    for (TSFunction function : list) {
                        //如果有子级菜单 则地址设为空
                        if (function.hasSubFunction(functionMap)) function.setFunctionUrl("");
                    }

                    Collections.sort(list, new NumberComparator());
                }
                //清空变量，降低内存使用
                map.clear();
            }
        }
        return functionMap;
    }

    @Override
    @DataSourceValue(DataSourceType.dataSource_ppms)
    public List<TerminalEntity> queryActivedSPTerminal() {

        return userDao.querySPActivatiedTerminal();
    }

    @Override
    public LoginLogEntity queryByCounterCode(String counterCode) {
        return userDao.queryByCounterCode(counterCode);
    }
}
