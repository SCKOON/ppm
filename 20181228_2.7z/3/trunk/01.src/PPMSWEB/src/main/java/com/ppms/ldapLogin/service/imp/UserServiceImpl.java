package com.ppms.ldapLogin.service.imp;

import com.ppms.entity.LoginLogEntity;
import com.ppms.ldapLogin.dao.UserDao;
import com.ppms.ldapLogin.service.UserServiceI;
import com.ppms.utils.DataSourceValue;
import org.jeecgframework.core.extend.datasource.DataSourceType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
@DataSourceValue(DataSourceType.dataSource_jeecg)
public class UserServiceImpl implements UserServiceI{

    @Autowired
    private UserDao userDao;

    @Override
    public LoginLogEntity queryByCounterCode(String counterCode) {
        return userDao.queryByCounterCode(counterCode);
    }
}
