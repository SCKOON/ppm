package com.ppms.ldapLogin.service;

import com.ppms.entity.LoginBlackListEntity;
import com.ppms.entity.LoginLogEntity;
import org.jeecgframework.core.common.service.CommonService;

public interface UserServiceI {

    public LoginLogEntity queryByCounterCode(String counterCode);
}
