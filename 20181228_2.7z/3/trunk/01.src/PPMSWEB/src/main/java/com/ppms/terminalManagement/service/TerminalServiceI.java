package com.ppms.terminalManagement.service;

import com.ppms.terminalManagement.dto.TerminalDTO;
import com.ppms.entity.TerminalEntity;
import com.ppms.utils.DataReturn;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.DataGrid;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface TerminalServiceI{

    public void delete(TerminalDTO entity) throws Exception;

    public Serializable save(TerminalEntity entity) throws Exception;

    public void saveOrUpdate(TerminalEntity entity) throws Exception;

    public void batchDelete(String ids) throws Exception;
    //add by yangyong
    public DataReturn getNewAllEntities(TerminalEntity terminalEntity, int page, int rows, HttpServletRequest request,String chalId);

    public TerminalEntity getEntity(Serializable id);

    /**
     * @Description 页面展示查询结果
     * @param terminalEntity
     * @param dataGrid
     */
    public void queryAllTerminalForView(TerminalEntity terminalEntity, DataGrid dataGrid);

    public boolean queryTerminalNameOrCodeIsUse(TerminalEntity terminalEntity);

    /**
     * @description 当用户选择切换status的时候，查询对应关联的terminal的状态是否一致
     * @param terminalEntity
     * @return
     */
    public Boolean queryCounterStatusIsValid(TerminalEntity terminalEntity);

    public void getDataGridReturn(CriteriaQuery cq, boolean isOffset);

    public <T> T getEntity(Class entityName, Serializable id);

    public <T> List<T> getListByCriteriaQuery(CriteriaQuery cq, Boolean ispage);

    /**
     * 查询所有的terminal的terminalcode和terminalName，以用作前台下拉框展示
     * @return
     */
    public List<Map<String, String>> queryAllTerminalCodeAndName();

    public List queryCounterByTerminalCode(String terminalCode);

    /**
     * 查询terminal的terminalcode和terminalName，以用作前台下拉框展示
     * @return
     */
    public List<Map<String, String>> queryAllTerminalCodeAndName(String centerCode);

    /**
     * genju id 查询terminal的terminalcode和terminalName，以用作前台下拉框展示
     * @return
     */
    public List<Map<String, String>> queryCunterListByTerminalIdAndStatus(String id,String status);

    public boolean checkIsTrue(String id,String status,String counterCode);

}
