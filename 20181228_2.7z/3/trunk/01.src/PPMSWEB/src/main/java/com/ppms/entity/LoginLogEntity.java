package com.ppms.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

/**   
 * @Title: Entity
 * @Description: 登录记录
 * @author zhangdaihao
 * @date 2018-07-13 09:37:39
 * @version V1.0   
 *
 */
@Entity
@Table(name = "t_s_login_log", schema = "")
@DynamicUpdate(true)
@DynamicInsert(true)
@SuppressWarnings("serial")
public class LoginLogEntity implements java.io.Serializable {
	/**id*/
	private java.lang.Integer id;
	/**username*/
	private java.lang.String username;
	/**logintime*/
	private java.util.Date createtime;
	/**status*/
	private java.lang.String status;

	/**browser*/
	private java.lang.String browser;

	/**ip*/
	private java.lang.String ip;
	/**sessionid*/
	private java.lang.String sessionid;

	private java.lang.String groupCode;

	private java.lang.Integer terminalId;

//	private java.lang.String counterCode;

	@Column(name ="sessionid",nullable=true,precision=64,length=64)
	public String getSessionid() {
		return sessionid;
	}

	public void setSessionid(String sessionid) {
		this.sessionid = sessionid;
	}

	/**
	 *方法: 取得java.lang.Integer

	 *@return: java.lang.Integer  id
	 */
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="ID",nullable=false,precision=10,scale=0,length=4)
	public java.lang.Integer getId(){
		return this.id;
	}

	/**
	 *方法: 设置java.lang.Integer
	 *@param: java.lang.Integer  id
	 */
	public void setId(java.lang.Integer id){
		this.id = id;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  username
	 */
	@Column(name ="USERNAME",nullable=false,precision=64,length=64)
	public java.lang.String getUsername(){
		return this.username;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  username
	 */
	public void setUsername(java.lang.String username){
		this.username = username;
	}

	@Column(name ="createTime",nullable=false,precision=23,scale=3,length=8)
	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  status
	 */
	@Column(name ="STATUS",nullable=true,precision=1,length=1)
	public java.lang.String getStatus(){
		return this.status;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  status
	 */
	public void setStatus(java.lang.String status){
		this.status = status;
	}

	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  browser
	 */
	@Column(name ="BROWSER",nullable=true,precision=64,length=64)
	public java.lang.String getBrowser(){
		return this.browser;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  browser
	 */
	public void setBrowser(java.lang.String browser){
		this.browser = browser;
	}

	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  ip
	 */
	@Column(name ="IP",nullable=true,precision=20,length=20)
	public java.lang.String getIp(){
		return this.ip;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  ip
	 */
	public void setIp(java.lang.String ip){
		this.ip = ip;
	}

	@Column(name ="groupCode",nullable=true,precision=64,length=64)
	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	@Column(name ="terminalId",nullable=true,precision=10,scale=0,length=4)
	public Integer getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(Integer terminalId) {
		this.terminalId = terminalId;
	}

//	@Column(name ="counterCode",nullable=true,precision=12,length=12)
//	public String getCounterCode() {
//		return counterCode;
//	}
//
//	public void setCounterCode(String counterCode) {
//		this.counterCode = counterCode;
//	}
}
