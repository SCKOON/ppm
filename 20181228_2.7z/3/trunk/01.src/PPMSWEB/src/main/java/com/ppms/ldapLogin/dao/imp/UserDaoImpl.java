package com.ppms.ldapLogin.dao.imp;

import com.constants.FailIgnoreEnum;
import com.constants.LoginStatusEnum;
import com.constants.SiteStatus;
import com.ppms.entity.TerminalEntity;
import com.ppms.ldapLogin.dao.UserDao;
import com.ppms.entity.LoginLogEntity;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.jeecgframework.core.common.dao.impl.GenericBaseCommonDao;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class UserDaoImpl extends GenericBaseCommonDao implements UserDao {

    @Override
    public int queryFailedCountAfterBeginTime(String username, Date beginDate) {
        //查询登录某时间段内失败次数
        Criteria criteria = getSession().createCriteria(LoginLogEntity.class);
        criteria.add(Restrictions.eq("username", username));
        criteria.add(Restrictions.ge("createtime", beginDate));
        criteria.add(Restrictions.eq("status", LoginStatusEnum.FAILED.getStatus()));
        criteria.add(Restrictions.eq("ignore", FailIgnoreEnum.NOIGNORE.getStatus()));
        criteria.setProjection(Projections.rowCount());
        return (Integer) criteria.uniqueResult();
    }

    @Override
    public void deleteUserRole(String username) {
        if (oConvertUtils.isNotEmpty(username)) {
            String hql = " delete from TSRoleUser as user where 1=1 and user.username = :username";
            Query query = super.getSession().createQuery(hql).setParameter("username",username);
            query.executeUpdate();
        }
    }

    @Override
    public List<TerminalEntity> querySPActivatiedTerminal() {
        String hql = " from TerminalEntity entity where 1=1 and entity.status = :status";
        Query query = super.getSession().createQuery(hql);
        query.setParameter("status", SiteStatus.ACTIVE.getStatus());
        List list = query.list();
        return list;
    }

    @Override
    public LoginLogEntity queryByCounterCode(String counterCode) {
        LoginLogEntity logEntity = null;
        String sql = "select top(1) * from t_s_login_log as log where log.counterCode = :counterCode order by createTime desc ";
        Query query = super.getSession().createQuery(sql);
        query.setParameter("counterCode", counterCode);
        List list = query.list();
        if(list != null && list.size()>0){
            logEntity = (LoginLogEntity)list.get(0);
        }
        return logEntity;
    }
}
