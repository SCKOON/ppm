package com.ppms.creditTopup.bean;

import java.math.BigDecimal;

/**
 * Created by yadongliang on 2018/7/3 0003.
 */
public class TopupConstants {

   /* public static final BigDecimal MIN_TOPUP_AMT = new BigDecimal(10);//当次缴费最低限额
    public static final BigDecimal MAX_TOPUP_AMT = new BigDecimal(100);//当次缴费最大限额
    public static final BigDecimal MAX_TOP_AMT_1D = new BigDecimal(500);//当日缴费限额*/

    public static final String TOPUPAMT_FORMAT_ERROR_ALARM = "Invalid top-up amount.";
    public static final String TOPUPAMT_ONCE_MINIMUM_ALARM = "This recharge is below the minimum limit, please recharge";
    public static final String TOPUPAMT_ONCE_MAXIMUM_ALARM = "This recharge is higher than the maximum limit, please recharge";
    public static final String TOPUPAMT_ONEDAY_MAXIMUM_ALARM = "This recharge will exceed the maximum limit of the day, please recharge";
    public static final String TOPUP_MAC_NOT_MATCH = "The current terminal information does not exist (no operation permission), please contact the administrator";//"MAC地址不匹配,无权限执行充值操作"

    private static final String TOPUP_HAVE_ARREARS = "The current account has arrears in EBS and is not allowed to open an account.";

    private static final int TOPUP_LOWEST_CREDIT = 0;//触发跳闸余额

    private static final String TOPUP_ARREARS = "0.2";//arrears参数

    private static final String TOPUP_TXNSTATUS_TOPUP = "01";//Top-up

    private static final String TOPUP_RECONSTATUS_UNRECON = "01";//未对账

    private static final String TOPUP_PAYMODE_CREDITCARD = "02";//Credit Card

    //credit_type
    private static final String TOPUP_CREDITTYPE_VISA = "01";//VISA
    private static final String TOPUP_CREDITTYPE_MASTERCARD = "02";//MASTER CARD

    private static final String TOPUP_UPDATE_FLAG_TOPUP = "03";//03-充值

    private static final String TOPUP_RESULT_SUCCESS = "Top-up successfully.";
    private static final String TOPUP_RESULT_FAILED = "Top-up failed.";

    //账户状态校验信息
    private static final String TOPUP_ACCOUNT_NOT_EXIST = "Account number doesn't exist.";
    private static final String TOPUP_ACCSTATUS_NOT_ACTIVATED = "Account is inactivated or closed.";

    //充值页面校验信息
    private static final String TOPUP_ACCNO_NULL= "Please enter account number.";//Account Number
    private static final String TOPUP_AMT_NULL= "Please enter top-up amount.";//Topup Amount
    private static final String TOPUP_PAYMODE_NULL= "Please select payment mode.";//Payment Mode
    private static final String TOPUP_VOUCHER_NULL= "Please select voucher number.";//Voucher Number

    //账户状态
    /*01：创建（待激活）或重新开户
    02: 等待激活，表示电表信息获取成功
    03: 获取电表信号成功
    90: 激活允许充值
    99：销户;*/
    private static final String CUSTOMER_ACCOUNT_STATUS_ACTIVATED = "90";//90：激活（允许充值）

    /**
     * 冲正状态
     */
    public enum REVERSE_STATUS{
        REVERSE_SUCCESS("Reverse successfully."),
        REVERSE_FAILURE_REPEAT("Reversal failed. Please try it again."),
        REVERSE_FAILURE("Reversal failed."),//程序异常
        REVERSE_HAVE_RECON("Cannot reverse as Day End Reconcilation is completed."),
        REVERSE_OTHER_RECON_STATUS("Cannot reverse as Day End Reconcilation failed."),
        REVERSE_NOT_CURRENT_BATCH("Cannot reverse as it is not in current transcation batch."),
        REVERSE_HAVE_REVERSED("Duplicated reveral is rejected."),
        REVERSE_OTHER_STATUS("Cannot reverse as Day End Reconcilation failed.");

        REVERSE_STATUS(String status){
            this.status = status;
        }

        private String status;

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

    }

    /**
     * 支付类型
     */
    public enum PAYMENT_MODE{
        CASH("01"),
        CREDIT("02"),
        DEBIT("03"),
        NETS("04"),
        CHEQUE("05"),
        VOUCHER("06"),
        OPENING_PREST_CREDIT("90");

        PAYMENT_MODE(String paymentMode){
            this.paymentMode = paymentMode;
        }

        private String paymentMode;

        public String getPaymentMode() {
            return paymentMode;
        }

        public void setPaymentMode(String paymentMode) {
            this.paymentMode = paymentMode;
        }
    }

    /**
     * txn_status
     * 01- Top-up
     * 02- 已冲正
     * 03- reverse
     * 04- 对账补入
     * 05- 对账删除
     * 06 - card fee
     * 07- account opening
     * 08 - account re-opening
     * 09 - issue card
     */
    public enum TXN_STATUS{
        TOPUP("01"),
        REVERSED("02"),
        REVERSE("03"),
        ACCOUNT_OPENING("07"),
        ACCOUNT_REOPENING("08");
        private String txnStatus;

        TXN_STATUS(String txnStatus) {
            this.txnStatus = txnStatus;
        }

        public String getTxnStatus() {
            return txnStatus;
        }

        public void setTxnStatus(String txnStatus) {
            this.txnStatus = txnStatus;
        }
    }

    /**
     * 余额更新记录表update_flag
     * 01: 新开户
     * 02: PAYU
     * 03: 充值
     * 04: 电费扣减
     * 05: 电费调整
     * 06: 冲正
     * 07: 退款
     * 08: 余额转出
     * 09: 余额转入
     * 10: 对账补入
     * 11: 对账删除
     * 12: 换表电费结算
     * 13. 销户
     * 14. 发行电卡
     * 15. 重新开户
     */
    public enum UPDATE_FLAG{
        ACCOUNT_OPENING("01"),
        ACCOUNT_PAYU_CONVERT("02"),
        ACCOUNT_TOPUP("03"),
        CREDIT_KOUJIAN("04"),
        CREDIT_TIAOZHENG("05"),
        ACCOUNT_REVERSE("06"),
        ACCOUNT_REFUND("07"),
        ACCOUNT_CREDIT_TRANSFER_OUT("08"),
        ACCOUNT_CREDIT_TRANSFER_IN("09"),
        ACCOUNT_CLOSING("13"),
        ACCOUNT_REOPEN("15");

        UPDATE_FLAG(String updateFlag){
            this.updateFlag = updateFlag;
        }

        private String updateFlag;

        public String getUpdateFlag() {
            return updateFlag;
        }

        public void setUpdateFlag(String updateFlag) {
            this.updateFlag = updateFlag;
        }
    }

    /**
     * 对账状态
     * 01- 未对账
     * 02- 对账中
     * 03- 对账完成（成功）
     * 11- 对账失败
     */
    public enum RECON_STATUS{

        UNRECON("01"),
        RECONING("02"),
        RECON_SUCCESS("03"),
        RECON_FAILUE("11");

        private String reconStatus;

        RECON_STATUS(String reconStatus) {
            this.reconStatus = reconStatus;
        }

        public String getReconStatus() {
            return reconStatus;
        }

        public void setReconStatus(String reconStatus) {
            this.reconStatus = reconStatus;
        }
    }

    /**
     * 退款申请及审批提示信息
     */
    public enum REFUND_MESSAGE{

        REFUND_APPLY_SUCCESS("Refund apply succeed."),
        REFUND_APPLY_FAILUE("Refund apply failed."),
        REFUND_APPROVAL_SUCCESS("Refund approval succeed."),
        REFUND_APPROVAL_FAILUE("Refund approval failed."),
        REFUND_UPDATE_BALANCE_FAILUE("Refund approval failed as unable to obtain customer credit balance.");//这种情况貌似不存在,用户余额表不可能没有该用户余额信息

        private String message;

        REFUND_MESSAGE(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }

    /**
     * 票据类型
     */
    public enum RECEIPT_TYPE{
        TOPUP("01"),
        REVERSE("02");
        private String receiptType;

        RECEIPT_TYPE(String receiptType) {
            this.receiptType = receiptType;
        }

        public String getReceiptType() {
            return receiptType;
        }

        public void setReceiptType(String receiptType) {
            this.receiptType = receiptType;
        }
    }

    /**
     * 票据打印状态 是 否
     */
    public enum RECEIPT_PRINT_STATUS{
        UNPRINTED("0"),
        PRINTED("1");
        private String printStatus;

        RECEIPT_PRINT_STATUS(String printStatus) {
            this.printStatus = printStatus;
        }

        public String getPrintStatus() {
            return printStatus;
        }

        public void setPrintStatus(String printStatus) {
            this.printStatus = printStatus;
        }
    }

    /**
     * 退款状态
     * 01- pending 提交申请
     * 02- approved 通过
     * 03- declined 拒绝
     */
    public enum REFUND_STATUS{

        REFUND_PENDING("01"),
        REFUND_APPROVED("02"),
        REFUND_DECLNED("03");

        private String status;

        REFUND_STATUS(String status) {
            this.status = status;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }
    }

    public static int getTopupLowestCredit() {
        return TOPUP_LOWEST_CREDIT;
    }

    public static String getTopupAccountNotExist() {
        return TOPUP_ACCOUNT_NOT_EXIST;
    }

    public static String getTopupamtOnceMinimumAlarm() {
        return TOPUPAMT_ONCE_MINIMUM_ALARM;
    }

    public static String getTopupamtOnceMaximumAlarm() {
        return TOPUPAMT_ONCE_MAXIMUM_ALARM;
    }

    public static String getTopupamtOnedayMaximumAlarm() {
        return TOPUPAMT_ONEDAY_MAXIMUM_ALARM;
    }

    public static String getTopupArrears() {
        return TOPUP_ARREARS;
    }

    public static String getTopupTxnstatusTopup() {
        return TOPUP_TXNSTATUS_TOPUP;
    }

    public static String getTopupReconstatusUnrecon() {
        return TOPUP_RECONSTATUS_UNRECON;
    }

    public static String getTopupPaymodeCreditcard() {
        return TOPUP_PAYMODE_CREDITCARD;
    }

    public static String getTopupCredittypeVisa() {
        return TOPUP_CREDITTYPE_VISA;
    }

    public static String getTopupCredittypeMastercard() {
        return TOPUP_CREDITTYPE_MASTERCARD;
    }

    public static String getTopupResultSuccess() {
        return TOPUP_RESULT_SUCCESS;
    }

    public static String getTopupResultFailed() {
        return TOPUP_RESULT_FAILED;
    }

    public static String getTopupUpdateFlagTopup() {
        return TOPUP_UPDATE_FLAG_TOPUP;
    }

    public static String getTopupAccnoNull() {
        return TOPUP_ACCNO_NULL;
    }

    public static String getTopupAmtNull() {
        return TOPUP_AMT_NULL;
    }

    public static String getTopupPaymodeNull() {
        return TOPUP_PAYMODE_NULL;
    }

    public static String getTopupVoucherNull() {
        return TOPUP_VOUCHER_NULL;
    }

    public static String getTopupAccstatusNotActivated() {
        return TOPUP_ACCSTATUS_NOT_ACTIVATED;
    }

    public static String getCustomerAccountStatusActivated() {
        return CUSTOMER_ACCOUNT_STATUS_ACTIVATED;
    }

    public static String getTopupMacNotMatch() {
        return TOPUP_MAC_NOT_MATCH;
    }

    public static String getTopupHaveArrears() {
        return TOPUP_HAVE_ARREARS;
    }

    public static String getTopupamtFormatErrorAlarm() {
        return TOPUPAMT_FORMAT_ERROR_ALARM;
    }
}
