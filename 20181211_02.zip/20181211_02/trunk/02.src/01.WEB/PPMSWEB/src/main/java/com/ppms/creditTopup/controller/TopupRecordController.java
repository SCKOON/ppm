package com.ppms.creditTopup.controller;

import com.alibaba.fastjson.JSONObject;
import com.constants.Constants;
import com.constants.SiteStatus;
import com.ppms.creditTopup.bean.ReceiptPrintObj;
import com.ppms.creditTopup.bean.TopupConstants;
import com.ppms.creditTopup.bean.TopupPreviewVO;
import com.ppms.creditTopup.dao.TopupDao;
import com.ppms.creditTopup.service.TopupRecordServiceI;
import com.ppms.dayendRecon.service.DayendReconServiceI;
import com.ppms.entity.*;
import com.ppms.ldapLogin.util.ResourceUtils;
import com.ppms.tstypeQuery.service.TstypeServiceI;
import com.ppms.utils.DataReturn;
import com.ppms.utils.GetClientIPUtil;
import com.ppms.utils.MathMoneyUtils;
import com.ppms.vo.*;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.util.DateUtils;
import org.jeecgframework.core.util.MyBeanUtils;
import org.jeecgframework.core.util.StringUtil;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.jeecgframework.web.system.pojo.base.TSType;
import org.jeecgframework.web.system.pojo.base.TSTypegroup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.*;

/**
 * @Title: 费用相关controller
 * @Description:
 * @author yadongliang
 * @date 2018-05-02 09:33:38
 * @version V1.0
 *
 */
@Controller
@RequestMapping("/topupRecordController")
public class TopupRecordController extends BaseController {

	private static final Logger logger = Logger.getLogger(TopupRecordController.class);

	@Autowired
	private TopupRecordServiceI topupRecordService;
	@Autowired
	private DayendReconServiceI dayendReconService;
	@Autowired
	private TstypeServiceI tstypeService;

	private String batchNoSuffix;

	public String getBatchNoSuffix() {
		return batchNoSuffix;
	}

	public void setBatchNoSuffix(String batchNoSuffix) {
		this.batchNoSuffix = batchNoSuffix;
	}

	/**
	 * @description: SP充值-主页面
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:36
	 */
	@RequestMapping(params = "topup")
	public ModelAndView topup(HttpServletRequest request) {
		ModelAndView modelAndView = new ModelAndView("ppms/paymentCollection/credit_topup");
		String payModeList = getPayModeList("PAY_MODE");
		modelAndView.addObject("payModeList",payModeList);
		return modelAndView;
	}

	/**
	 * @description: SP充值-客户信息多条件查询页面
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:36
	 */
	@RequestMapping(params = "detailQuery")
	public ModelAndView detailQuery(HttpServletRequest request) {
		String accountNo = request.getParameter("accountNo");
		ModelAndView mv = new ModelAndView("ppms/paymentCollection/search_condition");
		mv.addObject("accNo",accountNo);// 或mv.getModel().put("accNo",accountNo);
		return mv;
	}

	/*充值预览*/
	@RequestMapping(params = "topupPreview")
	public ModelAndView topupPreview(HttpServletRequest request) {
		TopupPreviewVO topupPreviewVO = topupRecordService.getPreviewVO(request);
		ModelAndView mv = new ModelAndView("ppms/paymentCollection/credit_topup_preview");
		mv.addObject("topupPreviewVO", topupPreviewVO);
		return mv;
	}

	/**
	 * @description: 客户充值记录查询-主页面 (用于柜台专员对账)
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:37
	 */
	@RequestMapping(params = "recordQuery")
	public ModelAndView recordQuery(HttpServletRequest request) {
		ModelAndView modelAndView = new ModelAndView("ppms/paymentCollection/topuprecord_query");
		modelAndView.addObject("counterList",getSelectCounter());
		modelAndView.addObject("terminalList",getSelectTerminal());
		return modelAndView;
	}

	/**
	 * @description: 客户充值记录查询-tab1
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:39
	 */
	@RequestMapping(params = "netBill")
	public ModelAndView netBill(HttpServletRequest request) {
		return new ModelAndView("ppms/paymentCollection/topuprecord_netbill");
	}

	/**
	 * @description: 客户充值记录查询-tab2
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:39
	 */
	@RequestMapping(params = "otherAccount")
	public ModelAndView otherAccount(HttpServletRequest request) {
		return new ModelAndView("ppms/paymentCollection/topuprecord_otheraccount");
	}

	/**
	 * @description: 冲正页面
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:39
	 */
	@RequestMapping(params = "recordReverse")
	public ModelAndView recordReverse(HttpServletRequest request) {
		ModelAndView modelAndView = new ModelAndView("ppms/paymentCollection/topuprecord_reverse");
		modelAndView.addObject("counterList",getSelectCounter());
		return modelAndView;
	}

	/**
	 * @description: 退款申请页面
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:39
	 */
	@RequestMapping(params = "refundApply")
	public ModelAndView refundApply(HttpServletRequest request) {
		return new ModelAndView("ppms/paymentCollection/refund_apply");
	}

	/**
	 * @description: 退款批准页面
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:39
	 */
	@RequestMapping(params = "refundApproval")
	public ModelAndView refundApproval(HttpServletRequest request) {
		return new ModelAndView("ppms/paymentCollection/refund_approval");
	}

	/**
	 * @description: 凭证重打页面
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:40
	 */
	@RequestMapping(params = "receiptReprint")
	public ModelAndView receiptReprint(HttpServletRequest request) {
		return new ModelAndView("ppms/paymentCollection/receipt_reprint");
	}

	/*================================================================================*/

	/**
	 * @description: 充值页面-离焦查询用户电表及其他信息
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:29
	 */
	@RequestMapping(params = "getCustInfo")
	@ResponseBody
	public ResultVo getCustInfo(HttpServletRequest request) {
		ResultVo custInfo = topupRecordService.getCustInfo(request);
		return custInfo;
	}

	/**
	 * @description: 充值-充值记录查询(ca和sp)
	 * @auther: liangyadong
	 * @date: 2018/9/29 0029 下午 5:32
	 */
	@RequestMapping(params = "datagrid")
	public void datagrid(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
		this.topupRecordService.getCreditTopupRec(dataGrid,request);
		TagUtil.datagrid(response, dataGrid);
	}

	/**
	 * @description: 客户详情信息-充值界面查询用户信息(弹框查询Query)
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 下午 4:46
	 */
	@RequestMapping(params = "definedDatagrid")
	public void definedDatagrid(ResultVo resultVo, HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
		DataReturn dataReturn = this.topupRecordService.getAllEntities(resultVo,dataGrid.getPage(),dataGrid.getRows(),request);
		dataGrid.setResults(dataReturn.getRows());
		dataGrid.setTotal((int)dataReturn.getTotal());
		TagUtil.datagrid(response, dataGrid);
	}

	/**
	 * @description: 冲正/充值记录查询-充值记录查询
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:15
	 */
	@RequestMapping(params = "recordDefinedDatagrid")
	public void recordDefinedDatagrid(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
		try {
			this.topupRecordService.getTopupRecord(dataGrid,request);
			if (dataGrid.getResults() != null && dataGrid.getResults().size() > 0) {
				List<SpTopUpRecEntity> list = dataGrid.getResults();
				List<SpTopupRecordVo> dtoList = new LinkedList<>();
				for (SpTopUpRecEntity entity : list) {
					SpTopupRecordVo vo = new SpTopupRecordVo();
					MyBeanUtils.copyBeanNotNull2Bean(entity, vo);
					dtoList.add(vo);
				}
				dataGrid.setResults(dtoList);
			}
		} catch (Exception e) {
			logger.error(e);
		}
		TagUtil.datagrid(response, dataGrid);
	}

	/*冲正前校验*/
	@RequestMapping(params = "reverseValid")
	@ResponseBody
	public AjaxJson reverseValid(HttpServletRequest request) {
		String message = "";
		AjaxJson j = new AjaxJson();
		j.setSuccess(true);
		String curLoginName = ResourceUtils.getSessionUser().getName();
		String refNo = request.getParameter("refNo");//根据refNo查询充值记录
		SpTopUpRecEntity topupRecordEntity = topupRecordService.getTopupRecordByRefNo(refNo);
		if (topupRecordEntity != null) {
			//非本人不允许reverse
			/*String cashierId = topupRecordEntity.getCashierId();
			if(!cashierId.equals(curLoginName)){
				j.setSuccess(false);
				j.setMsg("");
				return j;
			}*/

			// 冲正状态校验 拒绝重复冲正
			/*01- Top-up
			02- 已冲正
			03- reverse
			04- 对账补入
			05- 对账删除*/
			String databseTxnStatus = topupRecordEntity.getTxnStatus();
			if (databseTxnStatus.equals(TopupConstants.TXN_STATUS.TOPUP.getTxnStatus())) {//交易类型为topup
				// 批次号校验 仅限topup当日YYYYMMDD+01
				String databaseBatchNo = topupRecordEntity.getBatchNo();
				String batchNoDate = databaseBatchNo.substring(0, 8);
				String systemDate = DateUtils.date2Str(new Date(), DateUtils.yyyyMMdd);
				if (oConvertUtils.isNotEmpty(databaseBatchNo) && batchNoDate.equals(systemDate)) {//当前批次
					String databaseReconStatus = topupRecordEntity.getReconStatus();
					if (databaseReconStatus != null && databaseReconStatus.equals(TopupConstants.RECON_STATUS.RECON_SUCCESS.getReconStatus())) {
						message = TopupConstants.REVERSE_STATUS.REVERSE_HAVE_RECON.getStatus();//本批次已完成对账,拒绝冲正
						j.setSuccess(false);
						j.setMsg(message);
						return j;
					}
				} else {
					message = TopupConstants.REVERSE_STATUS.REVERSE_NOT_CURRENT_BATCH.getStatus();//非当前批次,拒绝冲正
					j.setSuccess(false);
					j.setMsg(message);
					return j;
				}
			} else {
				message = TopupConstants.REVERSE_STATUS.REVERSE_HAVE_REVERSED.getStatus();//已完成冲正,拒绝重复冲正
				j.setSuccess(false);
				j.setMsg(message);
				return j;
			}

//		else if(databseTxnStatus.equals(TopupConstants.TXN_STATUS.REVERSED.getTxnStatus())||databseTxnStatus.equals(TopupConstants.TXN_STATUS.REVERSE.getTxnStatus())){
//			message = TopupConstants.REVERSE_STATUS.REVERSE_HAVE_REVERSED.getStatus();//已完成冲正,拒绝重复冲正
//			j.setSuccess(false);
//			j.setMsg(message);
//			return j;
//		} else {
//			message = TopupConstants.REVERSE_STATUS.REVERSE_OTHER_STATUS.getStatus();//其他冲正状态,请联系管理员(对账补入,对账删除)
//			j.setSuccess(false);
//			j.setMsg(message);
//			return j;
//		}
		} else {
			j.setSuccess(false);
			j.setMsg("System error.");
			return j;
		}

		j.setMsg(message);
		return j;

	}

	/**
	 * @description: 冲正
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:32
	 */
	@RequestMapping(params = "reverse")
	@ResponseBody
	public AjaxJson reverse(HttpServletRequest request) {
		String message = "";
		AjaxJson j = new AjaxJson();
		message = this.topupRecordService.doReverse(request);
		j.setMsg(message);
		return j;
	}

	/**
	 * @description: 凭证打印
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:41
	 */
	@RequestMapping(params = "receiptPrint")
	public ModelAndView receiptPrint(HttpServletRequest request) {
		//1.查询缴费记录表中信息
		String refNo = request.getParameter("refNo");
		SpTopUpRecEntity topupRecordEntity = getSpTopUpRecEntity(refNo);
		//2.查询receipt_info表中信息,查询打印次数
		String printTimes = getPrintTimes(refNo);
		//3.封装查询结果
		ReceiptPrintObj printObj = getReceiptPrintObj(topupRecordEntity, printTimes);
		ModelAndView modelAndView = new ModelAndView("ppms/paymentCollection/receipt_print");
		modelAndView.addObject("printObj",printObj);
		return modelAndView;
	}

	private SpTopUpRecEntity getSpTopUpRecEntity(String refNo) {
        return topupRecordService.getTopupRecordByRefNo(refNo);
	}

	private String getPrintTimes(String refNo) {
		String printTimes = "RECEIPT";
		ReceiptInfoEntity receiptInfoEntity = new ReceiptInfoEntity();
		receiptInfoEntity.setRefNo(refNo);
		ReceiptInfoEntity receiptInfo = getReceiptInfo(receiptInfoEntity);
		if(oConvertUtils.isNotEmpty(receiptInfo)&&oConvertUtils.isNotEmpty(receiptInfo.getPrintTimes())){
			String sprintTimes = receiptInfo.getPrintTimes();
			BigDecimal times = new BigDecimal(sprintTimes);
			if(times.compareTo(new BigDecimal(1))==1){
				printTimes = "DUPLICATE RECEIPT";
			}
		}
		return printTimes;
	}

	public ReceiptInfoEntity getReceiptInfo(ReceiptInfoEntity receiptInfoEntity) {
		return this.topupRecordService.getReceiptInfo(receiptInfoEntity);
	}

	private ReceiptPrintObj getReceiptPrintObj(SpTopUpRecEntity topupRecordEntity, String printTimes) {
		ReceiptPrintObj printObj = new ReceiptPrintObj();
		printObj.setPrintTimes(printTimes);
		printObj.setRefNo(topupRecordEntity.getRefNo());
		String txnStatus = topupRecordEntity.getTxnStatus();
		String txnstatusName = "";
		String txnstatusId = tstypeService.getGroupIdByGroupCode("PAYMENT_TYPE");
		List<Map<String, Object>> txnstatusList = tstypeService.getTypeCodeAndNameByGroupId(txnstatusId);
		for(Map map : txnstatusList){
			if(txnStatus.equals(map.get("code"))){
				txnstatusName = map.get("name").toString();
			}
		}
		printObj.setTxnStatus(txnstatusName);
		printObj.setArrearAmt(topupRecordEntity.getArrearAmt());
		printObj.setPrepaidAmt(topupRecordEntity.getPrepaidAmt());
		printObj.setTopupAmt(topupRecordEntity.getTopupAmt());
		printObj.setTxnDate(topupRecordEntity.getTxnDate());
		printObj.setCashierId(topupRecordEntity.getCashierId());
		String channelCode = topupRecordEntity.getChannelCode();
		String channelName = tstypeService.getChannelNameByChannelCode(channelCode);
		printObj.setChannelCode(channelName);
		String tmnlCode = topupRecordEntity.getTmnlCode();
		String tmnlName = tstypeService.getTmnlNameByTmnlCode(tmnlCode);
		String counterId = topupRecordEntity.getCounterId();
		String counterName = tstypeService.getCounterNameByCounterCode(counterId);
		printObj.setTmnlCode(tmnlName);
		printObj.setCounterId(counterName);
		String payMode = topupRecordEntity.getPayMode();
		String paymodeName = "";
		String paymodeId = tstypeService.getGroupIdByGroupCode("PAY_MODE");
		List<Map<String, Object>> paymodeList = tstypeService.getTypeCodeAndNameByGroupId(paymodeId);
		for(Map map : paymodeList){
			if(payMode.equals(map.get("code"))){
				paymodeName = map.get("name").toString();
			}
		}
		printObj.setPayMode(paymodeName);
		printObj.setAccNo(topupRecordEntity.getAccNo());
		printObj.setRefNo(topupRecordEntity.getRefNo());
		return printObj;
	}

	/**
	 * @description: 冲正-更改txn_status
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:32
	 */
	@RequestMapping(params = "updateTxnStatus")
	@ResponseBody
	public Integer updateTxnStatus(SpTopUpRecEntity topupRecord, String status) throws Exception {
		return topupRecordService.updateTxnStatus(topupRecord,status);
	}

	/**
	 * @description: 退款申请页面Datagrid
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 下午 4:46
	 */
	@RequestMapping(params = "refundApplyDatagrid")
	public void refundApplyDatagrid(CustomerInfoDTO dto, AccountBalanceVo accountBalanceVo, HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
		CustomerInfoEntity customerInfoEntity = new CustomerInfoEntity();
		AcctBalEntity acctBalEntity = new AcctBalEntity();
		try {
			MyBeanUtils.copyBeanNotNull2Bean(accountBalanceVo, acctBalEntity);
			MyBeanUtils.copyBeanNotNull2Bean(dto, customerInfoEntity);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		DataReturn dataReturn = this.topupRecordService.getCustomerInfo(customerInfoEntity,acctBalEntity,dataGrid.getPage(),dataGrid.getRows(),request);
		dataGrid.setResults(dataReturn.getRows());
		dataGrid.setTotal((int)dataReturn.getTotal());
		TagUtil.datagrid(response, dataGrid);
	}

	/**
	 * @description: 退款申请
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:33
	 */
	@RequestMapping(params = "doApply")
	@ResponseBody
	public String transferAmount(RefundRecordEntity refundRecordEntity, HttpServletRequest request) {
		String message = topupRecordService.refundApply(refundRecordEntity, request);
		return message;
	}

	/**
	 * @description: 退款审批页面Datagrid
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 下午 4:41
	 */
	@RequestMapping(params = "refundApprovalDatagrid")
	public void refundApprovalDatagrid(RefundRecordVo refundRecordVo, CustomerInfoDTO dto, HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
		RefundRecordEntity refundRecordEntity = new RefundRecordEntity();
		CustomerInfoEntity customerInfoEntity = new CustomerInfoEntity();
		try {
			MyBeanUtils.copyBeanNotNull2Bean(refundRecordVo, refundRecordEntity);
			MyBeanUtils.copyBeanNotNull2Bean(dto, customerInfoEntity);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		DataReturn dataReturn = this.topupRecordService.getRefundApplyDatagrid(refundRecordEntity,customerInfoEntity,dataGrid.getPage(),dataGrid.getRows(),request);
		dataGrid.setResults(dataReturn.getRows());
		dataGrid.setTotal((int)dataReturn.getTotal());
		TagUtil.datagrid(response, dataGrid);
	}

	/**
	 * @description: 退款审批
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 下午 4:29
	 */
	@RequestMapping(params = "doApproval")
	@ResponseBody
	public String doApproval(HttpServletRequest request) {
		String message = topupRecordService.refundApproval(request);
		return message;
	}

	/**
	 * @description: 凭证打印列表查询
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 下午 4:28
	 */
	@RequestMapping(params = "receiptPrintDatagrid")
	public void receiptPrintDatagrid(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
		this.topupRecordService.getReceiptPrintDatagrid(request,dataGrid);
		TagUtil.datagrid(response, dataGrid);
	}

	/**
	 * @description: 打印收据 更新receipt_info
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 下午 4:28
	 */
	@RequestMapping(params = "updateReceiptInfo")
    @ResponseBody
	public void updateReceiptInfo(HttpServletRequest request) {
		topupRecordService.updateReceiptInfo(request);
	}

	/*校验充值金额限额*/
	@RequestMapping(params = "validAmount")
	@ResponseBody
	public AjaxJson validAmount(SpTopupRecordVo spTopupRecordVo, HttpServletRequest request, HttpServletResponse response) {
		AjaxJson json = new AjaxJson();
		json.setSuccess(true);
		String message = TopupConstants.getTopupResultSuccess();
		SpTopUpRecEntity topupRecordEntity = new SpTopUpRecEntity();
		try {
			MyBeanUtils.copyBeanNotNull2Bean(spTopupRecordVo, topupRecordEntity);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}

		//accNo自动补齐
		String accountNo = oConvertUtils.getString(request.getParameter("accountNo"));
		if(accountNo.length()==10){
			accountNo+="P";
		}

		//权限校验 是否有充值权限
		String clientIP = GetClientIPUtil.getIpAddr(request);
		if(StringUtil.isEmpty(clientIP)){
			json.setSuccess(false);
			json.setMsg("Unauthorized terminal.");
			return json;
		}
		CounterEntity counterInfo = topupRecordService.getCounterByIP(clientIP);
		if(counterInfo != null){
			String counterCode = counterInfo.getCode();
			if(!StringUtil.isEmpty(counterCode)){
				topupRecordEntity.setCounterId(counterCode);
			}
			TerminalEntity terminalEntity = counterInfo.getTerminalEntity();
			if(terminalEntity != null && (!StringUtil.isEmpty(terminalEntity.getCode()))){
				topupRecordEntity.setTmnlCode(terminalEntity.getCode());
				ChannelEntity channelEntity = terminalEntity.getChannelEntity();
				if(channelEntity != null && (!StringUtil.isEmpty(channelEntity.getCode()))){
					topupRecordEntity.setChannelCode(channelEntity.getCode());
				}else{
					message = "The SP Group information [" + topupRecordEntity.getAccNo() + "]  in PPMS do not exist. Please contact PPMS administrator.";
					json.setSuccess(false);
					json.setMsg(message);
					return json;
				}
			}else{
				message = "The terminal information [" + topupRecordEntity.getAccNo() + "]  in PPMS do not exist. Please contact PPMS administrator.";
				json.setMsg(message);
				json.setSuccess(false);
				return json;
			}
		} else {
			json.setSuccess(false);
			json.setMsg(TopupConstants.getTopupMacNotMatch());
			return json;
		}

		//金额格式校验, 是否是数值, 是否大于0, 是否是整数金额, 形如1.00
		String samount = request.getParameter("amount");
		boolean valid = MathMoneyUtils.isValid(samount);
		if(!valid){
			message = TopupConstants.getTopupamtFormatErrorAlarm();
			json.setMsg(message);
			json.setSuccess(false);
			return json;
		}

		BigDecimal amount = new BigDecimal(oConvertUtils.getString(request.getParameter("amount")));
		/*充值限值校验*/
		Map<String,Object> map = new HashMap<String,Object>();
		Date txnDate = new Date();
		String strDate = DateUtils.formatDate(txnDate, Constants.SIMPLE_YYYY_MM_DD);
		String batchNo = strDate + "01";//批次号:日期+01
		topupRecordEntity.setBatchNo(batchNo);
		map = checkTopupAmt(accountNo, amount, batchNo);
		if(!(Boolean)map.get(Constants.RETURN_STATUS)){
			message = map.get(Constants.ERROR_MSG).toString();
			json.setMsg(message);
			json.setSuccess(false);
			return json;
		}

		//校验账户是否存在
		CustomerInfoEntity customerInfoEntity = topupRecordService.get(CustomerInfoEntity.class, accountNo);
		if(customerInfoEntity == null){
			message = TopupConstants.getTopupAccountNotExist();
			json.setMsg(message);
			json.setSuccess(false);
			return json;
		}
		//校验账户是否激活
		boolean flag = this.topupRecordService.checkActiveOrNot(customerInfoEntity);
		if (false == flag) {
			message = TopupConstants.getTopupAccstatusNotActivated();
			json.setMsg(message);
			json.setSuccess(false);
			return json;
		}

		return json;
	}

	/**
	 * @description: 充值
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:33
	 */
	@RequestMapping(params = "doTopup")
	@ResponseBody
	public AjaxJson doTopup(SpTopupRecordVo spTopupRecordVo, HttpServletRequest request, HttpServletResponse response) {
		AjaxJson json = new AjaxJson();
		json.setSuccess(false);
		String message = TopupConstants.getTopupResultSuccess();
		SpTopUpRecEntity topupRecordEntity = new SpTopUpRecEntity();
		try {
			MyBeanUtils.copyBeanNotNull2Bean(spTopupRecordVo, topupRecordEntity);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		String accountNo = oConvertUtils.getString(request.getParameter("accountNo"));

		if(accountNo.length()==10){
			accountNo+="P";
		}
		String samount = request.getParameter("amount");
		//金额格式校验, 是否是数值, 是否大于0, 是否是整数金额, 形如1.00
		boolean valid = MathMoneyUtils.isValid(samount);
		if(!valid){
			message = TopupConstants.getTopupamtFormatErrorAlarm();
			json.setMsg(message);
			return json;
		}

		BigDecimal amount = new BigDecimal(oConvertUtils.getString(request.getParameter("amount")));

		/*充值限值校验*/
		Map<String,Object> map = new HashMap<String,Object>();
		Date txnDate = new Date();
		String strDate = DateUtils.formatDate(txnDate, Constants.SIMPLE_YYYY_MM_DD);
		String batchNo = strDate + this.batchNoSuffix;//批次号:日期+01
		topupRecordEntity.setBatchNo(batchNo);
		map = checkTopupAmt(accountNo, amount, batchNo);
		if(!(Boolean)map.get(Constants.RETURN_STATUS)){
			message = map.get(Constants.ERROR_MSG).toString();
			json.setMsg(message);
			return json;
		}

		String paymentMode = oConvertUtils.getString(request.getParameter("paymentMode"));
		String payNo = oConvertUtils.getString(request.getParameter("payNo"));
		CustomerInfoEntity customerInfoEntity = topupRecordService.get(CustomerInfoEntity.class, accountNo);
		//校验账户是否存在
		if(customerInfoEntity == null){
			message = TopupConstants.getTopupAccountNotExist();
			json.setMsg(message);
			return json;
		}
		//校验账户是否激活
		boolean flag = this.topupRecordService.checkActiveOrNot(customerInfoEntity);
		if (false == flag) {
			message = TopupConstants.getTopupAccstatusNotActivated();
			json.setMsg(message);
			return json;
		}

		//执行充值
		topupRecordEntity.setAccNo(accountNo);
		topupRecordEntity.setTopupAmt(amount);
		topupRecordEntity.setPayMode(paymentMode);
		topupRecordEntity.setPayNo(payNo);
		try {
			String clientIP = GetClientIPUtil.getIpAddr(request);
			map = this.topupRecordService.topup(topupRecordEntity,clientIP,customerInfoEntity);
			if((boolean)map.get(Constants.RETURN_STATUS)){
				json.setSuccess(true);
				json.setObj(map.get("refNo"));
			}else{
				message = (String)map.get(Constants.ERROR_MSG);
				json.setMsg(message);
				return json;
			}
		}catch (Exception e){
			message = e.getMessage();
			json.setMsg(message);
		}

		return json;
	}

	public String getPayModeList(String payMode){
		String groupId = getGroupIdByGroupCode(payMode);
		String typeCodeAndName = getTypeCodeAndNameByGroupId3(groupId);
		return typeCodeAndName;
	}

	/**
	 * @description: 查询counter信息(激活状态的counter信息)
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:28
	 */
	private String getSelectCounter(){
		CriteriaQuery cq = new CriteriaQuery(CounterEntity.class);
		cq.eq("status", SiteStatus.ACTIVE.getStatus());
		cq.add();
		List<CounterEntity> counterEntityList = this.topupRecordService.getListByCriteriaQuery(cq, false);
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		if (counterEntityList != null && counterEntityList.size() > 0) {
			for (CounterEntity counterEntity : counterEntityList) {
				Map map = new HashMap();
				String counterCode = counterEntity.getCode();
				String counterName = counterEntity.getName();
				map.put("code",counterCode);
				map.put("name",counterName);
				list.add(map);
			}
		}
		return JSONObject.toJSONString(list);
	}

	/**
	 * @description: 查询terminal信息(激活状态的terminal信息)
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:29
	 */
	private String getSelectTerminal(){
		CriteriaQuery cq = new CriteriaQuery(TerminalEntity.class);
		cq.eq("status", SiteStatus.ACTIVE.getStatus());
		cq.add();
		List<TerminalEntity> terminalEntityList = this.topupRecordService.getListByCriteriaQuery(cq, false);
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		if (terminalEntityList != null && terminalEntityList.size() > 0) {
			for (TerminalEntity terminalEntity : terminalEntityList) {
				Map map = new HashMap();
				String terminalCode = terminalEntity.getCode();
				String terminalName = terminalEntity.getName();
				map.put("code",terminalCode);
				map.put("name",terminalName);
				list.add(map);
			}
		}
		return JSONObject.toJSONString(list);
	}

	/**
	 * 根据groupName查询groupId
	 */
	public String getGroupIdByGroupCode(String typegroupcode){
		String typeGroupId = "";
		CriteriaQuery criteriaQuery = new CriteriaQuery(TSTypegroup.class);
		criteriaQuery.eq("typegroupcode",typegroupcode);
		criteriaQuery.add();
		List<TSTypegroup> tsTypegroupList = this.dayendReconService.getTstypeGroupList(criteriaQuery);
		if (tsTypegroupList!=null&&tsTypegroupList.size()>0){
			TSTypegroup tsTypegroup = tsTypegroupList.get(0);
			typeGroupId = tsTypegroup.getId();
		}

		return typeGroupId;
	}

	/**
	 * @description: 根据groupId查询groupCode和groupName(多个) 初始化paymode
	 * @auther: liangyadong
	 * @date: 2018/9/30 0030 上午 10:25
	 */
	public String getTypeCodeAndNameByGroupId3(String typeGroupId) {
		CriteriaQuery criteriaQuery = new CriteriaQuery(TSType.class);
		criteriaQuery.eq("TSTypegroup.id", typeGroupId);
		criteriaQuery.add();
		List<TSType> tsTypeList = this.dayendReconService.getTstypeList(criteriaQuery);
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		if (tsTypeList != null && tsTypeList.size() > 0) {
			for (TSType tsType : tsTypeList) {
				Map map = new HashMap();
				String typecode = tsType.getTypecode();
				String typename = tsType.getTypename();
				if(typecode.equals("01")||typecode.equals("02")||typecode.equals("03")||typecode.equals("04")||typecode.equals("05")||typecode.equals("06")){
					map.put("code",typecode);
					map.put("name",typename);
					list.add(map);
				}
			}
		}

		return JSONObject.toJSONString(list);
	}

	/*充值限额校验*/
	/**
	 * 缴费金额校验
	 * @param accNo 充值账户
	 * @param topupAmt 本次充值金额
	 * @return 提示信息
	 */
	public Map<String,Object> checkTopupAmt(String accNo, BigDecimal topupAmt, String batchNo){
		String msg = "";
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(Constants.RETURN_STATUS,false);

		String sminTopupAmt = getTopupAlmAmt("MIN_TOPUP_AMT");
		String smaxTopupAmt = getTopupAlmAmt("MAX_TOPUP_AMT");
		String smaxTopupAmt1Day = getTopupAlmAmt("DAILY_MAX_AMT");

		BigDecimal minTopupAmt = null;
		BigDecimal maxTopupAmt = null;
		BigDecimal maxTopupAmt1Day = null;

		if(oConvertUtils.isNotEmpty(sminTopupAmt)){
			minTopupAmt = new BigDecimal(sminTopupAmt);
		}else {
			msg = "Get MIN_TOPUP_AMT failure.";
			logger.error(msg);
			throw new NullPointerException(msg);
		}
		if(oConvertUtils.isNotEmpty(smaxTopupAmt)){
			maxTopupAmt = new BigDecimal(smaxTopupAmt);
		}else {
			msg = "Get MAX_TOPUP_AMT failure.";
			logger.error(msg);
			throw new NullPointerException(msg);
		}
		if(oConvertUtils.isNotEmpty(smaxTopupAmt1Day)){
			maxTopupAmt1Day = new BigDecimal(smaxTopupAmt1Day);
		}else {
			msg = "Get DAILY_MAX_AMT failure.";
			logger.error(msg);
			throw new NullPointerException(msg);
		}

		//当前缴费金额<最小允许缴费金额
		if (topupAmt.compareTo(minTopupAmt) == -1) {
			String minmsg = "Lower than acceptable minmum top-up amount. <br>Top up [SGD" + sminTopupAmt + "] - [SGD" + smaxTopupAmt + "].";
			map.put(Constants.ERROR_MSG,minmsg);
			return map;
		}
		//当前缴费金额>最大允许缴费金额
		if (topupAmt.compareTo(maxTopupAmt) == 1) {
			String maxmsg = "Higer than acceptable maximum top-up amount. <br>Top up [SGD" + sminTopupAmt + "] - [SGD" + smaxTopupAmt + "].";
			map.put(Constants.ERROR_MSG,maxmsg);
			return map;
		}
		//查询该账户当日总的充值金额
		BigDecimal oneDayTopupAmt = topupRecordService.getOneDayTopupAmt(accNo, batchNo);
		//当当前缴费金额>日允许的最大缴费金额
		if(oneDayTopupAmt.add(topupAmt).compareTo(maxTopupAmt1Day) == 1){
			String dailymsg = "Exceed cumulative top-up amount [SGD" + smaxTopupAmt1Day + "] for today.";
			map.put(Constants.ERROR_MSG,dailymsg);
			return map;
		}

		map.put(Constants.RETURN_STATUS,true);
		return map;
	}

	/*查询充值金额限值*/
	public String getTopupAlmAmt(String typeGroupCode){
		return tstypeService.getTopupAmtAlmValue(typeGroupCode);
	}
}
