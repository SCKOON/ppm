package com.ppms.codeAndNameChange.service.impl;

import com.ppms.codeAndNameChange.service.ChangeServiceI;
import org.jeecgframework.core.common.service.impl.CommonServiceImpl;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @Author: liangyadong
 * @Date: 2018/12/7 0007 20:31
 * @Description:
 */
@Service
public class ChangeServiceImpl extends CommonServiceImpl implements ChangeServiceI {

    @Override
    public String getTmnlNameByCode(List<Map<String, String>> tmnlMapList, String tmnlCode) {
        String tmnlName = "--";
        if (tmnlMapList != null && tmnlMapList.size() > 0) {
            for (Map<String, String> tmnlMap : tmnlMapList) {
                String code = tmnlMap.get("code");
                if(oConvertUtils.isNotEmpty(code)&&code.equals(tmnlCode)){
                    tmnlName = tmnlMap.get("name");
                }
            }
        }
        return tmnlName;
    }

    @Override
    public String getCounterNameByCode(List<Map<String, String>> counterMapList, String counterCode) {
        String counterName = "--";
        if (counterMapList != null && counterMapList.size() > 0) {
            for (Map<String, String> counterMap : counterMapList) {
                String code = counterMap.get("code");
                if(oConvertUtils.isNotEmpty(code)&&code.equals(counterCode)){
                    counterName = counterMap.get("name");
                }
            }
        }
        return counterName;
    }
}
