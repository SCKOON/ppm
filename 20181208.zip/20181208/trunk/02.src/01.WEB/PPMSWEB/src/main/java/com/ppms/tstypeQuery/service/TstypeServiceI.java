package com.ppms.tstypeQuery.service;

import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.service.CommonService;

import java.util.List;
import java.util.Map;

/**
 * Created by liangyadong on 2018/9/18 0018.
 */
public interface TstypeServiceI extends CommonService {
    List getTstypeList(CriteriaQuery cq);

    String getGroupIdByGroupCode(String typegroupcode);

    String getTypeNameByCode(String typeCode);

    List<Map<String, Object>> getTypeCodeAndNameByGroupId(String typeGroupId);

    String getCounterNameByCounterCode(String counterCode);

    String getTmnlNameByTmnlCode(String tmnlCode);

    String getChannelNameByChannelCode(String channelCode);

    String getTypeNameByGroupCodeAndTypeCode(String groupCode, String typeCode);

    String getTopupAmtAlmValue(String typeGroupCode);
}
