package com.ppms.codeAndNameChange.service;

import java.util.List;
import java.util.Map;

/**
 * @Author: liangyadong
 * @Date: 2018/12/7 0007 20:21
 * @Description:
 */
public interface ChangeServiceI {
    String getTmnlNameByCode(List<Map<String, String>> tmnlMapList, String tmnlCode);

    String getCounterNameByCode(List<Map<String, String>> counterMapList, String counterCode);
}
