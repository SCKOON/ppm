package com.constants;

/**
 * Created by liangyadong on 2018/8/17 0017.
 */
public class CAReconConstants {

    /**
     * 对账审批操作提示信息
     */
    public enum CA_RECON_TIP_MESSAGE{
        OPERATION_SUCCESS("Operation succeed."),
        OPERATION_FAILED("System error. Please try it again."),
        PLEASE_SELECT_ITEM("Please select one item."),
        APPROVED_FAILED_UPDATE_RECORD("Cannot approve as record updation failed.");
        private String message;

        CA_RECON_TIP_MESSAGE(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }

    }

    /**
     * abnormalRecord disctype
     */
    public enum DISC_TYPE{
        ADD("01"),
        DELETE("02"),
        DISCREPANCY("03");

        private String discType;

        DISC_TYPE(String discType) {
            this.discType = discType;
        }

        public String getDiscType() {
            return discType;
        }

    }

    /**
     * CA Recon申请状态
     */
    public enum APPLY_STATUS{
        PENDING("01"),
        APPROVED("02"),
        DECLINED("03");

        private String applyStatus;

        APPLY_STATUS(String applyStatus) {
            this.applyStatus = applyStatus;
        }

        public String getApplyStatus() {
            return applyStatus;
        }

    }

    /**
     * CA_TOP_UP交易类型
     */
    public enum TXN_STATUS{
        RECON_DELETE("05");//对账删除
        private String TxnStatus;

        TXN_STATUS(String txnStatus) {
            TxnStatus = txnStatus;
        }

        public String getTxnStatus() {
            return TxnStatus;
        }

    }

}
