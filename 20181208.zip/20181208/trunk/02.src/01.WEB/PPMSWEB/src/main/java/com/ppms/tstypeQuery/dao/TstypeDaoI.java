package com.ppms.tstypeQuery.dao;

import java.math.BigDecimal;

/**
 * Created by liangyadong on 2018/9/18 0018.
 */
public interface TstypeDaoI {
    String getCounterNameByCounterCode(String counterCode);

    String getTmnlNameByTmnlCode(String tmnlCode);

    String getChannelNameByChannelCode(String channelCode);

    String getTypeNameByGroupCodeAndTypeCode(String groupCode, String typeCode);

    /*充值金额限值*/
    String getTopupAmtAlmValue(String typeGroupCode);
}
