package com.ppms.tstypeQuery.dao.impl;

import com.ppms.entity.ChannelEntity;
import com.ppms.entity.CounterEntity;
import com.ppms.entity.TerminalEntity;
import com.ppms.tstypeQuery.dao.TstypeDaoI;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.jeecgframework.core.common.dao.impl.GenericBaseCommonDao;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liangyadong on 2018/9/18 0018.
 */
@Repository
public class TstypeDaoImpl extends GenericBaseCommonDao implements TstypeDaoI{
    @Override
    public String getCounterNameByCounterCode(String counterCode) {
        StringBuilder hql = new StringBuilder("from CounterEntity where code = ?");
        ArrayList params = new ArrayList();
        params.add(counterCode);
        String hqlQuery = hql.toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List<CounterEntity> counterEntityList = q.list();
        String counterName = "";
        if(counterEntityList!=null&&counterEntityList.size()>0){
            for(CounterEntity counterEntity : counterEntityList){
                counterName = counterEntity.getName();
            }
        }
        return counterName;
    }

    @Override
    public String getTmnlNameByTmnlCode(String tmnlCode) {
        StringBuilder hql = new StringBuilder("from TerminalEntity where code = ?");
        ArrayList params = new ArrayList();
        params.add(tmnlCode);
        String hqlQuery = hql.toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List<TerminalEntity> terminalEntityList = q.list();
        String tmnlName = "";
        if(terminalEntityList!=null&&terminalEntityList.size()>0){
            for(TerminalEntity terminalEntity : terminalEntityList){
                tmnlName = terminalEntity.getName();
            }
        }
        return tmnlName;
    }

    @Override
    public String getChannelNameByChannelCode(String channelCode) {
        StringBuilder hql = new StringBuilder("from ChannelEntity where code = ?");
        ArrayList params = new ArrayList();
        params.add(channelCode);
        String hqlQuery = hql.toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List<ChannelEntity> channelEntityList = q.list();
        String channelName = "";
        if(channelEntityList!=null&&channelEntityList.size()>0){
            for(ChannelEntity channelEntity : channelEntityList){
                channelName = channelEntity.getName();
            }
        }
        return channelName;
    }

    @Override
    public String getTypeNameByGroupCodeAndTypeCode(String groupCode, String typeCode) {
        String typeName = "";
        StringBuilder sql = new StringBuilder(
                " SELECT " +
                " showname " +
                " FROM " +
                "     ( " +
                "         SELECT " +
                "         typecode, " +
                "         showname " +
                "         FROM " +
                "         t_s_type " +
                "         WHERE " +
                "         typegroupid = ( " +
                "                 SELECT " +
                "         id " +
                "         FROM " +
                "         t_s_typegroup " +
                "         WHERE " +
                "         typegroupcode = ? " +
                "     ) " +
                " ) a " +
                "     WHERE " +
                " a.typecode = ? "
        );

        Query query = super.getSession().createSQLQuery(sql.toString());
        query.setParameter(0, groupCode);
        query.setParameter(1, typeCode);
        List list = query.list();
        if(list!=null&&list.size()>0){
            typeName = list.get(0).toString();
        }

        return typeName;
    }

    @Override
    public String getTopupAmtAlmValue(String typeGroupCode) {
        String value = null;
        String sql =
            " SELECT " +
            " s.typecode " +
            " FROM " +
            " t_s_type s " +
            " WHERE " +
            " s.typegroupid = ( " +
            " SELECT " +
            " t.id " +
            " FROM " +
            " t_s_typegroup t " +
            " WHERE " +
            " t.typegroupcode =:typeGroupCode ) " ;

        Map<String, String> map = new HashMap();
        if(oConvertUtils.isNotEmpty(typeGroupCode)){
            map.put("typeGroupCode",typeGroupCode);
        }
        Query query = getSession().createSQLQuery(sql);
        query.setProperties(map);
        List list = query.list();
        if(list!=null&&list.size()>0){
            Object obj = list.get(0);
            value = oConvertUtils.isEmpty(obj)?"":obj.toString();
        }

        return value;
    }
}
