package com.ppms.creditTopup.service.impl;

import com.constants.Constants;
import com.constants.ReconStatusEnum;
import com.ppms.codeAndNameChange.dao.ChangeDaoI;
import com.ppms.codeAndNameChange.service.ChangeServiceI;
import com.ppms.connection.dao.ConnectionDao;
import com.ppms.creditTopup.bean.ReverseVo;
import com.ppms.creditTopup.bean.TopupConstants;
import com.ppms.creditTopup.bean.TopupPreviewVO;
import com.ppms.creditTopup.dao.TopupDao;
import com.ppms.creditTopup.service.TopupRecordServiceI;
import com.ppms.customerInfo.dao.CustomerManageDao;
import com.ppms.dict.CacheDao;
import com.ppms.entity.*;
import com.ppms.ldapLogin.util.ResourceUtils;
import com.ppms.sms.service.SmsService;
import com.ppms.tstypeQuery.dao.TstypeDaoI;
import com.ppms.tstypeQuery.service.TstypeServiceI;
import com.ppms.utils.*;
import com.ppms.vo.*;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.common.service.impl.CommonServiceImpl;
import org.jeecgframework.core.extend.datasource.DataSourceType;
import org.jeecgframework.core.util.DateUtils;
import org.jeecgframework.core.util.StringUtil;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static oracle.net.aso.C11.i;

@Transactional( rollbackForClassName = {"Exception.class"})
@DataSourceValue(DataSourceType.dataSource_ppms)
@Service
public class TopupRecordServiceImpl extends CommonServiceImpl implements TopupRecordServiceI {

    private static final Logger logger = Logger.getLogger(TopupRecordServiceImpl.class);

    public static final BigDecimal ZERO = new BigDecimal(0);

    @Autowired
    private SmsService smsService;

    @Autowired
    private TopupDao topupDao;

    private String minTopupAmt;

    private String maxTopupAmt;

    private String maxTopupAmt1Day;

    private String batchNoSuffix;

    @Autowired
    private CacheDao cacheDao;

    @Autowired
    private ConnectionDao connectionDao;

    @Autowired
    private ChangeServiceI changeServiceI;
    @Autowired
    private ChangeDaoI changeDaoI;
    @Autowired
    private TstypeServiceI tstypeServiceI;

    @Override
    public DataReturn getAllEntities(ResultVo resultVo, int page, int rows, HttpServletRequest request) {
        return topupDao.getAllEntities(resultVo,page,rows,request);
    }

    /**
     * @description: 冲正/充值记录查询-充值记录查询
     * @auther: liangyadong
     * @date: 2018/9/30 0030 上午 10:19
     */
    @Override
    public void getTopupRecord(DataGrid datagrid, HttpServletRequest request, String curLoginName) {
        //查询tmnlList和counterList
        List<Map<String, String>> tmnlMapList = changeDaoI.getTmnlMapList();
        List<Map<String, String>> counterMapList = changeDaoI.getCounterMapList();

        this.topupDao.getTopupRecord(datagrid, request, curLoginName);
        List<SpTopUpRecEntity> list = datagrid.getResults();
        List<ReverseVo> results = new ArrayList();
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++){
                ReverseVo reverseVo = new ReverseVo();
                SpTopUpRecEntity spTopUpRecEntity = list.get(i);
                reverseVo.setAccNo(spTopUpRecEntity.getAccNo());
                reverseVo.setCounterId(changeServiceI.getCounterNameByCode(counterMapList,spTopUpRecEntity.getCounterId()));
                reverseVo.setTmnlCode(changeServiceI.getTmnlNameByCode(tmnlMapList,spTopUpRecEntity.getTmnlCode()));
                reverseVo.setTopupAmt(spTopUpRecEntity.getTopupAmt());
                reverseVo.setPrepaidAmt(spTopUpRecEntity.getPrepaidAmt());
                reverseVo.setCurBal(spTopUpRecEntity.getCurBal());
                reverseVo.setTxnDate(spTopUpRecEntity.getTxnDate());
                reverseVo.setPayMode(spTopUpRecEntity.getPayMode());
                reverseVo.setPayNo(oConvertUtils.isEmpty(spTopUpRecEntity.getPayNo())?"--":spTopUpRecEntity.getPayNo());
                reverseVo.setTxnStatus(spTopUpRecEntity.getTxnStatus());
                reverseVo.setCashierId(spTopUpRecEntity.getCashierId());
                reverseVo.setRefNo(spTopUpRecEntity.getRefNo());
                results.add(reverseVo);
            }
        }
        datagrid.setResults(results);
    }

    /**
     * @description: 充值-充值记录查询
     * @auther: liangyadong
     * @date: 2018/9/30 0030 上午 11:21
     */
    @Override
    public void getCreditTopupRec(DataGrid datagrid, HttpServletRequest request) {
        //查询tmnlList和counterList
        List<Map<String, String>> tmnlMapList = changeDaoI.getTmnlMapList();
        List<Map<String, String>> counterMapList = changeDaoI.getCounterMapList();

        this.topupDao.getCreditTopupRec(datagrid,request);
        List list = datagrid.getResults();
        List<CreditTopupRecordVo> resultList = new ArrayList();
        DecimalFormat df = new DecimalFormat("0.00");
        if(list!=null&&list.size()>0){
            for (int i = 0; i < list.size(); i++) {
                CreditTopupRecordVo creditTopupRecordVo = new CreditTopupRecordVo();
                Object[] objects = (Object[]) list.get(i);
                creditTopupRecordVo.setAccNo(oConvertUtils.isEmpty(objects[0])?"":objects[0].toString());
                Object otopup = objects[1];
                if(otopup!=null){
                    BigDecimal big3 = ((BigDecimal) objects[1]).setScale(2, BigDecimal.ROUND_DOWN);
                    double db3 = big3.doubleValue();
                    String format = df.format(db3);
                    BigDecimal bigbal = new BigDecimal(format);
                    creditTopupRecordVo.setTopupAmt(bigbal);
                }
                Object oprepaidAmt = objects[2];
                if(oprepaidAmt!=null){
                    BigDecimal big3 = ((BigDecimal) objects[2]).setScale(2, BigDecimal.ROUND_DOWN);
                    double db3 = big3.doubleValue();
                    String format = df.format(db3);
                    BigDecimal bigbal = new BigDecimal(format);
                    creditTopupRecordVo.setPrepaidAmt(bigbal);
                }
                Object oarrearAmt = objects[3];
                if(oarrearAmt!=null){
                    BigDecimal big3 = ((BigDecimal) objects[3]).setScale(2, BigDecimal.ROUND_DOWN);
                    double db3 = big3.doubleValue();
                    String format = df.format(db3);
                    BigDecimal bigbal = new BigDecimal(format);
                    creditTopupRecordVo.setArrearAmt(bigbal);
                }
                Object ocurBal = objects[4];
                if(ocurBal!=null){
                    BigDecimal big3 = ((BigDecimal) objects[4]).setScale(2, BigDecimal.ROUND_DOWN);
                    double db3 = big3.doubleValue();
                    String format = df.format(db3);
                    BigDecimal bigbal = new BigDecimal(format);
                    creditTopupRecordVo.setCurBal(bigbal);
                }
                Object odate = objects[5];
                if(odate!=null){
                    creditTopupRecordVo.setTxnDate((Date)odate);
                }
                creditTopupRecordVo.setPayMode(oConvertUtils.isEmpty(objects[6])?"--":objects[6].toString());
                creditTopupRecordVo.setPayNo(oConvertUtils.isEmpty(objects[7])?"--":objects[7].toString());
                creditTopupRecordVo.setTmnlCode(oConvertUtils.isEmpty(objects[8])?"--":changeServiceI.getTmnlNameByCode(tmnlMapList, objects[8].toString()));
                creditTopupRecordVo.setCounterId(oConvertUtils.isEmpty(objects[9])?"--":changeServiceI.getCounterNameByCode(counterMapList, objects[9].toString()));
                creditTopupRecordVo.setCashierId(oConvertUtils.isEmpty(objects[10])?"--":objects[10].toString());
                resultList.add(creditTopupRecordVo);
            }

        }
        datagrid.setResults(resultList);
    }

    /**
     * 查询凭证信息
     * @param receiptInfoEntity
     * @return
     */
    public ReceiptInfoEntity getReceiptInfo(ReceiptInfoEntity receiptInfoEntity) {
        return topupDao.getReceiptInfo(receiptInfoEntity);
    }

    /**
     * 充值
     * @param topupRecordEntity
     * @return
     */
    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ, rollbackForClassName = {"Exception.class"})
    public Map<String,Object> topup(SpTopUpRecEntity topupRecordEntity, String clientIP, CustomerInfoEntity customerInfoEntity) {
        Map<String,Object> map = new HashMap<String,Object>();
        Date txnDate = new Date();
        String strDate = DateUtils.formatDate(txnDate, Constants.SIMPLE_YYYY_MM_DD);
        String accountNo = topupRecordEntity.getAccNo();
        map.put(Constants.RETURN_STATUS,true);

        // 获取当前登录的MAC地址并校验 改为clientIP
//        String mac = SystemInfoUtil.getMAC();//获取服务端MAC地址
        map = this.getDepartmentInfo(clientIP, topupRecordEntity);
        if(!(Boolean)map.get(Constants.RETURN_STATUS))  return map;

        //批次号:日期+01
        String batchNo = strDate + this.batchNoSuffix;
        topupRecordEntity.setBatchNo(batchNo);
        topupRecordEntity.setTxnDate(txnDate);

        //根据批次号校验当前账号缴费金额是否符合限制条件，校验：1.本次缴费金额 2.当天缴费总额
//        map = checkTopupAmt(accountNo, topupRecordEntity.getTopupAmt(), batchNo);
//        //金额校验限制，返回
//        if(!(Boolean)map.get(Constants.RETURN_STATUS))  return map;

        //set TopupEntity
        setTopupEntity(topupRecordEntity,customerInfoEntity);

        //生成缴费记录
        int topupRecId = topupDao.topup(topupRecordEntity);
        topupRecordEntity.setId(topupRecId);

        //更新余额记录表，判断是否生成远程合闸命令，以及生成短信记录等
        updateRelatedBalRec(topupRecordEntity,customerInfoEntity);

        //生成收据信息
        generateReceiptInfo(topupRecordEntity);

        //将refNo存入map返回给前台用于打印收据2018-12-02新增
        map.put("refNo", topupRecordEntity.getRefNo());

        return map;
    }

    private void generateReceiptInfo(SpTopUpRecEntity topupRecordEntity) {
        ReceiptInfoEntity receiptInfoEntity = new ReceiptInfoEntity();
        //生成refNo = terminalid + counterid + sFullTime(yyyyMMddHHmmssSSS)
        /*String strTxnDate = DateUtils.formatDate(new Date(),Constants.SIMPLE_YYYY_MM_DD_HH_MM_SS_SSS);
        String receiptNo = topupRecordEntity.getTmnlCode() + topupRecordEntity.getCounterId() + strTxnDate;
        receiptInfoEntity.setReceiptNo(receiptNo);*/
        receiptInfoEntity.setRefNo(topupRecordEntity.getRefNo());
        receiptInfoEntity.setReceiptType(TopupConstants.RECEIPT_TYPE.TOPUP.getReceiptType());
        receiptInfoEntity.setPrintTimes(TopupConstants.RECEIPT_PRINT_STATUS.UNPRINTED.getPrintStatus());
        super.save(receiptInfoEntity);
    }

    private void updateRelatedBalRec(SpTopUpRecEntity topupRecordEntity,CustomerInfoEntity customerInfoEntity) {
        //1.update account balance rec
        updateAcctBalanceInfo(topupRecordEntity);

        //2.trigger retmote connection, sms record, and insert account balance update log.
        triggerAndUpdateAcctBalLog(topupRecordEntity,customerInfoEntity);
    }

    private void triggerAndUpdateAcctBalLog(SpTopUpRecEntity topupRecordEntity,CustomerInfoEntity customerInfoEntity) {
        RemoteReconRecEntity remoteReconRecEntity = null;

        //如果上次余额<0且充值后当前余额>0时，生成远程合闸命令
        if((topupRecordEntity.getLastBal().compareTo(ZERO) < 0) && (topupRecordEntity.getCurBal().compareTo(ZERO) >= 0)){
            //生成远程合闸命令
            remoteReconRecEntity = this.remoteRecon(topupRecordEntity,customerInfoEntity);
        }
        BalanceRecEntity balRecEntity = this.setBalanceRec(topupRecordEntity);
        //生成短信
        try {
            String smsNo = this.generateSmsRec(topupRecordEntity,customerInfoEntity);
            if(!StringUtil.isEmpty(smsNo)){
                balRecEntity.setSmsNo(smsNo);
            }
        } catch (Exception e) {
            logger.error("********生成短信记录失败" + e.getMessage(),e);
        }
        if(remoteReconRecEntity != null && remoteReconRecEntity.getId() != null){
            balRecEntity.setCtlNo(String.valueOf(remoteReconRecEntity.getId()));
        }
        this.save(balRecEntity);
    }

    //生成远程合闸命令
    private RemoteReconRecEntity remoteRecon(SpTopUpRecEntity topupRecordEntity,CustomerInfoEntity customerInfoEntity) {
        RemoteReconRecEntity remoteReconRecEntity = new RemoteReconRecEntity();
        remoteReconRecEntity.setCustomerInfoEntity(customerInfoEntity);
        Set<MeterInfoEntity> meterInfoEntitySet = customerInfoEntity.getMeterInfoEntitySet().stream().filter(meterInfoEntity -> Constants.METER_STATUS.RUN.getStatus().equals(meterInfoEntity.getMeterStatus())).collect(Collectors.toSet());
        remoteReconRecEntity.setMeterId(((MeterInfoEntity)meterInfoEntitySet.toArray()[0]).getMeterId());
        remoteReconRecEntity.setTxnId(String.valueOf(topupRecordEntity.getId()));
        remoteReconRecEntity.setTxnType(Constants.REMOTE_RECON_TXN_TYPE.TOPUP.getTxnStatus());
        remoteReconRecEntity.setGenTime(new Date());
        remoteReconRecEntity.setOperStatus(Constants.REMOTER_OPER_STATUS.PENDING.getType());
        this.connectionDao.doSaveAndUpdate(remoteReconRecEntity);
        return remoteReconRecEntity;
    }

    private void updateAcctBalanceInfo(SpTopUpRecEntity topupRecordEntity) {
        AcctBalEntity acctBalEntity = this.getAcctBalEntity(topupRecordEntity.getAccNo());
        BigDecimal oldBal = acctBalEntity.getBalance();
        BigDecimal prepaidAmt = topupRecordEntity.getPrepaidAmt();
        BigDecimal newBal = oldBal.add(prepaidAmt);
        acctBalEntity.setBalance(newBal);
        acctBalEntity.setUpdateTime(topupRecordEntity.getTxnDate());
        super.updateEntitie(acctBalEntity);
    }

    private BalanceRecEntity setBalanceRec(SpTopUpRecEntity topupRecordEntity) {
        BalanceRecEntity balRecEntity = new BalanceRecEntity();
        balRecEntity.setUpdateTime(topupRecordEntity.getTxnDate());
        balRecEntity.setAccNo(topupRecordEntity.getAccNo());
        balRecEntity.setUpdateFlag(Constants.BALANCE_UPDATED_FLAG.TOPUP.getFlag());
        balRecEntity.setTxnNo(String.valueOf(topupRecordEntity.getId()));
        balRecEntity.setLastBal(topupRecordEntity.getLastBal());
        balRecEntity.setCurBal(topupRecordEntity.getCurBal());
        balRecEntity.setOperId(topupRecordEntity.getCashierId());
        return balRecEntity;
    }

    private Map<String,Object> setTopupEntity(SpTopUpRecEntity topupRecordEntity,CustomerInfoEntity customerInfoEntity) {
        String msg = null;
        BigDecimal arrears = new BigDecimal(0);
        String cashId = ResourceUtils.getSessionUser().getName();
        if(StringUtil.isEmpty(cashId)){
            msg = "Cashier is null! Please log in to the PPMS again.";
            logger.error(msg);
            throw new RuntimeException(msg);
        }else{
            topupRecordEntity.setCashierId(cashId);
        }

        //从库中查询该用户对应arrears参数,已改为百分数
        arrears = customerInfoEntity.getArrearPct();

        //arrears=缴费金额*参数
        BigDecimal calculateArrearAmt = topupRecordEntity.getTopupAmt().multiply(arrears);
        BigDecimal arrearAmtScale2 = calculateArrearAmt.setScale(2, BigDecimal.ROUND_DOWN);
        BigDecimal topupAmt = topupRecordEntity.getTopupAmt();
        //prepaid=缴费金额-arrears
        BigDecimal prepaidAmt = topupAmt.subtract(arrearAmtScale2);

        topupRecordEntity.setArrearAmt(arrearAmtScale2);
        topupRecordEntity.setPrepaidAmt(prepaidAmt);

        if(StringUtil.isEmpty(customerInfoEntity.getTariffCode()) || StringUtil.isEmpty(customerInfoEntity.getGstCode())){
            msg = "Top-up failure. No applicable TARIFF or GST is for customer [" + topupRecordEntity.getAccNo() + "].";
//            msg = "The tariff or GST code of customer[" + topupRecordEntity.getAccNo() + "] do not exist.";
            logger.error(msg);
            throw new NullPointerException(msg);
        }

        TariffInfoEntity tariffEntity = this.cacheDao.getCurrentTariff(customerInfoEntity.getTariffCode());
        GSTEntity gstEntity = this.cacheDao.getCurrentGst(customerInfoEntity.getGstCode());

        if(tariffEntity == null || gstEntity == null || StringUtil.isEmpty(tariffEntity.getCode()) || StringUtil.isEmpty(gstEntity.getCode())){
            msg = "Top-up failure. No applicable TARIFF or GST is for customer [" + topupRecordEntity.getAccNo() + "].";
//            msg = "The tariff or GST in PPMS do not exist. Please contact PPMS administrator.";
            logger.error(msg);
            throw new NullPointerException(msg);
        }

        //gstAmt gst_amt=(prepaid_amt/1+gst rate)*gst rate
        BigDecimal tempAmt = prepaidAmt.divide(new BigDecimal(1).add(gstEntity.getRate()),2, BigDecimal.ROUND_DOWN);

        BigDecimal gstAmt = tempAmt.multiply(gstEntity.getRate()).setScale(2, BigDecimal.ROUND_DOWN);
        topupRecordEntity.setGstAmt(gstAmt);

        // grossAmt gross_amt= prepaid_amt-gst_amt
        BigDecimal grossAmt = prepaidAmt.subtract(gstAmt);
        topupRecordEntity.setGrosssAmt(grossAmt);

        //缴费前余额 根据accNo查询A_ACCT_BAL
        AcctBalEntity acctBalEntity = getAcctBalEntity(topupRecordEntity.getAccNo());
        if(acctBalEntity == null){
            msg = "The account balance of customer[" + topupRecordEntity.getAccNo() + "]  in PPMS do not exist. Please contact PPMS administrator.";
            logger.error(msg);
            throw new NullPointerException(msg);
        }
        BigDecimal lastBal = acctBalEntity.getBalance();
        topupRecordEntity.setLastBal(lastBal);
        //当前余额 缴费前余额+sPrepaid
        topupRecordEntity.setCurBal(topupRecordEntity.getPrepaidAmt().add(topupRecordEntity.getLastBal()));

        //txn_status 为01 topup
        topupRecordEntity.setTxnStatus(TopupConstants.getTopupTxnstatusTopup());

        //recon_status 为01 未对账
        topupRecordEntity.setReconStatus(TopupConstants.getTopupReconstatusUnrecon());

        //生成refNo = channelid + terminalid + counterid + sFullTime(yyyyMMddHHmmssSSS)
        String strTxnDate = DateUtils.formatDate(topupRecordEntity.getTxnDate(),Constants.SIMPLE_YYYY_MM_DD_HH_MM_SS_SSS);
        String refNo = topupRecordEntity.getChannelCode() + topupRecordEntity.getTmnlCode() + topupRecordEntity.getCounterId() + strTxnDate;
        topupRecordEntity.setRefNo(refNo);

        return null;
    }

    private AcctBalEntity getAcctBalEntity(String accountNo) {
        List<AcctBalEntity> acctBalList = topupDao.getAcctBalByAccNo(accountNo);
        if(acctBalList.size() > 0){
            return acctBalList.get(0);
        }
        return null;
    }

    private Map<String,Object> getDepartmentInfo(String clientIP,SpTopUpRecEntity topupRecordEntity){
        Map<String,Object> map = new HashMap<String,Object>();
        String msg;
        map.put(Constants.RETURN_STATUS,true);
        /*if(StringUtil.isEmpty(macAddress)){
            map.put(Constants.RETURN_STATUS,false);
            map.put(Constants.ERROR_MSG,"Mac Address is null!");
            return map;
        }*/
        if(StringUtil.isEmpty(clientIP)){
            map.put(Constants.RETURN_STATUS,false);
            map.put(Constants.ERROR_MSG,"Unauthorized terminal.");
            return map;
        }
//        CounterEntity counterInfo = topupDao.getCounterInfo(macAddress);
        CounterEntity counterInfo = topupDao.getCounterByIP(clientIP);
        if(counterInfo != null){
            String counterCode = counterInfo.getCode();
            if(!StringUtil.isEmpty(counterCode)){
                topupRecordEntity.setCounterId(counterCode);
            }
            TerminalEntity terminalEntity = counterInfo.getTerminalEntity();
            if(terminalEntity != null && (!StringUtil.isEmpty(terminalEntity.getCode()))){
                topupRecordEntity.setTmnlCode(terminalEntity.getCode());
                ChannelEntity channelEntity = terminalEntity.getChannelEntity();
                if(channelEntity != null && (!StringUtil.isEmpty(channelEntity.getCode()))){
                    topupRecordEntity.setChannelCode(channelEntity.getCode());
                }else{
                    msg = "The SP Group information [" + topupRecordEntity.getAccNo() + "]  in PPMS do not exist. Please contact PPMS administrator.";
                    logger.error(msg);
                    throw new NullPointerException(msg);
                }
            }else{
                msg = "The terminal information [" + topupRecordEntity.getAccNo() + "]  in PPMS do not exist. Please contact PPMS administrator.";
                logger.error(msg);
                throw new NullPointerException(msg);
            }
        } else {
            map.put(Constants.RETURN_STATUS,false);
            map.put(Constants.ERROR_MSG,TopupConstants.getTopupMacNotMatch());
        }
        return map;
    }

    /*查询充值金额限值*/
    public String getTopupAlmAmt(String typeGroupCode){
        return tstypeServiceI.getTopupAmtAlmValue(typeGroupCode);
    }

    /**
     * 缴费金额校验
     * @param accNo 充值账户
     * @param topupAmt 本次充值金额
     * @return 提示信息
     */
    public Map<String,Object> checkTopupAmt(String accNo, BigDecimal topupAmt, String batchNo){
        String msg = "";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(Constants.RETURN_STATUS,false);

        String sminTopupAmt = getTopupAlmAmt("MIN_TOPUP_AMT");
        String smaxTopupAmt = getTopupAlmAmt("MAX_TOPUP_AMT");
        String smaxTopupAmt1Day = getTopupAlmAmt("DAILY_MAX_AMT");

        BigDecimal minTopupAmt = new BigDecimal(this.minTopupAmt);
        BigDecimal maxTopupAmt = new BigDecimal(this.maxTopupAmt);
        BigDecimal maxTopupAmt1Day = new BigDecimal(this.maxTopupAmt1Day);

        if(oConvertUtils.isNotEmpty(sminTopupAmt)){
            minTopupAmt = new BigDecimal(sminTopupAmt);
        }else {
            msg = "Get MIN_TOPUP_AMT failure.";
            logger.error(msg);
            throw new NullPointerException(msg);
        }
        if(oConvertUtils.isNotEmpty(smaxTopupAmt)){
            maxTopupAmt = new BigDecimal(smaxTopupAmt);
        }else {
            msg = "Get MAX_TOPUP_AMT failure.";
            logger.error(msg);
            throw new NullPointerException(msg);
        }
        if(oConvertUtils.isNotEmpty(smaxTopupAmt1Day)){
            maxTopupAmt1Day = new BigDecimal(smaxTopupAmt1Day);
        }else {
            msg = "Get DAILY_MAX_AMT failure.";
            logger.error(msg);
            throw new NullPointerException(msg);
        }

        //当前缴费金额<最小允许缴费金额
        if (topupAmt.compareTo(minTopupAmt) == -1) {
           map.put(Constants.ERROR_MSG,TopupConstants.TOPUPAMT_ONCE_MINIMUM_ALARM);
            return map;
        }
        //当前缴费金额>最大允许缴费金额
        if (topupAmt.compareTo(maxTopupAmt) == 1) {
            map.put(Constants.ERROR_MSG,TopupConstants.TOPUPAMT_ONCE_MAXIMUM_ALARM);
            return map;
        }
        //查询该账户当日总的充值金额
        BigDecimal oneDayTopupAmt = getOneDayTopupAmt(accNo, batchNo);
        //当当前缴费金额>日允许的最大缴费金额
        if(oneDayTopupAmt.add(topupAmt).compareTo(maxTopupAmt1Day) == 1){
            map.put(Constants.ERROR_MSG,TopupConstants.getTopupamtOnedayMaximumAlarm());
            return map;
        }

        map.put(Constants.RETURN_STATUS,true);
        return map;
    }

    private String generateSmsRec(SpTopUpRecEntity topupRecordEntity,CustomerInfoEntity customerInfoEntity) {
        StringBuffer stringBuffer = new StringBuffer();
        String smsId = "";

        //生成缴费短信
        smsId = generateTopupSmsRec(topupRecordEntity);
        stringBuffer.append(smsId).append(Constants.COMMA);

        // when 0=<creditBalance <=lowCreditAlarm,发送余额不足提醒短信
        if(topupRecordEntity.getCurBal().compareTo(customerInfoEntity.getLowCreditAlarm()) != 1
                && topupRecordEntity.getCurBal().compareTo(ZERO) != -1){
            smsId = generateLowCreditAlarmSmsRec(topupRecordEntity);
            stringBuffer.append(smsId).append(Constants.COMMA);
        }
        return stringBuffer.toString();
    }

    private String generateLowCreditAlarmSmsRec(SpTopUpRecEntity topupRecordEntity) {
        Map<String,String> smsParams = new HashMap<String,String>();
        String smsType = Constants.SMS_TYPE.LOW_CREDIT_ALERT.getType();
        String accountNo = topupRecordEntity.getAccNo();
        BigDecimal creditBalance = topupRecordEntity.getCurBal().setScale(Constants.AMT_DIGITS,BigDecimal.ROUND_DOWN);

        //AccountNo, CreditBalance
        smsParams.put(Constants.SMS_TEMPLATE_PARAMS.ACCOUNT_NO.getValue(),accountNo);
        smsParams.put(Constants.SMS_TEMPLATE_PARAMS.CREDIT_BALANCE.getValue(),String.valueOf(creditBalance));
        return this.smsService.generateSmsRecord(accountNo,smsType,smsParams);
    }

    private String generateTopupSmsRec(SpTopUpRecEntity topupRecordEntity) {
        Map<String,String> smsParams = new HashMap<String,String>();
        String smsType = Constants.SMS_TYPE.TOPUP.getType();

        //TopupAmt, AccountNo, TopupDate, CreditBalance
        BigDecimal topupAmt = topupRecordEntity.getPrepaidAmt().setScale(Constants.AMT_DIGITS,BigDecimal.ROUND_DOWN);
        String accountNo = topupRecordEntity.getAccNo();
        String topupDate = DateUtils.formatDate(topupRecordEntity.getTxnDate(),Constants.DD_MM_YYYY_HH_MM_SS_DOT);
        BigDecimal creditBalance = topupRecordEntity.getCurBal().setScale(Constants.AMT_DIGITS,BigDecimal.ROUND_DOWN);

        smsParams.put(Constants.SMS_TEMPLATE_PARAMS.TOPUP_AMT.getValue(),String.valueOf(topupAmt));
        smsParams.put(Constants.SMS_TEMPLATE_PARAMS.ACCOUNT_NO.getValue(),accountNo);
        smsParams.put(Constants.SMS_TEMPLATE_PARAMS.TOPUP_DATE.getValue(),topupDate);
        smsParams.put(Constants.SMS_TEMPLATE_PARAMS.CREDIT_BALANCE.getValue(),String.valueOf(creditBalance));
        return this.smsService.generateSmsRecord(accountNo,smsType,smsParams);
    }

    /**
     * 根据GSTCode查询gstRate
     * @param gstCode
     * @return
     */
    public GSTEntity getGstRateByAccNo(String gstCode){
        CriteriaQuery cq = new CriteriaQuery(GSTEntity.class);
        cq.eq("code",gstCode);
        cq.add();
        List<GSTEntity> gstEntityList = this.getListByCriteriaQuery(cq, false);

        GSTEntity gstEntity = null;
        if(gstEntityList != null && gstEntityList.size() > 0){
            gstEntity = gstEntityList.get(0);
        }
        return gstEntity;
    }

    /**
     * 校验账户是否已激活
     * @param customerInfoEntity
     * @return
     */
    @Override
    public boolean checkActiveOrNot(CustomerInfoEntity customerInfoEntity) {
        boolean flag = false;
        String accountStatus = customerInfoEntity.getAccountStatus();
        if (!StringUtil.isEmpty(accountStatus) && accountStatus.equals(TopupConstants.getCustomerAccountStatusActivated())){
            flag = true;
        }

        return flag;
    }

    /**
     * 执行冲正操作
     * @param request
     * @return
     */
    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ)
    public String doReverse(HttpServletRequest request) {
        String message = "";
        //获取当前登录人用户名
        String curLoginName = ResourceUtils.getSessionUser().getName();
        //根据refNo查询充值记录
        String refNo = request.getParameter("refNo");
        SpTopUpRecEntity topupRecordEntity = this.topupDao.getTopupRecordByRefNo(refNo);
        //关于该条冲正记录的的相关金额
        String accNo = topupRecordEntity.getAccNo();
        BigDecimal topupAmt = topupRecordEntity.getTopupAmt();
        BigDecimal prepaidAmt = topupRecordEntity.getPrepaidAmt();
        BigDecimal arrearAmt = topupRecordEntity.getArrearAmt();
        BigDecimal gstAmt = topupRecordEntity.getGstAmt();
        BigDecimal grosssAmt = topupRecordEntity.getGrosssAmt();
        //将金额转为负数 (乘以-1)
        BigDecimal multopupAmt = toFushu(topupAmt);
        BigDecimal mulprepaidAmt = toFushu(prepaidAmt);
        BigDecimal mularrearAmt = toFushu(arrearAmt);
        BigDecimal mulgstAmt = toFushu(gstAmt);
        BigDecimal mulgrosssAmt = toFushu(grosssAmt);
        // 冲正状态校验 拒绝重复冲正
		/*01- Top-up
		02- 已冲正
		03- reverse
		04- 对账补入
		05- 对账删除*/
        String databseTxnStatus = topupRecordEntity.getTxnStatus();
        if(databseTxnStatus.equals(TopupConstants.TXN_STATUS.TOPUP.getTxnStatus())){//交易状态为topup
            // 批次号校验 仅限topup当日YYYYMMDD+01
            String databaseBatchNo = topupRecordEntity.getBatchNo();
            String batchNoDate = databaseBatchNo.substring(0, 8);
            String systemDate  = DateUtils.date2Str(new Date(), DateUtils.yyyyMMdd);
            if(databaseBatchNo!=null && batchNoDate.equals(systemDate)){//当前批次
                // 对账状态校验
				/*01- 未对账
				02- 对账中
				03- 对账完成（成功）
				11- 对账失败*/
                String databaseReconStatus = topupRecordEntity.getReconStatus();
                if(databaseReconStatus.equals(TopupConstants.RECON_STATUS.UNRECON.getReconStatus())){//未对账
                    //更新原记录冲正状态变更为已冲正
                    String reversed = TopupConstants.TXN_STATUS.REVERSED.getTxnStatus();
                    topupRecordEntity.setTxnStatus(reversed);
                    Serializable serial = super.save(topupRecordEntity);
                    //更新余额记录表A_ACCT_BAL
                    BigDecimal curBal = topupRecordEntity.getCurBal();
                    AcctBalEntity acctBalEntity = this.get(AcctBalEntity.class, accNo);
                    BigDecimal latestBal = acctBalEntity.getBalance();
                    BigDecimal newBal = latestBal.subtract(prepaidAmt);
                    updateAcctBal(acctBalEntity, newBal);
                    //新增冲正记录
                    SpTopUpRecEntity reverseEntity = new SpTopUpRecEntity();
                    String sId = generateReverseRecord(curLoginName, topupRecordEntity, accNo, multopupAmt, mulprepaidAmt, mularrearAmt, mulgstAmt, mulgrosssAmt, latestBal, newBal, reverseEntity);
                    //更新余额变更记录表
                    generateBalanceRecord(curLoginName, topupRecordEntity, accNo, latestBal, newBal, sId);
                    //生成receiptInfo
                    generateReverseReceiptInfo(reverseEntity);
                    message = TopupConstants.REVERSE_STATUS.REVERSE_SUCCESS.getStatus();//冲正成功
                } else if (databaseReconStatus!=null && databaseReconStatus.equals(TopupConstants.RECON_STATUS.RECON_SUCCESS.getReconStatus())){
                    message = TopupConstants.REVERSE_STATUS.REVERSE_HAVE_RECON.getStatus();//本批次已完成对账,拒绝冲正
                } else {
                    message = TopupConstants.REVERSE_STATUS.REVERSE_OTHER_RECON_STATUS.getStatus();//其他对账状态,拒绝冲正
                }
            } else {
                message = TopupConstants.REVERSE_STATUS.REVERSE_NOT_CURRENT_BATCH.getStatus();//非当前批次,拒绝冲正
            }
        } else if(databseTxnStatus.equals(TopupConstants.TXN_STATUS.REVERSED.getTxnStatus())){
            message = TopupConstants.REVERSE_STATUS.REVERSE_HAVE_REVERSED.getStatus();//已完成冲正,拒绝重复冲正
        } else {
            message = TopupConstants.REVERSE_STATUS.REVERSE_OTHER_STATUS.getStatus();//其他冲正状态,请联系管理员
        }

        return message;
    }

    private void updateAcctBal(AcctBalEntity acctBalEntity, BigDecimal newBal) {
        acctBalEntity.setBalance(newBal);
        acctBalEntity.setUpdateTime(new Date());
        save(acctBalEntity);
    }

    private String generateReverseRecord(String curLoginName, SpTopUpRecEntity topupRecordEntity, String accNo, BigDecimal multopupAmt, BigDecimal mulprepaidAmt, BigDecimal mularrearAmt, BigDecimal mulgstAmt, BigDecimal mulgrosssAmt, BigDecimal latestBal, BigDecimal newBal, SpTopUpRecEntity reverseEntity) {
        String reverse = TopupConstants.TXN_STATUS.REVERSE.getTxnStatus();
        String channelCode = topupRecordEntity.getChannelCode();
        String tmnlCode = topupRecordEntity.getTmnlCode();
        String counterId = topupRecordEntity.getCounterId();
        reverseEntity.setAccNo(accNo);
        reverseEntity.setTxnStatus(reverse);
        //金额全部为负
        reverseEntity.setTopupAmt(multopupAmt);
        reverseEntity.setPrepaidAmt(mulprepaidAmt);
        reverseEntity.setArrearAmt(mularrearAmt);
        reverseEntity.setGstAmt(mulgstAmt);
        reverseEntity.setGrosssAmt(mulgrosssAmt);
        reverseEntity.setLastBal(latestBal);
        reverseEntity.setCurBal(newBal);
        reverseEntity.setTxnDate(new Date());
        reverseEntity.setBatchNo(generateBatchNo());
        reverseEntity.setCashierId(curLoginName);
        reverseEntity.setChannelCode(channelCode);
        reverseEntity.setTmnlCode(tmnlCode);
        reverseEntity.setCounterId(counterId);
        reverseEntity.setRefNo(generateRefNo(channelCode, tmnlCode, counterId));
        reverseEntity.setBatchNo(topupRecordEntity.getBatchNo()==null?"":topupRecordEntity.getBatchNo());
        reverseEntity.setCreditType(topupRecordEntity.getCreditType()==null?"":topupRecordEntity.getCreditType());
        reverseEntity.setPayMode(topupRecordEntity.getPayMode()==null?"":topupRecordEntity.getPayMode());
        reverseEntity.setPayNo(topupRecordEntity.getPayNo()==null?"":topupRecordEntity.getPayNo());
        reverseEntity.setReconStatus(topupRecordEntity.getReconStatus()==null?"":topupRecordEntity.getReconStatus());

        Serializable save = save(reverseEntity);
        return save.toString();
    }

    private void generateBalanceRecord(String curLoginName, SpTopUpRecEntity topupRecordEntity, String accNo, BigDecimal latestBal, BigDecimal newBal, String sId) {
        String reverseFlag = Constants.BALANCE_UPDATED_FLAG.REVERSE.getFlag();//冲正
        BalanceRecEntity balanceRecEntity = new BalanceRecEntity();
        balanceRecEntity.setAccNo(accNo);
        balanceRecEntity.setUpdateTime(new Date());
        balanceRecEntity.setTxnNo(sId);//txn_no reverseid
        balanceRecEntity.setUpdateFlag(reverseFlag);
        balanceRecEntity.setOperId(curLoginName);
        balanceRecEntity.setLastBal(latestBal);
        balanceRecEntity.setCurBal(newBal);
        try {
            BigDecimal newBalScale2 = newBal.setScale(2, BigDecimal.ROUND_DOWN);
            topupRecordEntity.setCurBal(newBalScale2);
            String smsNo = this.generateReverseSmsRec(topupRecordEntity);
            if(!StringUtil.isEmpty(smsNo)){
                balanceRecEntity.setSmsNo(smsNo);
            }
        } catch (Exception e) {
            logger.error("********生成短信记录失败" + e.getMessage(),e);
        }
        save(balanceRecEntity);
    }

    private void generateReverseReceiptInfo(SpTopUpRecEntity topupRecordEntity) {
        ReceiptInfoEntity receiptInfoEntity = new ReceiptInfoEntity();
        receiptInfoEntity.setRefNo(topupRecordEntity.getRefNo());
        receiptInfoEntity.setReceiptType(TopupConstants.RECEIPT_TYPE.REVERSE.getReceiptType());
        receiptInfoEntity.setPrintTimes(TopupConstants.RECEIPT_PRINT_STATUS.UNPRINTED.getPrintStatus());
        super.save(receiptInfoEntity);
    }

    /**
     * 退款申请
     * @param refundRecordEntity
     * @param request
     * @return
     */
    @Override
    public String refundApply(RefundRecordEntity refundRecordEntity, HttpServletRequest request) {
        String message = "";
        Date date = PersDateUtils.getDate();
        String curLoginName = ResourceUtils.getSessionUser().getName();
        //获取客户端mac地址 改为clientIP
//        String mac = request.getParameter("mac");
        String clientIP = GetClientIPUtil.getIpAddr(request);
        //查询counterCode,tmnlCode
        String counterCode = "";
        Integer terminalId = 0;
        String terminalCode = "";
        Integer channelId = 0;
        String channelCode = "";
        try{
//            CounterEntity counterInfo = topupDao.getCounterInfo(mac);
            CounterEntity counterInfo = topupDao.getCounterByIP(clientIP);
            if(counterInfo != null){
                counterCode = counterInfo.getCode();//counterCode
                terminalId = counterInfo.getTerminalEntity().getId();//外键
            } else {
                message = TopupConstants.getTopupMacNotMatch();
                return message;
            }
            TerminalEntity terminalInfo = topupDao.getTerminalInfo(terminalId);
            if(terminalInfo != null){
                terminalCode = terminalInfo.getCode();//terminalCode
                channelId = terminalInfo.getChannelEntity().getId();//外键
            }
            ChannelEntity channelInfo = topupDao.getChannelInfo(channelId);
            if(channelInfo != null){
                channelCode = channelInfo.getCode();//channelCode
            }
        } catch(Exception e) {
            logger.error("=========获取counter/terminal/channel信息失败=========" + e);
            message = "Get counter/terminal/channel information failed.";
            return message;
        }

        //credit balance - ∑refundAmt > 0 允许退款申请
        String accNo = refundRecordEntity.getAccNo();
        AcctBalEntity acctBalEntity = this.getEntity(AcctBalEntity.class, refundRecordEntity.getAccNo());
        BigDecimal balance = acctBalEntity.getBalance();
        boolean b = refundCheck(accNo, balance);
        if(!b){
            message = "The balance is too low, the refund request is rejected.";
            return message;
        }

        refundRecordEntity.setApplyId(curLoginName);
        refundRecordEntity.setCounterId(counterCode);
        refundRecordEntity.setTmnlCode(terminalCode);
        refundRecordEntity.setApplyTime(date);
        refundRecordEntity.setLastBal(balance);
        BigDecimal refundAmt = refundRecordEntity.getRefundAmt();
        refundRecordEntity.setCurBal(balance.subtract(refundAmt));
        refundRecordEntity.setApprStatus(TopupConstants.REFUND_STATUS.REFUND_PENDING.getStatus());
        refundRecordEntity.setPayMode(TopupConstants.PAYMENT_MODE.CHEQUE.getPaymentMode());
        refundRecordEntity.setBatchNo(generateBatchNo());
        try{
            super.save(refundRecordEntity);
            message = TopupConstants.REFUND_MESSAGE.REFUND_APPLY_SUCCESS.getMessage();
        } catch (Exception e){
            message = TopupConstants.REFUND_MESSAGE.REFUND_APPLY_FAILUE.getMessage();
            return message;
        }

        return message;
    }

    /**
     * @Author: liangyadong 退款申请前校验
     * @Date: 2018/11/27 0027 上午 10:00
     * @Description:
     */
    public boolean refundCheck(String accNo, BigDecimal balance){
        BigDecimal totalRefundAmt = topupDao.getTotalRefundAmtByAccNo(accNo);
        BigDecimal calculateResult = balance.subtract(totalRefundAmt);
        if(calculateResult.compareTo(ZERO)==1){//credit balance - ∑refundAmt > 0
            return true;
        }
        return false;
    }

    /**
     * 退款审批
     * @param request
     * @return
     */
    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ, rollbackForClassName = {"Exception.class"})
    public String refundApproval(HttpServletRequest request) {
        /**
         * 流程:
         * 1.审批时间
         * 2.审批人
         * 3.退款状态(通过或拒绝)
         * 4.审批原因
         * 5.terminalCode和counterCode(是否需要修改?)
         *
         * 审批通过的同时更新用户最新余额
         */
        String message = "";
        String sId = request.getParameter("id");//退款申请记录中的id
        Integer id = Integer.valueOf(sId);
        String mac = request.getParameter("mac");//客户端mac地址
        String advice = request.getParameter("advice");
        String sRefundAmt = request.getParameter("refundAmt");
        BigDecimal refundAmt = new BigDecimal(sRefundAmt);
        String remark = request.getParameter("remark");
        String curLoginName = ResourceUtils.getSessionUser().getName();
        Date date = PersDateUtils.getDate();
        RefundRecordEntity refundRecordEntity = null;
        //根据退款记录id查询该记录
        if(!StringUtils.isEmpty(id)){
            refundRecordEntity = this.getEntity(RefundRecordEntity.class, id);
            if (refundRecordEntity != null){
                refundRecordEntity.setApprId(curLoginName);
                refundRecordEntity.setApprTime(date);
                refundRecordEntity.setApprReason(remark);
            }
        }
        if(TopupConstants.REFUND_STATUS.REFUND_APPROVED.getStatus().equals(advice)){
            /**
             * 审批通过
             */
            //1.设置退款状态,对账状态
            refundRecordEntity.setApprStatus(advice);
            refundRecordEntity.setReconStatus(ReconStatusEnum.UNRECON.getStatus());
            //2.更新用户最新余额(用户余额扣除退款金额)
            AcctBalEntity acctBalEntity = this.getEntity(AcctBalEntity.class, refundRecordEntity.getAccNo());
            BigDecimal latestBalance = acctBalEntity.getBalance();
            //求最新余额
            BigDecimal curBalance = latestBalance.subtract(refundAmt);
            acctBalEntity.setBalance(curBalance);
            acctBalEntity.setUpdateTime(date);
            save(acctBalEntity);
            //3.更新余额变更记录表
            String refundFlag = Constants.BALANCE_UPDATED_FLAG.REFUND.getFlag();//update_flag 退款
            BalanceRecEntity balanceRecEntity = new BalanceRecEntity();
            balanceRecEntity.setAccNo(refundRecordEntity.getAccNo());
            balanceRecEntity.setUpdateTime(new Date());
            balanceRecEntity.setTxnNo(sId);//txn_no refundid
            balanceRecEntity.setUpdateFlag(refundFlag);
            balanceRecEntity.setOperId(curLoginName);
            balanceRecEntity.setLastBal(latestBalance);
            balanceRecEntity.setCurBal(curBalance);
            save(balanceRecEntity);
        } else if (TopupConstants.REFUND_STATUS.REFUND_DECLNED.getStatus().equals(advice)){
            /**
             * 审批未通过
             */
            //1.设置退款状态
            refundRecordEntity.setApprStatus(advice);
        }
        try{
            save(refundRecordEntity);
            message = TopupConstants.REFUND_MESSAGE.REFUND_APPROVAL_SUCCESS.getMessage();
        } catch(Exception e) {
            logger.error(e.getMessage(),e);
            message = TopupConstants.REFUND_MESSAGE.REFUND_APPROVAL_FAILUE.getMessage();
            return message;
        }

        return message;
    }

    /**
     * @description: 凭证重打页面,执行打印更新receiptInfo打印信息
     * @auther: liangyadong
     * @date: 2018/10/9 0009 上午 10:17
     */
    @Override
    public void updateReceiptInfo(HttpServletRequest request) {
        String refNo = request.getParameter("refNo");
        Date date = PersDateUtils.getDate();
        String sFullTime = PersDateUtils.getPatternDate(PersDateUtils.FORMAT_FULL_DATE_TIME, date);//yyyyMMddHHmmssSSS
        String sDateTime = PersDateUtils.getPatternDate(PersDateUtils.FORMAT_DATE_TIME, date);//yyyy-MM-dd HH:mm:ss:SSS
        String curLoginName = ResourceUtils.getSessionUser().getName();
        String receiptNo = sFullTime + curLoginName;
        //根据refNo查询receiptInfo
        ReceiptInfoEntity receiptInfo = topupDao.getReceiptInfo(refNo);
        try{
            receiptInfo.setReceiptNo(receiptNo);//receiptNo
            receiptInfo.setPrintDate(date);//printDate
            receiptInfo.setOperId(curLoginName);//operId
            String printTimes = receiptInfo.getPrintTimes();
            Integer times = Integer.valueOf(printTimes);
            int i = times + 1;
            receiptInfo.setPrintTimes(String.valueOf(i));//printTimes
            super.save(receiptInfo);
        } catch (Exception e){
            logger.error("ReceiptInfo update failed.");
        }

    }

    //充值页面离焦查询用户电表及其他信息
    @Override
    public ResultVo getCustInfo(HttpServletRequest request) {
        return topupDao.getCustInfo(request);
    }

    /**
     * @description: 根据refno查询sptopupinfo
     * @auther: liangyadong
     * @date: 2018/10/8 0008 下午 4:14
     */
    @Override
    public SpTopUpRecEntity getTopupRecordByRefNo(String refNo) {
        return topupDao.getTopupRecordByRefNo(refNo);
    }

    /**
     * @Author: liangyadong
     * @Date: 2018/11/30 0030 上午 10:08
     * @Description: 充值预览
     */
    @Override
    public TopupPreviewVO getPreviewVO(HttpServletRequest request) {
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy hh:mm:ss");
        String sdate = sdf.format(date);
        String[] strings = sdate.split(" ");
        String topupDate = strings[0];
        String topupTime = strings[1];
        String accountNo = request.getParameter("accountNo");
        if(accountNo.length()==10){
            accountNo+="P";
        }

        String samount = request.getParameter("amount");
        String sprepaidAmt = request.getParameter("prepaidAmt");
        String sarrearAmt = request.getParameter("arrearAmt");
        String sbalance = request.getParameter("balance");
        BigDecimal newBalance = new BigDecimal(0);

        BigDecimal prepaidAmount = new BigDecimal(sprepaidAmt);
        if(oConvertUtils.isNotEmpty(sbalance)){
            BigDecimal oldBalance = new BigDecimal(sbalance);
            newBalance = prepaidAmount.add(oldBalance);
        }

        TopupPreviewVO topupPreviewVO = new TopupPreviewVO();
        topupPreviewVO.setAccountNo(accountNo);
        topupPreviewVO.setTopupAmt(samount);
        topupPreviewVO.setPrepaidAmt(sprepaidAmt);
        topupPreviewVO.setArrearAmt(sarrearAmt);
        topupPreviewVO.setOldBalance(sbalance);
        topupPreviewVO.setNewBalance(newBalance.toString());
        topupPreviewVO.setTopupDate(topupDate);
        topupPreviewVO.setTopupTime(topupTime);

        return topupPreviewVO;
    }

    /**
     * 冲正-更改状态
     * @param topupRecord
     * @param status
     * @return
     */
    @Override
    public Integer updateTxnStatus(SpTopUpRecEntity topupRecord, String status) throws Exception {
        return topupDao.updateTxnStatus(topupRecord,status);
    }

    /**
     * 退款申请查询用户记录
     * @param customerInfoEntity
     * @param acctBalEntity
     * @param page
     * @param rows
     * @param request
     * @return
     */
    @Override
    public DataReturn getCustomerInfo(CustomerInfoEntity customerInfoEntity, AcctBalEntity acctBalEntity, int page, int rows, HttpServletRequest request) {
        return topupDao.getCustomerInfo(customerInfoEntity,acctBalEntity,page,rows,request);
    }

    /**
     * 退款申请列表
     * @param refundRecordEntity
     * @param customerInfoEntity
     * @param page
     * @param rows
     * @param request
     * @return
     */
    @Override
    public DataReturn getRefundApplyDatagrid(RefundRecordEntity refundRecordEntity, CustomerInfoEntity customerInfoEntity, int page, int rows, HttpServletRequest request) {
        return topupDao.getRefundApplyDatagrid(refundRecordEntity,customerInfoEntity,page,rows,request);
    }

    /**
     * @description: 凭证打印列表查询
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 3:27
     */
    @Override
    public void getReceiptPrintDatagrid(HttpServletRequest request, DataGrid dataGrid) {
        this.topupDao.getReceiptPrintDatagrid(request, dataGrid);
        List list = dataGrid.getResults();
        List<ReceiptPrintListVo> resultList = new ArrayList();
        DecimalFormat df = new DecimalFormat("0.00");
        if(list!=null&&list.size()>0) {
            for (int i = 0; i < list.size(); i++) {
                ReceiptPrintListVo receiptPrintListVo = new ReceiptPrintListVo();
                Object[] objects = (Object[]) list.get(i);
                receiptPrintListVo.setAccNo(objects[0]==null?"--":objects[0].toString());
                Object otopupAmt = objects[1];
                if(otopupAmt!=null){
                    BigDecimal big3 = ((BigDecimal) objects[1]).setScale(2, BigDecimal.ROUND_DOWN);
                    double db3 = big3.doubleValue();
                    String format = df.format(db3);
                    BigDecimal bigbal = new BigDecimal(format);
                    receiptPrintListVo.setTopupAmt(bigbal);
                }
                receiptPrintListVo.setTxnDate((Date) objects[2]);
                Object oarrearAmt = objects[3];
                if(oarrearAmt!=null){
                    BigDecimal big3 = ((BigDecimal) objects[3]).setScale(2, BigDecimal.ROUND_DOWN);
                    double db3 = big3.doubleValue();
                    String format = df.format(db3);
                    BigDecimal bigbal = new BigDecimal(format);
                    receiptPrintListVo.setArrearAmt(bigbal);
                }
                receiptPrintListVo.setCashierId(objects[4]==null?"--":objects[4].toString());
                receiptPrintListVo.setReceiptType(objects[5]==null?"--":objects[5].toString());
                receiptPrintListVo.setPrintTimes(objects[6]==null?"--":objects[6].toString());
                receiptPrintListVo.setRefNo(objects[7]==null?"--":objects[7].toString());
                resultList.add(receiptPrintListVo);
            }
        }
        dataGrid.setResults(resultList);
    }

    /**
     * 查询当日缴费总额
     * @param accNo
     * @param batchNo
     * @return
     */
    public BigDecimal getOneDayTopupAmt(String accNo, String batchNo){
        return topupDao.getOneDayTopupAmt(accNo, batchNo);
    }

    public void setMinTopupAmt(String minTopupAmt) {
        this.minTopupAmt = minTopupAmt;
    }

    public void setMaxTopupAmt(String maxTopupAmt) {
        this.maxTopupAmt = maxTopupAmt;
    }

    public void setMaxTopupAmt1Day(String maxTopupAmt1Day) {
        this.maxTopupAmt1Day = maxTopupAmt1Day;
    }

    public void setBatchNoSuffix(String batchNoSuffix) {
        this.batchNoSuffix = batchNoSuffix;
    }

    /**
     * 将金额转为相应负数
     */
    public BigDecimal toFushu(BigDecimal balance){
        if(balance!=null){
            return balance.multiply(new BigDecimal(-1));
        }
        return new BigDecimal(0);
    }

    /**
     * 生成refNo
     */
    public String generateRefNo(String channelCode, String terminalCode, String counterCode){
        SimpleDateFormat sdf = PersDateUtils.getSdf(PersDateUtils.FORMAT_FULL_DATE_TIME);
        String sdate = sdf.format(new Date());
        String refNo = channelCode + terminalCode + counterCode + sdate;

        return refNo;
    }

    /**
     * 生成batchNo
     */
    public String generateBatchNo(){
        SimpleDateFormat sdf = PersDateUtils.getSdf(PersDateUtils.FORMAT_DATE_NONE);
        String sdate = sdf.format(new Date());
        String batchNo = sdate + "01";

        return batchNo;
    }

    //生成reverse短信
    private String generateReverseSmsRec(SpTopUpRecEntity topupRecordEntity) {
        StringBuffer stringBuffer = new StringBuffer();
        String smsId = "";
        smsId = generateReversalSmsRec(topupRecordEntity);
        stringBuffer.append(smsId).append(Constants.COMMA);
        return stringBuffer.toString();
    }

    private String generateReversalSmsRec(SpTopUpRecEntity topupRecordEntity) {
        Map<String, String> smsParams = new HashMap<String, String>();
        String smsType = Constants.SMS_TYPE.REVERSE.getType();
        //ReverseAmt, AccountNo,ReverseDate,CreditBalance
        String reverseAmt = topupRecordEntity.getPrepaidAmt().toString();
        String accountNo = topupRecordEntity.getAccNo();
        String reverseDate = DateUtils.formatDate(topupRecordEntity.getTxnDate(), Constants.DD_MM_YYYY_HH_MM_SS_DOT);
        String creditBal = topupRecordEntity.getCurBal().toString();

        smsParams.put(Constants.SMS_TEMPLATE_PARAMS.REVERSE_AMT.getValue(), reverseAmt);
        smsParams.put(Constants.SMS_TEMPLATE_PARAMS.ACCOUNT_NO.getValue(), accountNo);
        smsParams.put(Constants.SMS_TEMPLATE_PARAMS.REVERSE_DATE.getValue(), reverseDate);
        smsParams.put(Constants.SMS_TEMPLATE_PARAMS.CREDIT_BALANCE.getValue(), creditBal);
        return this.smsService.generateSmsRecord(accountNo, smsType, smsParams);
    }

    @Override
    public CounterEntity getCounterByIP(String clientIP) {
        return topupDao.getCounterByIP(clientIP);
    }

    @Override
    public TerminalEntity getTerminalInfo(int terminalId) {
        return topupDao.getTerminalInfo(terminalId);
    }

    @Override
    public ChannelEntity getChannelInfo(int channelId) {
        return topupDao.getChannelInfo(channelId);
    }

}