﻿$(function () {
    $("#customerList").datagrid({
        onSelect: function (rowIndex, rowData) {
            $("#acc_No").val(rowData.accNo);
            $("#times").val(rowData.printCardTimes);
            $("#amount").val(rowData.cardFee);
        }

    });
})
var clickFlag = true;
function resetFlag() {
    clickFlag = true;
}
function customerListsearch() {
    if (!clickFlag) {
        return false;
    }
    clickFlag = false;
    setTimeout("resetFlag()", 500);
    var flag = true;
    var queryParams = $('#customerList').datagrid('options').queryParams;
    $('#customerListtb').find('*').each(function () {
        if ($(this).attr('name') == 'accNo') {
            var accNo = $(this).val();
            var exp = /^[pP0-9-]{10,11}$/;
            var reg = new RegExp(exp);
            if (!accNo || !reg.test(accNo)) {
                alertTip("[Account Number] <br> Please enter 10 to 11 valid characters.");
                flag = false;
            }
        }
        queryParams[$(this).attr('name')] = $(this).val();
    });
    if (!flag) {
        return false;
    }
    $('#customerList').datagrid({
        url: 'reprintCardController.do?datagrid&field=accNo,mobileNumber,installationNumber,salutation,blockNumber,streetName,address,printCardTimes,cardFee,',
        pageNumber: 1,
        onLoadSuccess: function (data) {
            if (data.total == 0) {
                alertTip("No record found.");
            }
        }
    });

}

function searchReset(name) {
    $("#" + name + "tb").find(":input").val("");
    $("#" + name).datagrid('loadData', {total: 0, rows: []});
}

function printTopUpCard() {
    var rows = $('#customerList').datagrid('getSelections');
    if (rows.length == 0) {
        alertTip("At least select one record");
        return false;
    }
    var acc_no = rows[0].accNo;
    var amount = $("#amount").val();
    layer.confirm(
        'Confirm print Top-Up Card ?', function (t) {
            if (t) {
                layer.closeAll();
                var url = 'reprintCardController.do?print&accno=' + rows[0].accNo;
                var title = 'Print Top-Up Card';
                var width = 670;
                var height = 450;
                createprintwindow(title, url, width, height, acc_no, amount);
            }
        }
    )
}
//     var newUrl = 'reprintCardController.do?print&accno=' + rows[0].accNo;
//     if (typeof(windowapi) == 'undefined') {
//         $.dialog({
//             content: 'url:' + addurl,
//             zIndex: getzIndex(),
//             lock: true,
//             width: width,
//             height: height,
//             title: title,
//             opacity: 0.3,
//             okVal: ' Print ',
//             ok: function () {
//                 iframe = parent.window.frames[0].frameElement.contentWindow;
//                 iframe.printall();
//                 // var content = "Sure to Print?";
//                 // layer.confirm(content, {
//                 //     btn: ['Confirm', 'Cancel'], //按钮
//                 //     shade: false //不显示遮罩
//                 // }, function () {
//                 //     var flag =false;
//                 //     $.ajax({
//                 //        url: "reprintCardController.do?topUpCardFee",
//                 //        cache: false,
//                 //         async: false,
//                 //         data: "accNo="+acc_no+"&topupAmt="+$("#amount").val(),
//                 //         success: function(){
//                 //             flag = true;
//                 //         },
//                 //         error: function () {
//                 //             alertTip("operate failed！");
//                 //         }
//                 //
//                 //     });
//                 //     // $.post("reprintCardController.do?topUpCardFee", {
//                 //     //         "accNo": acc_no,
//                 //     //         "topupAmt": $("#amount").val(),
//                 //     //     },
//                 //     //     function (data) {
//                 //     //         if (data.success) {
//                 //     //             flag = true;
//                 //     //         } else {
//                 //     //             alertTip("operate failed！");
//                 //     //         }
//                 //     //     }, "json");
//                 //     if(flag){
//                 //         iframe = parent.window.frames[0].frameElement.contentWindow;
//                 //         iframe.printall();
//                 //     }
//                 // }, function () {
//                 //     return;
//                 // });
//             },
//             cache: false,
//             cancelVal: 'Cancel',
//             cancel: true /*为true等价于function(){}*/
//         });
//     } else {
//         W.$.dialog({
//             content: 'url:' + addurl,
//             zIndex: getzIndex(),
//             lock: true,
//             width: width,
//             height: height,
//             parent: windowapi,
//             title: title,
//             opacity: 0.3,
//             cache: false,
//             cancelVal: 'Close',
//             cancel: function () {
//                 windowapi.zindex();
//             }
//         });
//
//     }
// }
var mark = false;
function createprintwindow(title, addurl, width, height, accNo, amount) {
    width = width ? width : 700;
    height = height ? height : 400;
    if (width == "100%" || height == "100%") {
        width = window.top.document.body.offsetWidth;
        height = window.top.document.body.offsetHeight - 100;
    }
    if (typeof(windowapi) == 'undefined') {
        $.dialog({
            resizable: true,
            content: 'url:' + addurl,
            zIndex: getzIndex(),
            lock: true,
            width: width,
            height: height,
            title: title,
            opacity: 0.3,
            cache: false,
            okVal: ' Print ',
            ok: function () {
                iframe = this.iframe.contentWindow;
                iframe.printall();
                mark = true;
                return false;
            },
            cancelVal: 'Close',
            cancel: function () {
                if(mark){
                    mark = false;
                    layer.confirm(
                        'print Card Successful ?',{btn:['YES','NO']}, function (t) {
                            if (t) {
                                layer.closeAll();
                                $.ajax({
                                    type: "post",
                                    url: "reprintCardController.do?topUpCardFee",
                                    data: {
                                        accNo: accNo,
                                        topupAmt: amount
                                    },
                                    dataType: "json",
                                    success: function (result) {
                                        $('#customerList').datagrid('reload');
                                    }
                                });
                                layer.confirm(
                                    'Confirm print Receipt ?', function (t) {
                                        if (t) {
                                            layer.closeAll();
                                            printReceipt(accNo);
                                        }
                                    }
                                )
                            }
                        }
                    )
                }
            }
        });
    }
}

function printReceipt(noVal) {

    var acc_no = noVal;
    var newUrl = 'reprintCardController.do?receiptPrint&accno=' + acc_no;
    var title = 'Print Receipt';
    var addurl = newUrl;
    var width = 670;
    var height = 450;
    if (typeof(windowapi) == 'undefined') {
        $.dialog({
            content: 'url:' + addurl,
            zIndex: getzIndex(),
            lock: true,
            width: width,
            height: height,
            title: title,
            opacity: 0.3,
            okVal: ' Print ',
            ok: function () {
                iframe = parent.window.frames[0].frameElement.contentWindow;
                iframe.printall();
                return false;
            },
            cache: false,
            cancelVal: 'Cancel',
            cancel: true /*为true等价于function(){}*/
        });
    } else {
        W.$.dialog({
            content: 'url:' + addurl,
            zIndex: getzIndex(),
            lock: true,
            width: width,
            height: height,
            parent: windowapi,
            title: title,
            opacity: 0.3,
            cache: false,
            cancelVal: 'Close',
            cancel: function () {
                windowapi.zindex();
            }
        });
    }
}