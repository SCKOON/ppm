package com.ppms.consumptionBillingQuery.dao.imp;

import com.ppms.consumptionBillingQuery.dao.ConsumptionBillingDao;
import com.ppms.utils.FormatValidateUtil;
import com.ppms.vo.ConsumptionBillingResultVo;
import com.ppms.utils.DataReturn;
import org.hibernate.Query;
import org.jeecgframework.core.common.dao.impl.GenericBaseCommonDao;
import org.springframework.stereotype.Repository;

import javax.servlet.http.HttpServletRequest;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Repository
public class ConsumptionBillingDaoImp extends GenericBaseCommonDao implements ConsumptionBillingDao{

        private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        @Override
        public DataReturn getAllEntities(ConsumptionBillingResultVo resultVo, int page, int rows, HttpServletRequest request,String lowCB) throws ParseException{

//            StringBuilder hql = new StringBuilder("select c.accNo,c.name,c.activationDate,c.accountStatus,b.meterId,b.consumption,m.ddSrc,b.charge,b.billing,b.gst,b.lastBal,b.curBal,b.calTime from CustomerInfoEntity as c,ChgBillingComptEntity as b,MeterDataEntity as m  where c.accNo=b.accNo and b.dataId=m.id");
            //StringBuilder hql = new StringBuilder("select c.accNo,c.name,c.activationDate,c.accountStatus,b.meterId,b.consumption,m.ddSrc,b.charge,b.billing,b.gst,b.lastBal,b.curBal,b.calTime,b.dataType,m.dataTime from CustomerInfoEntity as c,ChgBillingComptEntity as b,MeterDataEntity as m  where c.accNo=b.accNo and b.dataId=m.id");
            StringBuilder hql = new StringBuilder("select c.accNo,c.name,c.activationDate,c.accountStatus,b.meterId,b.consumption,b.charge,b.billing,b.gst,b.lastBal,b.curBal,b.calTime,b.dataType,b.curDataTime from CustomerInfoEntity as c,ChgBillingComptEntity as b where c.accNo=b.accNo ");



            StringBuilder condition = new StringBuilder("");
            List params = new ArrayList();
            BigDecimal dbLow = new BigDecimal(lowCB);

            String AoM = request.getParameter("AoM");
            String CB = request.getParameter("CB");//low or normal
            String tempCont = request.getParameter("tempCont");
            String date_begin = request.getParameter("calTime_begin");
            String date_end = request.getParameter("calTime_end");
            String dataType = request.getParameter("dataType");
            
            String temp []  = tempCont.split(",");

            if(AoM.equals("01")){
                for(int i=0;i<temp.length;i++){
                    temp[i] = FormatValidateUtil.validateAccNo(temp[i]);
                }
            }else if(AoM.equals("01")){
                for(int i=0;i<temp.length;i++){
                    temp[i] = FormatValidateUtil.validateMeterId(temp[i]);
                }

            }


            if(AoM.equals("01") && tempCont != null && !"".equals(tempCont)){
                condition.append(" and c.accNo in (:nums)");           
            }else if(AoM.equals("02") && tempCont != null && !"".equals(tempCont)){
                condition.append(" and b.meterId in (:nums)");
            }

            if (date_begin != null && !"".equals(date_begin)) {
                condition.append(" and b.calTime >= :calTimeB ");
            }

            if (date_end != null && !"".equals(date_end)) {
                condition.append(" and b.calTime <= :calTimeE ");          
            }
            if (dataType != null && !"".equals(dataType)) {
                condition.append(" and b.dataType = :dataType ");
            }

            if (CB != null && !"".equals(CB)) {
                if(CB.equals("01")){
                    condition.append(" and b.lastBal < :lastBal");
                }else if(CB.equals("02")){
                    condition.append(" and b.lastBal >= :lastBal");
                }
            }
            
            String hqlQuery = hql.append(condition.toString()).toString();
            Query q = getSession().createQuery(hqlQuery);
            
            if(tempCont != null && !"".equals(tempCont) && tempCont != null && !"".equals(tempCont)){
                q.setParameterList("nums", temp);               
            }
            if(date_begin!= null && !"".equals(date_begin)){
            	
              	 q.setParameter("calTimeB", sdf.parse(date_begin));
              }
            if(date_end!= null && !"".equals(date_end)){
            	  Calendar calendar = Calendar.getInstance();
                  calendar.setTime(sdf.parse(date_end));
                  calendar.add(Calendar.DAY_OF_MONTH,1);   	
              	 q.setParameter("calTimeE", calendar.getTime());
              }
            if(dataType!= null && !"".equals(dataType)){
              	 q.setParameter("dataType", dataType);
              	 }
            if(CB!= null && !"".equals(CB)){
                q.setParameter("lastBal", dbLow);
            }

            
            List listSize = q.list();
            int count = listSize.size();
            q.setFirstResult((page - 1) * rows).setMaxResults(rows);
            List list = q.list();

            List<ConsumptionBillingResultVo> resultVos = new ArrayList<>();
            DecimalFormat df = new DecimalFormat("0.00");

            for(int i=0; i < list.size(); i++){
                Object[] objects = (Object[]) list.get(i);
                ConsumptionBillingResultVo resultVo1 = new ConsumptionBillingResultVo();
                resultVo1.setAccNo((String) objects[0]);
                resultVo1.setName((String) objects[1]);
                resultVo1.setActivationDate((Date) objects[2]);
                resultVo1.setAccountStatus((String) objects[3]);            
                resultVo1.setMeterId((String) objects[4]);
                if (objects[5] != null) {
                    BigDecimal big5 = ((BigDecimal) objects[5]).setScale(4, BigDecimal.ROUND_DOWN);
//                    double db5 = big5.doubleValue();
//                    String format = df.format(db5);
//                    BigDecimal bigbal = new BigDecimal(format);
                    resultVo1.setConsumption(big5);
                }

              //  resultVo1.setConsumption((BigDecimal) objects[5]);
               // resultVo1.setDdSrc((String) objects[6]);
                if (objects[6] != null) {
                    BigDecimal big7 = ((BigDecimal) objects[6]).setScale(6, BigDecimal.ROUND_DOWN);
//                    double db7 = big7.doubleValue();
//                    String format = df.format(db7);
//                    BigDecimal bigbal = new BigDecimal(format);
                    resultVo1.setCharge(big7);
                }
                if (objects[7] != null) {
                    BigDecimal big8 = ((BigDecimal) objects[7]).setScale(6, BigDecimal.ROUND_DOWN);
//                    double db8 = big8.doubleValue();
//                    String format = df.format(db8);
//                    BigDecimal bigbal = new BigDecimal(format);
                    resultVo1.setBilling(big8);
                }
                if (objects[8] != null) {
                    BigDecimal big9 = ((BigDecimal) objects[8]).setScale(6, BigDecimal.ROUND_DOWN);
//                    double db9 = big9.doubleValue();
//                    String format = df.format(db9);
//                    BigDecimal bigbal = new BigDecimal(format);
                    resultVo1.setGst(big9);
                }
                if (objects[9] != null) {
                    BigDecimal big10 = ((BigDecimal) objects[9]).setScale(2, BigDecimal.ROUND_DOWN);
                    double db10 = big10.doubleValue();
                    String format = df.format(db10);
                    BigDecimal bigbal = new BigDecimal(format);
                    resultVo1.setLastBal(bigbal);
                }
                if (objects[10] != null) {
                    BigDecimal big11 = ((BigDecimal) objects[10]).setScale(2, BigDecimal.ROUND_DOWN);
                    double db11 = big11.doubleValue();
                    String format = df.format(db11);
                    BigDecimal bigbal = new BigDecimal(format);
                    resultVo1.setCurBal(bigbal);
                }
                resultVo1.setCalTime((Date) objects[11]);
                resultVo1.setDtaType((String) objects[12]);
                resultVo1.setDataTime((Date) objects[13]);
               
                resultVos.add(resultVo1);
            }

            DataReturn data = new DataReturn();
            data.setRows(resultVos);
            data.setTotal(count);

            return data;
        }
    }
