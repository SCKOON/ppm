package com.ppms.connection.dao.impl;

import com.constants.Constants;
import com.ppms.connection.dao.ConnectionDao;
import com.ppms.entity.RemoteDisconRecEntity;
import com.ppms.entity.RemoteReconRecEntity;
import com.ppms.utils.DataReturn;
import com.ppms.vo.DisconRecordVo;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.jeecgframework.core.common.dao.impl.CommonDao;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Repository
public class ConnectionDaoImpl extends CommonDao implements ConnectionDao {

    private static final Logger logger = Logger.getLogger(ConnectionDaoImpl.class);

    /**
     * @param vo
     * @param page
     * @param rows
     * @return
     * @Description 跳闸记录查询 时间范围是对于生成时间和执行时间两个字段
     */
    @Override
    public DataReturn queryHourPeriodDisconRecord(DisconRecordVo vo, int page, int rows) {

        StringBuilder hql = new StringBuilder("from RemoteDisconRecEntity remoteDisconRecord where 1=1 ");

        StringBuilder condition = new StringBuilder("");
        List params = new LinkedList();

        if (vo != null) {
            condition.append(" and (remoteDisconRecord.genTime between ? and ? or remoteDisconRecord.exeStartTime between ? and ?)");
            if (vo.getBeginDate() != null && vo.getEndDate() != null) {
                params.add(vo.getBeginDate());
                params.add(vo.getEndDate());
                params.add(vo.getBeginDate());
                params.add(vo.getEndDate());
            } else if (vo.getBeginDate() != null) {
                params.add(vo.getBeginDate());
                params.add(vo.getBeginDate());
            } else if (vo.getEndDate() != null) {
                condition.append(" and (remoteDisconRecord.genTime < ? or remoteDisconRecord.exeStartTime < ?) ");
                params.add(vo.getEndDate());
                params.add(vo.getEndDate());
            }
            if (!StringUtils.isEmpty(vo.getCtlStatus())) {
                condition.append(" and remoteDisconRecord.ctlStatus = ?");
                params.add(vo.getCtlStatus());
            }
            if (!StringUtils.isEmpty(vo.getAccNo())) {
                condition.append(" and remoteDisconRecord.accNo = ?");
                params.add(vo.getAccNo());
            }
        }
        String hqlQuery = hql.append(condition.toString()).toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        q.setFirstResult((page - 1) * rows).setMaxResults(rows);
        int count = this.findHql(hqlQuery, params.toArray()).size();
        List<RemoteDisconRecEntity> counterEntities = q.list();
        DataReturn data = new DataReturn();
        data.setRows(counterEntities);
        data.setTotal(count);
        return data;
    }

    @Override
    public void getResultCount(DataGrid dataGrid, HttpServletRequest request) {
        Map map = new HashMap<String, Object>();
        StringBuilder stringBuilder = new StringBuilder(" select count(*) from RemoteReconRecEntity as entity where 1=1 ");
        String ctlStatus = request.getParameter("ctlStatus");
        String accNo = request.getParameter("accNo");
        String operStatus = request.getParameter("operStatus");

        if (oConvertUtils.isNotEmpty(accNo)) {
            if(accNo.length()  == 10){
                accNo = accNo + "P";
            }else if(accNo.length() != 11){
                return;
            }
            stringBuilder.append(" and entity.customerInfoEntity.accNo = :accNo");
            map.put("accNo", accNo);
        }
        if (oConvertUtils.isNotEmpty(operStatus)) {
            stringBuilder.append(" and entity.operStatus = :operStatus");
            map.put("operStatus", operStatus);
        }
        if (oConvertUtils.isNotEmpty(ctlStatus)) {
            stringBuilder.append(" and entity.ctlStatus = :ctlStatus");
            map.put("ctlStatus", ctlStatus);
        }
        Query query = super.getSession().createQuery(stringBuilder.toString());
        query.setProperties(map);
        Integer size = ((Long)query.uniqueResult()).intValue();
        dataGrid.setTotal(size);

    }

    @Override
    public List<RemoteReconRecEntity> queryReconRecord(DataGrid dataGrid, HttpServletRequest request) {
        List<RemoteReconRecEntity> remoteReconRecEntityList = null;
        Map map = new HashMap<String, Object>();
        StringBuilder stringBuilder = new StringBuilder(" from RemoteReconRecEntity as entity where 1=1 ");
        String ctlStatus = request.getParameter("ctlStatus");
        String accNo = request.getParameter("accNo");
        String operStatus = request.getParameter("operStatus");

        if (oConvertUtils.isNotEmpty(accNo)) {
            if(accNo.length()  == 10){
                accNo = accNo + "P";
            }else if(accNo.length() != 11){
                return null;
            }
            stringBuilder.append(" and entity.customerInfoEntity.accNo = :accNo");
            map.put("accNo", accNo);
        }
        if (oConvertUtils.isNotEmpty(operStatus)) {
            stringBuilder.append(" and entity.operStatus = :operStatus");
            map.put("operStatus", operStatus);
        }
        if (oConvertUtils.isNotEmpty(ctlStatus)) {
            stringBuilder.append(" and entity.ctlStatus = :ctlStatus");
            map.put("ctlStatus", ctlStatus);
        }
        stringBuilder.append(" order by entity." + dataGrid.getSort() + " " + dataGrid.getOrder());
        Query query = super.getSession().createQuery(stringBuilder.toString());
        query.setFirstResult((dataGrid.getPage()-1)*dataGrid.getRows()).setMaxResults(dataGrid.getRows());
        query.setProperties(map);
        remoteReconRecEntityList = query.list();
        dataGrid.setResults(remoteReconRecEntityList);
        return remoteReconRecEntityList;
    }

    @Override
    public Integer doSaveAndUpdate(RemoteReconRecEntity remoteReconRecEntity) {
        String meterId = remoteReconRecEntity.getMeterId();
        if(!StringUtils.isEmpty(meterId)){
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("update RemoteReconRecEntity set operStatus=:operStatus,operTime=:operTime where meterId=:meterId and operStatus=:pendingStatus");
            super.getSession().createQuery(stringBuffer.toString())
                    .setParameter("operStatus", Constants.REMOTER_PRO_STATUS.ABANDON.getType())
                    .setParameter("operTime",new Date())
                    .setParameter("meterId",meterId)
                    .setParameter("pendingStatus",Constants.REMOTER_PRO_STATUS.WAITING.getType())
                    .executeUpdate();
            return (Integer) super.save(remoteReconRecEntity);
        }
        return -1;
    }
}
