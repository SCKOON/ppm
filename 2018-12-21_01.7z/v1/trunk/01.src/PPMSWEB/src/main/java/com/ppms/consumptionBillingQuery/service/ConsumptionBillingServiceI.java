package com.ppms.consumptionBillingQuery.service;

import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;

import org.jeecgframework.core.common.service.CommonService;

import com.ppms.vo.ConsumptionBillingResultVo;
import com.ppms.utils.DataReturn;

public interface ConsumptionBillingServiceI extends CommonService{
	public DataReturn getAllEntities(ConsumptionBillingResultVo resultVo, int page, int rows, HttpServletRequest request,String lowCB) throws ParseException;

}
