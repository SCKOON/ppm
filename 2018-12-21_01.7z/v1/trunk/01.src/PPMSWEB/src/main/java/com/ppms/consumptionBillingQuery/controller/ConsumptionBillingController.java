package com.ppms.consumptionBillingQuery.controller;

import com.alibaba.fastjson.JSONObject;
import com.ppms.consumptionBillingQuery.service.ConsumptionBillingServiceI;
import com.ppms.tstypeQuery.service.TstypeServiceI;
import com.ppms.utils.DataReturn;
import com.ppms.vo.ConsumptionBillingResultVo;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.jeecgframework.web.system.service.SystemService;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.ppms.dictionary.service.DictServiceI;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Validator;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**   
 * @Title: Controller
 * @Description: M_METER_DATA
 * @author zhangdaihao
 * @date 2018-05-15 15:04:46
 * @version V1.0   
 *
 */
@Controller
@RequestMapping("/consumptionBillingController")
public class ConsumptionBillingController extends BaseController {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = Logger.getLogger(ConsumptionBillingController.class);

	@Autowired
	private ConsumptionBillingServiceI consumptionBillingService;
	@Autowired
	private TstypeServiceI tstypeService;
	@Autowired
	private DictServiceI dictServiceI;

	/**
	 * M_METER_DATA列表 页面跳转
	 * 
	 * @return
	 */
	@RequestMapping(params = "list")
	public ModelAndView list(HttpServletRequest request) {
		//return new ModelAndView("ppms/consumptionBillingQuery/consumptionBillingList");
		ModelAndView modelAndView = new ModelAndView("ppms/consumptionBillingQuery/consumptionBillingList");
		String dataType = tstypeService.getGroupIdByGroupCode("METER_DATA_TYPE");
		List<Map<String, Object>> datatypeList = tstypeService.getTypeCodeAndNameByGroupId(dataType);
		String dataTypeList = JSONObject.toJSONString(datatypeList);
		modelAndView.addObject("dataTypeList",dataTypeList);
		return modelAndView;
	}



	/**
	 * easyui AJAX请求数据
	 * 
	 * @param request
	 * @param response
	 * @param dataGrid
	 */

	@RequestMapping(params = "datagrid")
	public void datagrid(ConsumptionBillingResultVo resultVo,HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        DataReturn dataReturn;
		Map<String, String> map = new HashMap<>();
		map = this.dictServiceI.queryForOptions("LOW_CREDIT_ALARM", "LOW CREDIT ALARM");
		String lowCB = null;
		if (null != map && map.size() > 0) {
			lowCB = (String) map.values().toArray()[0];
		}
		System.out.println("lowCB:"+lowCB);
		try {
			dataReturn = this.consumptionBillingService.getAllEntities(resultVo,dataGrid.getPage(),dataGrid.getRows(),request,lowCB);
	        dataGrid.setResults(dataReturn.getRows());
	        dataGrid.setTotal((int)dataReturn.getTotal());
		} catch (ParseException e) {
			logger.error(e.getMessage(),e);
		}
        TagUtil.datagrid(response, dataGrid);
	}
	
	
	
}
