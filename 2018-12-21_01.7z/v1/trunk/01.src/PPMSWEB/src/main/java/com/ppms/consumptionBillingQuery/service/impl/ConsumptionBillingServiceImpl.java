package com.ppms.consumptionBillingQuery.service.impl;

import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ppms.consumptionBillingQuery.dao.ConsumptionBillingDao;
import com.ppms.consumptionBillingQuery.service.ConsumptionBillingServiceI;
import com.ppms.vo.ConsumptionBillingResultVo;
import com.ppms.utils.DataReturn;
import com.ppms.utils.DataSourceValue;

import org.jeecgframework.core.common.service.impl.CommonServiceImpl;
import org.jeecgframework.core.extend.datasource.DataSourceType;

@Service("consumptionBillingService")
@Transactional
@DataSourceValue(DataSourceType.dataSource_ppms)
public class ConsumptionBillingServiceImpl extends CommonServiceImpl implements ConsumptionBillingServiceI {
    @Autowired
    private ConsumptionBillingDao consumptionBillingDao;
    
    @Override
    @DataSourceValue(DataSourceType.dataSource_ppms)
    public DataReturn getAllEntities(ConsumptionBillingResultVo resultVo, int page, int rows, HttpServletRequest request,String lowCB) throws ParseException{

        return consumptionBillingDao.getAllEntities(resultVo,page,rows,request,lowCB);
    }
	
}