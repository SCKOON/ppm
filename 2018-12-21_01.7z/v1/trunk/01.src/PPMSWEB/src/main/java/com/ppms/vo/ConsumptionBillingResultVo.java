package com.ppms.vo;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;


public class ConsumptionBillingResultVo {

	private String accNo;
	private String name;
	private String dataType;
	private Date activationDate;
	private String accountStatus;
	private String meterId;
	private BigDecimal consumption;
	//private String ddSrc;
	private BigDecimal charge;
	private BigDecimal billing;
	private BigDecimal gst;
	private BigDecimal lastBal;
	private BigDecimal curBal;
	private Date calTime;
	private Date dataTime;


	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

	public String getName(){
		return this.dataType;
	}
	public void setName(String dataType){
		this.dataType = dataType;
	}

	public String getDataType(){
		return this.dataType;
	}
	public void setDtaType(String dataType){
		this.dataType = dataType;
	}

	public Date getActivationDate(){
		return this.activationDate;
	}
	public void setActivationDate(Date activationDate){
		this.activationDate = activationDate;
	}

	public String getAccountStatus(){
		return this.accountStatus;
	}
	public void setAccountStatus(String accountStatus){
		this.accountStatus = accountStatus;
	}

	public String getMeterId(){
		return this.meterId;
	}
	public void setMeterId(String meterId){
		this.meterId = meterId;
	}

	public BigDecimal getConsumption(){
		return this.consumption;
	}
	public void setConsumption(BigDecimal consumption){
		this.consumption = consumption;
	}

/*	public java.lang.String getDdSrc(){
		return this.ddSrc;
	}
	public void setDdSrc(java.lang.String ddSrc){
		this.ddSrc = ddSrc;
	}*/

	public BigDecimal getBilling(){
		return this.billing;
	}
	public void setBilling(BigDecimal billing){
		this.billing = billing;
	}

	public BigDecimal getCharge(){
		return this.charge;
	}
	public void setCharge(BigDecimal charge){
		this.charge = charge;
	}

	public BigDecimal getGst(){
		return this.gst;
	}
	public void setGst(BigDecimal gst){
		this.gst = gst;
	}


	public BigDecimal getLastBal(){
		return this.lastBal;
	}
	public void setLastBal(BigDecimal lastBal){
		this.lastBal = lastBal;
	}

	public BigDecimal getCurBal(){
		return this.curBal;
	}
	public void setCurBal(BigDecimal curBal){
		this.curBal = curBal;
	}

	public java.util.Date getCalTime() {
		return calTime;
	}

	public void setCalTime(java.util.Date calTime) {
		this.calTime = calTime;
	}

	public java.util.Date getDataTime() {
		return dataTime;
	}

	public void setDataTime(java.util.Date dataTime) {
		this.dataTime = dataTime;
	}
}
