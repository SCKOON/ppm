package com.ppms.customerinfoQuery.dao.imp;

import com.ppms.customerinfoQuery.dao.CustomerInfoQueryDao;
import com.ppms.utils.DataReturn;
import com.ppms.utils.FormatValidateUtil;
import com.ppms.vo.CustomerMeterBalVo;
import org.hibernate.Query;
import org.jeecgframework.core.common.dao.impl.GenericBaseCommonDao;
import org.jeecgframework.core.util.StringUtil;
import org.springframework.stereotype.Repository;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Repository
public class CustomerInfoQueryDaoImp extends GenericBaseCommonDao implements CustomerInfoQueryDao {


    @Override
    public DataReturn getDataGridReturn(CustomerMeterBalVo resultVo, int page, int rows, HttpServletRequest request) throws ParseException{

        //StringBuilder hql = new StringBuilder("from CustomerMeterBalEntity where 1=1 ");
        StringBuilder hql = new StringBuilder("select c.accNo,c.accountStatus,c.balance,c.updateTime,c.mobileNumber,c.emailAddr,c.openDate,c.address from CustomerMeterBalEntity as c where 1=1 ");

        // DetailedTransactionEntity
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();



        String mobileNumber = FormatValidateUtil.validateMobileNo(resultVo.getMobileNumber());
        String address = resultVo.getAddress();
        String accNo = FormatValidateUtil.validateAccNo(resultVo.getAccNo());
        String accountStatus = resultVo.getAccountStatus();
        String meterId = FormatValidateUtil.validateMeterId(resultVo.getMeterId());


        if(!StringUtil.isEmpty(mobileNumber)){
            condition.append(" and mobileNumber = ? ");
            params.add(mobileNumber);
        }


        if(!StringUtil.isEmpty(address)){
            condition.append(" and c.address like ? ");
            params.add("%" + address  + "%");
        }

        if(!StringUtil.isEmpty(accNo)){
            condition.append(" and c.accNo = ? ");
            params.add(accNo);
        }

        if(!StringUtil.isEmpty(accountStatus)){
            condition.append(" and c.accountStatus = ? ");
            params.add(accountStatus);
        }

        String hqlQuery = hql.append(condition.toString()).toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        q.setFirstResult((page - 1) * rows).setMaxResults(rows);
        int count = this.findHql(hqlQuery, params.toArray()).size();
        List list = q.list();
        DecimalFormat df = new DecimalFormat("0.00");
        List<CustomerMeterBalVo> resultVos = new ArrayList<>();

        for(int i=0; i < list.size(); i++){
            Object[] objects = (Object[]) list.get(i);
            CustomerMeterBalVo resultVo1 = new CustomerMeterBalVo();
            resultVo1.setAccNo((String) objects[0]);
            resultVo1.setAccountStatus((String) objects[1]);
//            resultVo1.setMeterId((String) objects[2]);

            BigDecimal topupAmt1 = (BigDecimal) objects[2];
//            double v = topupAmt1.setScale(2, BigDecimal.ROUND_DOWN).doubleValue();
//            String format1 = df.format(v);
//            BigDecimal topupAmt = new BigDecimal(format1);
            resultVo1.setBalance(topupAmt1.setScale(2, BigDecimal.ROUND_DOWN));

            resultVo1.setUpdateTime((Date) objects[3]);
            resultVo1.setMobileNumber((String) objects[4]);
            resultVo1.setEmailAddr((String) objects[5]);
            resultVo1.setOpenDate((Date) objects[6]);
            resultVo1.setAddress((String) objects[7]);

            resultVos.add(resultVo1);
        }

        DataReturn data = new DataReturn();
        data.setRows(resultVos);
        data.setTotal(count);

        return data;
    }
}
