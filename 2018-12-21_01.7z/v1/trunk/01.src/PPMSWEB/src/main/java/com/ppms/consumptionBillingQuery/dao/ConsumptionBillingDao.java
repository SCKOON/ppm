package com.ppms.consumptionBillingQuery.dao;

import com.ppms.vo.ConsumptionBillingResultVo;
import com.ppms.utils.DataReturn;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;

public interface ConsumptionBillingDao {

    public DataReturn getAllEntities(ConsumptionBillingResultVo resultVo, int page, int rows, HttpServletRequest request,String lowCB) throws ParseException;
}
