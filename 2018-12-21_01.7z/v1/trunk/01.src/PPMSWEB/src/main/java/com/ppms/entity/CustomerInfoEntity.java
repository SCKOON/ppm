package com.ppms.entity;

import com.ppms.utils.JsonDateSerializer;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;


import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

/**
 * @Title: Entity
 * @Description: 客户档案信息
 * @author zhangdaihao
 * @date 2018-04-17 11:20:12
 * @version V1.0
 *
 */
@Entity
@Table(name = "a_customer_info", schema = "")
@DynamicUpdate(true)
@DynamicInsert(true)
@JsonIgnoreProperties(value={"acctBalEntity","meterInfoEntitySet"})
@SuppressWarnings("serial")
public class CustomerInfoEntity implements java.io.Serializable {
	/**accNo*/
	private String accNo;
	/**name*/
	private String name;
	/**nric*/
	private String nric;
	/**installationNumber*/
	private String installationNumber;
	/**salutation*/
	private String salutation;
	/**address*/
	private String address;
	/**premiseType*/
	private String premiseType;
	/**blockNumber*/
	private String blockNumber;
	/**streetName*/
	private String streetName;
	/**unitNumber*/
	private String unitNumber;
	/**postalCode*/
	private String postalCode;
	/**mailAddr*/
	private String mailAddr;
	/**emailAddr*/
	private String emailAddr;
	/**telephoneNumber*/
	private String telephoneNumber;
	/**faxNumber*/
	private String faxNumber;
	/**mobileNumber*/
	private String mobileNumber;
	/**tariffCode*/
	private String tariffCode;
	/**gstCode*/
	private String gstCode;
	/**presetCredit*/
	private BigDecimal presetCredit;
	/**emergencyCredit*/
	private BigDecimal emergencyCredit;
	/**emergencyState*/
	private String emergencyState;
	/**lowCreditAlarm*/
	private BigDecimal lowCreditAlarm;
	/**disconnectAlarm*/
	private BigDecimal disconnectAlarm;
	/** '01：创建（待激活）
	 02：激活（允许充值）
	 03：暂停
	 99：销户;',*/
	private String accountStatus;
	/**openDate*/
	private Date openDate;
	/**sheduledActivationDate*/
	private Date sheduledActivationDate;
	/**activationDate*/
	private Date activationDate;
	/**closeDate*/
	private Date closeDate;
	/**initReads*/
	private BigDecimal initReads;
	/**finalReads*/
	private BigDecimal finalReads;
	/**customer type
	 01- EBS (Postpaid - prepaid)
	 02- PAYU*/
	private String type;
	/**delFlag*/
	private String delFlag;
	/**arrear percentage
	 */
	private BigDecimal arrearPct;

	@Column(name ="print_card_times",nullable=true,precision=10,scale=0,length=4)
	public Integer getPrintCardTimes() {
		return printCardTimes;
	}

	public void setPrintCardTimes(Integer printCardTimes) {
		this.printCardTimes = printCardTimes;
	}

	private java.lang.Integer printCardTimes;

	private java.lang.String ebsActivationNotify;


	/**
	 * meter info
	 */
	private Set<MeterInfoEntity> meterInfoEntitySet;

	// account balance information
	@JsonIgnore
	private AcctBalEntity acctBalEntity;

	@OneToOne(mappedBy = "customerInfoEntity",cascade = CascadeType.REMOVE)
	public AcctBalEntity getAcctBalEntity() {
		return acctBalEntity;
	}

	public void setAcctBalEntity(AcctBalEntity acctBalEntity) {
		this.acctBalEntity = acctBalEntity;
	}

	@OneToMany(mappedBy = "customerInfoEntity",cascade = CascadeType.REMOVE)
	public Set<MeterInfoEntity> getMeterInfoEntitySet() {
		return meterInfoEntitySet;
	}

	public void setMeterInfoEntitySet(Set<MeterInfoEntity> meterInfoEntitySet) {
		this.meterInfoEntitySet = meterInfoEntitySet;
	}

	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  accNo
	 */
	@Id
	@GeneratedValue(generator="increment")
	@GenericGenerator(name="increment", strategy = "assigned")
	@Column(name ="ACC_NO",nullable=false,precision=12,length=12)
	public String getAccNo(){
		return this.accNo;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  accNo
	 */
	public void setAccNo(String accNo){
		this.accNo = accNo;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  name
	 */
	@Column(name ="NAME",nullable=true,precision=80,length=80)
	public String getName(){
		return this.name;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  name
	 */
	public void setName(String name){
		this.name = name;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  nric
	 */
	@Column(name ="NRIC",nullable=true,precision=20,length=20)
	public String getNric(){
		return this.nric;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  nric
	 */
	public void setNric(String nric){
		this.nric = nric;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  installationNumber
	 */
	@Column(name ="installation_no",nullable=true,precision=12,length=12)
	public String getInstallationNumber(){
		return this.installationNumber;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  installationNumber
	 */
	public void setInstallationNumber(String installationNumber){
		this.installationNumber = installationNumber;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  salutation
	 */
	@Column(name ="SALUTATION",nullable=true,precision=4,length=4)
	public String getSalutation(){
		return this.salutation;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  salutation
	 */
	public void setSalutation(String salutation){
		this.salutation = salutation;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  address
	 */
	@Column(name ="ADDRESS",nullable=true,precision=300,length=300)
	public String getAddress(){
		return this.address;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  address
	 */
	public void setAddress(String address){
		this.address = address;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  premiseType
	 */
	@Column(name ="PREMISE_TYPE",nullable=true,precision=8,length=8)
	public String getPremiseType(){
		return this.premiseType;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  premiseType
	 */
	public void setPremiseType(String premiseType){
		this.premiseType = premiseType;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  blockNumber
	 */
	@Column(name ="BLOCK_NUMBER",nullable=true,precision=10,length=10)
	public String getBlockNumber(){
		return this.blockNumber;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  blockNumber
	 */
	public void setBlockNumber(String blockNumber){
		this.blockNumber = blockNumber;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  streetName
	 */
	@Column(name ="STREET_NAME",nullable=true,precision=60,length=60)
	public String getStreetName(){
		return this.streetName;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  streetName
	 */
	public void setStreetName(String streetName){
		this.streetName = streetName;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  unitNumber
	 */
	@Column(name ="UNIT_NUMBER",nullable=true,precision=10,length=10)
	public String getUnitNumber(){
		return this.unitNumber;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  unitNumber
	 */
	public void setUnitNumber(String unitNumber){
		this.unitNumber = unitNumber;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  postalCode
	 */
	@Column(name ="POSTAL_CODE",nullable=true,precision=10,length=10)
	public String getPostalCode(){
		return this.postalCode;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  postalCode
	 */
	public void setPostalCode(String postalCode){
		this.postalCode = postalCode;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  mailAddr
	 */
	@Column(name ="MAIL_ADDR",nullable=true,precision=300,length=300)
	public String getMailAddr(){
		return this.mailAddr;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  mailAddr
	 */
	public void setMailAddr(String mailAddr){
		this.mailAddr = mailAddr;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  emailAddr
	 */
	@Column(name ="EMAIL_ADDR",nullable=true,precision=241,length=241)
	public String getEmailAddr(){
		return this.emailAddr;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  emailAddr
	 */
	public void setEmailAddr(String emailAddr){
		this.emailAddr = emailAddr;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  telephoneNumber
	 */
	@Column(name ="TELEPHONE_NUMBER",nullable=true,precision=30,length=30)
	public String getTelephoneNumber(){
		return this.telephoneNumber;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  telephoneNumber
	 */
	public void setTelephoneNumber(String telephoneNumber){
		this.telephoneNumber = telephoneNumber;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  faxNumber
	 */
	@Column(name ="FAX_NUMBER",nullable=true,precision=30,length=30)
	public String getFaxNumber(){
		return this.faxNumber;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  faxNumber
	 */
	public void setFaxNumber(String faxNumber){
		this.faxNumber = faxNumber;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  mobileNumber
	 */
	@Column(name ="MOBILE_NUMBER",nullable=true,precision=30,length=30)
	public String getMobileNumber(){
		return this.mobileNumber;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  mobileNumber
	 */
	public void setMobileNumber(String mobileNumber){
		this.mobileNumber = mobileNumber;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  tariffCode
	 */
	@Column(name ="TARIFF_CODE",nullable=true,precision=8,length=8)
	public String getTariffCode(){
		return this.tariffCode;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  tariffCode
	 */
	public void setTariffCode(String tariffCode){
		this.tariffCode = tariffCode;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  gstCode
	 */
	@Column(name ="GST_CODE",nullable=true,precision=8,length=8)
	public String getGstCode(){
		return this.gstCode;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  gstCode
	 */
	public void setGstCode(String gstCode){
		this.gstCode = gstCode;
	}
	/**
	 *方法: 取得BigDecimal
	 *@return: BigDecimal  presetCredit
	 */
	@Column(name ="PRESET_CREDIT",nullable=true,precision=5,scale=2,length=5)
	public BigDecimal getPresetCredit(){
		return this.presetCredit;
	}

	/**
	 *方法: 设置BigDecimal
	 *@param: BigDecimal  presetCredit
	 */
	public void setPresetCredit(BigDecimal presetCredit){
		this.presetCredit = presetCredit;
	}
	/**
	 *方法: 取得BigDecimal
	 *@return: BigDecimal  emergencyCredit
	 */
	@Column(name ="EMERGENCY_CREDIT",nullable=true,precision=6,scale=2,length=5)
	public BigDecimal getEmergencyCredit(){
		return this.emergencyCredit;
	}

	/**
	 *方法: 设置BigDecimal
	 *@param: BigDecimal  emergencyCredit
	 */
	public void setEmergencyCredit(BigDecimal emergencyCredit){
		this.emergencyCredit = emergencyCredit;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  emergencyState
	 */
	@Column(name ="EMERGENCY_STATE",nullable=true,precision=2,length=2)
	public String getEmergencyState(){
		return this.emergencyState;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  emergencyState
	 */
	public void setEmergencyState(String emergencyState){
		this.emergencyState = emergencyState;
	}
	/**
	 *方法: 取得BigDecimal
	 *@return: BigDecimal  lowCreditAlarm
	 */
	@Column(name ="LOW_CREDIT_ALARM",nullable=true,precision=6,scale=2,length=5)
	public BigDecimal getLowCreditAlarm(){
		return this.lowCreditAlarm;
	}

	/**
	 *方法: 设置BigDecimal
	 *@param: BigDecimal  lowCreditAlarm
	 */
	public void setLowCreditAlarm(BigDecimal lowCreditAlarm){
		this.lowCreditAlarm = lowCreditAlarm;
	}
	/**
	 *方法: 取得BigDecimal
	 *@return: BigDecimal  disconnectAlarm
	 */
	@Column(name ="DISCONNECT_ALARM",nullable=true,precision=4,scale=2,length=5)
	public BigDecimal getDisconnectAlarm(){
		return this.disconnectAlarm;
	}

	/**
	 *方法: 设置BigDecimal
	 *@param: BigDecimal  disconnectAlarm
	 */
	public void setDisconnectAlarm(BigDecimal disconnectAlarm){
		this.disconnectAlarm = disconnectAlarm;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String   '01：创建（待激活）
	02：激活（允许充值）
	03：暂停
	99：销户;',
	 */
	@Column(name ="ACCOUNT_STATUS",nullable=true,precision=2,length=2)
	public String getAccountStatus(){
		return this.accountStatus;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String   '01：创建（待激活）
	02：激活（允许充值）
	03：暂停
	99：销户;',
	 */
	public void setAccountStatus(String accountStatus){
		this.accountStatus = accountStatus;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  openDate
	 */
	@Column(name ="OPEN_DATE",nullable=true,precision=23,scale=3,length=8)
	@JsonSerialize(using = JsonDateSerializer.class)
	public Date getOpenDate(){
		return this.openDate;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  openDate
	 */
	public void setOpenDate(Date openDate){
		this.openDate = openDate;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  sheduledActivationDate
	 */
	@Column(name ="SHEDULED_ACTIVATION_DATE",nullable=true,precision=23,scale=3,length=8)
	public Date getSheduledActivationDate(){
		return this.sheduledActivationDate;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  sheduledActivationDate
	 */
	public void setSheduledActivationDate(Date sheduledActivationDate){
		this.sheduledActivationDate = sheduledActivationDate;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  activationDate
	 */
	@Column(name ="ACTIVATION_DATE",nullable=true,precision=23,scale=3,length=8)
	public Date getActivationDate(){
		return this.activationDate;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  activationDate
	 */
	public void setActivationDate(Date activationDate){
		this.activationDate = activationDate;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  closeDate
	 */
	@Column(name ="CLOSE_DATE",nullable=true,precision=23,scale=3,length=8)
	public Date getCloseDate(){
		return this.closeDate;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  closeDate
	 */
	public void setCloseDate(Date closeDate){
		this.closeDate = closeDate;
	}
	/**
	 *方法: 取得BigDecimal
	 *@return: BigDecimal  initReads
	 */
	@Column(name ="INIT_READS",nullable=true,precision=10,scale=4,length=9)
	public BigDecimal getInitReads(){
		return this.initReads;
	}

	/**
	 *方法: 设置BigDecimal
	 *@param: BigDecimal  initReads
	 */
	public void setInitReads(BigDecimal initReads){
		this.initReads = initReads;
	}
	/**
	 *方法: 取得BigDecimal
	 *@return: BigDecimal  finalReads
	 */
	@Column(name ="FINAL_READS",nullable=true,precision=10,scale=4,length=9)
	public BigDecimal getFinalReads(){
		return this.finalReads;
	}

	/**
	 *方法: 设置BigDecimal
	 *@param: BigDecimal  finalReads
	 */
	public void setFinalReads(BigDecimal finalReads){
		this.finalReads = finalReads;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  customer type
	01- EBS (Postpaid - prepaid)
	02- PAYU
	 */
	@Column(name ="TYPE",nullable=true,precision=2,length=2)
	public String getType(){
		return this.type;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  customer type
	01- EBS (Postpaid - prepaid)
	02- PAYU
	 */
	public void setType(String type){
		this.type = type;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  delFlag
	 */
	@Column(name ="DEL_FLAG",nullable=true,precision=2,length=2)
	public String getDelFlag(){
		return this.delFlag;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  delFlag
	 */
	public void setDelFlag(String delFlag){
		this.delFlag = delFlag;
	}
	/**
	 *方法: 取得BigDecimal
	 *@return: BigDecimal  arrear percentage

	 */
	@Column(name ="ARREAR_PCT",nullable=true,precision=4,scale=2,length=5)
	public BigDecimal getArrearPct(){
		return this.arrearPct;
	}

	/**
	 *方法: 设置BigDecimal
	 *@param: BigDecimal  arrear percentage

	 */
	public void setArrearPct(BigDecimal arrearPct){
		this.arrearPct = arrearPct;
	}

	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  ????????????????????EBS??
	01- ?????
	02- ?????
	 */
	@Column(name ="EBS_ACTIVATION_NOTIFY",nullable=true,precision=2,length=2)
	public java.lang.String getEbsActivationNotify(){
		return this.ebsActivationNotify;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  ????????????????????EBS??
	01- ?????
	02- ?????
	 */
	public void setEbsActivationNotify(java.lang.String ebsActivationNotify){
		this.ebsActivationNotify = ebsActivationNotify;
	}

	@Override
	public String toString() {
		return "CustomerInfoEntity{" +
				"accNo='" + accNo + '\'' +
				", name='" + name + '\'' +
				", nric='" + nric + '\'' +
				", installationNumber='" + installationNumber + '\'' +
				", salutation='" + salutation + '\'' +
				", address='" + address + '\'' +
				", premiseType='" + premiseType + '\'' +
				", blockNumber='" + blockNumber + '\'' +
				", streetName='" + streetName + '\'' +
				", unitNumber='" + unitNumber + '\'' +
				", postalCode='" + postalCode + '\'' +
				", mailAddr='" + mailAddr + '\'' +
				", emailAddr='" + emailAddr + '\'' +
				", telephoneNumber='" + telephoneNumber + '\'' +
				", faxNumber='" + faxNumber + '\'' +
				", mobileNumber='" + mobileNumber + '\'' +
				", tariffCode='" + tariffCode + '\'' +
				", gstCode='" + gstCode + '\'' +
				", presetCredit=" + presetCredit +
				", emergencyCredit=" + emergencyCredit +
				", emergencyState='" + emergencyState + '\'' +
				", lowCreditAlarm=" + lowCreditAlarm +
				", disconnectAlarm=" + disconnectAlarm +
				", accountStatus='" + accountStatus + '\'' +
				", openDate=" + openDate +
				", sheduledActivationDate=" + sheduledActivationDate +
				", activationDate=" + activationDate +
				", closeDate=" + closeDate +
				", initReads=" + initReads +
				", finalReads=" + finalReads +
				", type='" + type + '\'' +
				", delFlag='" + delFlag + '\'' +
				", arrearPct=" + arrearPct +
				", printCardTimes=" + printCardTimes +
				", ebsActivationNotify='" + ebsActivationNotify + '\'' +
				", meterInfoEntitySet=" + meterInfoEntitySet +
				", acctBalEntity=" + acctBalEntity +
				'}';
	}
}
