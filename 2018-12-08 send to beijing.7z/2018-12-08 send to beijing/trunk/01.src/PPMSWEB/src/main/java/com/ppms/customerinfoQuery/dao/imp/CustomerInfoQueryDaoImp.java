package com.ppms.customerinfoQuery.dao.imp;

import com.ppms.customerinfoQuery.dao.CustomerInfoQueryDao;
import com.ppms.entity.CustomerMeterBalEntity;
import com.ppms.entity.DetailedTransactionEntity;
import com.ppms.utils.DataReturn;
import com.ppms.vo.CustomerMeterBalVo;
import com.ppms.vo.MeterDataResultVo;
import org.hibernate.Query;
import org.jeecgframework.core.common.dao.impl.GenericBaseCommonDao;
import org.jeecgframework.core.util.StringUtil;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.stereotype.Repository;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Repository
public class CustomerInfoQueryDaoImp extends GenericBaseCommonDao implements CustomerInfoQueryDao {


    @Override
    public DataReturn getDataGridReturn(CustomerMeterBalVo resultVo, int page, int rows, HttpServletRequest request) throws ParseException{

        //StringBuilder hql = new StringBuilder("from CustomerMeterBalEntity where 1=1 ");
        StringBuilder hql = new StringBuilder("select c.accNo,c.accountStatus,c.meterId,c.balance,c.updateTime,c.mobileNumber,c.emailAddr,c.openDate,c.address from CustomerMeterBalEntity as c where 1=1 ");

        // DetailedTransactionEntity
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();


        String mobileNumber = request.getParameter("mobileNumber");
        String address = request.getParameter("address");
        String accNo = resultVo.getAccNo();
        String accountStatus = request.getParameter("accountStatus");
        String meterId = request.getParameter("meterId");


        if(!StringUtil.isEmpty(mobileNumber)){
            condition.append(" and mobileNumber like ? ");
            params.add( "%" + mobileNumber + "%");
        }


        if(!StringUtil.isEmpty(address)){
            condition.append(" and c.address like ? ");
            params.add("%" + address  + "%");
        }

        if(!StringUtil.isEmpty(accNo)){
            condition.append(" and c.accNo = ? ");
            params.add(accNo);
        }

        if(!StringUtil.isEmpty(accountStatus)){
            condition.append(" and c.accountStatus = ? ");
            params.add(accountStatus);
        }

        if(!StringUtil.isEmpty(meterId)){
            condition.append(" and c.meterId = ? ");
            params.add(meterId);
        }

        String hqlQuery = hql.append(condition.toString()).toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        q.setFirstResult((page - 1) * rows).setMaxResults(rows);
        int count = this.findHql(hqlQuery, params.toArray()).size();
        List list = q.list();
        DecimalFormat df = new DecimalFormat("0.00");
        List<CustomerMeterBalVo> resultVos = new ArrayList<>();

        for(int i=0; i < list.size(); i++){
            Object[] objects = (Object[]) list.get(i);
            CustomerMeterBalVo resultVo1 = new CustomerMeterBalVo();
            resultVo1.setAccNo((String) objects[0]);
            resultVo1.setAccountStatus((String) objects[1]);
            resultVo1.setMeterId((String) objects[2]);

            BigDecimal topupAmt1 = (BigDecimal) objects[3];
            double v = topupAmt1.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
            String format1 = df.format(v);
            BigDecimal topupAmt = new BigDecimal(format1);
            resultVo1.setBalance(topupAmt);

            resultVo1.setUpdateTime((Date) objects[4]);
            resultVo1.setMobileNumber((String) objects[5]);
            resultVo1.setEmailAddr((String) objects[6]);
            resultVo1.setOpenDate((Date) objects[7]);
            resultVo1.setAddress((String) objects[8]);

            resultVos.add(resultVo1);
        }

        DataReturn data = new DataReturn();
        data.setRows(resultVos);
        data.setTotal(count);

        return data;
    }
}
