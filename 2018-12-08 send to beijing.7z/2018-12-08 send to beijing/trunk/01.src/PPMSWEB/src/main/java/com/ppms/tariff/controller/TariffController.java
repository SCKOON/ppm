package com.ppms.tariff.controller;

import com.alibaba.fastjson.JSONObject;
import com.ppms.dictionary.service.DictServiceI;
import com.ppms.entity.TariffInfoEntity;
import com.ppms.entity.TariffRecordEntity;
import com.ppms.tariff.dto.TariffDTO;
import com.ppms.tariff.service.TariffServiceI;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.exception.BusinessException;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.common.model.json.ValidForm;
import org.jeecgframework.core.util.MyBeanUtils;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.*;

@Controller
@RequestMapping(value = {"/tariffController"})
public class TariffController extends BaseController {

    private static final Logger logger = Logger.getLogger(TariffController.class);

    //生成的tariff_version的前缀
    private static final String TYPEKEY = "TARIFF";

    //默认只允许新增一年的电价版本
    private int num = 1;

    @Autowired
    private TariffServiceI tariffServiceI;

    @Autowired
    private DictServiceI dictServiceI;

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    @RequestMapping(params = "toTariff")
    public ModelAndView goToView() {
        ModelAndView modelAndView = new ModelAndView("/ppms/tariff/tariffView");
        Map<String, String> tariffMap = this.dictServiceI.queryForOptions(TYPEKEY, null);
        List<Map<String, String>> nameList = this.formulateOptions(tariffMap);
        modelAndView.addObject("tariffList", JSONObject.toJSONString(nameList));
        return modelAndView;
    }

    @RequestMapping(params = "toTariffLog")
    public ModelAndView goToLogView() {
        return new ModelAndView("/ppms/tariff/tariffLogView");
    }

    @RequestMapping(params = "datagrid")
    public void datagrid(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        tariffServiceI.queryListByCondition(dataGrid, request);
        List<TariffDTO> dtoList = new ArrayList();
        if (null != dataGrid.getResults() && dataGrid.getResults().size() > 0) {
            List<TariffInfoEntity> tariffInfoEntities = dataGrid.getResults();
            for (TariffInfoEntity tariffInfoEntity : tariffInfoEntities) {
                TariffDTO dto = new TariffDTO();
                try {
                    MyBeanUtils.copyBeanNotNull2Bean(tariffInfoEntity, dto);
                } catch (Exception e) {
                    logger.error(e);
                }
                dtoList.add(dto);
            }
        }
        dataGrid.setResults(dtoList);
        TagUtil.datagrid(response, dataGrid);
    }

    @RequestMapping(params = "doDel")
    @ResponseBody
    public AjaxJson doDel(HttpServletRequest request) {
        logger.info("---delete tariff start---");
        AjaxJson j = new AjaxJson();
        String message = "Delete tariff failed";
        TariffInfoEntity entity = new TariffInfoEntity();
        String sid = request.getParameter("id");
        try {
            entity.setId(Integer.parseInt(sid));
            tariffServiceI.delete(entity);
            message = "Delete tariff successfully";
        } catch (Exception e) {
            logger.error(e);
            if (e instanceof BusinessException) {
                message = e.getMessage();
            }
        }
        j.setMsg(message);
        logger.info("--delete tariff end--,result:" + message);
        return j;
    }

    @RequestMapping(params = "toUpdate")
    public ModelAndView toUpdate(HttpServletRequest request) {
        logger.info("---to update tariff page---");
        String sid = request.getParameter("id");
        Map<String, String> tariffMap;
        Map<String, String> map = new HashMap<>();
        TariffInfoEntity tariffEntity = new TariffInfoEntity();
        TariffDTO dto = new TariffDTO();
        try {
            int id = Integer.parseInt(sid);
            tariffEntity = tariffServiceI.getEntity(TariffInfoEntity.class, id);
            tariffMap = this.dictServiceI.queryForOptions(TYPEKEY, null);
            String code = tariffEntity.getCode();
            if (tariffMap != null && tariffMap.size() > 0) {
                map.put(code, tariffMap.get(code));
            }
            MyBeanUtils.copyBeanNotNull2Bean(tariffEntity, dto);
        } catch (NumberFormatException e) {
            logger.error(e);
        } catch (Exception e) {
            logger.error(e);
        }
        request.setAttribute("entity", dto);
        List<Map<String, String>> nameList = this.formulateOptions(map);
        request.setAttribute("tariffName", JSONObject.toJSONString(nameList));
        return new ModelAndView("ppms/tariff/tariff-edit");
    }

    @RequestMapping(params = "toDetail")
    public ModelAndView detailView(HttpServletRequest request) {
        logger.info("---to detail tariff page---");
        String sid = request.getParameter("id");
        Map<String, String> tariffMap;
        Map<String, String> map = new HashMap<>();
        TariffInfoEntity tariffEntity = new TariffInfoEntity();
        TariffDTO dto = new TariffDTO();
        try {
            int id = Integer.parseInt(sid);
            tariffEntity = tariffServiceI.getEntity(TariffInfoEntity.class, id);
            tariffMap = this.dictServiceI.queryForOptions(TYPEKEY, null);
            String code = tariffEntity.getCode();
            if (tariffMap != null && tariffMap.size() > 0) {
                map.put(code, tariffMap.get(code));
            }
            MyBeanUtils.copyBeanNotNull2Bean(tariffEntity, dto);
        } catch (NumberFormatException e) {
            logger.error(e);
        } catch (Exception e) {
            logger.error(e);
        }
        request.setAttribute("entity", dto);
        List<Map<String, String>> nameList = this.formulateOptions(map);
        request.setAttribute("tariffName", JSONObject.toJSONString(nameList));
        return new ModelAndView("ppms/tariff/tariff-detail");
    }

    @RequestMapping(params = "toAdd")
    public ModelAndView toAdd(HttpServletRequest request) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("ppms/tariff/tariff-add");
        //查询数据库中已经设置的电价版本
        List<String> list = tariffServiceI.queryVersionInCurrentYear();
        //当前月份可以新增的版本
        Map<String, String> map = this.genereateVersion(this.num);
        for (String s : list) {
            if (oConvertUtils.isNotEmpty(s)) {
                map.remove(s);
            }
        }
        //包装电价版本
        List<Map<String, String>> maplist = this.formulateOptions(map);
        //包装电价信息
        Map<String, String> tariffMap = this.dictServiceI.queryForOptions(TYPEKEY, null);
        List<Map<String, String>> nameList = this.formulateOptions(tariffMap);

        //生成新增电价版本下拉框的数据
        modelAndView.addObject("version", JSONObject.toJSONString(maplist));
        modelAndView.addObject("tariffName", JSONObject.toJSONString(nameList));
        return modelAndView;
    }

    private List<Map<String, String>> formulateOptions(Map<String, String> map) {
        List<Map<String, String>> mapList = new ArrayList<>();
        if (map != null && map.size() > 0) {
            Set<Map.Entry<String, String>> entrySet = map.entrySet();
            Iterator iterator = entrySet.iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, String> entry = (Map.Entry<String, String>) iterator.next();
                Map<String, String> map1 = new HashMap<>();
                map1.put("code", entry.getKey());
                map1.put("name", entry.getValue());
                mapList.add(map1);
            }
        }
        return mapList;
    }

    /**
     * tariff 新增操作，必须校验日期日期是否和数据库的其它记录由重叠
     *
     * @param tariff
     * @param request
     * @return
     */
    @RequestMapping(params = "doSave")
    @ResponseBody
    public AjaxJson save(TariffDTO tariff, HttpServletRequest request) {
        logger.info("--add tariff start--");
        AjaxJson j = new AjaxJson();
        String message = "Add Tariff version [" + tariff.getVersion() + "] failed";
        TariffInfoEntity tariffEntity = new TariffInfoEntity();
        try {
            MyBeanUtils.copyBeanNotNull2Bean(tariff, tariffEntity);
            tariffServiceI.saveAndLog(tariffEntity);
            message = "Add Tariff version [" + tariff.getVersion() + "] successfully";
        } catch (BusinessException e) {
            message = e.getMessage();
        } catch (Exception e) {
            logger.error(e);
        }
        j.setMsg(message);
        logger.info("--add tariff end--,result:" + message);
        return j;
    }

    @RequestMapping(params = "doUpdate")
    @ResponseBody
    public AjaxJson update(TariffDTO tariff, HttpServletRequest request) {
        logger.info("--------update tariff start--------");
        AjaxJson j = new AjaxJson();
        String version = request.getParameter("version");
        String message = "update Tariff version [" + version + "] failed";
        TariffInfoEntity tariffEntity = new TariffInfoEntity();
        if (null != tariff.getId()) {
            try {
                MyBeanUtils.copyBeanNotNull2Bean(tariff, tariffEntity);
                tariffServiceI.updateAndLog(tariffEntity);
                message = "update Tariff version [" + version + "] successfully";
            } catch (BusinessException e) {
                message = e.getMessage();
            } catch (Exception e) {
                logger.error(e);
            }
        }

        j.setMsg(message);
        logger.info("---update tariff end---,result:" + message);
        return j;
    }

    @RequestMapping(params = "logdatagrid")
    public void datagridLog(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        this.tariffServiceI.queryLogListByCondition(dataGrid, request);
        List<TariffDTO> dtoList = new ArrayList<>();
        if (null != dataGrid.getResults() && dataGrid.getResults().size() > 0) {
            List<TariffRecordEntity> tariffInfoEntities = dataGrid.getResults();
            for (TariffRecordEntity tariffInfoEntity : tariffInfoEntities) {
                TariffDTO dto = new TariffDTO();
                try {
                    MyBeanUtils.copyBeanNotNull2Bean(tariffInfoEntity, dto);
                    dto.setRate(tariffInfoEntity.getKwhRate().setScale(4, BigDecimal.ROUND_DOWN).toPlainString());
                } catch (Exception e) {
                    logger.error(e);
                }
                dtoList.add(dto);
            }
            dataGrid.setResults(dtoList);
        }
        TagUtil.datagrid(response, dataGrid);

    }

    @RequestMapping(params = "queryNameExistOrNot")
    @ResponseBody
    public ValidForm queryNameExistOrNot(HttpServletRequest request) {
        ValidForm v = new ValidForm();
        String name = oConvertUtils.getString(request.getParameter("param"));
        String oldName = oConvertUtils.getString(request.getParameter("name"));
        logger.info(" watch tariff name is exist or not. newName:[" + name + "]，oldname[" + oldName + "]");
        List<TariffInfoEntity> tariffEntityList = new ArrayList<>();
        if (!StringUtils.isEmpty(name)) {
            CriteriaQuery criteriaQuery = new CriteriaQuery(TariffInfoEntity.class);
            criteriaQuery.eq("name", name);
            criteriaQuery.add();
            try {
                tariffEntityList = this.tariffServiceI.getListByCriteriaQuery(criteriaQuery, false);
            } catch (Exception e) {
                logger.error(e);
            }
        }


        if (tariffEntityList != null && tariffEntityList.size() > 0 && !name.equals(oldName)) {
            v.setInfo("Tariff name exists");
            v.setStatus("n");
        }
        logger.info("watch tariff name is exist or not , result:" + v.getInfo());
        return v;
    }

    /**
     * 自动生成tariff version，生成格式为2018Q3格式
     *
     * @param years 生成几年的版本，默认生成当前时间的往后推一年的版本
     * @return
     */
    private Map<String, String> genereateVersion(Integer years) {
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        //获取当前日期的年月
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);

        //获取当前季度
        int quarter = month / 3 + 1;

        if (null == years || years > 2) {
            years = 1;
        }
        Map<String, String> map = new LinkedHashMap();
        for (int i = 0; i < 4; i++) {
            if (quarter == 4) {
                year += 1;
                quarter = 1;
            } else {
                quarter += 1;
            }
            String value = year + "Q" + quarter;
            //生成新增的版本下拉框
            map.put(value, value);
        }
        return map;
    }
}
