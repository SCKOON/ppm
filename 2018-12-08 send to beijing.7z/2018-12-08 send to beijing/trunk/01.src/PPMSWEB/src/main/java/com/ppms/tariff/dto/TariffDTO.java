package com.ppms.tariff.dto;

import java.math.BigDecimal;
import java.util.Date;

public class TariffDTO {

    private Integer id;
    /**name*/
    private String name;
    /**startTime*/
    private Date startTime;
    /**endTime*/
    private Date endTime;
    /**kwhRate*/
    private String rate;
    /**version*/
    private String version;
    /**code*/
    private String code;

    private Date createTime;

    /**operId*/
    private String operName;
    /**operDate*/
    private Date operDate;
    /**01:create
     02:edit
     03:delete*/
    private String operType;
    /**remark*/
    private String remark;

    public String getOperName() {
        return operName;
    }

    public void setOperName(String operName) {
        this.operName = operName;
    }

    public Date getOperDate() {
        return operDate;
    }

    public void setOperDate(Date operDate) {
        this.operDate = operDate;
    }

    public String getOperType() {
        return operType;
    }

    public void setOperType(String operType) {
        this.operType = operType;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return "TariffDTO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", kwhRate=" + rate +
                ", version='" + version + '\'' +
                ", code='" + code + '\'' +
                '}';
    }
}
