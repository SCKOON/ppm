package com.ppms.channelManagement.dto;

import org.jeecgframework.poi.excel.annotation.Excel;

import java.util.Date;

public class ChannelDTO {

    private java.lang.String code;

    private java.lang.String type;

    private java.lang.String isAuto;

    private java.lang.String name;

    private java.lang.String status;

    private java.lang.String remark;

    private java.lang.Integer dayToGenerateFile;

    private java.lang.Integer id;

    private java.util.Date createTime;
    /**creator*/
    @Excel(name="creator")
    private java.lang.String creator;

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getIsAuto() {
        return isAuto;
    }

    public void setIsAuto(String isAuto) {
        this.isAuto = isAuto;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getDayToGenerateFile() {
        return dayToGenerateFile;
    }

    public void setDayToGenerateFile(Integer dayToGenerateFile) {
        this.dayToGenerateFile = dayToGenerateFile;
    }


}
