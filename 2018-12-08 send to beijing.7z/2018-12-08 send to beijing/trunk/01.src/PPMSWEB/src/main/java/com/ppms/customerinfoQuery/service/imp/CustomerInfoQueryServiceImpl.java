package com.ppms.customerinfoQuery.service.imp;
import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.ppms.customerinfoQuery.dao.CustomerInfoQueryDao;
import com.ppms.entity.CustomerMeterBalEntity;
import com.ppms.entity.DetailedTransactionEntity;
import com.ppms.transactionInfoReport.dao.TransactionInfoReportDao;
import com.ppms.utils.DataReturn;
import com.ppms.vo.CustomerMeterBalVo;
import com.ppms.vo.RefundSummaryInfoVo;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.dao.jdbc.JdbcDao;
import org.jeecgframework.core.common.service.impl.CommonServiceImpl;
import org.jeecgframework.core.extend.datasource.DataSourceType;
import org.jeecgframework.core.util.*;
import org.jeecgframework.web.cgform.enhance.CgformEnhanceJavaInter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ppms.customerinfoQuery.service.CustomerInfoQueryServiceI;
import com.ppms.utils.DataSourceValue;

import javax.servlet.http.HttpServletRequest;

@Service("customerInfoQueryService")
@Transactional
@DataSourceValue(DataSourceType.dataSource_ppms)
public class CustomerInfoQueryServiceImpl extends CommonServiceImpl implements CustomerInfoQueryServiceI {

    @Autowired
    private CustomerInfoQueryDao customerInfoQueryDao;

    public DataReturn getDataGridReturn(CustomerMeterBalVo resultVo, int page, int rows, HttpServletRequest request) throws ParseException{
        if(resultVo != null && oConvertUtils.isNotEmpty(resultVo.getAccNo())){
            String accno = resultVo.getAccNo();
            if(accno.length() == 10){
                accno = accno + "P";
                resultVo.setAccNo(accno);
            }
        }
        return customerInfoQueryDao.getDataGridReturn(resultVo,page,rows,request);

}

}