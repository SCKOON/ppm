package com.ppms.terminalManagement.dao;

import com.ppms.entity.CounterEntity;
import com.ppms.entity.TerminalEntity;
import com.ppms.utils.DataReturn;
import org.jeecgframework.core.common.dao.IGenericBaseCommonDao;
import org.jeecgframework.core.common.model.json.DataGrid;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

public interface TerminalDao extends IGenericBaseCommonDao {

    //add by yangyong 20180802 start
    public DataReturn getNewAllEntities(TerminalEntity terminalEntity, int page, int rows, HttpServletRequest request,String chnlId);
    //add by yangyong 20180802 end

    /**
     * @Description 界面查询结果
     * @author sc
     * @param terminalEntity
     * @param dataGrid
     */
    public void queryAllTerminalForView(TerminalEntity terminalEntity, DataGrid dataGrid);

    /**
     * @description 查询terminal name和code是否重复
     * @param terminalEntity
     * @return
     */
    public List<TerminalEntity> queryTerminalInUser(TerminalEntity terminalEntity);

    /**
     * @description 当用户选择切换status的时候，查询对应关联的terminal的状态是否一致
     * @param terminalEntity
     * @return
     */
    public List<CounterEntity> queryCounterStatus(TerminalEntity terminalEntity);

    /**
     * 查询所有的terminal的terminalcode和terminalName
     * @return
     */
    public List<Map<String, String>> queryAllTerminalCodeAndName(String channelCode);

}
