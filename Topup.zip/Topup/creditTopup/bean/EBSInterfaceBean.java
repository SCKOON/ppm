package com.ppms.creditTopup.bean;

/**
 * Created by liangyadong on 2018/8/21 0021.
 */
public class EBSInterfaceBean {
    private String ERROR_CODE;
    private String Y_OPEN_AMNT;
    private String Y_OVERDUE_AMNT;
    private String Y_CREDIT_AMNT;

    public String getERROR_CODE() {
        return ERROR_CODE;
    }

    public void setERROR_CODE(String ERROR_CODE) {
        this.ERROR_CODE = ERROR_CODE;
    }

    public String getY_OPEN_AMNT() {
        return Y_OPEN_AMNT;
    }

    public void setY_OPEN_AMNT(String y_OPEN_AMNT) {
        Y_OPEN_AMNT = y_OPEN_AMNT;
    }

    public String getY_OVERDUE_AMNT() {
        return Y_OVERDUE_AMNT;
    }

    public void setY_OVERDUE_AMNT(String y_OVERDUE_AMNT) {
        Y_OVERDUE_AMNT = y_OVERDUE_AMNT;
    }

    public String getY_CREDIT_AMNT() {
        return Y_CREDIT_AMNT;
    }

    public void setY_CREDIT_AMNT(String y_CREDIT_AMNT) {
        Y_CREDIT_AMNT = y_CREDIT_AMNT;
    }
}
