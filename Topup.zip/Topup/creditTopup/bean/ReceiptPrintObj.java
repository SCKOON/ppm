package com.ppms.creditTopup.bean;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by yadongliang on 2018/6/4 0004.
 */
public class ReceiptPrintObj {

    //TopupRecordEntity
    private java.lang.String refNo;
    private java.lang.String accNo;
    private java.util.Date txnDate;
    private BigDecimal topupAmt;
    private BigDecimal arrearAmt;//20%
    private java.lang.String payMode;
    private BigDecimal prepaidAmt;//80%
    private java.lang.String channelCode;
    private java.lang.String tmnlCode;
    private java.lang.String counterId;
    private java.lang.String cashierId;
    private java.lang.String txnStatus;

    //ReceiptInfoEntity
    private String receiptType;
    private String printTimes;

    //扩展属性GST/Co Reg No 等
    private String ext1;
    private String ext2;
    private String ext3;
    private String ext4;
    private String ext5;

    public String getRefNo() {
        return refNo;
    }

    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }

    public String getAccNo() {
        return accNo;
    }

    public void setAccNo(String accNo) {
        this.accNo = accNo;
    }

    public Date getTxnDate() {
        return txnDate;
    }

    public void setTxnDate(Date txnDate) {
        this.txnDate = txnDate;
    }

    public BigDecimal getTopupAmt() {
        return topupAmt;
    }

    public void setTopupAmt(BigDecimal topupAmt) {
        this.topupAmt = topupAmt;
    }

    public BigDecimal getArrearAmt() {
        return arrearAmt;
    }

    public void setArrearAmt(BigDecimal arrearAmt) {
        this.arrearAmt = arrearAmt;
    }

    public String getPayMode() {
        return payMode;
    }

    public void setPayMode(String payMode) {
        this.payMode = payMode;
    }

    public BigDecimal getPrepaidAmt() {
        return prepaidAmt;
    }

    public void setPrepaidAmt(BigDecimal prepaidAmt) {
        this.prepaidAmt = prepaidAmt;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getTmnlCode() {
        return tmnlCode;
    }

    public void setTmnlCode(String tmnlCode) {
        this.tmnlCode = tmnlCode;
    }

    public String getCounterId() {
        return counterId;
    }

    public void setCounterId(String counterId) {
        this.counterId = counterId;
    }

    public String getCashierId() {
        return cashierId;
    }

    public void setCashierId(String cashierId) {
        this.cashierId = cashierId;
    }

    public String getTxnStatus() {
        return txnStatus;
    }

    public void setTxnStatus(String txnStatus) {
        this.txnStatus = txnStatus;
    }

    public String getReceiptType() {
        return receiptType;
    }

    public void setReceiptType(String receiptType) {
        this.receiptType = receiptType;
    }

    public String getPrintTimes() {
        return printTimes;
    }

    public void setPrintTimes(String printTimes) {
        this.printTimes = printTimes;
    }

    public String getExt1() {
        return ext1;
    }

    public void setExt1(String ext1) {
        this.ext1 = ext1;
    }

    public String getExt2() {
        return ext2;
    }

    public void setExt2(String ext2) {
        this.ext2 = ext2;
    }

    public String getExt3() {
        return ext3;
    }

    public void setExt3(String ext3) {
        this.ext3 = ext3;
    }

    public String getExt4() {
        return ext4;
    }

    public void setExt4(String ext4) {
        this.ext4 = ext4;
    }

    public String getExt5() {
        return ext5;
    }

    public void setExt5(String ext5) {
        this.ext5 = ext5;
    }
}
