package com.ppms.creditTopup.bean;

/**
 * @Author: liangyadong
 * @Date: 2018/11/30 0030 10:02
 * @Description:
 */
public class TopupPreviewVO {

    private String accountNo;
    private String topupAmt;
    private String prepaidAmt;
    private String arrearAmt;
    private String oldBalance;
    private String newBalance;
    private String topupDate;
    private String topupTime;

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getTopupAmt() {
        return topupAmt;
    }

    public void setTopupAmt(String topupAmt) {
        this.topupAmt = topupAmt;
    }

    public String getPrepaidAmt() {
        return prepaidAmt;
    }

    public void setPrepaidAmt(String prepaidAmt) {
        this.prepaidAmt = prepaidAmt;
    }

    public String getArrearAmt() {
        return arrearAmt;
    }

    public void setArrearAmt(String arrearAmt) {
        this.arrearAmt = arrearAmt;
    }

    public String getOldBalance() {
        return oldBalance;
    }

    public void setOldBalance(String oldBalance) {
        this.oldBalance = oldBalance;
    }

    public String getNewBalance() {
        return newBalance;
    }

    public void setNewBalance(String newBalance) {
        this.newBalance = newBalance;
    }

    public String getTopupDate() {
        return topupDate;
    }

    public void setTopupDate(String topupDate) {
        this.topupDate = topupDate;
    }

    public String getTopupTime() {
        return topupTime;
    }

    public void setTopupTime(String topupTime) {
        this.topupTime = topupTime;
    }
}
