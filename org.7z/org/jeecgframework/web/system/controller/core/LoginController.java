package org.jeecgframework.web.system.controller.core;

import com.alibaba.fastjson.JSONObject;
import com.constants.LoginStatusEnum;
import com.constants.SiteStatus;
import com.ppms.entity.LoginLogEntity;
import com.ppms.entity.TerminalEntity;
import com.ppms.ldapLogin.service.LoginServiceI;
import com.ppms.ldapLogin.util.ResourceUtils;
import com.ppms.terminalManagement.service.TerminalServiceI;
import com.ppms.utils.AESDecoder;
import com.ppms.utils.ClientIPUtils;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.constant.Globals;
import org.jeecgframework.core.enums.SysThemesEnum;
import org.jeecgframework.core.util.ContextHolderUtils;
import org.jeecgframework.core.util.StringUtil;
import org.jeecgframework.core.util.SysThemesUtil;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.web.system.pojo.base.TSFunction;
import org.jeecgframework.web.system.pojo.base.TSRole;
import org.jeecgframework.web.system.pojo.base.TSRoleFunction;
import org.jeecgframework.web.system.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.session.ExpiringSession;
import org.springframework.session.Session;
import org.springframework.session.SessionRepository;
import org.springframework.session.jdbc.JdbcOperationsSessionRepository;
import org.springframework.session.web.http.CookieHttpSessionStrategy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.*;

@Controller
@RequestMapping({"/loginController"})
public class LoginController
        extends BaseController {
    private Logger logger = Logger.getLogger(LoginController.class);
    public static final String LOGIN_KEY = "abcdefgabcdefg12";
    @Autowired
    private LoginServiceI loginService;
    private SystemService systemService;
    @Autowired
    private SessionRepository jdbcSessionRepository;

    @Autowired
    private TerminalServiceI terminalServiceI;

    @Autowired
    public void setSystemService(SystemService systemService) {
        this.systemService = systemService;
    }

    private String trustStorePath;

    private String trustStorePwd;

    private String ldapUrl;

    private String ldapLoginAcct;

    private String ldapLoginPwd;

    private String baseDN;

    private String searchFilter;

    private String searchAttrs;

    private String[] searchAttrsArray;

    private String groupPrefx;

    public LoginController() {
        Properties properties = new Properties();
        ClassPathResource pathResource = new ClassPathResource("ldap.properties", getClass().getClassLoader());
        try {
            PropertiesLoaderUtils.fillProperties(properties, pathResource);
            this.trustStorePath = properties.getProperty("ldap.cert.trustStore.path");
            this.trustStorePwd = properties.getProperty("ldap.cert.trustStore.pwd");
            this.ldapUrl = properties.getProperty("ldap.url");
            this.ldapLoginAcct = properties.getProperty("ldap.login.account");
            this.ldapLoginPwd = properties.getProperty("ldap.login.pwd");
            this.baseDN = properties.getProperty("ldap.search.baseDN");
            this.searchFilter = properties.getProperty("ladp.search.filter");
            this.searchAttrs = properties.getProperty("ladp.search.searchAtts");
            this.groupPrefx = properties.getProperty("ldap.user.group.prefix");
            if (!StringUtil.isEmpty(searchAttrs)) {
                this.searchAttrsArray = this.searchAttrs.split(",");
            }
            if (!StringUtil.isEmpty(this.ldapLoginPwd)) {
                this.ldapLoginPwd = AESDecoder.aesDecrypt(this.ldapLoginPwd);
            }
            if (!StringUtil.isEmpty(this.trustStorePwd)) {
                this.trustStorePwd = AESDecoder.aesDecrypt(this.trustStorePwd);
            }

////            System.setProperty("javax.net.ssl.trustStore", properties.getProperty("security.ldap.ssl.trustStorePath"));
////            System.setProperty("javax.net.ssl.trustStorePassword", properties.getProperty("security.ldap.ssl.keyStorePassword"));
//            System.setProperty("javax.net.ssl.keyStore", properties.getProperty("security.ldap.ssl.trustStorePath"));
//            System.setProperty("javax.net.ssl.keyStorePassword", properties.getProperty("security.ldap.ssl.keyStorePassword"));
////            System.setProperty("javax.net.debug", "all");
            System.setProperty("com.sun.jndi.ldap.object.disableEndpointIdentification", "true");
        } catch (IOException e) {
            this.logger.error(e);
        }
    }


    @RequestMapping(params = {"checkuser"})
    @ResponseBody
    public AjaxJson checkuser(HttpServletRequest req, HttpServletResponse res) {
        AjaxJson j = new AjaxJson();
        return getAjaxJson(req, res);
    }

    private AjaxJson getAjaxJson(HttpServletRequest req, HttpServletResponse res) {
        AjaxJson j = new AjaxJson();
        String browserType = "";
        Cookie[] cookies = req.getCookies();
        Map<String, Object> attrMap = new HashMap();
        List<String> strList = new ArrayList();
        List<String> groupList = new ArrayList();

        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                Cookie cookie = cookies[i];
                if ("BROWSER_TYPE".equals(cookie.getName())) {
                    browserType = cookie.getValue();
                    break;
                }
            }
        }
        String userName = null;
        String password = null;
        try {
            userName = AESDecoder.aesDecrypt(req.getParameter("userName"), LOGIN_KEY);
            logger.info("login username[" + userName + "]");
            password = AESDecoder.aesDecrypt(req.getParameter("password"), LOGIN_KEY);
            logger.info("login password[" + password + "]");
        } catch (Exception e) {
            this.logger.error(e);
            j.setSuccess(false);
            j.setMsg("Account or Password is null.");
            return j;
        }
        if (StringUtil.isEmpty(userName) || StringUtil.isEmpty(password)) {
            j.setSuccess(false);
            j.setMsg("Account or Password is null.");
            return j;
        } else {
            UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(userName, password);
            try {
                groupList = this.connectLDAPServer(userName, password);
                if (groupList != null) {
                    strList.addAll(groupList);
                    attrMap.put("orgNum", Integer.valueOf(strList.size()));
                } else {
                    j.setSuccess(false);
                    j.setMsg("No group ID set for you in LDAP server.");
                    return j;
                }
            } catch (AuthenticationException e) {
                logger.error(e.getMessage(), e);
                j.setSuccess(false);
                j.setMsg(e.getMessage());
                return j;
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
                j.setSuccess(false);
                j.setMsg("Network Connection Exception.");
                return j;
            }
            attrMap.put("orgList", strList);
            j.setAttributes(attrMap);
            SessionRepository repository = this.jdbcSessionRepository;
            Session springSession = repository.createSession();
            CookieHttpSessionStrategy cookieHttpSessionStrategy = new CookieHttpSessionStrategy();
            cookieHttpSessionStrategy.onNewSession(springSession, req, res);
            springSession.setAttribute(springSession.getId(), authenticationToken);
            if (groupList.size() == 1) {
                authenticationToken.setDetails(strList.get(0));
            }
            springSession.setAttribute("orgList", groupList);
            springSession.setAttribute("browserType", browserType);
            repository.save(springSession);
            return j;
        }
    }

    private List<String> connectLDAPServer(String userName, String password) throws Exception {
        TrustManagerFactory tf = null;

        KeyManagerFactory kf = KeyManagerFactory.getInstance("SunX509");
        KeyStore ks = KeyStore.getInstance("JKS");
        ks.load(new FileInputStream(this.trustStorePath), this.trustStorePwd.toCharArray());
        kf.init(ks, this.trustStorePwd.toCharArray());
        tf = TrustManagerFactory.getInstance("SunX509");
        tf.init(ks);

        SSLContext sc = SSLContext.getInstance("TLSv1.2");
        sc.init(kf.getKeyManagers(), tf.getTrustManagers(), SecureRandom.getInstanceStrong());
        SSLContext.setDefault(sc);

        String FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
        LdapContext ctx = null;

        Hashtable<String, String> env = new Hashtable<String, String>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, FACTORY);
        env.put(Context.PROVIDER_URL, this.ldapUrl);
        env.put(Context.REFERRAL, "follow");
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, this.ldapLoginAcct); // login ldap account
        env.put(Context.SECURITY_CREDENTIALS, this.ldapLoginPwd); // password
        ctx = new InitialLdapContext(env, null);
        System.out.println("LDAPS connection... success.");
        SearchControls controls = new SearchControls();
        controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        controls.setReturningAttributes(this.searchAttrsArray);

        NamingEnumeration enumeration = ctx.search(this.baseDN, this.searchFilter.replace("{0}", userName), controls);
        while (enumeration != null && enumeration.hasMoreElements()) {
            Object object = enumeration.nextElement();
            if (object instanceof SearchResult) {
                SearchResult searchResult = (SearchResult) object;
                Attributes attributes = searchResult.getAttributes();
                Attribute attribute = attributes.get("userPrincipalName");
                System.out.println(attribute.getID());
                System.out.println(attribute.get());
                ctx.addToEnvironment(Context.SECURITY_PRINCIPAL, attribute.get());
                ctx.addToEnvironment(Context.SECURITY_CREDENTIALS, password);
                try {
                    ctx.reconnect(null);
                    return findUserGroups(attributes);
                } catch (NamingException e) {
                    logger.error(e);
                    throw new AuthenticationException("User account or password is incorrect.");
                }

            }
        }
        return null;
    }

    public List<String> findUserGroups(Attributes attributes) throws Exception {
        List<String> list = new ArrayList<String>();

        Attribute attribute2 = attributes.get("memberOf");
        NamingEnumeration<?> namingEnumeration = attribute2.getAll();
        while (namingEnumeration != null && namingEnumeration.hasMoreElements()) {
            Object object = namingEnumeration.nextElement();
            String group = (String) object;
            logger.info("Attribute Value[" + group + "].");
            String[] groupIdArray = group.split(",");
            if (groupIdArray != null && groupIdArray.length > 0) {
                for (String groupId : groupIdArray) {
                    if (groupId.startsWith("CN=PPMS")) {
                        String[] temp = groupId.split("=");
                        if (temp != null && temp.length > 1) {
                            list.add(temp[1]);
                            break;
                        }
                    }
                }
            }
        }
        return list;
    }

    private boolean isAlreadyLogin(String username) {
        if (oConvertUtils.isEmpty(username)) {
            return true;
        }
        return this.loginService.isUserLogin(username);
    }

    @RequestMapping(params = {"userOrgSelect"})
    public ModelAndView userOrgSelect(HttpServletRequest request) {
        String username = request.getParameter("name");
        List<String> strList = new LinkedList();
        Object object = request.getSession().getAttribute("orgList");
        if (object instanceof List) {
            strList = (List<String>) object;
        }
        request.setAttribute("name", username);
        request.setAttribute("orgList", strList);

        List<TerminalEntity> entityList = this.loginService.queryActivedSPTerminal();
        request.setAttribute("terminalList", entityList);

        return new ModelAndView("login/userOrgSelect");
    }

    @RequestMapping(params = {"changeDefaultOrg"})
    @ResponseBody
    public AjaxJson changeDefaultOrg(HttpServletRequest req) {
        AjaxJson j = new AjaxJson();
        HttpSession session = req.getSession();
        String orgId = oConvertUtils.getString(req.getParameter("orgId"));
        Object object = session.getAttribute("orgList");
        if (object instanceof List) {
            //ruguo chuansong de roleid buzai ldap jieguoji zhong, ze jiang chuansong de roleid zhiwei kong
            List<String> orgList = (List<String>) object;
            if (oConvertUtils.isNotEmpty(orgId) && !orgList.contains(orgId)) {
                orgId = "";
                j.setSuccess(false);
            }
        } else {
            j.setSuccess(false);
        }
        String terminalId = oConvertUtils.getString(req.getParameter("terminalId"));
        String counterCode = oConvertUtils.getString(req.getParameter("counterCode"));
//        if(!terminalServiceI.checkIsTrue(terminalId,SiteStatus.ACTIVE.getStatus(),counterCode)){
//            j.setSuccess(false);
//        }else{
//            LoginLogEntity entity = loginService.queryByCounterCode(counterCode);
//            if(entity != null){
//                ExpiringSession jdbcSession = (ExpiringSession)jdbcSessionRepository.getSession(entity.getSessionid());
//                if(jdbcSession != null && !jdbcSession.isExpired()){
//                    j.setSuccess(false);
//                    j.setMsg("Current Terminal have been occupied.");
//                    return j;
//                }
//            }
            UsernamePasswordAuthenticationToken authentication = (UsernamePasswordAuthenticationToken) ResourceUtils.getSessionUser();
            session.setAttribute("terminalId", terminalId);
            session.setAttribute("counterCode", counterCode);
            authentication.setDetails(orgId);
            session.setAttribute(session.getId(), authentication);
//        }
        return j;
    }

    @RequestMapping(params = "getCounterList")
    @ResponseBody
    public AjaxJson getCounterList(HttpServletRequest request, HttpServletResponse response) {
        AjaxJson json = new AjaxJson();
        json.setSuccess(false);
        String id = request.getParameter("terminalId");
        if (oConvertUtils.isNotEmpty(id)) {
            Map<String, Object> map = new HashMap();
            try {
                map.put("counterList", JSONObject.toJSONString(terminalServiceI.queryCunterListByTerminalIdAndStatus(id, SiteStatus.ACTIVE.getStatus())));
                json.setSuccess(true);
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
            json.setAttributes(map);
        }
        return json;
    }

    @RequestMapping(params = {"login"})
    public String login(ModelMap modelMap, HttpServletRequest request, HttpServletResponse response) {
        UsernamePasswordAuthenticationToken authentication = null;
        HttpSession session = request.getSession();
        Object object;
        if (((object = session.getAttribute(session.getId())) != null) && ((object instanceof Authentication))) {
            authentication = (UsernamePasswordAuthenticationToken) object;
        } else {
            session.invalidate();
        }
        if (authentication != null) {
            logger.info(authentication.toString());
            modelMap.put("userName", authentication.getName());
            String counterCode = (String)session.getAttribute("counterCode");
            LoginLogEntity entity = null;
//            try {
//                entity = loginService.queryByCounterCode(counterCode);
//            } catch (Exception e) {
//                logger.error(e.getMessage(),e);
//                request.setAttribute("errorMsg", "Network Anomaly.");
//                request.setAttribute("encryptKey", LOGIN_KEY);
//                return "login/login";
//            }
            if(entity != null){
                ExpiringSession jdbcSession = (ExpiringSession)jdbcSessionRepository.getSession(entity.getSessionid());
                if(jdbcSession != null && !jdbcSession.isExpired()){
                    request.setAttribute("errorMsg", "Current Terminal have been occupied.");
                    request.setAttribute("encryptKey", LOGIN_KEY);
                    return "login/login";
                }
            }
            LoginLogEntity logEntity = new LoginLogEntity();
            logEntity.setBrowser(oConvertUtils.getString(session.getAttribute("browserType")));
            logEntity.setStatus(LoginStatusEnum.SUCCESS.getStatus());
            logEntity.setUsername(authentication.getName());
            logEntity.setCreatetime(new Date());
            logEntity.setSessionid(session.getId());

            logEntity.setGroupCode(ResourceUtils.getCurrentUserRole());
            logEntity.setTerminalId(Integer.valueOf(oConvertUtils.getInt((String) session.getAttribute("terminalId"))));
//            logEntity.setCounterCode(counterCode);
            try {
                logEntity.setIp(new ClientIPUtils().getIp(request));
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
            try {
                this.loginService.save(logEntity, authentication);
            } catch (Exception e) {
                this.logger.error(e);
                request.setAttribute("errorMsg", "Network Anomaly.");
                request.setAttribute("encryptKey", LOGIN_KEY);
                return "login/login";
            }
            SysThemesEnum sysTheme = SysThemesUtil.getSysTheme(request);
            if (("fineui".equals(sysTheme.getStyle())) || ("ace".equals(sysTheme.getStyle())) || ("diy".equals(sysTheme.getStyle())) || ("acele".equals(sysTheme.getStyle())) || ("hplus".equals(sysTheme.getStyle()))) {
                request.setAttribute("menuMap", getFunctionMap(authentication));
            }
            Cookie cookie = new Cookie("INDEXSTYLE", sysTheme.getStyle());

            cookie.setMaxAge(86400);
            response.addCookie(cookie);

            Cookie zIndexCookie = new Cookie("ZINDEXNUMBER", "1990");
            zIndexCookie.setMaxAge(86400);
            response.addCookie(zIndexCookie);
            return sysTheme.getIndexPath();
        }
        request.setAttribute("encryptKey", LOGIN_KEY);
        return "login/login";
    }

    @RequestMapping(params = {"logout"})
    public ModelAndView logout(HttpServletRequest request) {
        HttpSession session = ContextHolderUtils.getSession();
        if (session != null) {
            Authentication authentication = (Authentication) session.getAttribute(session.getId());
            String browserType = (String) request.getSession().getAttribute("browserType");
            if (authentication != null) {
                LoginLogEntity entity = new LoginLogEntity();
                entity.setCreatetime(new Date());
                entity.setStatus(LoginStatusEnum.LOGOUT.getStatus());
                entity.setUsername(authentication.getName());
                entity.setSessionid(session.getId());
                entity.setBrowser(browserType);
                entity.setIp(request.getRemoteAddr());
                try {
                    this.systemService.save(entity);
                } catch (Exception e) {
                    this.logger.error(e);
                }
            }
            session.invalidate();
        }
        ModelAndView modelAndView = new ModelAndView("login/login");
        modelAndView.addObject("encryptKey", "abcdefgabcdefg12");
        return modelAndView;
    }

    @RequestMapping(params = {"left"})
    public ModelAndView left(HttpServletRequest request) {
        Authentication user = ResourceUtils.getSessionUser();
        HttpSession session = ContextHolderUtils.getSession();
        ModelAndView modelAndView = new ModelAndView();
        if (user == null) {
            session.invalidate();
            modelAndView.setView(new RedirectView("loginController.do?login"));
        } else {
            modelAndView.setViewName("main/left");
            request.setAttribute("menuMap", getFunctionMap(user));
        }
        return modelAndView;
    }

    private Map<Integer, List<TSFunction>> getFunctionMap(Authentication user) {
        Map<Integer, List<TSFunction>> mapList = new HashMap();
        try {
            mapList = this.loginService.queryUserAuthentication(user);
        } catch (Exception e) {
            this.logger.error(e);
        }
        return mapList;
    }

    /**
     * @deprecated
     */
    private void assembleFunctionsByRole(Map<String, TSFunction> loginActionlist, TSRole role) {
        List<TSRoleFunction> roleFunctionList = this.systemService.findByProperty(TSRoleFunction.class, "TSRole.id", role.getId());
        for (TSRoleFunction roleFunction : roleFunctionList) {
            TSFunction function = roleFunction.getTSFunction();
            if (function.getFunctionType().intValue() != Globals.Function_TYPE_FROM.intValue()) {
                loginActionlist.put(function.getId(), function);
            }
        }
    }

    @RequestMapping(params = {"home"})
    public ModelAndView home(HttpServletRequest request) {
        SysThemesEnum sysTheme = SysThemesUtil.getSysTheme(request);
        if (("ace".equals(sysTheme.getStyle())) || ("diy".equals(sysTheme.getStyle())) || ("acele".equals(sysTheme.getStyle()))) {
            request.setAttribute("show", "1");
        } else {
            request.setAttribute("show", "0");
        }
        return new ModelAndView("main/home");
    }

    @RequestMapping(params = {"acehome"})
    public ModelAndView acehome(HttpServletRequest request) {
        SysThemesEnum sysTheme = SysThemesUtil.getSysTheme(request);
        if (("ace".equals(sysTheme.getStyle())) || ("diy".equals(sysTheme.getStyle())) || ("acele".equals(sysTheme.getStyle()))) {
            request.setAttribute("show", "1");
        } else {
            request.setAttribute("show", "0");
        }
        return new ModelAndView("main/acehome");
    }

    @RequestMapping(params = {"hplushome"})
    public ModelAndView hplushome(HttpServletRequest request) {
        SysThemesEnum sysTheme = SysThemesUtil.getSysTheme(request);


        return new ModelAndView("main/hplushome");
    }

    @RequestMapping(params = {"fineuiHome"})
    public ModelAndView fineuiHome(HttpServletRequest request) {
        return new ModelAndView("main/fineui_home");
    }

    @RequestMapping(params = {"noAuth"})
    public ModelAndView noAuth(HttpServletRequest request) {
        return new ModelAndView("common/noAuth");
    }
}
