package org.jeecgframework.web.system.controller.core;

import com.constants.LoginStatusEnum;
import com.ppms.entity.LoginLogEntity;
import com.ppms.entity.TerminalEntity;
import com.ppms.ldapLogin.service.LoginServiceI;
import com.ppms.ldapLogin.util.ResourceUtils;
import com.ppms.utils.AESDecoder;
import com.ppms.utils.ClientIPUtils;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.constant.Globals;
import org.jeecgframework.core.enums.SysThemesEnum;
import org.jeecgframework.core.util.ContextHolderUtils;
import org.jeecgframework.core.util.ListtoMenu;
import org.jeecgframework.core.util.SysThemesUtil;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.web.system.pojo.base.TSFunction;
import org.jeecgframework.web.system.pojo.base.TSRole;
import org.jeecgframework.web.system.pojo.base.TSRoleFunction;
import org.jeecgframework.web.system.service.MutiLangServiceI;
import org.jeecgframework.web.system.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.session.Session;
import org.springframework.session.SessionRepository;
import org.springframework.session.web.http.CookieHttpSessionStrategy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;


//@RequestMapping({"/loginController"})
public class LoginControllerOriginal
        extends BaseController
{
    private Logger logger = Logger.getLogger(LoginControllerOriginal.class);
    @Autowired
    private LoginServiceI loginService;
    private SystemService systemService;
    public static final int initialState = 0;
    private static final Map<String, Integer> map = new ConcurrentHashMap(30);
    @Autowired
    private SessionRepository jdbcSessionRepository;
    @Autowired
    private ProviderManager providerManager;
    @Autowired
    private MutiLangServiceI mutiLangService;

    @Autowired
    public void setSystemService(SystemService systemService)
    {
        this.systemService = systemService;
    }

    public LoginControllerOriginal()
    {
       Properties properties = new Properties();
        ClassPathResource pathResource = new ClassPathResource("ldap.properties", getClass().getClassLoader());
        try
        {
            PropertiesLoaderUtils.fillProperties(properties, pathResource);
//            System.setProperty("javax.net.ssl.trustStore", properties.getProperty("security.ldap.ssl.trustStorePath"));
//            System.setProperty("javax.net.ssl.trustStorePassword", properties.getProperty("security.ldap.ssl.keyStorePassword"));
            System.setProperty("javax.net.ssl.keyStore", properties.getProperty("security.ldap.ssl.trustStorePath"));
            System.setProperty("javax.net.ssl.keyStorePassword", properties.getProperty("security.ldap.ssl.keyStorePassword"));
//            System.setProperty("javax.net.debug", "all");
            System.setProperty("com.sun.jndi.ldap.object.disableEndpointIdentification", "true");
        }
        catch (IOException e)
        {
            this.logger.error(e);
        }
    }




    @RequestMapping(params={"checkuser"})
    @ResponseBody
    public AjaxJson checkuser(HttpServletRequest req, HttpServletResponse res)
    {
        AjaxJson j = new AjaxJson();
        return getAjaxJson(req, res);
    }

    private AjaxJson getAjaxJson(HttpServletRequest req, HttpServletResponse res) {
        AjaxJson j = new AjaxJson();
        String browserType = "";
        Cookie[] cookies = req.getCookies();
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++)
            {
                Cookie cookie = cookies[i];
                if ("BROWSER_TYPE".equals(cookie.getName()))
                {
                    browserType = cookie.getValue();
                    break;
                }
            }
        }
        String userName = null;
        String password = null;
        try
        {
            userName = AESDecoder.aesDecrypt(req.getParameter("userName"));
            password = AESDecoder.aesDecrypt(req.getParameter("password"));
        }
        catch (Exception e)
        {
            this.logger.error(e);
            e.printStackTrace();
        }
        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(userName, password);
        Map<String, Object> attrMap = new HashMap();
        List<String> strList = new ArrayList();
        if (!"TDIS2709".equals(userName))
        {
            try
            {
                System.setProperty("javax.net.ssl.trustStore", "F:\\ProgramFiles\\jdk1.8.0_181\\jre\\lib\\security\\SPCert.jks");
                System.setProperty("javax.net.ssl.trustStorePassword", "NARI_$123");
//            System.setProperty("javax.net.debug", "all");
                System.setProperty("com.sun.jndi.ldap.object.disableEndpointIdentification", "true");
                authenticationToken = (UsernamePasswordAuthenticationToken)this.providerManager.authenticate(authenticationToken);
            }
            catch (Exception e)
            {
                this.logger.error(e);
                j.setMsg("username or password is error");
                j.setSuccess(false);
                return j;
            }
            if (authenticationToken.getAuthorities() != null)
            {
                attrMap.put("orgNum", Integer.valueOf(authenticationToken.getAuthorities().size()));
                if (authenticationToken.getAuthorities().size() > 1) {
                    for (GrantedAuthority authority : authenticationToken.getAuthorities()) {
                        strList.add(authority.getAuthority());
                    }
                }
            }
        }
        else
        {
            strList.add("HDB_CC_CASHIER");
            strList.add("HDB_CC_COUNTER");
            strList.add("HDB_CC_EXECS");
            strList.add("HDB_CC_SUPERVISOR");
            strList.add("MLT_CC_CASHIER");
            strList.add("MLT_CC_COUNTER");
            strList.add("MLT_CC_EXECS");
            strList.add("MLT_CC_SUPERVISOR");
            strList.add("PPMS_EI");
            strList.add("PPMS_EM");
            strList.add("admin");
            attrMap.put("orgNum", Integer.valueOf(strList.size()));
        }
        attrMap.put("orgList", strList);
        j.setAttributes(attrMap);

        SessionRepository repository = this.jdbcSessionRepository;
        Session springSession = repository.createSession();
        CookieHttpSessionStrategy cookieHttpSessionStrategy = new CookieHttpSessionStrategy();
        cookieHttpSessionStrategy.onNewSession(springSession, req, res);
        springSession.setAttribute(springSession.getId(), authenticationToken);
        springSession.setAttribute("browserType", browserType);
        repository.save(springSession);

        return j;
    }

    private boolean isAlreadyLogin(String username)
    {
        if (oConvertUtils.isEmpty(username)) {
            return true;
        }
        return this.loginService.isUserLogin(username);
    }

    @RequestMapping(params={"userOrgSelect"})
    public ModelAndView userOrgSelect(HttpServletRequest request)
    {
        String username = request.getParameter("name");
        String parajson = request.getParameter("param");
        List<String> strList = new LinkedList();
        if (oConvertUtils.isNotEmpty(parajson))
        {
            String[] auth = parajson.split(",");
            strList = Arrays.asList(auth);
        }
        request.setAttribute("name", username);
        request.setAttribute("orgList", strList);

        List<TerminalEntity> entityList = this.loginService.queryActivedSPTerminal();
        request.setAttribute("terminalList", entityList);

        return new ModelAndView("login/userOrgSelect");
    }

    @RequestMapping(params={"changeDefaultOrg"})
    @ResponseBody
    public AjaxJson changeDefaultOrg(HttpServletRequest req)
    {
        AjaxJson j = new AjaxJson();
        HttpSession session = req.getSession();
        String orgId = oConvertUtils.getString(req.getParameter("orgId"));
        String terminalId = oConvertUtils.getString(req.getParameter("terminalId"));
        UsernamePasswordAuthenticationToken authentication = (UsernamePasswordAuthenticationToken)ResourceUtils.getSessionUser();
        session.setAttribute("terminalId", terminalId);
        authentication.setDetails(orgId);
        session.setAttribute(session.getId(), authentication);
        return j;
    }

    @RequestMapping(params={"login"})
    public String login(ModelMap modelMap, HttpServletRequest request, HttpServletResponse response)
    {
        UsernamePasswordAuthenticationToken authentication = null;
        HttpSession session = request.getSession();
        Object object;
        if (((object = session.getAttribute(session.getId())) != null) && ((object instanceof Authentication))) {
            authentication = (UsernamePasswordAuthenticationToken)object;
        } else {
            session.invalidate();
        }
        if (authentication != null)
        {
            modelMap.put("userName", authentication.getName());


            LoginLogEntity logEntity = new LoginLogEntity();
            logEntity.setBrowser(oConvertUtils.getString(session.getAttribute("browserType")));
            logEntity.setStatus(LoginStatusEnum.SUCCESS.getStatus());
            logEntity.setUsername(authentication.getName());
            logEntity.setCreatetime(new Date());
            logEntity.setSessionid(session.getId());

            logEntity.setGroupCode(ResourceUtils.getCurrentUserRole());
            logEntity.setTerminalId(Integer.valueOf(oConvertUtils.getInt((String)session.getAttribute("terminalId"))));
            try
            {
                try
                {
                    logEntity.setIp(new ClientIPUtils().getIp(request));
                }
                catch (Exception e)
                {
                    this.logger.error(e);
                }
                this.loginService.save(logEntity, authentication);
            }
            catch (Exception e)
            {
                this.logger.error(e);
            }
            SysThemesEnum sysTheme = SysThemesUtil.getSysTheme(request);
            if (("fineui".equals(sysTheme.getStyle())) || ("ace".equals(sysTheme.getStyle())) || ("diy".equals(sysTheme.getStyle())) || ("acele".equals(sysTheme.getStyle())) || ("hplus".equals(sysTheme.getStyle()))) {
                request.setAttribute("menuMap", getFunctionMap(authentication));
            }
            Cookie cookie = new Cookie("INDEXSTYLE", sysTheme.getStyle());

            cookie.setMaxAge(86400);
            response.addCookie(cookie);

            Cookie zIndexCookie = new Cookie("ZINDEXNUMBER", "1990");
            zIndexCookie.setMaxAge(86400);
            response.addCookie(zIndexCookie);
            return sysTheme.getIndexPath();
        }
        request.setAttribute("encryptKey", "abcdefgabcdefg12");
        return "login/login";
    }

    @RequestMapping(params={"logout"})
    public ModelAndView logout(HttpServletRequest request)
    {
        HttpSession session = ContextHolderUtils.getSession();
        if (session != null)
        {
            Authentication authentication = (Authentication)session.getAttribute(session.getId());
            String browserType = (String)request.getSession().getAttribute("browserType");
            if (authentication != null)
            {
                LoginLogEntity entity = new LoginLogEntity();
                entity.setCreatetime(new Date());
                entity.setStatus(LoginStatusEnum.LOGOUT.getStatus());
                entity.setUsername(authentication.getName());
                entity.setSessionid(session.getId());
                entity.setBrowser(browserType);
                entity.setIp(request.getRemoteAddr());
                try
                {
                    this.systemService.save(entity);
                }
                catch (Exception e)
                {
                    this.logger.error(e);
                }
            }
            session.invalidate();
        }
        ModelAndView modelAndView = new ModelAndView("login/login");
        modelAndView.addObject("encryptKey", "abcdefgabcdefg12");
        return modelAndView;
    }

    @RequestMapping(params={"beforeClearSession"})
    public void clearSession(HttpServletRequest request)
    {
        request.getSession().invalidate();
    }

    @RequestMapping(params={"left"})
    public ModelAndView left(HttpServletRequest request)
    {
        Authentication user = ResourceUtils.getSessionUser();
        HttpSession session = ContextHolderUtils.getSession();
        ModelAndView modelAndView = new ModelAndView();
        if (user == null)
        {
            session.invalidate();
            modelAndView.setView(new RedirectView("loginController.do?login"));
        }
        else
        {
            modelAndView.setViewName("main/left");
            request.setAttribute("menuMap", getFunctionMap(user));
        }
        return modelAndView;
    }

    private Map<Integer, List<TSFunction>> getFunctionMap(Authentication user)
    {
        Map<Integer, List<TSFunction>> mapList = new HashMap();
        try
        {
            mapList = this.loginService.queryUserAuthentication(user);
        }
        catch (Exception e)
        {
            this.logger.error(e);
        }
        return mapList;
    }

    /**
     * @deprecated
     */
    private void assembleFunctionsByRole(Map<String, TSFunction> loginActionlist, TSRole role)
    {
        List<TSRoleFunction> roleFunctionList = this.systemService.findByProperty(TSRoleFunction.class, "TSRole.id", role.getId());
        for (TSRoleFunction roleFunction : roleFunctionList)
        {
            TSFunction function = roleFunction.getTSFunction();
            if (function.getFunctionType().intValue() != Globals.Function_TYPE_FROM.intValue()) {
                loginActionlist.put(function.getId(), function);
            }
        }
    }

    @RequestMapping(params={"home"})
    public ModelAndView home(HttpServletRequest request)
    {
        SysThemesEnum sysTheme = SysThemesUtil.getSysTheme(request);
        if (("ace".equals(sysTheme.getStyle())) || ("diy".equals(sysTheme.getStyle())) || ("acele".equals(sysTheme.getStyle()))) {
            request.setAttribute("show", "1");
        } else {
            request.setAttribute("show", "0");
        }
        return new ModelAndView("main/home");
    }

    @RequestMapping(params={"acehome"})
    public ModelAndView acehome(HttpServletRequest request)
    {
        SysThemesEnum sysTheme = SysThemesUtil.getSysTheme(request);
        if (("ace".equals(sysTheme.getStyle())) || ("diy".equals(sysTheme.getStyle())) || ("acele".equals(sysTheme.getStyle()))) {
            request.setAttribute("show", "1");
        } else {
            request.setAttribute("show", "0");
        }
        return new ModelAndView("main/acehome");
    }

    @RequestMapping(params={"hplushome"})
    public ModelAndView hplushome(HttpServletRequest request)
    {
        SysThemesEnum sysTheme = SysThemesUtil.getSysTheme(request);







        return new ModelAndView("main/hplushome");
    }

    @RequestMapping(params={"fineuiHome"})
    public ModelAndView fineuiHome(HttpServletRequest request)
    {
        return new ModelAndView("main/fineui_home");
    }

    @RequestMapping(params={"noAuth"})
    public ModelAndView noAuth(HttpServletRequest request)
    {
        return new ModelAndView("common/noAuth");
    }

    @RequestMapping(params={"top"})
    public ModelAndView top(HttpServletRequest request)
    {
        Authentication user = ResourceUtils.getSessionUser();
        HttpSession session = ContextHolderUtils.getSession();
        if (user == null)
        {
            session.invalidate();
            return new ModelAndView(new RedirectView("loginController.do?login"));
        }
        request.setAttribute("menuMap", getFunctionMap(user));
        return new ModelAndView("main/bootstrap_top");
    }

    @RequestMapping(params={"shortcut_top"})
    public ModelAndView shortcut_top(HttpServletRequest request)
    {
        Authentication user = ResourceUtils.getSessionUser();
        HttpSession session = ContextHolderUtils.getSession();
        if (user == null)
        {
            session.invalidate();
            return new ModelAndView(new RedirectView("loginController.do?login"));
        }
        request.setAttribute("menuMap", getFunctionMap(user));
        return new ModelAndView("main/shortcut_top");
    }

    @RequestMapping(params={"primaryMenu"})
    @ResponseBody
    public String getPrimaryMenu()
    {
        List<TSFunction> primaryMenu = (List)getFunctionMap(ResourceUtils.getSessionUser()).get(Integer.valueOf(0));
        String floor = "";
        if (primaryMenu == null) {
            return floor;
        }
        for (TSFunction function : primaryMenu) {
            if (function.getFunctionLevel().shortValue() == 0)
            {
                String lang_key = function.getFunctionName();
                String lang_context = this.mutiLangService.getLang(lang_key);
                lang_context = lang_context.trim();
                if ("业务申请".equals(lang_context))
                {
                    String ss = "<div style='width:67px;position: absolute;top:39px;text-align:center;color:#909090;font-size:13px;'><span style='letter-spacing:-1px;'>" + lang_context + "</span></div>";
                    floor = floor + " <li style='position: relative;'>" + ss + "<img class='imag1' src='plug-in/login/images/ywsq.png' />  <img class='imag2' src='plug-in/login/images/ywsq-up.png' style='display: none;' /></li> ";
                }
                else if ("个人办公".equals(lang_context))
                {
                    String ss = "<div style='width:67px;position: absolute;top:39px;text-align:center;color:#909090;font-size:13px;'><span style='letter-spacing:-1px;'>" + lang_context + "</span></div>";
                    floor = floor + " <li style='position: relative;'>" + ss + "<img class='imag1' src='plug-in/login/images/grbg.png' />  <img class='imag2' src='plug-in/login/images/grbg-up.png' style='display: none;' /></li> ";
                }
                else if ("流程管理".equals(lang_context))
                {
                    String ss = "<div style='width:67px;position: absolute;top:39px;text-align:center;color:#909090;font-size:13px;'><span style='letter-spacing:-1px;'>" + lang_context + "</span></div>";
                    floor = floor + " <li style='position: relative;'>" + ss + "<img class='imag1' src='plug-in/login/images/lcsj.png' />  <img class='imag2' src='plug-in/login/images/lcsj-up.png' style='display: none;' /></li> ";
                }
                else if ("Online 开发".equals(lang_context))
                {
                    floor = floor + " <li><img class='imag1' src='plug-in/login/images/online.png' />  <img class='imag2' src='plug-in/login/images/online_up.png' style='display: none;' /> </li> ";
                }
                else if ("自定义表单".equals(lang_context))
                {
                    String ss = "<div style='width:67px;position: absolute;top:39px;text-align:center;color:#909090;font-size:13px;'><span style='letter-spacing:-1px;'>" + lang_context + "</span></div>";
                    floor = floor + " <li style='position: relative;'>" + ss + "<img class='imag1' src='plug-in/login/images/zdybd.png' />  <img class='imag2' src='plug-in/login/images/zdybd-up.png' style='display: none;' /></li> ";
                }
                else if ("系统监控".equals(lang_context))
                {
                    floor = floor + " <li><img class='imag1' src='plug-in/login/images/xtjk.png' />  <img class='imag2' src='plug-in/login/images/xtjk_up.png' style='display: none;' /> </li> ";
                }
                else if ("统计报表".equals(lang_context))
                {
                    floor = floor + " <li><img class='imag1' src='plug-in/login/images/tjbb.png' />  <img class='imag2' src='plug-in/login/images/tjbb_up.png' style='display: none;' /> </li> ";
                }
                else if ("消息中间件".equals(lang_context))
                {
                    String ss = "<div style='width:67px;position: absolute;top:39px;text-align:center;color:#909090;font-size:13px;'><span style='letter-spacing:-1px;'>" + lang_context + "</span></div>";
                    floor = floor + " <li style='position: relative;'>" + ss + "<img class='imag1' src='plug-in/login/images/msg.png' />  <img class='imag2' src='plug-in/login/images/msg_up.png' style='display: none;' /></li> ";
                }
                else if ("系统管理".equals(lang_context))
                {
                    floor = floor + " <li><img class='imag1' src='plug-in/login/images/xtgl.png' />  <img class='imag2' src='plug-in/login/images/xtgl_up.png' style='display: none;' /> </li> ";
                }
                else if ("常用示例".equals(lang_context))
                {
                    floor = floor + " <li><img class='imag1' src='plug-in/login/images/cysl.png' />  <img class='imag2' src='plug-in/login/images/cysl_up.png' style='display: none;' /> </li> ";
                }
                else if (lang_context.contains("消息推送"))
                {
                    String s = "<div style='width:67px;position: absolute;top:39px;text-align:center;color:#909090;font-size:13px;'>消息推送</div>";
                    floor = floor + " <li style='position: relative;'>" + s + "<img class='imag1' src='plug-in/login/images/msg.png' />  <img class='imag2' src='plug-in/login/images/msg_up.png' style='display: none;' /></li> ";
                }
                else
                {
                    String s = "";
                    if ((lang_context.length() >= 5) && (lang_context.length() < 7)) {
                        s = "<div style='width:67px;position: absolute;top:39px;text-align:center;color:#909090;font-size:13px;'><span style='letter-spacing:-1px;'>" + lang_context + "</span></div>";
                    } else if (lang_context.length() < 5) {
                        s = "<div style='width:67px;position: absolute;top:39px;text-align:center;color:#909090;font-size:13px;'>" + lang_context + "</div>";
                    } else if (lang_context.length() >= 7) {
                        s = "<div style='width:67px;position: absolute;top:39px;text-align:center;color:#909090;font-size:13px;'><span style='letter-spacing:-1px;'>" + lang_context.substring(0, 6) + "</span></div>";
                    }
                    floor = floor + " <li style='position: relative;'>" + s + "<img class='imag1' src='plug-in/login/images/default.png' />  <img class='imag2' src='plug-in/login/images/default_up.png' style='display: none;' /></li> ";
                }
            }
        }
        return floor;
    }

    @RequestMapping(params={"primaryMenuDiy"})
    @ResponseBody
    public String getPrimaryMenuDiy()
    {
        List<TSFunction> primaryMenu = (List)getFunctionMap(ResourceUtils.getSessionUser()).get(Integer.valueOf(1));
        String floor = "";
        if (primaryMenu == null) {
            return floor;
        }
        String menuString = "user.manage role.manage department.manage menu.manage";
        for (TSFunction function : primaryMenu) {
            if ((menuString.contains(function.getFunctionName())) &&
                    (function.getFunctionLevel().shortValue() == 1))
            {
                String lang_key = function.getFunctionName();
                String lang_context = this.mutiLangService.getLang(lang_key);
                if ("申请".equals(lang_key))
                {
                    lang_context = "申请";
                    String s = "";
                    s = "<div style='width:67px;position: absolute;top:47px;text-align:center;color:#000000;font-size:12px;'>" + lang_context + "</div>";
                    floor = floor + " <li><img class='imag1' src='plug-in/login/images/head_icon1.png' />  <img class='imag2' src='plug-in/login/images/head_icon1.png' style='display: none;' />" + s + " </li> ";
                }
                else if ("Online 开发".equals(lang_context))
                {
                    floor = floor + " <li><img class='imag1' src='plug-in/login/images/online.png' />  <img class='imag2' src='plug-in/login/images/online_up.png' style='display: none;' /> </li> ";
                }
                else if ("统计查询".equals(lang_context))
                {
                    floor = floor + " <li><img class='imag1' src='plug-in/login/images/guanli.png' />  <img class='imag2' src='plug-in/login/images/guanli_up.png' style='display: none;' /> </li> ";
                }
                else if ("系统管理".equals(lang_context))
                {
                    floor = floor + " <li><img class='imag1' src='plug-in/login/images/xtgl.png' />  <img class='imag2' src='plug-in/login/images/xtgl_up.png' style='display: none;' /> </li> ";
                }
                else if ("常用示例".equals(lang_context))
                {
                    floor = floor + " <li><img class='imag1' src='plug-in/login/images/cysl.png' />  <img class='imag2' src='plug-in/login/images/cysl_up.png' style='display: none;' /> </li> ";
                }
                else if ("系统监控".equals(lang_context))
                {
                    floor = floor + " <li><img class='imag1' src='plug-in/login/images/xtjk.png' />  <img class='imag2' src='plug-in/login/images/xtjk_up.png' style='display: none;' /> </li> ";
                }
                else if (lang_context.contains("消息推送"))
                {
                    String s = "<div style='width:67px;position: absolute;top:40px;text-align:center;color:#909090;font-size:12px;'>消息推送</div>";
                    floor = floor + " <li style='position: relative;'><img class='imag1' src='plug-in/login/images/msg.png' />  <img class='imag2' src='plug-in/login/images/msg_up.png' style='display: none;' />" + s + "</li> ";
                }
                else
                {
                    String s = "";
                    if ((lang_context.length() >= 5) && (lang_context.length() < 7)) {
                        s = "<div style='width:67px;position: absolute;top:40px;text-align:center;color:#000000;font-size:12px;'><span style='letter-spacing:-1px;'>" + lang_context + "</span></div>";
                    } else if (lang_context.length() < 5) {
                        s = "<div style='width:67px;position: absolute;top:40px;text-align:center;color:#000000;font-size:12px;'>" + lang_context + "</div>";
                    } else if (lang_context.length() >= 7) {
                        s = "<div style='width:67px;position: absolute;top:40px;text-align:center;color:#000000;font-size:12px;'><span style='letter-spacing:-1px;'>" + lang_context.substring(0, 6) + "</span></div>";
                    }
                    floor = floor + " <li style='position: relative;'><img class='imag1' src='plug-in/login/images/head_icon2.png' />  <img class='imag2' src='plug-in/login/images/default_up.png' style='display: none;' />" + s + "</li> ";
                }
            }
        }
        return floor;
    }

    @RequestMapping(params={"getPrimaryMenuForWebos"})
    @ResponseBody
    public AjaxJson getPrimaryMenuForWebos()
    {
        AjaxJson j = new AjaxJson();

        Object getPrimaryMenuForWebos = ContextHolderUtils.getSession().getAttribute("getPrimaryMenuForWebos");
        if (oConvertUtils.isNotEmpty(getPrimaryMenuForWebos))
        {
            j.setMsg(getPrimaryMenuForWebos.toString());
        }
        else
        {
            String PMenu = ListtoMenu.getWebosMenu(getFunctionMap(ResourceUtils.getSessionUser()));
            ContextHolderUtils.getSession().setAttribute("getPrimaryMenuForWebos", PMenu);
            j.setMsg(PMenu);
        }
        return j;
    }

    @RequestMapping(params={"login2"})
    public String login2()
    {
        return "login/login2";
    }

    @RequestMapping(params={"login3"})
    public String login3()
    {
        return "login/login3";
    }
}
