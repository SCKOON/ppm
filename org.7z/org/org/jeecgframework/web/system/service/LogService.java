/**
 * 
 */
package org.jeecgframework.web.system.service;

import org.jeecgframework.core.common.service.CommonService;


/**
 * 日志Service接口
 * @author  方文荣
 *
 */
public interface LogService extends CommonService{

}
