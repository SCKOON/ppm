package org.jeecgframework.web.system.controller.core;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;
import javax.net.ssl.X509TrustManager;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

/**
 * Created by admPPMSd on 10/16/2018.
 */
public class DummyTrustmanager implements X509TrustManager {

    public DummyTrustmanager(){
        javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
                new HostnameVerifier() {
                    @Override
                    public boolean verify(String s, SSLSession sslSession) {
                        return true;
                    }
                }
        );
    }
    public void checkClientTrusted(X509Certificate[] xcs, String string) {
        System.out.println("checkClientTrusted...");
        // do nothing
    }
    public void checkServerTrusted(X509Certificate[] xcs, String string) throws CertificateException {
        System.out.println("checkServerTrusted...");
        // do nothing
    }
    public X509Certificate[] getAcceptedIssuers() {
        return new java.security.cert.X509Certificate[0];
    }


}
