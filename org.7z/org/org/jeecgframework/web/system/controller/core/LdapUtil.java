package org.jeecgframework.web.system.controller.core;

import com.ppms.utils.JSONUtils;
import org.apache.tools.ant.taskdefs.MacroDef;
import org.springframework.ldap.core.AttributesMapper;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Date;
import java.util.Hashtable;

import javax.naming.*;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

/**
 * Created by admPPMSd on 10/17/2018.
 */
public class LdapUtil {

    public static void main(String[] args) throws NoSuchAlgorithmException, KeyStoreException, UnrecoverableKeyException, CertificateException, FileNotFoundException, IOException, KeyManagementException {
        String[] IP = new String[]{"10.87.1.83", "10.153.3.83"};
        InetAddress inetAddress = null;
        inetAddress = InetAddress.getByName(IP[0].toString().trim());
        System.out.println(IP[0].toString().trim() + ":::" + inetAddress.getHostName());
        InetAddress inetAddress2 = null;
        inetAddress2 = InetAddress.getByName(IP[1].toString().trim());
        System.out.println(IP[1].toString().trim() + ":::" + inetAddress2.getHostName());

//        System.setProperty("javax.net.debug", "all");
        System.setProperty("com.sun.jndi.ldap.object.disableEndpointIdentification", "true");

        TrustManagerFactory tf = null;

        KeyManagerFactory kf = KeyManagerFactory.getInstance("SunX509");
        KeyStore ks = KeyStore.getInstance("JKS");
        ks.load(new FileInputStream("F:\\ProgramFiles\\jdk1.8.0_181\\jre\\lib\\security\\SPCert.jks"), "NARI_$123".toCharArray());
        kf.init(ks, "NARI_$123".toCharArray());
        tf = TrustManagerFactory.getInstance("SunX509");
        tf.init(ks);

        SSLContext sc = SSLContext.getInstance("TLSv1.2");

        sc.init(kf.getKeyManagers(), tf.getTrustManagers(), SecureRandom.getInstanceStrong());

        SSLContext.setDefault(sc);


        String URL = "ldaps://singaporepower.local:636/dc=singaporepower,dc=local";
        String URL2 = "ldaps://sp-is-ad03.singaporepower.local:636/dc=singaporepower,dc=local";
        String FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
        LdapContext ctx = null;

        Hashtable<String, String> env = new Hashtable<String, String>();

        env.put(Context.INITIAL_CONTEXT_FACTORY, FACTORY);
        env.put(Context.PROVIDER_URL, URL2);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        /*env.put(Context.SECURITY_PRINCIPAL, "Sap\\ldapPPMSd"); // login ldap account
        env.put(Context.SECURITY_CREDENTIALS, "Welcome@19"); // password*/
        env.put(Context.SECURITY_PRINCIPAL, "Sap\\ldapPPMSd"); // login ldap account
        env.put(Context.SECURITY_CREDENTIALS, "Welcome@19"); // password
//        env.put("com.sun.jndi.connection.timecout","10000000");
//        env.put(Context.SECURITY_PROTOCOL,"ssl");
//        env.put(Context.REFERRAL,"ignore");
//        env.put("java.naming.ldap.factory.socket","org.jeecgframework.web.system.controller.core.MySSLSocketFactory"); //package+className

        try {
            ctx = new InitialLdapContext(env, null);

            System.out.println("LDAPS connection... success.");


            System.out.println("LDAPS connection... success.");
            String baseDN = "dc=singaporepower,dc=local";
            String filter = "(&(cn=TDIS2709)(objectclass=person))";
            String fiter2 = "(objectClass=group)";
            String serachDN = "ou=NonEmployeeAccounts";
            String serachDN2 = "ou=PPMS_Grp,ou=Systems_Grp,OU=GROUP";
//            String[] returnedAtts = {"cn","member","userpassword","userPassword","displayName","memberOf"};
            String[] returnedAtts = {"memberOf"};
            SearchControls controls = new SearchControls();
            controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            controls.setReturningAttributes(returnedAtts);

            /*NamingEnumeration<NameClassPair> list = ctx.list(serachDN);
            while (list != null && list.hasMoreElements()) {

                NameClassPair nameParser = list.next();
                System.out.println(nameParser.getName());
            }*/
            NamingEnumeration enumeration = ctx.search(serachDN, filter, controls);




            if (enumeration == null) {
                System.out.println("en is null....");
            }

            while (enumeration != null && enumeration.hasMoreElements()) {
                Object object = enumeration.nextElement();
                if (object instanceof SearchResult) {
                    SearchResult result = (SearchResult) object;

                    Attributes userInfo = result.getAttributes();
                    Attribute attribute2 = userInfo.get("memberOf");
                    NamingEnumeration enumeration1 = attribute2.getAll();
                    while (enumeration1 != null && enumeration1.hasMoreElements()) {
                        Object object2 = enumeration1.nextElement();
                        System.out.println((String)object2);

                    }
                    Attribute attribute = userInfo.get("displayName");
                    String userName = result.getName() + "," + baseDN;
                    ctx.addToEnvironment(Context.SECURITY_PRINCIPAL,"TDIS2709@spgroup.com.sg");
                    ctx.addToEnvironment(Context.SECURITY_CREDENTIALS,"NARI_$123");
                    ctx.reconnect(null);

                }
            }
        } catch (javax.naming.AuthenticationException e) {
            System.out.println("LDAPS connect... failure.");
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("LDAPS connect...error.");
            e.printStackTrace();
        }
    }


}


