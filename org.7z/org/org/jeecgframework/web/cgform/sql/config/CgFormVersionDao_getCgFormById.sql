select 
* 
from cgform_head  
where id = :id