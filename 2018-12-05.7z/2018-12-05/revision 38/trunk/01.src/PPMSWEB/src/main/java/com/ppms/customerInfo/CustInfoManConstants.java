package com.ppms.customerInfo;

/**
 * Created by liangyadong on 2018/8/3 0003.
 */
public class CustInfoManConstants {

    /**
     * 开户提示信息
     */
    public enum OPENING_TIP_MESSAGE{
        OPENING_SUCCESS("Account Opening Success."),
        OPENING_ALREADY_EXIST("This account number has existed!"),
        OPENING_FAILURE("Account Opening Failure!");

        private String message;

        OPENING_TIP_MESSAGE(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }

    }

    /**
     * customer type 账户类型
     * 01- EBS (Postpaid - prepaid)
     * 02- PAYU
     */
    public enum ACCOUNT_OPENING_TYPE{

        ACCOUNT_EBS("01"),
        ACCOUNT_PAYU("02");

        private String type;

        ACCOUNT_OPENING_TYPE(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }

    }

    /**
     * 开户销户记录-账户状态
     */
    public enum ACCOUNT_TYPE{
        ACCOUNT_OPENING("01"),//OPENNING
        ACCOUNT_CLOSING("02");//CLOSING

        private String type;

        ACCOUNT_TYPE(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }

    }

    /**
     * 客户档案表账户状态
     * 01: 创建（待激活）或重新开户
     * 02: 等待激活，表示电表信息获取成功
     * 03: 电表信号获取成功
     * 90: 激活(允许充值)
     * 99: 销户
     */
    public enum ACCOUNT_STATUS{
        ACCOUNT_OPENING("01"),
        ACCOUNT_WAIT_ACTIVIT("02"),
        GET_METER_SIGNAL_SUCCESS("03"),
        ACCOUNT_ACTIVITED("90"),
        ACCOUNT_CLOSED("99");

        private String status;

        ACCOUNT_STATUS(String status) {
            this.status = status;
        }

        public String getStatus() {
            return status;
        }

    }

    /**
     * 销户申请提示信息
     */
    public enum ACCOUNT_CLOSING_APPLY_MESSAGE{
        ACCOUNT_CLOSING_APPLY_SUCCESS("Account Closing Success."),
        ACCOUNT_CLOSING_APPLY_FAILED("Account Closing Failure."),
        ACCOUNT_CLOSING_MANUAL_SUCCESS("New account information is sumitted successfully."),
        ACCOUNT_CLOSING_MANUAL_FAILED("New account information enter failure."),
        ACCOUNT_CLOSING_EBS_HASARREAR("EBS has arrears, please submit the account application after liquidation");

        private String message;

        ACCOUNT_CLOSING_APPLY_MESSAGE(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }

    }

    /**
     * 档案信息保存/更新
     */
    public enum SAVE_ACCOUNT_INFO{
        SAVE_ACCOUNT_INFO_SUCCESS("Customer Information Updation Success."),
        SAVE_ACCOUNT_INFO_FAILED("Customer Information Updation Failure.");
        private String message;

        SAVE_ACCOUNT_INFO(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }

    }

    /**
     * 开户 预置金额等信息
     */
    public enum ACCOUNT_OPENING_TYPEGROUPCODE{
        PRESET_CREDIT("PRESET_CREDIT"),
        EMER_CREDIT_LIMIT("EMER_CREDIT_LIMIT"),
        LOW_CREDIT_ALARM("LOW_CREDIT_ALARM"),
        DEFAULT_ARREAR_PCT("DEFAULT_ARREAR_PCT");
        private String typeName;

        ACCOUNT_OPENING_TYPEGROUPCODE(String typeName) {
            this.typeName = typeName;
        }

        public String getTypeName() {
            return typeName;
        }

    }

    //A_BALANCE_REC UPDATE_FLAG
    /*01: 新开户
    02: PAYU
    03: 充值
    04: 电费扣减
    05: 电费调整
    06: 冲正
    07: 退款
    08: 余额转出
    09: 余额转入
    10: 对账补入
    11: 对账删除
    12: 换表电费结算
    13. 销户
    14. 发行电卡
    15. 重新开户*/
    public enum UPDATE_FLAG{
        ACCOUNT_OPENING_EBS("01"),
        ACCOUNT_OPENING_PAYU("02");
        private String updateFlag;

        UPDATE_FLAG(String updateFlag) {
            this.updateFlag = updateFlag;
        }

        public String getUpdateFlag() {
            return updateFlag;
        }

    }

}
