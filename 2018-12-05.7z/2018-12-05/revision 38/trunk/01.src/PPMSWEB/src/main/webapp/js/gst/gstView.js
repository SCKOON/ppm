function update(title, url, id, width, height) {
    gridname = id;
    var rowsData = $('#' + id).datagrid('getSelections');
    if (!rowsData || rowsData.length == 0) {
        alertTip('Please select edit item');
        return;
    }
    if (rowsData.length > 1) {
        alertTip('Please one item to edit');
        return;
    }
    var obj = rowsData[0];
    if (obj['startTime'] != null) {
        var startTime = obj['startTime'].slice(0, 10);
        var now = new Date();
        var startDate = new Date(startTime.replace(/-/g, '/'));
        if (now >= startDate) {
            alertTip('The GST is outdated or in use. Edit is not allowed.');
            return;
        }
    }
    url += '&id=' + obj['id'];

    createwindow(title, url, width, height);
}

function deleteDialog(id) {
    //提示框
    $.messager.confirm("Message", "Delete this GST？", function (r) {
        if (r) {
            var url = "gstController.do?doDel&id=" + id;
            $.ajax({
                url: url,
                type: "get",
                dataType: "json",
                success: function (data) {
                    top.alertTip(data.msg);
                    if (data.success) {
                        $("#gstList").datagrid('reload');
                    }
                }
            })
        }
    });
}

// function gstListsearch() {
//     if (!clickFlag) {
//         return false;
//     }
//     clickFlag = false;
//     setTimeout("changeFlag()", 1000);
//     try {
//         if (!$("#gstListForm").Validform({tiptype: 3}).check()) {
//             return false;
//         }
//     } catch (e) {
//     }
//     if (true) {
//         var queryParams = $('#gstList').datagrid('options').queryParams;
//         $('#gstListtb').find('*').each(function () {
//             queryParams[$(this).attr('name')] = $(this).val();
//         });
//         $('#gstList').datagrid({
//             url: 'gstController.do?datagrid&field=id,version,code,startTime,rate,createTime,',
//             pageNumber: 1,
//             queryParams: queryParams,
//             onLoadSuccess: function(data){
//                 if (data.total == 0) {
//                     $(this).datagrid('appendRow', { version: '<div style="text-align:center;color:red">No record found！</div>' }).datagrid('mergeCells', { index: 0, field: 'version', colspan: 5 })
//                 }
//             }
//         });
//     }
// }