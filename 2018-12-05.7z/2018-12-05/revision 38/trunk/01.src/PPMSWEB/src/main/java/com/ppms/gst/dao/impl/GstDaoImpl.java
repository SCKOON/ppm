package com.ppms.gst.dao.impl;

import com.constants.DelFlagEnum;
import com.ppms.entity.GSTEntity;
import com.ppms.entity.GstLogEntity;
import com.ppms.gst.dao.GstDaoI;
import org.hibernate.Query;
import org.jeecgframework.core.common.dao.impl.GenericBaseCommonDao;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.util.DateUtils;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.p3.core.logger.Logger;
import org.jeecgframework.p3.core.logger.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


@Repository
public class GstDaoImpl extends GenericBaseCommonDao implements GstDaoI {
    private static Logger logger = LoggerFactory.getLogger(GstDaoImpl.class);

    @Override
    public List<GSTEntity> queryListByCondition(DataGrid dataGrid, HttpServletRequest request) {
        List<GSTEntity> gstEntityList = null;
        Map map = new HashMap<String, Object>();
        String code = request.getParameter("code");
        String version = request.getParameter("version");
        String beginTime = request.getParameter("startTime");
        StringBuilder stringBuilder = new StringBuilder("from GSTEntity as entity where 1=1 ");
        boolean flag = false;

        if (oConvertUtils.isNotEmpty(code)) {
            stringBuilder.append(" and entity.code like :code");
            map.put("code", "%" + code + "%");
        }
        if (oConvertUtils.isNotEmpty(version)) {
            stringBuilder.append(" and entity.version like :version");
            map.put("version", "%" + version + "%");
        }
        stringBuilder.append(" and entity.delFlag = :delFlag");
        map.put("delFlag", DelFlagEnum.VALID.getStatus());
        if (oConvertUtils.isNotEmpty(beginTime)) {
            flag = true;
            try {
                map.put("beginTime", DateUtils.parseDate(beginTime, "yyyy-MM-dd"));
                stringBuilder.append(" and entity.startTime <= :beginTime");
                stringBuilder.append(" order by entity.startTime desc ");
            } catch (ParseException e) {
                logger.error(e.getMessage(), e);
            }
        }
        if (dataGrid != null && !flag) {
            if (dataGrid.getSort() != null && oConvertUtils.isNotEmpty(dataGrid.getSort())) {
                stringBuilder.append(" order by entity." + dataGrid.getSort() + " " + dataGrid.getOrder());
            }
        }
        Query query = super.getSession().createQuery(stringBuilder.toString());
        query.setFirstResult(0);
        query.setMaxResults(1);
        query.setProperties(map);
        gstEntityList = query.list();
        dataGrid.setResults(gstEntityList);
        dataGrid.setTotal(gstEntityList.size());
        if (!flag) {
            super.paginateDataGrid(gstEntityList, dataGrid, query);
        }
        return gstEntityList;
    }

    @Override
    public List<GstLogEntity> queryListRecordByCondition(DataGrid dataGrid, HttpServletRequest request) {
        List<GstLogEntity> gstLogEntityList = null;
        Map map = new HashMap<String, Object>();
        StringBuilder stringBuilder = new StringBuilder(" from GstLogEntity as entity where 1=1 ");
        if (request != null) {
            String code = request.getParameter("code");
            String beginTime = request.getParameter("startTime");
            String endTime = request.getParameter("endTime");
            String version = request.getParameter("version");
            if (oConvertUtils.isNotEmpty(version)) {
                stringBuilder.append(" and entity.version like :version");
                map.put("version", "%" + version + "%");
            }
            if (oConvertUtils.isNotEmpty(code)) {
                stringBuilder.append(" and entity.code like :code");
                map.put("code", "%" + code + "%");
            }
            if (oConvertUtils.isNotEmpty(beginTime)) {
                try {
                    map.put("beginTime", DateUtils.parseDate(beginTime, "yyyy-MM-dd hh:mm:ss"));
                    stringBuilder.append(" and entity.startTime >= :beginTime");
                } catch (ParseException e) {
                    logger.error(e.getMessage(), e);
                }
            }
            if (oConvertUtils.isNotEmpty(endTime)) {
                try {
                    map.put("endTime", DateUtils.parseDate(endTime, "yyyy-MM-dd hh:mm:ss"));
                    stringBuilder.append(" and entity.endTime <= :endTime");
                } catch (ParseException e) {
                    logger.error(e.getMessage(), e);
                }
            }
        }
        if (dataGrid != null) {
            if (dataGrid.getSort() != null && oConvertUtils.isNotEmpty(dataGrid.getSort())) {
                stringBuilder.append(" order by entity." + dataGrid.getSort() + " " + dataGrid.getOrder());
            }
        }
        Query query = super.getSession().createQuery(stringBuilder.toString());
        query.setProperties(map);
        gstLogEntityList = query.list();
        super.paginateDataGrid(gstLogEntityList, dataGrid, query);
        return gstLogEntityList;
    }

    //gst version 2018V_1
    @Override
    public int queryLastVersionNum(int year) {
        int num = 0;
        String hql = "from GSTEntity as entity where 1=1 and entity.version like :version";
        Query query = super.getSession().createQuery(hql);
        query.setParameter("version", year + "%");
        List<GSTEntity> list = query.list();
        if (null != list && list.size() > 0) {
            List<Integer> integerList = new ArrayList<>();
            for (GSTEntity entity : list) {
                String version = entity.getVersion();
                try {
                    int versionNum = Integer.parseInt(version.substring(5));
                    integerList.add(versionNum);
                } catch (NumberFormatException e) {
                    logger.error(e.getMessage(), e);
                }
            }
            if (integerList.size() > 0) {
                Integer[] nums = new Integer[integerList.size()];
                integerList.toArray(nums);
                Arrays.sort(nums);
                num = nums[nums.length - 1];
            }
        }

        return num;
    }

    /**
     * @return
     * @description 查询当前时间在用的GST
     */
    @Override
    public GSTEntity queryCurrentInUse() {
        GSTEntity gstEntity = null;
        Date currentDate = new Date();
        String hql = "from GSTEntity as entity where 1=1 and delFlag = :delFlag and entity.startTime <= :currentDate order by entity.startTime desc";
        Query query = super.getSession().createQuery(hql);
        query.setParameter("currentDate", currentDate);
        query.setParameter("delFlag", DelFlagEnum.VALID.getStatus());
        List<GSTEntity> list = query.list();
        if (null != list && list.size() > 0) {
            gstEntity = list.get(0);
        }

        return gstEntity;
    }

    /**
     * 新增时查询开始时间是否合法
     *
     * @return
     */
    @Override
    public boolean queryIsTimeConflict(GSTEntity gstEntity) {
        Map<String, Object> map = new HashMap();
        StringBuilder nativeSQL = new StringBuilder("select * from GST_INFO as info where 1=1 and del_flag = :delFlag ");
        map.put("delFlag",DelFlagEnum.VALID.getStatus());
        if (oConvertUtils.isNotEmpty(gstEntity.getVersion())) {
            nativeSQL.append(" and info.version != :version ");
            map.put("version", gstEntity.getVersion());
        }
        if (gstEntity.getId() != null) {
            nativeSQL.append(" and info.id != :id ");
            map.put("id", gstEntity.getId().intValue());
        }
        if (gstEntity.getStartTime() != null) {
            nativeSQL.append(" and CONVERT(nvarchar(10),info.start_time,120) = :start_time ");
            map.put("start_time", DateUtils.date2Str(gstEntity.getStartTime(), new SimpleDateFormat("yyyy-MM-dd")));
        }
        List list = super.getSession().createSQLQuery(nativeSQL.toString()).setProperties(map).list();
        return list.size() > 0;
    }
}
