package com.ppms.vo;

import java.math.BigDecimal;

/**
 * Created by yadongliang on 2018/5/7 0007.
 */
public class ResultVo {
    private String accNo;
    private String name;
    private String nric;
    private String address;
    private String premiseType;
    private BigDecimal balance;
    private String meterId;
    private String accountStatus;
    private String telephoneNumber;
    private BigDecimal arrearPct;

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public String getAccNo() {
        return accNo;
    }

    public void setAccNo(String accNo) {
        this.accNo = accNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNric() {
        return nric;
    }

    public void setNric(String nric) {
        this.nric = nric;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPremiseType() {
        return premiseType;
    }

    public void setPremiseType(String premiseType) {
        this.premiseType = premiseType;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public String getMeterId() {
        return meterId;
    }

    public void setMeterId(String meterId) {
        this.meterId = meterId;
    }

    public BigDecimal getArrearPct() {
        return arrearPct;
    }

    public void setArrearPct(BigDecimal arrearPct) {
        this.arrearPct = arrearPct;
    }
}
