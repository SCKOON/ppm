function checkGst(){

    var begin = $("input[name='startTime']").val();
    if(undefined == begin || null==begin || ""==begin){
        $(".datebox :eq(0)").siblings(".Validform_checktip").addClass("Validform_wrong").text("Effective Date must not be empty!");
    }
    var now = new Date();
    var startDate = new Date(begin.replace(/-/g, '/'));
    if(now >= startDate){
        $(".datebox :eq(0)").siblings(".Validform_checktip").addClass("Validform_wrong").text("Effective Date should be after current day.");
    }
    var len = $(".Validform_error,.Validform_wrong").length;
    if (len > 0) {
        $(".Validform_error")[0].focus();
        return false;
    }
}

$(function(){
    $(".datebox").eq(0).click(function(){
        $(".datebox").eq(0).siblings(".Validform_checktip").removeClass("Validform_wrong Validform_right").text("");
    })
});