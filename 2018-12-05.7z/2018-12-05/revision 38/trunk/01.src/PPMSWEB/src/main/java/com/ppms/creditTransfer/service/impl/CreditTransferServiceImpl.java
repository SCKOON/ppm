package com.ppms.creditTransfer.service.impl;

import com.constants.Constants;
import com.constants.UpdateFlagEnum;
import com.ppms.connection.dao.ConnectionDao;
import com.ppms.creditTransfer.dao.CreditTransferDao;
import com.ppms.creditTransfer.dto.CreditTransferDetail;
import com.ppms.entity.*;
import com.constants.ApproveStatusEnum;
import com.ppms.ldapLogin.util.ResourceUtils;
import com.ppms.sms.service.SmsService;
import com.ppms.utils.DataReturn;
import com.ppms.utils.DataSourceValue;
import com.ppms.vo.CreditTransferQueryVo;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.exception.BusinessException;
import org.jeecgframework.core.extend.datasource.DataSourceType;
import org.jeecgframework.core.util.DateUtils;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.ppms.creditTransfer.service.CreditTransferServiceI;
import org.jeecgframework.core.common.service.impl.CommonServiceImpl;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service("creditTransferService")
@Transactional
@DataSourceValue(DataSourceType.dataSource_ppms)
public class CreditTransferServiceImpl extends CommonServiceImpl implements CreditTransferServiceI {

    @Autowired
    private CreditTransferDao creditTransferDao;

    @Autowired
    private SmsService smsService;

    @Autowired
    private ConnectionDao connectionDao;

    public static final BigDecimal ZERO = new BigDecimal(0);

    private static final Logger logger = Logger.getLogger(CreditTransferServiceImpl.class);

    /**
     * 修改转出人的余额值，记录余额转出记录(申请转移不发短信)
     *
     * @param creditTransferEntity
     * @param request
     * @param lowCredit            低信用预警值
     * @return
     */
    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ, rollbackForClassName = {"Exception.class"})
    public void applyTransfer(CreditTransferEntity creditTransferEntity, HttpServletRequest request, String lowCredit) throws Exception {
        if (oConvertUtils.isEmpty(creditTransferEntity.getSrcAccNo())) {
            throw new BusinessException("Source AccountNo. can't be empty");
        }
        if(oConvertUtils.isEmpty(creditTransferEntity.getTgtAccNo())){
            throw new BusinessException("Target AccountNo. can't be empty");
        }
        if (creditTransferEntity.getSrcAccNo().equals(creditTransferEntity.getTgtAccNo())) {
            throw new BusinessException("Transfer from and to can't be the same Customer");
        }
        String reg = "^\\d{1,4}(?:\\.\\d{1,2})?$";
        if (oConvertUtils.isEmpty(creditTransferEntity.getTransferAmt()) || !match(reg, creditTransferEntity.getTransferAmt().toString())) {
            throw new BusinessException("Transfer Amount should be between 0 and 9999.99 (SGD)");
        }

        creditTransferEntity.setApplyId(ResourceUtils.getSessionUser().getName());
        creditTransferEntity.setApplyTime(new Date());
        /**
         * 01- pending
         * 02- approved
         * 03- declined
         */
        creditTransferEntity.setApprStatus(ApproveStatusEnum.PENDING.getStatus());

        String srcAccNo = creditTransferEntity.getSrcAccNo();
        String tgtAccNo = creditTransferEntity.getTgtAccNo();

        AcctBalEntity srcAcctBalEntity = super.get(AcctBalEntity.class, srcAccNo);
        AcctBalEntity tgtAcctBalEntity = super.get(AcctBalEntity.class, tgtAccNo);
        srcAcctBalEntity.setUpdateTime(new Date());

        creditTransferEntity.setSrcLastBal(srcAcctBalEntity.getBalance());
        creditTransferEntity.setTgtLastBal(tgtAcctBalEntity.getBalance());

        BigDecimal transferAmount = creditTransferEntity.getTransferAmt();
        if (srcAcctBalEntity.getBalance().compareTo(transferAmount) < 0) {
            throw new RuntimeException("Source Account Balance is not sufficient!");
        }
        BigDecimal currentSrcBalance = srcAcctBalEntity.getBalance().subtract(transferAmount);

        BigDecimal currentTgtBalance = tgtAcctBalEntity.getBalance().add(transferAmount);
        srcAcctBalEntity.setBalance(currentSrcBalance);

        creditTransferEntity.setSrcCurBal(currentSrcBalance);
        creditTransferEntity.setTgtCurBal(currentTgtBalance);

        //修改数据库中当前记录的余额
        super.saveOrUpdate(srcAcctBalEntity);
        //保存当前转出记录，hibernate save()方法的返回值是新增加记录的主键
        //获取刚才保存到余额转移记录的id，保存在余额记录表中
        int serializable = (Integer) super.save(creditTransferEntity);

        //生成余额转出短信发送给转出账户
        Map<String, String> map = new HashMap<>();
        map.put("TransferAmount", transferAmount.toString());
        map.put("SourceAccountNo", srcAccNo);
        map.put("TargetAccountNo", tgtAccNo);
        map.put("SrcAcctNoBalance", currentSrcBalance.toString());
        //发送短信id  有可能一次会发送好几条短信
        String result = smsService.generateSmsRecord(srcAccNo, Constants.SMS_TYPE.CREDIT_TRANSFERRING_OUT.getType(), map);

        //如果用户余额低于预警值，发送低余额预警短信
        if (oConvertUtils.isNotEmpty(lowCredit)) {
            try {
                if (currentSrcBalance.compareTo(new BigDecimal(lowCredit)) < 0) {
                    Map<String, String> creditMap = new HashMap<>();
                    creditMap.put("AccountNo", srcAccNo);
                    creditMap.put("CreditBalance", currentSrcBalance.setScale(2,BigDecimal.ROUND_DOWN).toPlainString());
                    result += ",";
                    result += smsService.generateSmsRecord(srcAccNo, Constants.SMS_TYPE.LOW_CREDIT_ALERT.getType(), creditMap);
                }
            } catch (Exception e) {
                logger.error(e);
            }
        }

        //将该次余额转移记录保存到余额记录表中
        BalanceRecEntity balanceRecEntity = new BalanceRecEntity();
        balanceRecEntity.setUpdateTime(new Date());
        balanceRecEntity.setAccNo(creditTransferEntity.getSrcAccNo());
        balanceRecEntity.setUpdateFlag(UpdateFlagEnum.CREDITTRANSFEROUT.getStatus());
        balanceRecEntity.setTxnNo(serializable + "");
        balanceRecEntity.setLastBal(creditTransferEntity.getSrcLastBal());
        balanceRecEntity.setCurBal(creditTransferEntity.getSrcCurBal());
        balanceRecEntity.setSmsNo(result);
        //余额转移申请没有，只有远程跳闸合闸有控制批号
        balanceRecEntity.setCtlNo("");
        balanceRecEntity.setOperId(ResourceUtils.getSessionUser().getName());
        super.save(balanceRecEntity);
    }

    /**
     * @param regex 正则表达式字符串
     * @param str   要匹配的字符串
     * @return 如果str 符合 regex的正则表达式格式,返回true, 否则返回 false;
     */
    private static boolean match(String regex, String str) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        return matcher.matches();
    }

    @Override
    public List<Map<String, Object>> getDetailView(String srcNo, String tgtNo) {
        return creditTransferDao.getDetailView(srcNo, tgtNo);
    }

    @Override
    public List<Integer> queryCounterIdForAudit(String terminalId) {
        return creditTransferDao.queryCounterIdForAudit(Integer.parseInt(terminalId));
    }

    /**
     * @param entity
     * @param approveOrNot
     * @param dealReason
     * @return
     * @description 循环遍历数组中的需要执行转移或拒绝转移的主键，执行相应余额转移业务
     * 1.修改credit_transfer表中审批意见，审批原因
     * 2.修改target用户的a_acct_balance的值
     * 3.从credit_transfer获取当前转移记录的id，设为a_balance_rec表的 transaction_number,更新target accno的余额
     */
    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ, rollbackForClassName = {"Exception.class"})
    public void doTransfer(CreditTransferEntity entity, String approveOrNot, String dealReason) throws Exception {
        if (oConvertUtils.isEmpty(approveOrNot)) {
            throw new BusinessException("Approve advice should not be empty!");
        }else if(!approveOrNot.equals(ApproveStatusEnum.DECLINED.getStatus())){
            if(!approveOrNot.equals(ApproveStatusEnum.APPROVED.getStatus())){
                throw new BusinessException("please select the correct Approve advice!");
            }
        }
        //1
        //保存用户余额转移记录
        CreditTransferEntity creditTransferEntity = super.getEntity(CreditTransferEntity.class, entity.getId());
        if(oConvertUtils.isNotEmpty(creditTransferEntity.getApprStatus())){
            throw new BusinessException("please select pending record!");
        }
        creditTransferEntity.setApprId(ResourceUtils.getSessionUser().getName());
        creditTransferEntity.setApprTime(new Date());
        creditTransferEntity.setApprStatus(approveOrNot);
        creditTransferEntity.setApplyReason(dealReason);
        super.saveOrUpdate(creditTransferEntity);

        //2
        //保存用户余额

        //判断是批准还是拒绝,操作的是不同acc_no的用户
        //拒绝的话，余额记录修改的是转出用户，批准的话，余额记录修改的是转入用户
        String acc_no = creditTransferEntity.getTgtAccNo();
        if (ApproveStatusEnum.DECLINED.getStatus().equals(approveOrNot)) {
            acc_no = creditTransferEntity.getSrcAccNo();
        }

        //计算余额
        AcctBalEntity acctBalEntity = getEntity(AcctBalEntity.class, acc_no);
        //转移金额
        BigDecimal transferAmount = creditTransferEntity.getTransferAmt();
        //转移前金额
        BigDecimal lastBalance = acctBalEntity.getBalance();
        //转移后金额
        BigDecimal currentBalance = lastBalance.add(transferAmount);
        acctBalEntity.setBalance(currentBalance);
        acctBalEntity.setUpdateTime(new Date());
        //保存用户余额
        super.saveOrUpdate(acctBalEntity);

        //中间还有一个发送短信的过程，返回值是sms_no
        //如果审批通过，需要同时向余额申请转出客户和转入客户发送短信，如果审批拒绝，则只向余额转出客户发送短信
        String smsNo = "";
        Map<String, String> map = new HashMap();
        if (ApproveStatusEnum.DECLINED.getStatus().equals(approveOrNot)) {
            map.put("TransferAmount", transferAmount.toString());
            map.put("SourceAccountNo", creditTransferEntity.getSrcAccNo());
            map.put("TargetAccountNo", creditTransferEntity.getTgtAccNo());
            map.put("SrcAcctNoBalance", currentBalance.toString());
            smsNo = smsService.generateSmsRecord(acc_no, Constants.SMS_TYPE.CANCEL_CREDIT_TRANSFERRING.getType(), map);
        } else if (ApproveStatusEnum.APPROVED.getStatus().equals(approveOrNot)) {
            //审批通过，需要发送短信
            map.put("TransferAmount", transferAmount.toString());
            map.put("SourceAccountNo", creditTransferEntity.getSrcAccNo());
            map.put("TargetAccountNo", creditTransferEntity.getTgtAccNo());
            map.put("TgtAcctNoBalance", currentBalance.toString());
            smsNo = smsService.generateSmsRecord(acc_no, Constants.SMS_TYPE.CREDIT_TRANSFERRING_RECEIVED.getType(), map);
        }
        //判断是否是跳闸转合闸
        if (lastBalance.compareTo(ZERO) < 0 && currentBalance.compareTo(ZERO) > 0) {
            //生成合闸命令
            RemoteReconRecEntity remoteReconRecEntity = new RemoteReconRecEntity();
            CustomerInfoEntity customerInfoEntity = super.getEntity(CustomerInfoEntity.class, acc_no);
            remoteReconRecEntity.setCustomerInfoEntity(customerInfoEntity);
            Set<MeterInfoEntity> meterInfoEntitySet = customerInfoEntity.getMeterInfoEntitySet().stream().filter(meterInfoEntity -> Constants.METER_STATUS.RUN.getStatus().equals(meterInfoEntity.getMeterStatus())).collect(Collectors.toSet());
            remoteReconRecEntity.setMeterId(((MeterInfoEntity) meterInfoEntitySet.toArray()[0]).getMeterId());
            remoteReconRecEntity.setTxnType(Constants.REMOTE_RECON_TXN_TYPE.CREDIT_TRANSFER_IN.getTxnStatus());
            remoteReconRecEntity.setGenTime(new Date());
            remoteReconRecEntity.setOperStatus(Constants.REMOTER_OPER_STATUS.PENDING.getType());
            this.connectionDao.doSaveAndUpdate(remoteReconRecEntity);
        }
        //3
        //保存余额转移记录
        BalanceRecEntity balanceRecordEntity = new BalanceRecEntity();
        balanceRecordEntity.setTxnNo(creditTransferEntity.getId() + "");
        balanceRecordEntity.setUpdateTime(new Date());
        balanceRecordEntity.setAccNo(acc_no);
        //操作员
        balanceRecordEntity.setOperId(ResourceUtils.getSessionUser().getName());
        balanceRecordEntity.setUpdateFlag(UpdateFlagEnum.CREDITTRANSFERIN.getStatus());
        balanceRecordEntity.setLastBal(lastBalance);
        balanceRecordEntity.setCurBal(currentBalance);
        balanceRecordEntity.setSmsNo(smsNo);
        super.save(balanceRecordEntity);
    }

    /**
     * 查询余额申请列表并返回装配到页面的相应数据
     *
     * @return DataReturn
     */
    @Override
    public DataReturn getApplyCreditTransferRecord(CreditTransferQueryVo vo, int page, int rows, String terminalId) {

        return creditTransferDao.getCreditTransferList(vo, page, rows, terminalId);
    }

    /**
     * @param detail
     * @return
     * @description 用户发起余额转移申请时，展示用户申请明细
     */
    @Override
    public CreditTransferDetail generateDetailInformation(CreditTransferDetail detail) {
        if ((oConvertUtils.isNotEmpty(detail.getSrcAccNo()) && oConvertUtils.isNotEmpty(detail.getTgtAccNo())) && oConvertUtils.isNotEmpty(detail.getAmount())) {

            try {
                //从数据库查询转移源账户余额
                AcctBalEntity srcAcctBalEntity = super.get(AcctBalEntity.class, detail.getSrcAccNo());
                //从数据库查询转移目标账户余额
                AcctBalEntity tgtAcctBalEntity = super.get(AcctBalEntity.class, detail.getTgtAccNo());

                detail.setAppdate(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date()));
                detail.setSrcCurBal(srcAcctBalEntity.getBalance().subtract(new BigDecimal(detail.getAmount())).setScale(2, BigDecimal.ROUND_DOWN));
                detail.setTgtNewBal(tgtAcctBalEntity.getBalance().add(new BigDecimal(detail.getAmount())).setScale(2, BigDecimal.ROUND_DOWN));
                detail.setSrcLast(srcAcctBalEntity.getBalance().setScale(2, BigDecimal.ROUND_DOWN));
                detail.setTgtLast(tgtAcctBalEntity.getBalance().setScale(2, BigDecimal.ROUND_DOWN));
                detail.setAmount(new BigDecimal(detail.getAmount()).setScale(2, BigDecimal.ROUND_DOWN).toString());
            } catch (Exception e) {
                logger.error(e);
            }
        }
        return detail;
    }

    @Override
    public CreditTransferDetail queryForDetail(String transferId) {
        CreditTransferDetail detail = creditTransferDao.queryFromTransferRecord(transferId);
        String status = detail.getStatus();
        if (!StringUtils.isEmpty(status)) {
            if (ApproveStatusEnum.PENDING.getStatus().equals(status)) {
                status = ApproveStatusEnum.PENDING.name();
            } else if (ApproveStatusEnum.APPROVED.getStatus().equals(status)) {
                status = ApproveStatusEnum.APPROVED.name();
            } else if (ApproveStatusEnum.DECLINED.getStatus().equals(status)) {
                status = ApproveStatusEnum.DECLINED.name();
            }
        }
        detail.setStatus(status);
        return detail;
    }
}