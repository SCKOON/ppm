package com.ppms.creditTransfer.dao.imp;

import com.constants.ApproveStatusEnum;
import com.ppms.creditTransfer.dao.CreditTransferDao;
import com.ppms.creditTransfer.dto.CreditTransferDetail;
import com.ppms.entity.CounterEntity;
import com.ppms.entity.CreditTransferEntity;
import com.ppms.entity.TerminalEntity;
import com.ppms.utils.DataReturn;
import com.ppms.utils.DataSourceValue;
import com.ppms.vo.CreditTransferQueryVo;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.jeecgframework.core.common.dao.impl.GenericBaseCommonDao;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.extend.datasource.DataSourceType;
import org.jeecgframework.core.util.ReflectHelper;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.tag.vo.datatable.SortDirection;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Repository
@DataSourceValue(DataSourceType.dataSource_ppms)
public class CreditTransferImp extends GenericBaseCommonDao implements CreditTransferDao {

    private static final Logger logger = Logger.getLogger(CreditTransferImp.class);

    /**
     * 根据审核状态查询对应的余额转移申请记录列表信息
     *
     * @return
     */
    @Override
    public DataReturn getCreditTransferList(CreditTransferQueryVo vo, int page, int rows, String terminalId) {
        DataReturn data = new DataReturn();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        StringBuilder countQuery = new StringBuilder("select count(*) ");
        StringBuilder hqlQuery = new StringBuilder("select creditTransfer,src.address as srcAddress,tgt.address as tgtAddress ");
        StringBuilder hql = new StringBuilder(" from CreditTransferEntity creditTransfer,CustomerInfoEntity src,CustomerInfoEntity tgt where creditTransfer.srcAccNo =  src.accNo and creditTransfer.tgtAccNo =  tgt.accNo ");
        StringBuilder condition = new StringBuilder("");
        Map parametermap = new HashMap<String, Object>();
        String apprStatus = vo.getApprStatus();

        if(StringUtils.isNotEmpty(apprStatus) ){
            condition.append(" and creditTransfer.apprStatus = :apprStatus ");
            parametermap.put("apprStatus", apprStatus);
        }

        String srcAccNo = vo.getSrcAccNo();
        if (StringUtils.isNotEmpty(srcAccNo)) {
            condition.append(" and creditTransfer.srcAccNo = :srcAccNo ");
            parametermap.put("srcAccNo", srcAccNo);
        }
        String tgtAccNo = vo.getTgtAccNo();
        if (StringUtils.isNotEmpty(tgtAccNo)) {
            condition.append(" and creditTransfer.tgtAccNo = :tgtAccNo ");
            parametermap.put("tgtAccNo", tgtAccNo);
        }
//        if (null != userNameList && userNameList.size() > 0) {
//            condition.append(" and creditTransfer.counterid in :nameList ");
//            parametermap.put("nameList", userNameList);
//        }
        if (StringUtils.isNotEmpty(terminalId)) {
            condition.append(" and creditTransfer.terminalid = :terminalid ");
            parametermap.put("terminalid", Integer.parseInt(terminalId));
        }

        String date_begin = vo.getApplyDate_begin();
        if (StringUtils.isNotEmpty(date_begin)) {
            condition.append(" and creditTransfer.applyTime >= :beginTime ");
            Date start = null;
            try {
                start = simpleDateFormat.parse(date_begin);
            } catch (ParseException e) {
                logger.error(e);
            }
            parametermap.put("beginTime", start);
        }
        String date_end = vo.getApplyDate_end();
        if (StringUtils.isNotEmpty(date_end)) {
            condition.append(" and creditTransfer.applyTime <= :endTime ");
            Calendar calendar = Calendar.getInstance();
            Date end = null;
            try {
                end = simpleDateFormat.parse(date_end);
            } catch (ParseException e) {
                logger.error(e);
            }
            calendar.setTime(end);
            //能查询endtime当天的数据
            calendar.add(Calendar.DAY_OF_MONTH, 1);
            parametermap.put("endTime", calendar.getTime());
        }
        String counthql = hqlQuery.append(hql.toString()).append(condition.toString()).append(" order by creditTransfer.applyTime desc ").toString();
        String queryhql = hqlQuery.append(hql.toString()).append(condition.toString()).append(" order by creditTransfer.applyTime desc ").toString();
        Query q = getSession().createQuery(counthql);
        q.setProperties(parametermap);
        int count = q.list().size();
        data.setTotal(count);
        q = getSession().createQuery(queryhql);
        q.setProperties(parametermap);
        q.setFirstResult((page - 1) * rows).setMaxResults(rows);
        List entityList = q.list();
        List<Map<String, Object>> mapList = new LinkedList();
        CreditTransferEntity creditTransferEntity = new CreditTransferEntity();
        String[] fieldNames = ReflectHelper.getFiledName(creditTransferEntity);
        for (int i = 0; i < entityList.size(); i++) {
            Map<String, Object> map = new HashMap<>();
            Object[] o = (Object[]) entityList.get(i);
            map.put("srcAddress", o[1]);
            map.put("srcAddress", o[2]);
            for (int j = 0; j < fieldNames.length; j++) {
                Object object = ReflectHelper.getFieldValueByName(fieldNames[j], o[0]);
                String[] fieldStr = new String[]{"srcLastBal", "srcCurBal", "tgtLastBal", "tgtCurBal", "transferAmt"};
                List<String> list = Arrays.asList(fieldStr);
                if (list.contains(fieldNames[j])) {
                    if (oConvertUtils.isNotEmpty(object) && object instanceof BigDecimal) {
                        map.put(fieldNames[j], ((BigDecimal) object).setScale(2, BigDecimal.ROUND_DOWN));
                        continue;
                    }
                }
                map.put(fieldNames[j], object);
            }
            mapList.add(map);
        }
        data.setRows(mapList);
        return data;
    }

    //通过审批员code查询柜台操作员用户
    @Override
    public List<Integer> queryCounterIdForAudit(int terminalId) {
        List<Integer> integerList = new ArrayList<>();
        String hql = " from TerminalEntity as terminal where terminal.id = :id";
        Query q = getSession().createQuery(hql);
        q.setParameter("id", terminalId);
        List<TerminalEntity> terminalEntities = q.list();
        if (terminalEntities.size() > 0) {
            TerminalEntity entity = terminalEntities.get(0);
            Set<CounterEntity> counterEntitySet = entity.getCounterEntities();
            if (counterEntitySet != null && counterEntitySet.size() > 0) {
                Iterator<CounterEntity> iterator = counterEntitySet.iterator();
                while (iterator.hasNext()) {
                    CounterEntity entity1 = iterator.next();
                    integerList.add(entity1.getId());
                }
            }
        }
        return integerList;
    }

    @Override
    public List<Map<String, Object>> getDetailView(String srcNo, String tgtNo) {
        StringBuilder hql = new StringBuilder("select creditTransfer,src.name as srcCustomerName,tgt.name,src.address as srcAddress,tgt.address as tgtAddress from CreditTransferEntity creditTransfer,CustomerInfoEntity src,CustomerInfoEntity tgt where creditTransfer.srcAccNo =  src.accNo and creditTransfer.tgtAccNo =  tgt.accNo ");
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        if (!"".equals(oConvertUtils.getString(srcNo))) {
            condition.append(" and creditTransfer.srcAccNo = ? ");
            params.add(srcNo);
        }
        if (!"".equals(oConvertUtils.getString(tgtNo))) {
            condition.append(" and creditTransfer.tgtAccNo = ? ");
            params.add(tgtNo);
        }
        String hqlQuery = hql.append(condition.toString()).toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List entityList = q.list();
        List<Map<String, Object>> mapList = new LinkedList<Map<String, Object>>();
        String[] fieldNames = ReflectHelper.getFiledName(new CreditTransferEntity());
        for (int i = 0; i < entityList.size(); i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            Object[] o = (Object[]) entityList.get(i);
            map.put("srcCustomerName", o[1]);
            map.put("tgtCustomerName", o[2]);
            map.put("srcAddress", o[3]);
            map.put("srcAddress", o[4]);
            for (int j = 0; j < fieldNames.length; j++) {
                Object object = ReflectHelper.getFieldValueByName(fieldNames[j], o[0]);
                map.put(fieldNames[j], object);
            }
            mapList.add(map);
        }
        return mapList;
    }

    @Override
    public CreditTransferEntity getRecentRecord(String accNo) {

        CriteriaQuery cq = new CriteriaQuery(CreditTransferEntity.class);

        if (!"".equals(oConvertUtils.getString(accNo))) {
            cq.eq("srcAccNo", accNo);
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("applyTime", SortDirection.desc);
        cq.setOrder(map);
        cq.add();
        Criteria criteria = cq.getDetachedCriteria().getExecutableCriteria(getSession());


        return (CreditTransferEntity) (criteria.list().get(0));
    }

    @Override
    public CreditTransferDetail queryFromTransferRecord(String transferId) {

        if (StringUtils.isEmpty(transferId)) {
            return null;
        }
        CreditTransferDetail detail = new CreditTransferDetail();
        String hql = "select transfer.srcAccNo as srcAccNo,transfer.tgtAccNo as tgtAccNo,transfer.transferAmt as transferAmt,transfer.srcCurBal as srcCurBal,transfer.srcLastBal as srcLastBal,transfer.tgtCurBal as tgtCurBal,transfer.tgtLastBal as tgtLastBal,transfer.applyReason as applyReason,transfer.applyTime as applyTime,transfer.apprStatus as apprStatus,transfer.apprTime as apprTime,transfer.apprReason as apprReason,a.address as srcAddress,c.address as tgtAddress from CreditTransferEntity transfer, CustomerInfoEntity a, CustomerInfoEntity c where transfer.id = :transferId and transfer.srcAccNo = a.accNo and transfer.tgtAccNo = c.accNo";
        Query query = getSession().createQuery(hql);
        query.setParameter("transferId", Integer.parseInt(transferId));
        List list = query.list();
        for (int i = 0; i < list.size(); i++) {
            Object[] o = (Object[]) list.get(i);

            int j = 0;
            detail.setSrcAccNo(parseObject(o[j++]));
            detail.setTgtAccNo(parseObject(o[j++]));
            detail.setAmount(parseObject(o[j++]));

            String srcCurBal = parseObject(o[j++]);
            detail.setSrcCurBal(StringUtils.isEmpty(srcCurBal)?null:new BigDecimal(srcCurBal).setScale(2, BigDecimal.ROUND_DOWN));
            String srcLastBal = parseObject(o[j++]);
            detail.setSrcLast(StringUtils.isEmpty(srcLastBal)?null:new BigDecimal(srcLastBal).setScale(2, BigDecimal.ROUND_DOWN));

            String tgtCurBal = parseObject(o[j++]);
            detail.setTgtNewBal(StringUtils.isEmpty(tgtCurBal)?null:new BigDecimal(tgtCurBal).setScale(2, BigDecimal.ROUND_DOWN));
            String tgtLastBal = parseObject(o[j++]);
            detail.setTgtLast(StringUtils.isEmpty(tgtLastBal)?null:new BigDecimal(tgtLastBal).setScale(2, BigDecimal.ROUND_DOWN));

            detail.setApplyReason(parseObject(o[j++]));
            detail.setAppdate(parseObject(o[j++]));
            detail.setStatus(parseObject(o[j++]));
            detail.setApprovedate(parseObject(o[j++]));
            detail.setApprReason(parseObject(o[j++]));
            detail.setSrcAddress(parseObject(o[j++]));
            detail.setTgtAddress(parseObject(o[j++]));

        }
        return detail;
    }

    private String parseObject(Object object){
        if(oConvertUtils.isEmpty(object)){
            return "";
        }
        if(object instanceof String){
            return (String)object;
        }
        return object.toString();
    }
}
