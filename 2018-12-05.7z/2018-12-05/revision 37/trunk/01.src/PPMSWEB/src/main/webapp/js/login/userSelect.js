function showCenter(value){
    var value = $("#groupId").val();
    if(value==null||value==''){
        return;
    }else{
        if(value.lastIndexOf('COUNTER')>0||value.lastIndexOf('CASHIER')>0){
            $("tr.terminal").hide();
            $("#terminalId").removeAttr("datatype");
        }else if(value.lastIndexOf('EXECS')>0){
            $("tr.terminal").show();
            $("#terminalId").attr("datatype", "select1");
        }
    }
}