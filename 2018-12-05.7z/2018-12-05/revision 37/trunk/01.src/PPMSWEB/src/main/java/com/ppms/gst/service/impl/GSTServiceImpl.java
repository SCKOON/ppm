package com.ppms.gst.service.impl;

import com.constants.ActiveFlagEnum;
import com.constants.DelFlagEnum;
import com.constants.OperTypeEnum;
import com.ppms.entity.GSTEntity;
import com.ppms.entity.GstLogEntity;
import com.ppms.gst.dao.GstDaoI;
import com.ppms.gst.service.GSTServiceI;
import com.ppms.ldapLogin.util.ResourceUtils;
import com.ppms.utils.DataSourceValue;
import com.ppms.utils.ObjectOperUtil;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.exception.BusinessException;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.extend.datasource.DataSourceType;
import org.jeecgframework.core.util.MyBeanUtils;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@Transactional
@DataSourceValue(DataSourceType.dataSource_ppms)
public class GSTServiceImpl implements GSTServiceI {

    @Autowired
    private GstDaoI gstDaoI;

    /**e
     * Logger for this class
     */
    private static final Logger logger = Logger.getLogger(GSTServiceImpl.class);

    /**
     * 参考tariff的新增
     *
     * @param entity
     * @throws Exception
     */
    @Override
    @Transactional
    public void saveAndLog(GSTEntity entity) throws Exception {
        if (oConvertUtils.isEmpty(entity.getVersion())) {
            throw new BusinessException("GST version or code can't be empty");
        }
        if (oConvertUtils.isNotEmpty(entity.getStartTime())) {
            if (entity.getStartTime().before(new Date())) {
                throw new BusinessException("Gst Start Date should be after today！");
            }
        } else {
            throw new BusinessException("Gst Start Date should not be empty!");
        }
        if (gstDaoI.queryIsTimeConflict(entity)) {
            throw new BusinessException("Start Date comflict with other records!");
        }
        if (entity.getRate() == null) {
            throw new BusinessException("Gst rate can't be empty!");
        } else {
            String reg = "^\\d{1,2}(?:\\.\\d{1,2})?$";
            if (!match(reg, entity.getRate().toString())) {
                throw new BusinessException("Invalid Gst Rate");
            }
        }
        GstLogEntity gstLogEntity = new GstLogEntity();
        //标识当前记录的操作时间
        entity.setCreateTime(new Date());

        gstLogEntity.setOperDate(new Date());
        gstLogEntity.setOperName(ResourceUtils.getSessionUser().getName());
        gstLogEntity.setVersion(entity.getVersion());
        gstLogEntity.setCode(entity.getCode());
        gstLogEntity.setOperType(OperTypeEnum.ADD.getStatus());
        entity.setDelFlag(DelFlagEnum.VALID.getStatus());

        MyBeanUtils.copyBeanNotNull2Bean(entity, gstLogEntity);

        handleRate(entity);
        gstDaoI.save(entity);
        gstDaoI.save(gstLogEntity);
    }

    /**
     * @return 与当前系统已存在电价记录冲突返回false，否则返回true
     * @description 校验当前电价设定的时间是否与已存在的tariff冲突
     */
    private boolean checkTimeConflict(GSTEntity entity) {
        Date beginTime = entity.getStartTime();
        CriteriaQuery criteriaQuery = new CriteriaQuery(GSTEntity.class);
        if (null != entity.getId()) {
            criteriaQuery.notEq("id", entity.getId());
        }
        if (oConvertUtils.isNotEmpty(entity.getVersion())) {
            criteriaQuery.notEq("version", entity.getVersion());
        }
        criteriaQuery.eq("startTime", beginTime);
        criteriaQuery.add();
        List list = gstDaoI.getListByCriteriaQuery(criteriaQuery, false);
        if (null != list && list.size() > 0) {
            return false;
        }
        return true;
    }

    @Override
    public void updateAndLog(GSTEntity entity) throws Exception {
        GstLogEntity gstLogEntity = new GstLogEntity();
        if (StringUtils.isEmpty(entity.getVersion())) {
            throw new BusinessException("GST version should not be empty");
        }
        if (oConvertUtils.isNotEmpty(entity.getStartTime())) {
            if (entity.getStartTime().before(new Date())) {
                throw new BusinessException("GST Start Date should be after today's date");
            }
        } else {
            throw new BusinessException("GST Start Date should not be empty");
        }
        if (gstDaoI.queryIsTimeConflict(entity)) {
            throw new BusinessException("Start Date conflicts with other GST records");
        }
        if (entity.getRate() == null) {
            throw new BusinessException("GST rate should not be empty");
        } else {
            String reg = "^\\d{1,2}(?:\\.\\d{1,2})?$";
            if (!match(reg, entity.getRate().toString())) {
                throw new BusinessException("Invalid GST rate");
            }
        }

        gstLogEntity.setOperDate(new Date());
        gstLogEntity.setOperName(ResourceUtils.getSessionUser().getName());

        //标识当前记录的操作状态
        gstLogEntity.setOperType(OperTypeEnum.EDIT.getStatus());
        GSTEntity oldGstEntity = gstDaoI.getEntity(GSTEntity.class, entity.getId());

        gstDaoI.getSession().evict(oldGstEntity);
        entity.setCreateTime(oldGstEntity.getCreateTime());
        entity.setDelFlag(oldGstEntity.getDelFlag());
        oldGstEntity.setRate(oldGstEntity.getRate().movePointRight(2));
        gstLogEntity.setRemark(new InnerClass().contrastValue(oldGstEntity, entity));
        MyBeanUtils.copyBeanNotNull2Bean(entity, gstLogEntity);


        handleRate(entity);
        gstDaoI.saveOrUpdate(entity);
        gstDaoI.save(gstLogEntity);

    }

    /**
     * @param regex 正则表达式字符串
     * @param str   要匹配的字符串
     * @return 如果str 符合 regex的正则表达式格式,返回true, 否则返回 false;
     */
    private static boolean match(String regex, String str) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        return matcher.matches();
    }

    /**
     * @param entity
     * @return
     * @description 对前台输入的rate进行百分比取值
     */
    private void handleRate(GSTEntity entity) {
        BigDecimal rate = entity.getRate();
        if (rate != null) {
            try {
                //往数据库存入rate的百分值
                entity.setRate(rate.divide(new BigDecimal(100), 4, RoundingMode.DOWN));
            } catch (NumberFormatException e) {
                logger.error(e);
            }
        }
    }

    public int queryLastVersionNum(int year) {
        return gstDaoI.queryLastVersionNum(year);
    }

    @Override
    @Transactional
    public void delete(GSTEntity gstEntity) throws Exception {
        gstEntity = gstDaoI.get(GSTEntity.class, gstEntity.getId());
        if(gstEntity.getStartTime().before(new Date())){
            throw new BusinessException("Deletion failure. The GST is in use");
        }
        //查询当前在用的gst是否和删除的是同一个版本
//        GSTEntity entity = gstDaoI.queryCurrentInUse();
//        if (null != entity) {
//            if (gstEntity.getId().intValue() == entity.getId().intValue()) {
//                throw new BusinessException("The gst is in use,deny delete!");
//            }
//        }
        GstLogEntity gstLogEntity = new GstLogEntity();
        gstEntity.setDelFlag(DelFlagEnum.DELETE.getStatus());

        MyBeanUtils.copyBeanNotNull2Bean(gstEntity, gstLogEntity);

        gstLogEntity.setOperDate(new Date());
        gstLogEntity.setOperName(ResourceUtils.getSessionUser().getName());
        gstLogEntity.setOperType(OperTypeEnum.DELETE.getStatus());

        gstDaoI.saveOrUpdate(gstEntity);
        gstDaoI.save(gstLogEntity);
    }

    @Override
    public List<GSTEntity> queryListByCondition(DataGrid dataGrid, HttpServletRequest request) {
        return gstDaoI.queryListByCondition(dataGrid, request);
    }

    @Override
    public List<GstLogEntity> queryListRecordByCondition(DataGrid dataGrid, HttpServletRequest request) {
        return gstDaoI.queryListRecordByCondition(dataGrid, request);
    }

    @Override
    public <T> T getEntity(Class entityName, Serializable id) {
        return gstDaoI.getEntity(entityName, id);
    }

    @Override
    public <T> List<T> getListByCriteriaQuery(CriteriaQuery cq, Boolean ispage) {
        return gstDaoI.getListByCriteriaQuery(cq, ispage);
    }

    private static class InnerClass extends ObjectOperUtil {

        private static Map<String, String> map = new HashMap();

        static {
            map.put("version", "GST Version");
            map.put("code", "GST Code");
            map.put("startTime", "Start Time");
            map.put("rate", "Rate(%)");
        }

        @Override
        protected void init() {
            super.addExcludFileds("createTime");
            super.addExcludFileds("delFlag");
            super.addExcludFileds("startFlag");
            super.addExcludFileds("code");
            super.addExcludFileds("endTime");
        }

        @Override
        protected String transferPropertyName(String orignName) {
            String transferName = map.get(orignName);

            return oConvertUtils.getString(transferName);
        }

        @Override
        protected Object format(String fieldName, Object obj) {

            if (obj == null) {
                return "";
            }
            if (Date.class.isAssignableFrom(obj.getClass())) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                String strTime = simpleDateFormat.format(obj);
                return strTime;
            }
            if (fieldName != null) {
                switch (fieldName) {
                    case "startFlag":
                        return obj.equals(ActiveFlagEnum.DISABLED.getStatus()) ? "Disabled" : "Enabled";
                    case "delFlag":
                        return obj.equals(DelFlagEnum.DELETE.getStatus()) ? "Delete" : "Valid";
                }
            }
            return obj.toString();
        }
    }
}