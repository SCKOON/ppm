package com.ppms.creditupdaterecQuery.dao.impl;

import com.ppms.creditupdaterecQuery.dao.CreditUpdateRecDao;
import com.ppms.entity.SmsRecEntity;
import com.ppms.utils.DataReturn;
import com.ppms.vo.CreditURecResultVo;
import com.ppms.vo.SmsRecExVo;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.jeecgframework.core.common.dao.impl.GenericBaseCommonDao;
import org.jeecgframework.core.util.StringUtil;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.stereotype.Repository;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
@Repository
public class CreditUpdateRecDaoImp extends GenericBaseCommonDao implements CreditUpdateRecDao{

    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    @Override
    public DataReturn getAllEntities(CreditURecResultVo resultVo, int page, int rows, HttpServletRequest request) throws ParseException{


      //  StringBuilder hql = new StringBuilder("select b.accNo,m.meterId,b.curBal,b.updateFlag,b.updateTime,b.ctlNo,case when b.smsNo < '0' then NULL else b.smsNo end,b.lastBal from  BalanceRecordEntity as b,MeterInfoEntity as m where b.accNo = m.accNo  ");
        StringBuilder sql = new StringBuilder("SELECT b.acc_no,m.meter_id,b.cur_bal,b.update_flag,b.update_time,b.ctl_no,case when b.sms_no < '0' then NULL when b.sms_no is null then NULL else b.sms_no end as sms_no,b.last_bal FROM A_BALANCE_REC b,A_METER_INFO m where b.acc_no = m.acc_no  ");

        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
         
        String accNo = request.getParameter("accNo");
        String meterId= request.getParameter("meterId");
        String updateFlag = request.getParameter("updateFlag");
        String date_begin = request.getParameter("updateTime_begin");
        String date_end = request.getParameter("updateTime_end");


        if(!StringUtil.isEmpty(accNo)){
            condition.append(" and b.acc_no = ? ");
            params.add(accNo);
        }

        if(!StringUtil.isEmpty(meterId)){
            condition.append(" and m.meter_id = ? ");
            params.add(meterId);
        }

        if(!StringUtil.isEmpty(updateFlag)){
            condition.append(" and b.update_flag = ? ");
            params.add(updateFlag);
        }

        if(!StringUtil.isEmpty(date_begin)){
            condition.append(" and b.update_time >= ? ");
            params.add(sdf.parse(date_begin));
        }

        if(!StringUtil.isEmpty(date_end)){
            condition.append(" and b.update_time <= ? ");
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(sdf.parse(date_end));
            calendar.add(Calendar.DAY_OF_MONTH,1);
            params.add(calendar.getTime());
        }
        
        String sqlQuery = sql.append(condition.toString()).toString();
        SQLQuery q = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }

        List listSize = q.list();

        q.setFirstResult((page - 1) * rows).setMaxResults(rows);
        List list = q.list();


        List<CreditURecResultVo> resultVos = new ArrayList<>();
        DecimalFormat df = new DecimalFormat("0.00");
 
        for(int i=0; i < list.size(); i++){
            Object[] objects = (Object[]) list.get(i);
            CreditURecResultVo resultVo1 = new CreditURecResultVo();
            resultVo1.setAccNo((String) objects[0]);
            resultVo1.setMeterId((String) objects[1]);
            //resultVo1.setCurBal((BigDecimal) objects[2]);
            if (objects[2] != null) {
                BigDecimal big2 = ((BigDecimal) objects[2]).setScale(2, BigDecimal.ROUND_HALF_UP);
                double db2 = big2.doubleValue();
                String format = df.format(db2);
                BigDecimal bigbal = new BigDecimal(format);
                resultVo1.setCurBal(bigbal);
            }
            resultVo1.setUpdateFlag((String) objects[3]);
            resultVo1.setUpdateTime((Date) objects[4]);
            resultVo1.setCtlNo((String) objects[5]);
            resultVo1.setSmsNo((String) objects[6]);
            //resultVo1.setLastBal((BigDecimal) objects[7]);
            if (objects[7] != null) {
                BigDecimal big7 = ((BigDecimal) objects[7]).setScale(2, BigDecimal.ROUND_HALF_UP);
                double db7 = big7.doubleValue();
                String format = df.format(db7);
                BigDecimal bigbal = new BigDecimal(format);
                resultVo1.setLastBal(bigbal);
            }

            resultVos.add(resultVo1);
        }
        int count = listSize.size();
        DataReturn data = new DataReturn();
        data.setRows(resultVos);
        data.setTotal(count);

        return data;
    }


    @Override
    public DataReturn getSmsAllEntities(SmsRecExVo resultVo, int page, int rows, HttpServletRequest request) throws ParseException{

        StringBuilder hql = new StringBuilder("from SmsRecEntity where 1=1 ");
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();

        String smsNo = resultVo.getSmsNo();
        if(oConvertUtils.isNotEmpty(smsNo)&&smsNo.contains(",")){
            smsNo = smsNo.substring(0,smsNo.length()-1);
        }


        if(!StringUtil.isEmpty(smsNo)){
            condition.append(" and id = ? ");
            params.add(Integer.parseInt(smsNo));
        }

        System.out.println("smsNo:"+smsNo);

        String hqlQuery = hql.append(condition.toString()).toString();

        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        q.setFirstResult((page-1)*rows).setMaxResults(rows);
        int count = this.findHql(hqlQuery,params.toArray()).size();
        List<SmsRecEntity> SmsRecEntity = q.list();
        DataReturn data = new DataReturn();
        data.setRows(SmsRecEntity);
        data.setTotal(count);
        return data;
    }


}
