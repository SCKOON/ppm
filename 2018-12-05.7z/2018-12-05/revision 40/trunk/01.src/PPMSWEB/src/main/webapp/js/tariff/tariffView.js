/**
 * 更新事件打开窗口
 * @param title 编辑框标题
 * @param addurl//目标页面地址
 * @param id//主键字段
 */
function update(title, url, id, width, height, isRestful) {
    gridname = id;
    var rowsData = $('#' + id).datagrid('getSelections');
    if (!rowsData || rowsData.length == 0) {
        alertTip('Please select edit item');
        return;
    }
    if (rowsData.length > 1) {
        alertTip('Please one item to edit');
        return;
    }
    var begin = rowsData[0].startTime;
    var end = rowsData[0].endTime;
    if(begin != null && end!=null && begin != "" && end != ""){
        var beginTime = new Date(begin.replace(/-/g, '/'));
        var endTime = new Date(end.replace(/-/g, '/'));
        var now = new Date();
        var currentYear = now.getFullYear();
        var currentMonth = now.getMonth()+1;
        var currentDate = now.getDate();
        var currentTime = new Date((currentYear+'-'+currentMonth+'-'+currentDate).replace(/-/g, '/'));

        if(endTime.getTime() <= currentTime.getTime() || beginTime.getTime() <= currentTime.getTime()){
            alertTip("No permit to update the past tariff!");
            return false;
        }
    }
    url += '&id=' + rowsData[0].id;
    createwindow(title, url, width, height);
}

function deleteDialog(id) {
    //提示框
    $.messager.confirm("Message", "Comfirm to delete this tariff？", function (r) {
        if (r) {
            var url = "tariffController.do?doDel&id=" + id;
            $.ajax({
                url: url,
                type: "get",
                dataType: "json",
                success: function (data) {
                    top.alertTip(data.msg);
                    if (data.success) {
                        $("#tariffList").datagrid('reload');
                    }
                }
            })
        }
    });
}