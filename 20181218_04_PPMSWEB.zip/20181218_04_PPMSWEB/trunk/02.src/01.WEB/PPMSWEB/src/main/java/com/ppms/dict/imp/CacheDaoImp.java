package com.ppms.dict.imp;

import com.ppms.dict.CacheDao;
import com.ppms.entity.*;
import com.ppms.utils.JSONUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.jeecgframework.core.common.dao.impl.CommonDao;
import org.jeecgframework.core.common.dao.impl.GenericBaseCommonDao;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.web.system.pojo.base.TSFunction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.text.SimpleDateFormat;
import java.util.*;

@Repository
public class CacheDaoImp extends GenericBaseCommonDao implements CacheDao {

    private static final Logger LOGGER = Logger.getLogger(com.ppms.dict.imp.CacheDaoImp.class);

    @Autowired
    private CommonDao commonDao;

    @Override
    public Map<String, DataDictGroupTypeDetail> getDataTypeByKey(String key) {
        Map<String, DataDictGroupTypeDetail> map = null;
        if (StringUtils.isEmpty(key)) return null;

        StringBuilder hql = new StringBuilder(" select * from v_type_group_detail where 1=1 ");
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        if (key != null && !"".equals(key)) {
            condition.append(" and typegroupname = ? ");
            params.add(key);
        }
        String hqlQuery = hql.append(condition).toString();
        Query q = commonDao.getSession().createSQLQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List list = q.list();
        if (list != null && list.size() > 0) {
            map = new HashMap();
            for (int i = 0; i < list.size(); i++) {
                DataDictGroupTypeDetail typeDetail = new DataDictGroupTypeDetail();
                Object[] objects = (Object[]) list.get(i);
                int j = 0;
                typeDetail.setGroupId((String) objects[j++]);
                typeDetail.setTypecode((String) objects[j++]);
                typeDetail.setTypegroupname((String) objects[j++]);
                j++;
                typeDetail.setTypeId((String) objects[j++]);
                typeDetail.setTypecode((String) objects[j++]);
                typeDetail.setTypename((String) objects[j++]);
                typeDetail.setShowName((String) objects[j++]);
                map.put(typeDetail.getTypename(), typeDetail);
            }
        }

        return map;
    }

    @Override
    public DataDictGroupTypeDetail getDataTypeByMapKey(String key, String mapKey) {
        if (StringUtils.isEmpty(key) || StringUtils.isEmpty(mapKey)) return null;
        DataDictGroupTypeDetail detail = new DataDictGroupTypeDetail();
        StringBuilder hql = new StringBuilder(" select * from v_type_group_detail where 1=1 ");
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        if (key != null && !"".equals(key)) {
            condition.append(" and typegroupname = ? ");
            params.add(key);
        }
        if (mapKey != null && !"".equals(mapKey)) {
            condition.append(" and typename = ? ");
            params.add(mapKey);
        }
        String hqlQuery = hql.append(condition).toString();
        Query q = commonDao.getSession().createSQLQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List list = q.list();
        if (list != null && list.size() > 0) {
            Object[] objects = (Object[]) list.get(0);
            int j = 0;
            detail.setGroupId((String) objects[j++]);
            detail.setTypecode((String) objects[j++]);
            detail.setTypegroupname((String) objects[j++]);
            try {
                Object o = objects[j++];
                if (oConvertUtils.isNotEmpty(o) && o instanceof String) {
                    detail.setCreateDate(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse((String) o));
                }
            } catch (Exception e) {
                LOGGER.error(e);
            }
            detail.setTypeId((String) objects[j++]);
            detail.setTypecode((String) objects[j++]);
            detail.setTypename((String) objects[j++]);
            detail.setShowName((String) objects[j++]);
            LOGGER.info("To load system parameter, GroupKey:[" + key + "], MapKey:[" + mapKey + "],value:[" + JSONUtils.beanToJson(detail) + "] s successful.");
        }
        return detail;
    }

    @Override
    public MessageEntity getSmsTemplate(String smsType) {
        MessageEntity smsTemplate = null;
        StringBuffer sb = new StringBuffer();
        List<Object> list = new ArrayList<Object>();

        if (smsTemplate == null) {
            String hql = "from MessageEntity where 1=1";
            sb.append(hql);

            if (smsType != null && !"".equals(smsType)) {
                sb.append(" and smsType = ? ");
                list.add(smsType);
            }

            Query q = commonDao.getSession().createQuery(sb.toString());
            if (list != null && list.size() > 0) {
                for (int i = 0; i < list.size(); i++) {
                    q.setParameter(i, list.get(i));
                }
            }
            List<MessageEntity> resultList = q.list();
            if (resultList != null && resultList.size() > 0) {
                smsTemplate = resultList.get(0);
            }
            LOGGER.info("To load sms information from MS SQL, keys:[" + smsType + "],value:[ " + JSONUtils.beanToJson(smsTemplate) + "] is successful.");
        }
        return smsTemplate;
    }

    /**
     * @param roleCode
     * @return
     * @description 从redis缓存查找，如果查找不到则从数据库查找，并将查询结果放入redis
     */
    @Override
    public Map<String, Object> getAllFunctionByRole(String roleCode) {
        Map<String, Object> loginActionlist = new HashMap<String, Object>();
        if (oConvertUtils.isNotEmpty(roleCode)) {
            StringBuilder hqlsb1 = new StringBuilder("select distinct f from TSFunction f,TSRoleFunction rf ").append("where rf.TSFunction.id=f.id and rf.TSRole.roleCode=? ");
            List<TSFunction> list1 = super.findHql(hqlsb1.toString(), roleCode);
            for (TSFunction function : list1) {
                try {
                    loginActionlist.put(function.getId(), function.clone());
                } catch (CloneNotSupportedException e) {
                    LOGGER.error(e);
                }
            }
            //清空变量，降低内存使用
            list1.clear();
        }

        return loginActionlist;
    }

    @Override
    public TariffInfoEntity getCurrentTariff(String tariffCode) {
        Date date = new Date();

//        String hql = "from TariffInfoEntity t where t.code=? and t.startTime<=? and t.endTime>=?";//20181218测试修改
        String hql = "from TariffInfoEntity t where t.code=? and t.startTime<=?";//20181218现场测试修改
        Query query = super.getSession().createQuery(hql)
                .setParameter(0, tariffCode)
                .setParameter(1, date);
//                .setParameter(2, date);
        List<TariffInfoEntity> list = query.list();
        if (list != null && list.size() > 0)
            return list.get(0);
        return null;
    }

    @Override
    public GSTEntity getCurrentGst(String gstCode) {
        Date date = new Date();

//        String hql = "from GSTEntity t where t.code=? and t.startTime<=? and t.endTime>=?";//20181218现场测试修改
        String hql = "from GSTEntity t where t.code=? and t.startTime<=?";//20181218现场测试修改
        Query query = super.getSession().createQuery(hql)
                .setParameter(0, gstCode)
                .setParameter(1, date);
//                .setParameter(2, date);
        List<GSTEntity> list = query.list();
        if (list != null && list.size() > 0)
            return list.get(0);
        return null;
    }

    @Override
    public Map<String, String> queryForOptions(String groupKey, String typeName) {
        Map<String, String> resultMap = new HashMap();
        if (oConvertUtils.isNotEmpty(groupKey)) {
            if(oConvertUtils.isNotEmpty(typeName)){
                DataDictGroupTypeDetail detail = this.getDataTypeByMapKey(groupKey,typeName);
                if(detail!=null){
                    resultMap.put(detail.getShowName(),detail.getTypecode());
                }
            }else{
                Map<String,DataDictGroupTypeDetail> map = this.getDataTypeByKey(groupKey);
                if(map!=null&&map.size()>0){
                    Collection collection = map.values();
                    Iterator iterator = collection.iterator();
                    while(iterator.hasNext()){
                        DataDictGroupTypeDetail detail = (DataDictGroupTypeDetail)iterator.next();
                        resultMap.put(detail.getTypecode(),detail.getShowName());
                    }
                }
            }
        }
        return resultMap;
    }
}
