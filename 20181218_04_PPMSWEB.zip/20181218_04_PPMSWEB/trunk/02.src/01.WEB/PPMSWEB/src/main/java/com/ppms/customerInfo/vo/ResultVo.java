package com.ppms.customerInfo.vo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by yadongliang on 2018/5/8 0008.
 */
public class ResultVo {
    private String id;
    private String accNo;
    private String name;
    private String nric;
    private String accountStatus;
    private Date openDate;
    private BigDecimal balance;
    private Date updateTime;
    private String meterId;
    private String premiseType;
    private Date applyTime;
    private String closingStatus;
    private String readingType;
    private String operationStatus;

    private Date sheduledActivationDate;
    private String telephoneNumber;
    private String address;

    private String z3Number;
    private Date modeChangeTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAccNo() {
        return accNo;
    }

    public void setAccNo(String accNo) {
        this.accNo = accNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNric() {
        return nric;
    }

    public void setNric(String nric) {
        this.nric = nric;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public Date getOpenDate() {
        return openDate;
    }

    public void setOpenDate(Date openDate) {
        this.openDate = openDate;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getMeterId() {
        return meterId;
    }

    public void setMeterId(String meterId) {
        this.meterId = meterId;
    }

    public String getPremiseType() {
        return premiseType;
    }

    public void setPremiseType(String premiseType) {
        this.premiseType = premiseType;
    }

    public Date getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }

    public String getClosingStatus() {
        return closingStatus;
    }

    public void setClosingStatus(String closingStatus) {
        this.closingStatus = closingStatus;
    }

    public String getReadingType() {
        return readingType;
    }

    public void setReadingType(String readingType) {
        this.readingType = readingType;
    }

    public String getOperationStatus() {
        return operationStatus;
    }

    public void setOperationStatus(String operationStatus) {
        this.operationStatus = operationStatus;
    }

    public Date getSheduledActivationDate() {
        return sheduledActivationDate;
    }

    public void setSheduledActivationDate(Date sheduledActivationDate) {
        this.sheduledActivationDate = sheduledActivationDate;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZ3Number() {
        return z3Number;
    }

    public void setZ3Number(String z3Number) {
        this.z3Number = z3Number;
    }

    public Date getModeChangeTime() {
        return modeChangeTime;
    }

    public void setModeChangeTime(Date modeChangeTime) {
        this.modeChangeTime = modeChangeTime;
    }
}
