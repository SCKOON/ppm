package com.ppms.customerInfo.dao.impl;

import com.ppms.customerInfo.dao.CustomerManageDao;
import com.ppms.customerInfo.vo.ClosingDetailVo;
import com.ppms.entity.*;
import com.ppms.customerInfo.vo.ResultVo;
import com.ppms.utils.DataReturn;
import com.ppms.utils.PersDateUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.jeecgframework.core.common.dao.impl.GenericBaseCommonDao;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by yadongliang on 2018/5/8 0008.
 */
@Repository
@Transactional(isolation = Isolation.REPEATABLE_READ, rollbackForClassName = {"Exception.class"})
public class CustomerManageDaoImpl extends GenericBaseCommonDao implements CustomerManageDao {

    private static final Logger logger = Logger.getLogger(CustomerManageDaoImpl.class);

    @Override
    public DataReturn getAllEntities(ResultVo resultVo, int page, int rows, HttpServletRequest request) {
        StringBuilder hql = new StringBuilder("select c.accNo,c.name,c.nric,c.sheduledActivationDate,c.accountStatus,m.meterId from CustomerInfoEntity as c,MeterInfoEntity as m where c.accNo=m.accNo");
        StringBuilder condition = new StringBuilder("");
        ArrayList params = new ArrayList();

        String accNo = resultVo.getAccNo();
        if (accNo != null && !"".equals(accNo)) {
            condition.append(" and c.accNo = ? ");
            params.add(accNo);
        }

        String name = resultVo.getName();
        if (name != null && !"".equals(name)) {
            condition.append(" and c.name like ? ");
            params.add("%" + name + "%");
        }

        String nric = resultVo.getNric();
        if (nric != null && !"".equals(nric)) {
            condition.append(" and c.nric = ? ");
            params.add(nric);
        }

        Date sheduledActivationDate = resultVo.getSheduledActivationDate();
        if (sheduledActivationDate != null) {
            condition.append(" and c.sheduledActivationDate = ? ");
            params.add(nric);
        }

        String accountStatus = resultVo.getAccountStatus();
        if (accountStatus != null && !"".equals(accountStatus)) {
            condition.append(" and c.accountStatus = ? ");
            params.add(nric);
        }

        String meterId = resultVo.getMeterId();
        if (meterId != null && !"".equals(meterId)) {
            condition.append(" and m.meterId = ? ");
            params.add(meterId);
        }

        String hqlQuery = hql.append(condition.toString()).toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }

        q.setFirstResult((page - 1) * rows).setMaxResults(rows);
        int count = this.findHql(hqlQuery, params.toArray()).size();
        List list = q.list();

        List<ResultVo> resultVos = new ArrayList<>();

        if(list!=null&&list.size()>0){
            for(int i=0; i < list.size(); i++){
                Object[] objects = (Object[]) list.get(i);
                ResultVo resultVo1 = new ResultVo();
                resultVo1.setAccNo((String) objects[0]);
                resultVo1.setName((String) objects[1]);
                resultVo1.setNric((String) objects[2]);
                resultVo1.setSheduledActivationDate((Date) objects[3]);
                resultVo1.setAccountStatus((String) objects[4]);
                resultVo1.setMeterId((String) objects[5]);
                resultVos.add(resultVo1);
            }
        }

        DataReturn data = new DataReturn();
        data.setRows(resultVos);
        data.setTotal(count);

        return data;
    }

    //查询客户信息-销户申请页面
    @Override
    public DataReturn getCustomerInfo(int page, int rows, HttpServletRequest request) {
        StringBuilder sql = new StringBuilder(
            " SELECT " +
            " c.acc_no, " +
            " c.name, " +
            " c.nric, " +
            " c.account_status, " +
            " c.open_date, " +
            " m.meter_id, " +
            " a.BALANCE, " +
            " a.UPDATE_TIME, " +
            " ac.apply_time, " +
            " ac.closing_status, " +
            " ac.reading_type, " +
            " ac.operation_status " +
            " FROM " +
            " A_CUSTOMER_INFO c " +
            " LEFT JOIN A_METER_INFO m ON c.acc_no = m.acc_no " +
            " LEFT JOIN A_ACCT_BAL a ON c.acc_no = a.ACC_NO " +
            " LEFT JOIN A_CLOSING_REC ac ON c.acc_no = ac.acc_no " +
            " WHERE 1 = 1 " +
            " and m.meter_status = '03' "//03:正常运行，指成功激活
        );

        StringBuilder condition = new StringBuilder();
        List params = new ArrayList();

        String accNo = request.getParameter("accNo");
        if (accNo != null && !"".equals(accNo)){
            condition.append(" and c.acc_no like ? ");
            params.add("%" + accNo + "%");
        }

        /*String nric = request.getParameter("nric");
        if (nric != null && !"".equals(nric)){
            condition.append(" and c.nric = ? ");
            params.add(nric);
        }*/

        String accountStatus = request.getParameter("accountStatus");
        if (accountStatus != null && !"".equals(accountStatus)){
            condition.append(" and c.account_status = ? ");
            params.add(accountStatus);
        }

        String sqlQuery = sql.append(condition.toString()).toString();

        SQLQuery q = getSession().createSQLQuery(sqlQuery);

        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List objectList = q.list();
        int count = 0;
        if (objectList!=null&&objectList.size()>0){
            count = objectList.size();
        }
        q.setFirstResult((page - 1)*rows);
        q.setMaxResults(rows).list();
        List list = q.list();
        List<ResultVo> resultVoList = new ArrayList<>();
        DecimalFormat df = new DecimalFormat("0.00");
        if(list!=null&&list.size()>0){
            for (int i = 0; i < list.size(); i++){
                ResultVo resultVo = new ResultVo();
                Object[] objects = (Object[]) list.get(i);
                resultVo.setAccNo(objects[0]==null?"--":objects[0].toString());
                resultVo.setName(objects[1]==null?"--":objects[1].toString());
                resultVo.setNric(objects[2]==null?"--":objects[2].toString());
                resultVo.setAccountStatus(objects[3]==null?"--":objects[3].toString());
                resultVo.setOpenDate((Date) objects[4]);
                resultVo.setMeterId(objects[5]==null?"--":objects[5].toString());
                if(objects[6]!=null){
                    BigDecimal big3 = ((BigDecimal) objects[6]).setScale(2, BigDecimal.ROUND_DOWN);
                    double db3 = big3.doubleValue();
                    String format = df.format(db3);
                    BigDecimal bigbal = new BigDecimal(format);
                    resultVo.setBalance(bigbal);
                }else{
                    resultVo.setBalance(new BigDecimal("0"));
                }
                resultVo.setUpdateTime((Date) objects[7]);
                resultVo.setApplyTime((Date) objects[8]);
                resultVo.setClosingStatus(objects[9]==null?"--":objects[9].toString());
                resultVo.setReadingType(objects[10]==null?"--":objects[10].toString());
                resultVo.setOperationStatus(objects[11]==null?"--":objects[11].toString());
                resultVo.setId(objects[0]==null?"--":objects[0].toString());//设置id 前台datagrid操作按钮用于获取选中行
                resultVoList.add(resultVo);
            }
        }

        DataReturn dataReturn = new DataReturn();
        dataReturn.setRows(resultVoList);
        dataReturn.setTotal(count);

        return dataReturn;
    }

    //销户申请-提交申请记录
    @Override
    public void goApplyClosing(HttpServletRequest request) {
        //接收前台数据
        String accNo = request.getParameter("accNo");
        String name = request.getParameter("name");
        String meterId = request.getParameter("meterId");

        //提交申请记录额外数据
        String sDate = PersDateUtils.getPatternDate(PersDateUtils.FORMAT_FULL_DATE_TIME, new Date());
        Date currentTime = PersDateUtils.str2Date(sDate, PersDateUtils.getSdf(PersDateUtils.FORMAT_FULL_DATE_TIME));
        String readingType = "01";//ODR
        String closingStatus = "01";//applied
        String operationStatus = "01";//创建

        AClosingRecordEntity aClosingRecordEntity = new AClosingRecordEntity();
        aClosingRecordEntity.setAccNo(accNo);
        aClosingRecordEntity.setAccName(name);
        aClosingRecordEntity.setMeterId(meterId);
        aClosingRecordEntity.setApplyTime(currentTime);
        aClosingRecordEntity.setReadingType(readingType);
        aClosingRecordEntity.setClosingStatus(closingStatus);
        aClosingRecordEntity.setOperationStatus(operationStatus);
        aClosingRecordEntity.setUpdateTime(currentTime);

        save(aClosingRecordEntity);

    }

    //销户申请记录查询
    @Override
    public AClosingRecordEntity getClosingRecord(String accNo) {
        StringBuilder hql = new StringBuilder(" from AClosingRecordEntity a where a.accNo = ? ");
        List params = new ArrayList();
        if (!"".equals(accNo)) {
            params.add(accNo);
        }
        String hqlQuery = hql.toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List<AClosingRecordEntity> list = q.list();
        AClosingRecordEntity entity = null;
        if(list != null && list.size() > 0){
            entity = list.get(0);
        }

        return entity;
    }

    //销户详情查询
    @Override
    public ClosingDetailVo getClosingDetail(HttpServletRequest request) {

        StringBuilder sql = new StringBuilder(
                " SELECT " +
                " a.acc_no, " +
                " a.meter_id, " +
                " a.last_reading, " +
                " a.last_reading_time, " +
                " p.CONSUMPTION, " +
                " p.GST, " +
                " p.CHARGE, " +
                " p.BILLING, " +
                " b.BALANCE " +
                " FROM " +
                " A_CLOSING_REC a " +
                " LEFT JOIN PROCESS_CHARGE_DATA p ON a.PRO_ID = p.ID " +
                " LEFT JOIN A_ACCT_BAL b ON a.acc_no = b.ACC_NO " +
                " WHERE " +
                " 1=1 " +
                " and a.acc_no = :accNo "
        );

        Map<String, String> map = new HashMap();
        String accNo = request.getParameter("accNo");
        if(oConvertUtils.isNotEmpty(accNo)){
            map.put("accNo",accNo);
        }

        Query query = getSession().createSQLQuery(sql.toString());
        query.setProperties(map);
        List list = query.list();
        ClosingDetailVo vo = new ClosingDetailVo();
        if(list!=null&&list.size()>0){
            Object[] o = (Object[]) list.get(0);
            vo.setAccNo((String) o[0]);
            vo.setMeterId((String) o[1]);
            vo.setFinalReading((BigDecimal) o[2]);
            vo.setFinalReadingTime((Date) o[3]);
            vo.setConsumption((BigDecimal) o[4]);
            vo.setGst((BigDecimal) o[5]);
            vo.setCharges((BigDecimal) o[6]);
            vo.setBilling((BigDecimal) o[7]);
            vo.setFinalCreditBal(((BigDecimal) o[8]).setScale(2, BigDecimal.ROUND_DOWN));
        }
        return vo;
    }

    //获取holiday列表
    @Override
    public List getHolidayList() {
        StringBuilder hql = new StringBuilder(" from HolidayInfoEntity h where h.startTime <= h.endTime ");
        String hqlQuery = hql.toString();
        Query query = getSession().createQuery(hqlQuery);
        List<HolidayInfoEntity> list = query.list();
        return list;
    }

    @Override
    public CustomerInfoEntity selectByPrimaryKey(String accountNo) {
        return (CustomerInfoEntity)super.get(CustomerInfoEntity.class,accountNo);
    }

    @Override
    public void update(CustomerInfoEntity customerInfo) {
        super.updateEntitie(customerInfo);
    }

    //查询tariff信息, 在用,未删除,类别
    @Override
    public List getTariffInfo(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        StringBuilder sql1 = new StringBuilder(
                " SELECT " +
                " a.code, " +
                " a.kwh_rate, " +
                " a.start_time, " +
                " a.end_time " +
                " FROM " +
                " TARIFF_INFO a " +
                " INNER JOIN ( " +
                " SELECT " +
                " code, " +
                "MAX (start_time) 'start_time' " +
                " FROM " +
                " TARIFF_INFO " +
                " WHERE " +
                " 1=1 "
        );
        StringBuilder sql2 = new StringBuilder(
                " GROUP BY " +
                " code " +
                " ) b ON a.code = b.code " +
                " AND a.start_time = b.start_time "
        );

        StringBuilder sql3 = new StringBuilder(
                " ORDER BY " +
                " a.code "
        );

        StringBuilder condition1 = new StringBuilder();
        StringBuilder condition2 = new StringBuilder();
        List params = new ArrayList();

        if(date!=null){
            condition1.append(" AND CONVERT(VARCHAR(10),start_time,121) <=  ? ");
            condition2.append(" AND CONVERT(VARCHAR(10),b.start_time,121) <=  ? ");
            params.add(sdf.format(date));
            params.add(sdf.format(date));
        }

        String sqlQuery = sql1.append(condition1).append(sql2).append(condition2).append(sql3).toString();
        Query q = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }

        List list = q.list();

        return list;
    }

    //查询gst信息code和rate
    @Override
    public List getGstInfo(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        StringBuilder sql1 = new StringBuilder(
                " SELECT " +
                " a.code, " +
                " a.rate, " +
                " a.start_time, " +
                " a.end_time " +
                " FROM " +
                " GST_INFO a " +
                " INNER JOIN ( " +
                " SELECT " +
                " code, " +
                "MAX (start_time) 'start_time' " +
                " FROM " +
                " GST_INFO " +
                " WHERE " +
                " 1=1 "
        );
        StringBuilder sql2 = new StringBuilder(
                " GROUP BY " +
                " code " +
                " ) b ON a.code = b.code " +
                " AND a.start_time = b.start_time "
        );

        StringBuilder sql3 = new StringBuilder(
                " ORDER BY " +
                " a.code "
        );

        StringBuilder condition1 = new StringBuilder();
        StringBuilder condition2 = new StringBuilder();
        List params = new ArrayList();

        if(date!=null){
            condition1.append(" AND CONVERT(VARCHAR(10),start_time,121) <=  ? ");
            condition2.append(" AND CONVERT(VARCHAR(10),b.start_time,121) <=  ? ");
            params.add(sdf.format(date));
            params.add(sdf.format(date));
        }

        String sqlQuery = sql1.append(condition1).append(sql2).append(condition2).append(sql3).toString();
        Query q = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }

        List list = q.list();

        return list;
    }

    @Override
    public void queryCustomerInfoForActivation(HttpServletRequest request, DataGrid dataGrid, String accountType) {
        StringBuilder sql = new StringBuilder(
                " SELECT " +
                        " c.acc_no, " +
                        " c.sheduled_activation_date, " +
                        " c.account_status, " +
                        " m.meter_id, " +
                        " c.address, " +
                        " m.z3_notif_no, " +
                        " m.mode_chg_time " +
                        " FROM " +
                        " A_CUSTOMER_INFO c " +
                        " LEFT JOIN A_METER_INFO m ON c.acc_no = m.acc_no " +
                        " WHERE m.meter_status = '02' "
        );

        StringBuilder condition = new StringBuilder();
        List params = new ArrayList();

        String accNo = request.getParameter("accNo");
        String accountStatus = request.getParameter("accountStatus");

        if(oConvertUtils.isNotEmpty(accNo)){
            condition.append(" and c.acc_no like ? ");
            params.add("%" + accNo + "%");
        }

        if(oConvertUtils.isNotEmpty(accountStatus)){
            condition.append(" and c.account_status = ? ");
            params.add(accountStatus);
        }

        if(oConvertUtils.isNotEmpty(accountType)){
            condition.append(" and c.type = ? ");
            params.add(accountType);
        }

        String sqlQuery = sql.append(condition.toString()).toString();
        Query query = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                query.setParameter(i, params.get(i));
            }
        }
        List list = query.list();
        super.paginateDataGrid(list, dataGrid, query);
    }
}
