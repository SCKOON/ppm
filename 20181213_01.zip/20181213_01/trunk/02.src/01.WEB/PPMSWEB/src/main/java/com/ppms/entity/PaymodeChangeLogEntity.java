package com.ppms.entity;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.util.Date;

/**   
 * @Title: Entity
 * @Description: PaymodeChangeLog
 * @author zhangdaihao
 * @date 2018-12-13 18:08:44
 * @version V1.0   
 *
 */
@Entity
@Table(name = "PAYMODE_CHG_LOG", schema = "")
@DynamicUpdate(true)
@DynamicInsert(true)
@SuppressWarnings("serial")
public class PaymodeChangeLogEntity implements java.io.Serializable {
	/**sp_topup_rec id*/
	private String txnId;
	/**batchNo*/
	private String batchNo;
	/**accNo*/
	private String accNo;
	/**oldPayMode*/
	private String oldPayMode;
	/**01	Cash
   02	Credit Card
   03	Debit
   04	Nets
   05	Cheque
   06	Voucher*/
	private String newPayMode;
	/**cashierId*/
	private String cashierId;
	/**operId*/
	private String operId;
	/**operTime*/
	private Date operTime;
	/**remark*/
	private String remark;
	/**id*/
	private Integer id;

	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  sp_topup_rec id
	 */
	@Column(name ="TXN_ID",nullable=true,precision=32,length=32)
	public String getTxnId(){
		return this.txnId;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  sp_topup_rec id
	 */
	public void setTxnId(String txnId){
		this.txnId = txnId;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  batchNo
	 */
	@Column(name ="BATCH_NO",nullable=true,precision=10,length=10)
	public String getBatchNo(){
		return this.batchNo;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  batchNo
	 */
	public void setBatchNo(String batchNo){
		this.batchNo = batchNo;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  accNo
	 */
	@Column(name ="ACC_NO",nullable=true,precision=12,length=12)
	public String getAccNo(){
		return this.accNo;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  accNo
	 */
	public void setAccNo(String accNo){
		this.accNo = accNo;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  oldPayMode
	 */
	@Column(name ="OLD_PAY_MODE",nullable=true,precision=2,length=2)
	public String getOldPayMode(){
		return this.oldPayMode;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  oldPayMode
	 */
	public void setOldPayMode(String oldPayMode){
		this.oldPayMode = oldPayMode;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  01	Cash
   02	Credit Card
   03	Debit
   04	Nets
   05	Cheque
   06	Voucher
	 */
	@Column(name ="NEW_PAY_MODE",nullable=true,precision=2,length=2)
	public String getNewPayMode(){
		return this.newPayMode;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  01	Cash
   02	Credit Card
   03	Debit
   04	Nets
   05	Cheque
   06	Voucher
	 */
	public void setNewPayMode(String newPayMode){
		this.newPayMode = newPayMode;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  cashierId
	 */
	@Column(name ="CASHIER_ID",nullable=true,precision=8,length=8)
	public String getCashierId(){
		return this.cashierId;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  cashierId
	 */
	public void setCashierId(String cashierId){
		this.cashierId = cashierId;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  operId
	 */
	@Column(name ="OPER_ID",nullable=true,precision=12,length=12)
	public String getOperId(){
		return this.operId;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  operId
	 */
	public void setOperId(String operId){
		this.operId = operId;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  operTime
	 */
	@Column(name ="OPER_TIME",nullable=true,precision=23,scale=3,length=8)
	public Date getOperTime(){
		return this.operTime;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  operTime
	 */
	public void setOperTime(Date operTime){
		this.operTime = operTime;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  remark
	 */
	@Column(name ="REMARK",nullable=true,precision=128,length=128)
	public String getRemark(){
		return this.remark;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  remark
	 */
	public void setRemark(String remark){
		this.remark = remark;
	}
	/**
	 *方法: 取得java.lang.Integer
	 *@return: java.lang.Integer  id
	 */

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="ID",nullable=false,precision=10,scale=0,length=4)
	public Integer getId(){
		return this.id;
	}

	/**
	 *方法: 设置java.lang.Integer
	 *@param: java.lang.Integer  id
	 */
	public void setId(Integer id){
		this.id = id;
	}
}
