package com.ppms.dayendRecon.dao.impl;

import com.ppms.codeAndNameChange.dao.ChangeDaoI;
import com.ppms.dayendRecon.dao.DayendReconDao;
import com.ppms.entity.*;
import com.ppms.ldapLogin.util.ResourceUtils;
import com.ppms.utils.PersDateUtils;
import com.ppms.vo.DayendReconVo;
import com.ppms.vo.SpTopupRecordVo;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.jeecgframework.core.common.dao.impl.GenericBaseCommonDao;
import org.jeecgframework.core.util.StringUtil;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by yadongliang on 2018/5/29 0029.
 */
@Repository
public class DayendReconDaoImpl extends GenericBaseCommonDao implements DayendReconDao {

    @Autowired
    private ChangeDaoI changeDaoI;

    /**
     * CARDFEE
     */
    @Override
    public Map<String, Object> getTotalCardFeeInfo(HttpServletRequest request, HttpServletResponse response, int page, int rows, String curLoginName) {

        StringBuilder sql = new StringBuilder(
                " SELECT " +
                        " sp.pay_mode, " +
                        " COUNT (sp.topup_amt) AS cardFeeTopupCount, " +
                        " SUM (sp.topup_amt) AS cardFeeTopupAmt " +
                        " FROM " +
                        " SP_TOPUP_REC sp " +
                        " WHERE " +
                        " sp.txn_status = '06' " +
                        " AND sp.recon_status = '01' "

        );
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        //查询条件
        //time
        String dayendDate = request.getParameter("dayendDate");
        if(!StringUtil.isEmpty(dayendDate)){
            condition.append(" AND DateDiff(dd, sp.txn_date, ? ) = 0 ");
            params.add(dayendDate);
        }
        //counter
        String terminal = request.getParameter("terminal");
        if(!StringUtil.isEmpty(terminal)){
            condition.append(" AND sp.tmnl_code = ? ");
            params.add(terminal);
        }
        //center
        String counter = request.getParameter("counter");
        if(!StringUtil.isEmpty(counter)){
            condition.append(" AND sp.counter_id = ? ");
            params.add(counter);
        }
        //curLoginName
        if(!StringUtil.isEmpty(curLoginName)){
            condition.append(" AND sp.cashier_id = ? ");
            params.add(curLoginName);
        }

        String sqlQuery = sql.append(condition.toString()).append(" GROUP BY sp.pay_mode ").toString();
        Query q = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }

        List objectList = q.list();
        int count = 0;
        if (objectList!=null&&objectList.size()>0){
            count = objectList.size();
        }

        q.setFirstResult((page - 1) * rows).setMaxResults(rows);
        List list = q.list();
        List<Map<String, Object>> mapList = new ArrayList<>();
        if(list != null && list.size() > 0){
            for (int i = 0; i < list.size(); i++) {
                DayendReconVo dayendReconVo = new DayendReconVo();
                Object[] objects = (Object[]) list.get(i);
                Map<String, Object> map = new HashMap<>();
                if(objects[0] != null){
                    String payMode = (String) objects[0];
                    if(payMode.equals("01")){
                        map.put("payMode","Cash");
                    }else if(payMode.equals("02")){
                        map.put("payMode","Credit Card");
                    }else if(payMode.equals("03")){
                        map.put("payMode","Debit");
                    }else if(payMode.equals("04")){
                        map.put("payMode","Nets");
                    }else if(payMode.equals("05")){
                        map.put("payMode","Cheque");
                    }else if(payMode.equals("06")){
                        map.put("payMode","Voucher");
                    }
                }else{
                    map.put("payMode","");
                }
                map.put("cardfeeCount",objects[1] != null ? (Integer) objects[1] : 0);
                if(oConvertUtils.isNotEmpty(objects[2])){
                    String scardfeeAmt = new BigDecimal(objects[2].toString()).setScale(2, BigDecimal.ROUND_DOWN).toString();
                    map.put("cardfeeAmt",scardfeeAmt);
                }else{
                    map.put("cardfeeAmt","NA");
                }

                mapList.add(map);

            }
        }

        Map<String, Object> returnMap = new HashMap<>();
        returnMap.put("total",count);
        returnMap.put("rows",mapList);

        return returnMap;
    }

    /**
     * TOPUP
     *
     * @param request
     * @param response
     * @param page
     * @param rows
     * @return
     */
    @Override
    public Map<String, Object> getTotalTopupInfo(HttpServletRequest request, HttpServletResponse response, int page, int rows, String curLoginName) {
        StringBuilder sql = new StringBuilder(
                " SELECT " +
                        " sp.pay_mode AS payMode, " +
                        " COUNT (sp.topup_amt) AS topupCount, " +
                        " SUM (sp.topup_amt) AS txnAmt, " +
                        " SUM (sp.prepaid_amt) AS prepaidAmt, " +
                        " SUM (sp.arrear_amt) AS arrearAmt " +
                        " FROM " +
                        " SP_TOPUP_REC sp " +
                        " WHERE " +
                        " sp.txn_status in ('01','02') " +
                        " AND sp.recon_status = '01' "

        );
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        //查询条件
        //time
        String dayendDate = request.getParameter("dayendDate");
        if(!StringUtil.isEmpty(dayendDate)){
            condition.append(" AND DateDiff(dd, sp.txn_date, ? ) = 0 ");
            params.add(dayendDate);
        }
        //counter
        String terminal = request.getParameter("terminal");
        if(!StringUtil.isEmpty(terminal)){
            condition.append(" AND sp.tmnl_code = ? ");
            params.add(terminal);
        }
        //center
        String counter = request.getParameter("counter");
        if(!StringUtil.isEmpty(counter)){
            condition.append(" AND sp.counter_id = ? ");
            params.add(counter);
        }
        //curLoginName
        if(!StringUtil.isEmpty(curLoginName)){
            condition.append(" AND sp.cashier_id = ? ");
            params.add(curLoginName);
        }

        String sqlQuery = sql.append(condition.toString()).append(" GROUP BY sp.pay_mode ").toString();
        Query q = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List objectList = q.list();
        int count = 0;
        if (objectList!=null&&objectList.size()>0){
            count = objectList.size();
        }
        q.setFirstResult((page - 1) * rows).setMaxResults(rows);
        List list = q.list();
        List<Map<String, Object>> mapList = new ArrayList<>();
        if(list != null && list.size() > 0){
            for (int i = 0; i < list.size(); i++) {
                Object[] objects = (Object[]) list.get(i);
                Map<String, Object> map = new HashMap<>();
                if(objects[0] != null){
                    String payMode = (String) objects[0];
                    if(payMode.equals("01")){
                        map.put("payMode","Cash");
                    }else if(payMode.equals("02")){
                        map.put("payMode","Credit Card");
                    }else if(payMode.equals("03")){
                        map.put("payMode","Debit");
                    }else if(payMode.equals("04")){
                        map.put("payMode","Nets");
                    }else if(payMode.equals("05")){
                        map.put("payMode","Cheque");
                    }else if(payMode.equals("06")){
                        map.put("payMode","Voucher");
                    }
                }else{
                    map.put("payMode","");
                }
                map.put("topupCount",objects[1] != null ? (Integer) objects[1] : 0);
                if(oConvertUtils.isNotEmpty(objects[2])){
                    String stxnAmt = new BigDecimal(objects[2].toString()).setScale(2, BigDecimal.ROUND_DOWN).toString();
                    map.put("txnAmt",stxnAmt);
                }else {
                    map.put("txnAmt","NA");
                }

                if(oConvertUtils.isNotEmpty(objects[3])){
                    String sprepaidAmt = new BigDecimal(objects[3].toString()).setScale(2, BigDecimal.ROUND_DOWN).toString();
                    map.put("prepaidAmt",sprepaidAmt);
                }else {
                    map.put("prepaidAmt","NA");
                }

                if(oConvertUtils.isNotEmpty(objects[4])){
                    String sarrearAmt = new BigDecimal(objects[4].toString()).setScale(2, BigDecimal.ROUND_DOWN).toString();
                    map.put("arrearAmt",sarrearAmt);
                }else {
                    map.put("arrearAmt","NA");
                }

                mapList.add(map);

            }
        }
        Map<String, Object> returnMap = new HashMap<>();
        returnMap.put("total",count);
        returnMap.put("rows",mapList);

        return returnMap;
    }

    /**
     * REVERSE
     */
    @Override
    public Map<String, Object> getTotalReverseInfo(HttpServletRequest request, HttpServletResponse response, int page, int rows, String curLoginName) {
        StringBuilder sql = new StringBuilder(
                " SELECT " +
                        " sp.pay_mode AS payMode, " +
                        " COUNT (sp.topup_amt) AS reverseCount, " +
                        " SUM (sp.topup_amt) AS reverseAmt " +
                        " FROM " +
                        " SP_TOPUP_REC sp " +
                        " WHERE " +
                        " sp.txn_status = '03' " +
                        " AND sp.recon_status = '01' "

        );
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        //查询条件
        //time
        String dayendDate = request.getParameter("dayendDate");
        if(!StringUtil.isEmpty(dayendDate)){
            condition.append(" AND DateDiff(dd, sp.txn_date, ? ) = 0 ");
            params.add(dayendDate);
        }
        //counter
        String terminal = request.getParameter("terminal");
        if(!StringUtil.isEmpty(terminal)){
            condition.append(" AND sp.tmnl_code = ? ");
            params.add(terminal);
        }
        //center
        String counter = request.getParameter("counter");
        if(!StringUtil.isEmpty(counter)){
            condition.append(" AND sp.counter_id = ? ");
            params.add(counter);
        }
        //curLoginName
        if(!StringUtil.isEmpty(curLoginName)){
            condition.append(" AND sp.cashier_id = ? ");
            params.add(curLoginName);
        }

        String sqlQuery = sql.append(condition.toString()).append(" GROUP BY sp.pay_mode ").toString();
        Query q = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List objectList = q.list();
        int count = 0;
        if (objectList!=null&&objectList.size()>0){
            count = objectList.size();
        }
        q.setFirstResult((page - 1) * rows).setMaxResults(rows);
        List list = q.list();
        List<Map<String, Object>> mapList = new ArrayList<>();
        if(list != null && list.size() > 0){
            for (int i = 0; i < list.size(); i++) {
                Object[] objects = (Object[]) list.get(i);
                Map<String, Object> map = new HashMap<>();
                if(objects[0] != null){
                    String payMode = (String) objects[0];
                    if(payMode.equals("01")){
                        map.put("payMode","Cash");
                    }else if(payMode.equals("02")){
                        map.put("payMode","Credit Card");
                    }else if(payMode.equals("03")){
                        map.put("payMode","Debit");
                    }else if(payMode.equals("04")){
                        map.put("payMode","Nets");
                    }else if(payMode.equals("05")){
                        map.put("payMode","Cheque");
                    }else if(payMode.equals("06")){
                        map.put("payMode","Voucher");
                    }
                }else{
                    map.put("payMode","");
                }
                map.put("reverseCount",objects[1] != null ? (Integer) objects[1] : 0);
                if(oConvertUtils.isNotEmpty(objects[2])){
                    String sreverseAmt = new BigDecimal(objects[2].toString()).setScale(2, BigDecimal.ROUND_DOWN).toString();
                    map.put("reverseAmt",sreverseAmt);
                }else {
                    map.put("reverseAmt","NA");
                }

                mapList.add(map);
            }
        }

        Map<String, Object> returnMap = new HashMap<>();
        returnMap.put("total",count);
        returnMap.put("rows",mapList);

        return returnMap;
    }

    /**
     * 四种交易类型汇总 all
     *
     * @param request
     * @param response
     * @param page
     * @param rows
     * @return
     */
    @Override
    public Map<String, Object> getDayendAll(HttpServletRequest request, HttpServletResponse response, int page, int rows, String curLoginName) {
        StringBuilder sql1 = new StringBuilder(
                " SELECT * from (select pay_mode,sum(topupCount) as topupCount,sum(reverseCount) as reverseCount, " +
                        " sum(cardfeeCount)as cardfeeCount,sum(txnCount)as txnCount, " +
                        " sum(topupAmt)as topupAmt,sum(arrearsAmt)as arrearsAmt,sum(reverseAmt)as reverseAmt, " +
                        " sum(cardfeeAmt)as cardfeeAmt,sum(totalAmt)as totalAmt " +
                        " from " +
                        "         ((SELECT " +
                        "                 sp.pay_mode, " +
                        "                 COUNT (CASE WHEN sp.txn_status IN ('01','02') THEN sp.topup_amt END) topupCount, " +
                        "                 COUNT (CASE WHEN sp.txn_status = '03' THEN sp.topup_amt END) reverseCount, " +
                        "                 COUNT (CASE WHEN sp.txn_status = '06' THEN sp.topup_amt END) cardfeeCount, " +
                        "                 COUNT (sp.topup_amt) txnCount, " +
                        "                 SUM (CASE WHEN sp.txn_status IN ('01','02') THEN sp.topup_amt ELSE 0 END) topupAmt, " +
                        "                 SUM (CASE WHEN sp.txn_status IN ('01','02') THEN sp.arrear_amt ELSE 0 END) arrearsAmt, " +
                        "                 SUM (CASE WHEN sp.txn_status = '03' THEN sp.topup_amt ELSE 0 END) reverseAmt, " +
                        "                 SUM (CASE WHEN sp.txn_status = '06' THEN sp.topup_amt ELSE 0 END) cardfeeAmt, " +
                        "                 SUM (sp.topup_amt) totalAmt " +
                        "                 FROM " +
                        "                 SP_TOPUP_REC sp " +
                        "                 WHERE " +
                        "                 sp.recon_status = '01' "

        );

        StringBuilder sql3 = new StringBuilder(
                " GROUP BY " +
                        " sp.pay_mode " +
                        " )) a where pay_mode in (01,02,03,04,05,06) GROUP BY pay_mode ) aa "
        );

        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        //查询条件
        //time
        String dayendDate = request.getParameter("dayendDate");
        if(!StringUtil.isEmpty(dayendDate)){
            condition.append(" AND DateDiff(dd, sp.txn_date, ? ) = 0 ");
            params.add(dayendDate);
        }
        //counter
        String terminal = request.getParameter("terminal");
        if(!StringUtil.isEmpty(terminal)){
            condition.append(" AND sp.tmnl_code = ? ");
            params.add(terminal);
        }
        //center
        String counter = request.getParameter("counter");
        if(!StringUtil.isEmpty(counter)){
            condition.append(" AND sp.counter_id = ? ");
            params.add(counter);
        }
        //curLoginName
        if(!StringUtil.isEmpty(curLoginName)){
            condition.append(" AND sp.cashier_id = ? ");
            params.add(curLoginName);
        }

        String sqlQuery = sql1.append(condition).append(sql3).toString();
        Query q = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }

        List objectList = q.list();
        int count = 0;
        if (objectList!=null&&objectList.size()>0){
            count = objectList.size();
        }
        q.setFirstResult((page - 1) * rows).setMaxResults(rows);
        List list = q.list();
        List<Map<String, Object>> mapList = new ArrayList<>();
        if(list != null && list.size() > 0){
            for (int i = 0; i < list.size(); i++) {
                Object[] objects = (Object[]) list.get(i);
                Map<String, Object> map = new HashMap<>();
                if(objects[0] != null){
                    String payMode = (String) objects[0];
                    if(payMode.equals("01")){
                        map.put("payMode","Cash");
                    }else if(payMode.equals("02")){
                        map.put("payMode","Credit Card");
                    }else if(payMode.equals("03")){
                        map.put("payMode","Debit");
                    }else if(payMode.equals("04")){
                        map.put("payMode","Nets");
                    }else if(payMode.equals("05")){
                        map.put("payMode","Cheque");
                    }else if(payMode.equals("06")){
                        map.put("payMode","Voucher");
                    }
                }else{
                    map.put("payMode","");
                }
                map.put("topupCount",objects[1] != null ? (Integer) objects[1] : 0);
                map.put("reverseCount",objects[2] != null ? (Integer) objects[2] : 0);
                map.put("cardfeeCount",objects[3] != null ? (Integer) objects[3] : 0);
                map.put("totalCount",objects[4] != null ? (Integer) objects[4] : 0);

                //充值总额
                if(oConvertUtils.isNotEmpty(objects[5])){
                    String stxnAmt = new BigDecimal(objects[5].toString()).setScale(2, BigDecimal.ROUND_DOWN).toString();
                    map.put("txnAmt",stxnAmt);
                }else {
                    map.put("txnAmt","NA");
                }

                if(oConvertUtils.isNotEmpty(objects[6])){
                    String sarrearAmt = new BigDecimal(objects[6].toString()).setScale(2, BigDecimal.ROUND_DOWN).toString();
                    map.put("arrearAmt",sarrearAmt);
                }else {
                    map.put("arrearAmt","NA");
                }

                if(oConvertUtils.isNotEmpty(objects[7])){
                    String sreverseAmt = new BigDecimal(objects[7].toString()).setScale(2, BigDecimal.ROUND_DOWN).toString();
                    map.put("reverseAmt",sreverseAmt);
                }else {
                    map.put("reverseAmt","NA");
                }
                if(oConvertUtils.isNotEmpty(objects[8])){
                    String scardfeeAmt = new BigDecimal(objects[8].toString()).setScale(2, BigDecimal.ROUND_DOWN).toString();
                    map.put("cardfeeAmt",scardfeeAmt);
                }else {
                    map.put("cardfeeAmt","NA");
                }
                if(oConvertUtils.isNotEmpty(objects[9])){
                    String stotalAmt = new BigDecimal(objects[9].toString()).setScale(2, BigDecimal.ROUND_DOWN).toString();
                    map.put("totalAmt",stotalAmt);
                }else {
                    map.put("totalAmt","NA");
                }

                mapList.add(map);
            }
        }

        Map<String, Object> returnMap = new HashMap<>();
        returnMap.put("total",count);
        returnMap.put("rows",mapList);

        return returnMap;
    }

    /**
     * DETAIL
     */
    @Override
    public Map<String, Object> getDayendDetail(HttpServletRequest request, HttpServletResponse response, int page, int rows, String curLoginName){
        StringBuilder sql1 = new StringBuilder(
                " SELECT " +
                        " id, refNo, accNo, txnDate, amount, center, counter, payMode, txnType, cashier " +
                        " FROM " +
                        " ( ( " +
                        "     SELECT " +
                        "     sp.id AS id, " +
                        "     sp.ref_no AS refNo, " +
                        "     sp.acc_no AS accNo, " +
                        "     sp.txn_date AS txnDate, " +
                        "     sp.topup_amt AS amount, " +
                        "     sp.tmnl_code AS center, " +
                        "     sp.counter_id AS counter, " +
                        "     sp.pay_mode AS payMode, " +
                        "     sp.txn_status AS txnType, " +
                        "     sp.cashier_id AS cashier " +
                        "     FROM " +
                        "     SP_TOPUP_REC sp " +
                        "     WHERE " +
                        "     sp.recon_status = '01' " +
                        "     AND pay_mode in (01,02,03,04,05,06) "
        );

        StringBuilder sql3 = new StringBuilder(" ) ) result WHERE 1 = 1 ");
        StringBuilder condition = new StringBuilder();
        List params = new ArrayList();
        //查询条件
        //time
        String dayendDate = request.getParameter("dayendDate");
        if(!StringUtil.isEmpty(dayendDate)){
            condition.append(" AND DateDiff(dd, result.txnDate, ? ) = 0 ");
            params.add(dayendDate);
        }
        //counter
        String terminal = request.getParameter("terminal");
        if(!StringUtil.isEmpty(terminal)){
            condition.append(" AND result.center = ? ");
            params.add(terminal);
        }
        //center
        String counter = request.getParameter("counter");
        if(!StringUtil.isEmpty(counter)){
            condition.append(" AND result.counter = ? ");
            params.add(counter);
        }
        //txnType
        String txnType = request.getParameter("txnType");
        if(!StringUtil.isEmpty(txnType)){
            condition.append(" AND result.txntype = ? ");
            params.add(txnType);
        }
        //payMode
        String payMode1 = request.getParameter("payMode");
        if(!StringUtil.isEmpty(payMode1)){
            condition.append(" AND result.payMode = ? ");
            params.add(payMode1);
        }
        //curLoginName
        if(!StringUtil.isEmpty(curLoginName)){
            condition.append(" AND result.cashier = ? ");
            params.add(curLoginName);
        }

        String sqlQuery = sql1.append(sql3).append(condition).toString();
        Query q = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }

        List objectList = q.list();
        int count = 0;
        if (objectList!=null&&objectList.size()>0){
            count = objectList.size();
        }
        q.setFirstResult((page - 1) * rows).setMaxResults(rows);
        List list = q.list();
        List<Map<String, Object>> mapList = new ArrayList<>();
        if(list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                Object[] objects = (Object[]) list.get(i);
                Map<String, Object> map = new HashMap<>();
                map.put("id", oConvertUtils.isNotEmpty(objects[0]) ? objects[0] : "");
                map.put("refNo", oConvertUtils.isNotEmpty(objects[1]) ? objects[1] : "--");
                map.put("accNo", oConvertUtils.isNotEmpty(objects[2]) ? objects[2] : "--");
                if (oConvertUtils.isNotEmpty(objects[3])) {
                    String sdate = objects[3].toString();
                    Date txnDate = PersDateUtils.str2Date(sdate, PersDateUtils.getSdf(PersDateUtils.YYYY_MM_DD_HH_MM_SS));
                    SimpleDateFormat sdf = new SimpleDateFormat(PersDateUtils.YYYY_MM_DD_HH_MM_SS);
                    String ssdate = sdf.format(txnDate);
                    map.put("txnDate", ssdate);
                } else {
                    map.put("txnDate", "--");
                }
                if (oConvertUtils.isNotEmpty(objects[4])) {
                    BigDecimal amount = new BigDecimal(objects[4].toString());
                    String samount = amount.setScale(2, BigDecimal.ROUND_DOWN).toString();
                    map.put("amount", samount);
                } else {
                    map.put("amount", "NA");
                }

                if (oConvertUtils.isNotEmpty(objects[5])) {
                    String obj5 = objects[5].toString();
                    String centerName = changeDaoI.getTmnlNameByCode(obj5);
                    map.put("center", centerName);
                } else {
                    map.put("center", "--");
                }
                if (oConvertUtils.isNotEmpty(objects[6])) {
                    String obj6 = objects[6].toString();
                    String counterName = changeDaoI.getCounterNameByCode(obj6);
                    map.put("counter", counterName);
                } else {
                    map.put("counter", "--");
                }
                map.put("payMode", objects[7] != null ? objects[7] : "");
                if(objects[8] != null){
                    String payMode = (String) objects[8];
                    if(payMode.equals("01")){
                        map.put("txnType","Top-up");
                    }else if(payMode.equals("02")){
                        map.put("txnType","Reversed");
                    }else if(payMode.equals("03")){
                        map.put("txnType","Reverse");
                    }else if(payMode.equals("06")){
                        map.put("txnType","Card Fee");
                    }
                }

                map.put("cashierId", objects[9] != null ? objects[9] : "");

                mapList.add(map);
            }
        }

        Map<String, Object> returnMap = new HashMap<>();
        returnMap.put("total",count);
        returnMap.put("rows",mapList);

        return returnMap;
    }

    /**
     * SETTLEMENT-sptopup
     * dayend查询充值记录-未对账
     */
    @Override
    public List<SpTopUpRecEntity> getTopupRecordList(HttpServletRequest request, String curLoginName) {
        StringBuilder hql = new StringBuilder(
                " from SpTopUpRecEntity sp where sp.reconStatus = '01' "
        );
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        //查询条件
        //time
        String dayendDate = request.getParameter("dayendDate");
        if(!StringUtil.isEmpty(dayendDate)){
            condition.append(" AND DateDiff(dd, sp.txnDate, ? ) = 0 ");
            params.add(dayendDate);
        }
        //center
        String terminal = request.getParameter("terminal");
        if(!StringUtil.isEmpty(terminal)){
            condition.append(" AND sp.tmnlCode = ? ");
            params.add(terminal);
        }
        //counter
        String counter = request.getParameter("counter");
        if(!StringUtil.isEmpty(counter)){
            condition.append(" AND sp.counterId = ? ");
            params.add(counter);
        }
        //curLoginName
        if(!StringUtil.isEmpty(curLoginName)){
            condition.append(" AND sp.cashierId = ? ");
            params.add(curLoginName);
        }

        String hqlQuery = hql.append(condition.toString()).toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List<SpTopUpRecEntity> list = q.list();

        return list;
    }

    /**
     * SETTLEMENT-refund
     * dayend查询退款记录-审批已通过且未对账
     */
//    @Override
//    public List<RefundRecordEntity> getRefundRecordList(HttpServletRequest request, String curLoginName) {
//        StringBuilder hql = new StringBuilder(
//            " from RefundRecordEntity re where re.reconStatus = '01' and re.apprStatus = '02' "
//        );
//
//        StringBuilder condition = new StringBuilder("");
//        List params = new ArrayList();
//        //查询条件
//        //time
//        String dayendDate = request.getParameter("dayendDate");
//        if(!StringUtil.isEmpty(dayendDate)){
//            condition.append(" AND DateDiff(dd, re.apprTime, ? ) = 0 ");
//            params.add(dayendDate);
//        }
//        //counter
//        String terminal = request.getParameter("terminal");
//        if(!StringUtil.isEmpty(terminal)){
//            condition.append(" AND re.tmnlCode = ? ");
//            params.add(terminal);
//        }
//        //center
//        String counter = request.getParameter("counter");
//        if(!StringUtil.isEmpty(counter)){
//            condition.append(" AND re.counterId = ? ");
//            params.add(counter);
//        }
//        //curLoginName
//        if(!StringUtil.isEmpty(curLoginName)){
//            condition.append(" AND re.applyId = ? ");
//            params.add(curLoginName);
//        }
//
//        String hqlQuery = hql.append(condition.toString()).toString();
//        Query q = getSession().createQuery(hqlQuery);
//        if (params != null && params.size() > 0) {
//            for (int i = 0; i < params.size(); i++) {
//                q.setParameter(i, params.get(i));
//            }
//        }
//        List<RefundRecordEntity> list = q.list();
//
//        return list;
//    }

    //根据日期和当前登录人用户名查询countercodeList
    @Override
    public List getCounterCodeList(String date, String cashierName) {
        StringBuilder sql = new StringBuilder(
                " SELECT DISTINCT " +
                        " a.counter_id " +
                        " FROM " +
                        " ( " +
                        " SELECT DISTINCT " +
                        " sp.counter_id " +
                        " FROM " +
                        " SP_TOPUP_REC sp " +
                        " WHERE " +
                        " sp.txn_status IN ( " +
                        " '01', " +
                        " '02', " +
                        " '03', " +
                        " '04', " +
                        " '05', " +
                        " '06' ) "

        );
//        StringBuilder sql2 = new StringBuilder(
//                    " UNION ALL " +
//                    " SELECT DISTINCT " +
//                    " re.counter_id " +
//                    " FROM " +
//                    " REFUND_REC re " +
//                    " WHERE " +
//                    " re.appr_status = '02' "
//        );

        StringBuilder sql3 = new StringBuilder(
                " ) a "
        );
        StringBuilder condition = new StringBuilder("");
//        StringBuilder condition2 = new StringBuilder("");
        List params = new ArrayList();
//        List params2 = new ArrayList();
        if(!StringUtil.isEmpty(date)){
            condition.append(" AND DateDiff(dd, sp.txn_date, ? ) = 0 ");
//            condition2.append(" AND DateDiff(dd, re.apply_time, ? ) = 0 ");
            params.add(date);
//            params2.add(date);
        }
        if(!StringUtil.isEmpty(cashierName)){
            condition.append(" AND sp.cashier_id = ? ");
//            condition2.append(" AND re.apply_id = ? ");
            params.add(cashierName);
//            params2.add(cashierName);
        }
//        String sqlQuery = sql.append(condition).append(sql2).append(condition2).append(sql3).toString();
        String sqlQuery = sql.append(condition).append(sql3).toString();
        SQLQuery q = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
//        if (params2 != null && params2.size() > 0) {
//            for (int i = 0; i < params2.size(); i++) {
//                q.setParameter(i+params.size(), params.get(i));
//            }
//        }
        List list = q.list();
        List<String> counterList = new ArrayList();
        list.removeAll(Collections.singleton(null));
        if(list!=null&&list.size()>0){
            for(int i = 0; i < list.size(); i++){
                String counter = list.get(i).toString();
                counterList.add(counter);
            }
        }

        return counterList;
    }

    //根据tmnlId查询其下的所有已激活的counter
    @Override
    public List<CounterEntity> getcounterListByTmnlId(int tmnlId) {
        StringBuilder hql = new StringBuilder(" from CounterEntity t where t.status = '02' ");
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        if(tmnlId!=0){
            condition.append(" AND t.terminalEntity.id = ? ");
            params.add(tmnlId);
        }
        String hqlQuery = hql.append(condition.toString()).toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List<CounterEntity> list = q.list();

        return list;
    }

    /**
     * @description: 根据refNo和id查询sptopup记录
     * @auther: liangyadong
     * @date: 2018/10/10 0010 上午 11:07
     */
    @Override
    public SpTopupRecordVo getSptopupRecord(HttpServletRequest request) {
        StringBuilder sql = new StringBuilder(
                " SELECT " +
                        " s.acc_no, " +
                        " s.pay_mode, " +
                        " s.id, " +
                        " s.ref_no " +
                        " FROM " +
                        " SP_TOPUP_REC s " +
                        " where 1=1 "
        );
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        if(!StringUtil.isEmpty(request.getParameter("refNo"))){
            condition.append(" AND s.ref_no = ? ");
            params.add(request.getParameter("refNo"));
        }
        if(!StringUtil.isEmpty(request.getParameter("id"))){
            condition.append(" AND s.id = ? ");
            params.add(request.getParameter("id"));
        }
        String sqlQuery = sql.append(condition).toString();
        SQLQuery q = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List list = q.list();
        SpTopupRecordVo spTopupRecordVo = new SpTopupRecordVo();
        if(list!=null&&list.size()>0){
            Object[] objects = (Object[]) list.get(0);
            spTopupRecordVo.setAccNo(objects[0]==null?"":objects[0].toString());
            spTopupRecordVo.setPayMode(objects[1]==null?"":objects[1].toString());
            spTopupRecordVo.setId((Integer)objects[2]);
            spTopupRecordVo.setRefNo(objects[3]==null?"":objects[3].toString());
        }

        return spTopupRecordVo;
    }

    /**
     * @description: 根据id查询refund记录
     * @auther: liangyadong
     * @date: 2018/10/10 0010 上午 11:08
     */
//    @Override
//    public SpTopupRecordVo getRefundRecord(HttpServletRequest request) {
//        StringBuilder sql = new StringBuilder(
//                " SELECT " +
//                " r.acc_no, " +
//                " r.pay_mode, " +
//                " r.id " +
//                " FROM " +
//                " REFUND_REC r " +
//                " where 1=1 "
//        );
//        StringBuilder condition = new StringBuilder("");
//        List params = new ArrayList();
//        if(!StringUtil.isEmpty(request.getParameter("id"))){
//            condition.append(" AND r.id = ? ");
//            params.add(request.getParameter("id"));
//        }
//        String sqlQuery = sql.append(condition).toString();
//        SQLQuery q = getSession().createSQLQuery(sqlQuery);
//        if (params != null && params.size() > 0) {
//            for (int i = 0; i < params.size(); i++) {
//                q.setParameter(i, params.get(i));
//            }
//        }
//        List list = q.list();
//        SpTopupRecordVo spTopupRecordVo = new SpTopupRecordVo();
//        if(list!=null&&list.size()>0){
//            Object[] objects = (Object[]) list.get(0);
//            spTopupRecordVo.setAccNo(objects[0]==null?"":objects[0].toString());
//            spTopupRecordVo.setPayMode(objects[1]==null?"":objects[1].toString());
//            spTopupRecordVo.setId((Integer) objects[2]);
//            spTopupRecordVo.setRefNo("");
//        }
//
//        return spTopupRecordVo;
//    }

    @Override
    public List<DayendReconEntity> getDayendreconList(HttpServletRequest request, String curLoginName) {
        StringBuilder sql = new StringBuilder(
                " SELECT " +
                "        ( CASE WHEN sp.txn_status = '01' THEN '01' " +
                " WHEN sp.txn_status = '02' THEN '01' " +
                " WHEN sp.txn_status = '03' THEN '02' " +
                " WHEN sp.txn_status = '06' THEN '04' " +
                " ELSE '' END ) " +
                " txn_status, " +
                "         SUM ( CASE WHEN sp.pay_mode = '01' THEN sp.topup_amt ELSE 0 END ) cash_amt, " +
                "         SUM ( CASE WHEN sp.pay_mode = '01' THEN 1 ELSE 0 END ) cash_cnt, " +
                "         SUM ( CASE WHEN sp.pay_mode = '04' THEN sp.topup_amt ELSE 0 END ) nets_amt, " +
                "         SUM ( CASE WHEN sp.pay_mode = '04' THEN 1 ELSE 0 END ) nets_cnt, " +
                "         SUM ( CASE WHEN sp.pay_mode = '02' THEN sp.topup_amt ELSE 0 END ) cdcard_amt, " +
                "         SUM ( CASE WHEN sp.pay_mode = '02' THEN 1 ELSE 0 END ) cdcard_cnt, " +
                "         SUM ( CASE WHEN sp.pay_mode = '06' THEN sp.topup_amt ELSE 0 END ) voucher_amt, " +
                "         SUM ( CASE WHEN sp.pay_mode = '06' THEN 1 ELSE 0 END ) voucher_cnt, " +
                "         SUM ( CASE WHEN sp.pay_mode = '05' THEN sp.topup_amt ELSE 0 END ) cheque_amt, " +
                "         SUM ( CASE WHEN sp.pay_mode = '05' THEN 1 ELSE 0 END ) cheque_cnt, " +
                "         SUM ( CASE WHEN sp.pay_mode NOT IN ('01','02','04','05','06') THEN sp.topup_amt ELSE 0 END ) other_amt, " +
                "         SUM ( CASE WHEN sp.pay_mode NOT IN ('01','02','04','05','06') THEN 1 ELSE 0 END ) other_cnt, " +
                "         SUM ( CASE WHEN sp.pay_mode IN ('01','02','03','04','05','06','90') THEN sp.topup_amt ELSE 0 END ) total_amt, " +
                "         SUM ( CASE WHEN sp.pay_mode IN ('01','02','03','04','05','06','90') THEN 1 ELSE 0 END ) total_cnt, " +
                "         SUM ( sp.topup_amt ) total_topup_amt, " +
                "         SUM ( sp.arrear_amt ) total_arrear_amt, " +
                "         SUM ( sp.prepaid_amt ) total_prepaid_amt " +
                "         FROM " +
                " SP_TOPUP_REC sp " +
                " WHERE " +
                " sp.recon_status = '03' " +
                " AND sp.txn_status IN ('01','02','03','06') "
        );
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        //查询条件
        //time
        String dayendDate = request.getParameter("dayendDate");
        if(!StringUtil.isEmpty(dayendDate)){
            condition.append(" AND DateDiff(dd, sp.txn_date, ? ) = 0 ");
            params.add(dayendDate);
        }
        //center
        String terminal = request.getParameter("terminal");
        if(!StringUtil.isEmpty(terminal)){
            condition.append(" AND sp.tmnl_code = ? ");
            params.add(terminal);
        }
        //counter
        String counter = request.getParameter("counter");
        if(!StringUtil.isEmpty(counter)){
            condition.append(" AND sp.counter_id = ? ");
            params.add(counter);
        }
        //curLoginName
        if(!StringUtil.isEmpty(curLoginName)){
            condition.append(" AND sp.cashier_id = ? ");
            params.add(curLoginName);
        }
        String sqlQuery = sql.append(condition.toString()).append(" GROUP BY sp.txn_status ").toString();
        Query q = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List list = q.list();
        List<DayendReconEntity> dayendReconList = new ArrayList<>();
        if(list!=null&&list.size()>0){
            for(int i = 0; i<list.size();i++){
                Object[] objects = (Object[]) list.get(i);
                DayendReconEntity dayendReconEntity = new DayendReconEntity();
                /*DAY_END_RECON表txn_type
                01- topup
                02- reverse
                03- refund
                04- card fee*/
                if(oConvertUtils.isNotEmpty(objects[0])){
                    dayendReconEntity.setTxnType(objects[0].toString());
                    dayendReconEntity.setCashAmt((BigDecimal)objects[1]);
                    dayendReconEntity.setCashCnt((Integer)objects[2]);
                    dayendReconEntity.setNetsAmt((BigDecimal)objects[3]);
                    dayendReconEntity.setNetsCnt((Integer)objects[4]);
                    dayendReconEntity.setCdcardAmt((BigDecimal)objects[5]);
                    dayendReconEntity.setCdcardCnt((Integer)objects[6]);
                    dayendReconEntity.setVoucherAmt((BigDecimal)objects[7]);
                    dayendReconEntity.setVoucherCnt((Integer)objects[8]);
                    dayendReconEntity.setChequeAmt((BigDecimal)objects[9]);
                    dayendReconEntity.setChequeCnt((Integer)objects[10]);
                    dayendReconEntity.setOtherAmt((BigDecimal)objects[11]);
                    dayendReconEntity.setOtherCnt((Integer)objects[12]);
                    dayendReconEntity.setTotalAmt((BigDecimal)objects[13]);
                    dayendReconEntity.setTotalCnt((Integer)objects[14]);
                    dayendReconEntity.setTotalTopupAmt((BigDecimal)objects[15]);
                    dayendReconEntity.setTotalArrearAmt((BigDecimal)objects[16]);
                    dayendReconEntity.setTotalPrepaidAmt((BigDecimal)objects[17]);
                    dayendReconList.add(dayendReconEntity);
                }
            }
        }

        return dayendReconList;
    }

    //根据批次号查询settleInfo记录
    @Override
    public SettlementInfoEntityEntity getSettleInfoEntityByBatchNo(String batchNo) {
        StringBuilder hql = new StringBuilder(" from SettlementInfoEntityEntity a where a.batchNo = ? ");
        List params = new ArrayList();
        if (!"".equals(batchNo)) {
            params.add(batchNo);
        }
        String hqlQuery = hql.toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List<SettlementInfoEntityEntity> list = q.list();
        SettlementInfoEntityEntity entity = null;
        if(list != null && list.size() > 0){
            entity = list.get(0);
        }

        return entity;
    }

    @Override
    public TerminalEntity getTerminalEntityByCenterCode(String centerCode) {
        StringBuilder hql = new StringBuilder(" from TerminalEntity a where a.code = ? ");
        List params = new ArrayList();
        if (!"".equals(centerCode)) {
            params.add(centerCode);
        }
        String hqlQuery = hql.toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List<TerminalEntity> list = q.list();
        TerminalEntity entity = null;
        if(list != null && list.size() > 0){
            entity = list.get(0);
        }

        return entity;
    }

    /**
     * @description: 查询DayendRecon,对应批次对账记录
     * @auther: liangyadong
     * @date: 2018/10/26 0026 上午 9:33
     */
    @Override
    public List checkSettleStatus(String batchNo, String terminal, String counter, String cashierId, String operId) {

        StringBuilder sql = new StringBuilder("SELECT * FROM DAY_END_RECON d WHERE 1 = 1 ");
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        //查询条件
        //batchNo
        if(!StringUtil.isEmpty(batchNo)){
            condition.append(" AND d.batch_no = ? ");
            params.add(batchNo);
        }
        //center
        if(!StringUtil.isEmpty(terminal)){
            condition.append(" AND d.tmnl_code = ? ");
            params.add(terminal);
        }
        //counter
        if(!StringUtil.isEmpty(counter)){
            condition.append(" AND d.counter_id = ? ");
            params.add(counter);
        }
        //cashierId
        if(!StringUtil.isEmpty(cashierId)){
            condition.append(" AND d.cashier_id = ? ");
            params.add(cashierId);
        }
        //operId
        if(!StringUtil.isEmpty(operId)){
            condition.append(" AND d.oper_id = ? ");
            params.add(operId);
        }
        String sqlQuery = sql.append(condition.toString()).toString();
        Query q = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List list = q.list();

        return list;
    }
}
