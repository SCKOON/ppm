function retrySendMessage(id) {
    var title = 'Reconnection';
    var addurl = 'remoteReconRecController.do?detailWindow&id=' + id;
    var width = 600;
    var height = 180;
    if (width == "100%" || height == "100%") {
        width = window.top.document.body.offsetWidth;
        height = window.top.document.body.offsetHeight - 100;
    }
    $.dialog({
        content: 'url:' + addurl,
        lock: true,
        zIndex: getzIndex(),
        width: width,
        height: height,
        title: title,
        opacity: 0.3,
        cache: false,
        okVal: 'Confirm',
        ok: function () {
            iframe = this.iframe.contentWindow;
            var balance = $('#balance', iframe.document).val();
            if (balance > 0) {
                $.messager.confirm('Alert', 'Confirm Reconnnect?', function (t) {
                    if (t) {
                        $.ajax({
                            type: "post",
                            url: "remoteReconRecController.do?reconnect",
                            data: {id: id},
                            dataType: "json",
                            success: function (result) {
                                alertTip(result.msg);
                                $('#remoteRecon').datagrid('reload');
                            }
                        });
                    }
                });
            } else {
                alertTip("Can not reconnect as credit balance is insufficient.");
                this.close();
                return false;
            }
        },
        cancelVal: 'Close',
        cancel: true /*为true等价于function(){}*/
    });
}

function remoteReconsearch() {
    var queryParams = {};
    var flag = true;
    var accNo = $("input[name='accNo']").val();
    var operStatus = $("#operStatus").val();
    var ctlStatus = $("#ctlStatus").val();
    var exp = /^[pP0-9-]{10,11}$/;
    var reg = new RegExp(exp);
    if (accNo && !reg.test(accNo)) {
        alertTip("[Account Number] <br> Please enter 10 to 11 valid characters.");
        flag = false;
    }
    queryParams['accNo'] = accNo;
    queryParams['operStatus'] = operStatus;
    queryParams['ctlStatus'] = ctlStatus;
    if (!flag) {
        return false;
    } else {
        if (!accNo && !ctlStatus && !operStatus) {
            alertTip("No record found.");
        }else{
            $('#remoteRecon').datagrid({
                url: 'remoteReconRecController.do?datagrid&field=id,customerInfoEntity.accNo,meterId,txnType,genTime,operStatus,ctlStatus,exeStartTime,exeEndTime,operTimes,',
                pageNumber: 1,
                queryParams: queryParams,
                onLoadSuccess: function (data) {
                    if (data.total == 0) {
                        alertTip("No record found.");
                        $("#remoteRecon").datagrid('loadData',{total:1,rows:[]});
                    }
                }
            });
        }
    }
}
