package com.ppms.vo;

import java.util.Date;

/**
 * Created by admPPMSd on 12/14/2018.
 */
public class ReplacementVo {
    private String accNo;

    private Date replaceTime_begin;

    private Date replaceTime_end;

    public String getAccNo() {
        return accNo;
    }

    public void setAccNo(String accNo) {
        this.accNo = accNo;
    }

    public Date getReplaceTime_begin() {
        return replaceTime_begin;
    }

    public void setReplaceTime_begin(Date replaceTime_begin) {
        this.replaceTime_begin = replaceTime_begin;
    }

    public Date getReplaceTime_end() {
        return replaceTime_end;
    }

    public void setReplaceTime_end(Date replaceTime_end) {
        this.replaceTime_end = replaceTime_end;
    }
}
