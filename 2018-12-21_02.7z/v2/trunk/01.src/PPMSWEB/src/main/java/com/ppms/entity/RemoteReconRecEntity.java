package com.ppms.entity;

import javax.persistence.*;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

/**   
 * @Title: Entity
 * @Description: 合闸 表
 * @author zhangdaihao
 * @date 2018-06-29 09:01:55
 * @version V1.0   
 *
 */
@Entity
@Table(name = "REMOTE_RECON_REC", schema = "")
@DynamicUpdate(true)
@DynamicInsert(true)
@SuppressWarnings("serial")
public class RemoteReconRecEntity implements java.io.Serializable {
	/**txnId*/
	private java.lang.String txnId;
	/**txnType*/
	private java.lang.String txnType;
	/**genTime*/
	private java.util.Date genTime;
	/**accNo*/
//	private java.lang.String accNo;
	/**macId*/
//	private java.lang.String macId;
	/**meterId*/
	private java.lang.String meterId;
	/**operStatus*/
	private java.lang.String operStatus;
	/**operTime*/
	private java.util.Date operTime;
	/**operTimes*/
	private java.lang.Integer operTimes;
	/**exeStartTime*/
	private java.util.Date exeStartTime;
	/**exeEndTime*/
	private java.util.Date exeEndTime;
	/**ctlStatus*/
	private java.lang.String ctlStatus;
	/**meterConStatus*/
	private java.lang.String meterConStatus;
	/**ctlTime*/
	private java.util.Date ctlTime;
	/**delFlag*/
	private java.lang.String delFlag;
	/**jobIds*/
	private java.lang.String jobIds;
	/**id*/
	private java.lang.Integer id;
	/**emailId*/
	private java.lang.Integer emailId;

	private CustomerInfoEntity customerInfoEntity;

	@ManyToOne
	@JoinColumn(name = "ACC_NO")
	public CustomerInfoEntity getCustomerInfoEntity() {
		return customerInfoEntity;
	}

	public void setCustomerInfoEntity(CustomerInfoEntity customerInfoEntity) {
		this.customerInfoEntity = customerInfoEntity;
	}

	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  txnId
	 */
	@Column(name ="TXN_ID",nullable=true,precision=12,length=12)
	public java.lang.String getTxnId(){
		return this.txnId;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  txnId
	 */
	public void setTxnId(java.lang.String txnId){
		this.txnId = txnId;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  txnType
	 */
	@Column(name ="TXN_TYPE",nullable=true,precision=2,length=2)
	public java.lang.String getTxnType(){
		return this.txnType;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  txnType
	 */
	public void setTxnType(java.lang.String txnType){
		this.txnType = txnType;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  genTime
	 */
	@Column(name ="GEN_TIME",nullable=true,precision=23,scale=3,length=8)
	public java.util.Date getGenTime(){
		return this.genTime;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  genTime
	 */
	public void setGenTime(java.util.Date genTime){
		this.genTime = genTime;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  accNo
	 */
//	@Column(name ="ACC_NO",nullable=true,precision=12,length=12)
//	public java.lang.String getAccNo(){
//		return this.accNo;
//	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  accNo
	 */
//	public void setAccNo(java.lang.String accNo){
//		this.accNo = accNo;
//	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  macId
	 */
//	@Column(name ="MAC_ID",nullable=true,precision=32,length=32)
//	public java.lang.String getMacId(){
//		return this.macId;
//	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  macId
	 */
//	public void setMacId(java.lang.String macId){
//		this.macId = macId;
//	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  meterId
	 */
	@Column(name ="METER_ID",nullable=true,precision=12,length=12)
	public java.lang.String getMeterId(){
		return this.meterId;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  meterId
	 */
	public void setMeterId(java.lang.String meterId){
		this.meterId = meterId;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  operStatus
	 */
	@Column(name ="OPER_STATUS",nullable=true,precision=2,length=2)
	public java.lang.String getOperStatus(){
		return this.operStatus;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  operStatus
	 */
	public void setOperStatus(java.lang.String operStatus){
		this.operStatus = operStatus;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  operTime
	 */
	@Column(name ="OPER_TIME",nullable=true,precision=23,scale=3,length=8)
	public java.util.Date getOperTime(){
		return this.operTime;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  operTime
	 */
	public void setOperTime(java.util.Date operTime){
		this.operTime = operTime;
	}
	/**
	 *方法: 取得java.lang.Integer
	 *@return: java.lang.Integer  operTimes
	 */
	@Column(name ="OPER_TIMES",nullable=true,precision=10,scale=0,length=4)
	public java.lang.Integer getOperTimes(){
		return this.operTimes;
	}

	/**
	 *方法: 设置java.lang.Integer
	 *@param: java.lang.Integer  operTimes
	 */
	public void setOperTimes(java.lang.Integer operTimes){
		this.operTimes = operTimes;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  exeStartTime
	 */
	@Column(name ="EXE_START_TIME",nullable=true,precision=23,scale=3,length=8)
	public java.util.Date getExeStartTime(){
		return this.exeStartTime;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  exeStartTime
	 */
	public void setExeStartTime(java.util.Date exeStartTime){
		this.exeStartTime = exeStartTime;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  exeEndTime
	 */
	@Column(name ="EXE_END_TIME",nullable=true,precision=23,scale=3,length=8)
	public java.util.Date getExeEndTime(){
		return this.exeEndTime;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  exeEndTime
	 */
	public void setExeEndTime(java.util.Date exeEndTime){
		this.exeEndTime = exeEndTime;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  ctlStatus
	 */
	@Column(name ="CTL_STATUS",nullable=true,precision=2,length=2)
	public java.lang.String getCtlStatus(){
		return this.ctlStatus;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  ctlStatus
	 */
	public void setCtlStatus(java.lang.String ctlStatus){
		this.ctlStatus = ctlStatus;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  meterConStatus
	 */
	@Column(name ="METER_CON_STATUS",nullable=true,precision=2,length=2)
	public java.lang.String getMeterConStatus(){
		return this.meterConStatus;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  meterConStatus
	 */
	public void setMeterConStatus(java.lang.String meterConStatus){
		this.meterConStatus = meterConStatus;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  ctlTime
	 */
	@Column(name ="CTL_TIME",nullable=true,precision=23,scale=3,length=8)
	public java.util.Date getCtlTime(){
		return this.ctlTime;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  ctlTime
	 */
	public void setCtlTime(java.util.Date ctlTime){
		this.ctlTime = ctlTime;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  delFlag
	 */
	@Column(name ="DEL_FLAG",nullable=true,precision=2,length=2)
	public java.lang.String getDelFlag(){
		return this.delFlag;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  delFlag
	 */
	public void setDelFlag(java.lang.String delFlag){
		this.delFlag = delFlag;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  jobIds
	 */
	@Column(name ="JOB_ID",nullable=true,precision=256,length=256)
	public java.lang.String getJobIds(){
		return this.jobIds;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  jobIds
	 */
	public void setJobIds(java.lang.String jobIds){
		this.jobIds = jobIds;
	}
	/**
	 *方法: 取得java.lang.Integer
	 *@return: java.lang.Integer  id
	 */
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="ID",nullable=false,precision=10,scale=0,length=4)
	public java.lang.Integer getId(){
		return this.id;
	}

	/**
	 *方法: 设置java.lang.Integer
	 *@param: java.lang.Integer  id
	 */
	public void setId(java.lang.Integer id){
		this.id = id;
	}
	/**
	 *方法: 取得java.lang.Integer
	 *@return: java.lang.Integer  emailId
	 */
	@Column(name ="EMAIL_ID",nullable=true,precision=10,scale=0,length=4)
	public java.lang.Integer getEmailId(){
		return this.emailId;
	}

	/**
	 *方法: 设置java.lang.Integer
	 *@param: java.lang.Integer  emailId
	 */
	public void setEmailId(java.lang.Integer emailId){
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "RemoteReconRecEntity{" +
				"txnId='" + txnId + '\'' +
				", txnType='" + txnType + '\'' +
				", genTime=" + genTime +
				", meterId='" + meterId + '\'' +
				", operStatus='" + operStatus + '\'' +
				", operTime=" + operTime +
				", operTimes=" + operTimes +
				", exeStartTime=" + exeStartTime +
				", exeEndTime=" + exeEndTime +
				", ctlStatus='" + ctlStatus + '\'' +
				", meterConStatus='" + meterConStatus + '\'' +
				", ctlTime=" + ctlTime +
				", delFlag='" + delFlag + '\'' +
				", jobIds='" + jobIds + '\'' +
				", id=" + id +
				'}';
	}
}
