package com.ppms.connection.service.impl;

import com.constants.Constants;
import com.ppms.connection.dao.ConnectionDao;
import com.ppms.entity.RemoteReconRecEntity;
import com.ppms.utils.DataSourceValue;
import org.jeecgframework.core.common.exception.BusinessException;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.extend.datasource.DataSourceType;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ppms.connection.service.RemoteReconRecServiceI;
import org.jeecgframework.core.common.service.impl.CommonServiceImpl;

import javax.servlet.http.HttpServletRequest;

@Service("remoteReconRecService")
@Transactional
@DataSourceValue(DataSourceType.dataSource_ppms)
public class RemoteReconRecServiceImpl extends CommonServiceImpl implements RemoteReconRecServiceI {

    @Autowired
    private ConnectionDao connectionDao;

    @Override
    public void queryReconRecord(DataGrid dataGrid, HttpServletRequest request) {
        connectionDao.getResultCount(dataGrid, request);
        if (dataGrid.getTotal() > 0) {
            connectionDao.queryReconRecord(dataGrid, request);
        }
    }

    /**
     * 合闸
     * 业务逻辑：将需要合闸的记录的操作状态修改为pending，并且将合闸次数加1
     *
     * @param entity
     */
    @Override
    public void markReconnect(RemoteReconRecEntity entity) {
        RemoteReconRecEntity reconRecEntity = super.getEntity(RemoteReconRecEntity.class, entity.getId());
        if (oConvertUtils.isNotEmpty(reconRecEntity.getCtlStatus()) && !reconRecEntity.getCtlStatus().equals(Constants.REMOTER_CTRL_STATUS.FAILURE.getType())) {
            throw new BusinessException("");
        }
        reconRecEntity.setOperStatus(Constants.REMOTER_OPER_STATUS.PENDING.getType());
        Integer times = 1;
        if (reconRecEntity.getOperTimes() != null) {
            times = reconRecEntity.getOperTimes() + 1;
        }
        reconRecEntity.setOperTimes(times);
        super.updateEntitie(reconRecEntity);
    }
}