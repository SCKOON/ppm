package com.ppms.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import javax.persistence.SequenceGenerator;

/**   
 * @Title: Entity
 * @Description: BALANCE_REMOTE_REC_VIEW
 * @author zhangdaihao
 * @date 2018-04-28 11:09:50
 * @version V1.0   
 *
 */
@Entity
@Table(name = "BALANCE_REMOTE_REC_VIEW", schema = "")
@DynamicUpdate(true)
@DynamicInsert(true)
@SuppressWarnings("serial")
public class RemoteRecEntity implements java.io.Serializable {
	/**CHARGE AND BILLING COMPUTATION ID - (TXN_TYPE = 01/02)
   REVERSE_REC_ID(TXN_TYPE = 03)
   PROCESS_CHARGE_DATA ID (TXN_TYPE = 04)*/
	private java.lang.String txnId;
	/**01- REGISTER DATA (CHARGE DEDUCTION)
   02- INTERVAL DATA (CHARGE DEDUCTION)
   03-  REVERSE
   04- FAULTY METER REPLACEMENT(CHARGE DEDUCTION)*/
	private java.lang.String txnType;
	/**GENERATED TIME*/
	private java.util.Date genTime;
//	/**CONTROL COUNT*/
//	private java.lang.Integer ctlCount;
	/**accNo*/
	private java.lang.String accNo;
//	/**01-NOT IN CONTROL TIME RANGE
//   02- APPLY
//   03-APPROVED
//   04-DECLINED
//   */
//	private java.lang.String appStatus;
//	/**DISCONNECTION RECORD APPLICATION TIME*/
//	private java.util.Date appTime;
//	/**APPROVAL TIME*/
//	private java.util.Date apprTime;
	/**01- PENDING
   02- EXECUTING
   03- COMPLETED*/
	private java.lang.String operStatus;
	/**OPERATION TIME - PENDING STATUS*/
	private java.util.Date operTime;
	/**operTimes*/
	private java.lang.Integer operTimes;
	/**exeStartTime*/
	private java.util.Date exeStartTime;
	/**exeEndTime*/
	private java.util.Date exeEndTime;
	/**01- SUCCESS
   02- FILED
   03- UNKNOWN*/
	private java.lang.String ctlStatus;
	/**CONTROL TIME(RETURNED BY NMS)*/
	private java.util.Date ctlTime;
	/**METER SWITCH CONNECTION STATUS(TBD)
   01- CONNECT
   02- SOFT_CONNECT
   03-DISCONNECT*/
	private java.lang.String meterConStatus;
//	/**disconFileId*/
//	private java.lang.String disconFileId;
	/**delFlag*/
	private java.lang.String delFlag;
	/**meterId*/
	private java.lang.String meterId;
	/**ctl_no*/
	private java.lang.Integer ctlNo;
	/**update_flag*/
	private java.lang.String updateFlag;
	/**name*/
//	private java.lang.String name;
	/**controlType*/
	private java.lang.String controlType;
	
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  CHARGE AND BILLING COMPUTATION ID - (TXN_TYPE = 01/02)
   REVERSE_REC_ID(TXN_TYPE = 03)
   PROCESS_CHARGE_DATA ID (TXN_TYPE = 04)
	 */
	@Id
	@GeneratedValue(generator = "paymentableGenerator")
	@GenericGenerator(name = "paymentableGenerator", strategy = "uuid")
	@Column(name ="TXN_ID",nullable=true,precision=12,length=12)
	public java.lang.String getTxnId(){
		return this.txnId;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  CHARGE AND BILLING COMPUTATION ID - (TXN_TYPE = 01/02)
   REVERSE_REC_ID(TXN_TYPE = 03)
   PROCESS_CHARGE_DATA ID (TXN_TYPE = 04)
	 */
	public void setTxnId(java.lang.String txnId){
		this.txnId = txnId;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  01- REGISTER DATA (CHARGE DEDUCTION)
   02- INTERVAL DATA (CHARGE DEDUCTION)
   03-  REVERSE
   04- FAULTY METER REPLACEMENT(CHARGE DEDUCTION)
	 */
	@Column(name ="TXN_TYPE",nullable=true,precision=2,length=2)
	public java.lang.String getTxnType(){
		return this.txnType;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  01- REGISTER DATA (CHARGE DEDUCTION)
   02- INTERVAL DATA (CHARGE DEDUCTION)
   03-  REVERSE
   04- FAULTY METER REPLACEMENT(CHARGE DEDUCTION)
	 */
	public void setTxnType(java.lang.String txnType){
		this.txnType = txnType;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  GENERATED TIME
	 */
	@Column(name ="GEN_TIME",nullable=true,precision=23,scale=3,length=8)
	public java.util.Date getGenTime(){
		return this.genTime;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  GENERATED TIME
	 */
	public void setGenTime(java.util.Date genTime){
		this.genTime = genTime;
	}
//	/**
//	 *方法: 取得java.lang.Integer
//	 *@return: java.lang.Integer  CONTROL COUNT
//	 */
//	@Column(name ="CTL_COUNT",nullable=true,precision=10,scale=0,length=4)
//	public java.lang.Integer getCtlCount(){
//		return this.ctlCount;
//	}
//
//	/**
//	 *方法: 设置java.lang.Integer
//	 *@param: java.lang.Integer  CONTROL COUNT
//	 */
//	public void setCtlCount(java.lang.Integer ctlCount){
//		this.ctlCount = ctlCount;
//	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  accNo
	 */
	@Column(name ="ACC_NO",nullable=true,precision=12,length=12)
	public java.lang.String getAccNo(){
		return this.accNo;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  accNo
	 */
	public void setAccNo(java.lang.String accNo){
		this.accNo = accNo;
	}

//	/**
//	 *方法: 取得java.lang.String
//	 *@return: java.lang.String  01-NOT IN CONTROL TIME RANGE
//   02- APPLY
//   03-APPROVED
//   04-DECLINED
//   
//	 */
//	@Column(name ="APP_STATUS",nullable=true,precision=2,length=2)
//	public java.lang.String getAppStatus(){
//		return this.appStatus;
//	}
//
//	/**
//	 *方法: 设置java.lang.String
//	 *@param: java.lang.String  01-NOT IN CONTROL TIME RANGE
//   02- APPLY
//   03-APPROVED
//   04-DECLINED
//   
//	 */
//	public void setAppStatus(java.lang.String appStatus){
//		this.appStatus = appStatus;
//	}
//	/**
//	 *方法: 取得java.util.Date
//	 *@return: java.util.Date  DISCONNECTION RECORD APPLICATION TIME
//	 */
//	@Column(name ="APP_TIME",nullable=true,precision=23,scale=3,length=8)
//	public java.util.Date getAppTime(){
//		return this.appTime;
//	}
//
//	/**
//	 *方法: 设置java.util.Date
//	 *@param: java.util.Date  DISCONNECTION RECORD APPLICATION TIME
//	 */
//	public void setAppTime(java.util.Date appTime){
//		this.appTime = appTime;
//	}
//	/**
//	 *方法: 取得java.util.Date
//	 *@return: java.util.Date  APPROVAL TIME
//	 */
//	@Column(name ="APPR_TIME",nullable=true,precision=23,scale=3,length=8)
//	public java.util.Date getApprTime(){
//		return this.apprTime;
//	}
//
//	/**
//	 *方法: 设置java.util.Date
//	 *@param: java.util.Date  APPROVAL TIME
//	 */
//	public void setApprTime(java.util.Date apprTime){
//		this.apprTime = apprTime;
//	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  01- PENDING
   02- EXECUTING
   03- COMPLETED
	 */
	@Column(name ="OPER_STATUS",nullable=true,precision=2,length=2)
	public java.lang.String getOperStatus(){
		return this.operStatus;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  01- PENDING
   02- EXECUTING
   03- COMPLETED
	 */
	public void setOperStatus(java.lang.String operStatus){
		this.operStatus = operStatus;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  OPERATION TIME - PENDING STATUS
	 */
	@Column(name ="OPER_TIME",nullable=true,precision=23,scale=3,length=8)
	public java.util.Date getOperTime(){
		return this.operTime;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  OPERATION TIME - PENDING STATUS
	 */
	public void setOperTime(java.util.Date operTime){
		this.operTime = operTime;
	}
	/**
	 *方法: 取得java.lang.Integer
	 *@return: java.lang.Integer  operTimes
	 */
	@Column(name ="OPER_TIMES",nullable=true,precision=10,scale=0,length=4)
	public java.lang.Integer getOperTimes(){
		return this.operTimes;
	}

	/**
	 *方法: 设置java.lang.Integer
	 *@param: java.lang.Integer  operTimes
	 */
	public void setOperTimes(java.lang.Integer operTimes){
		this.operTimes = operTimes;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  exeStartTime
	 */
	@Column(name ="EXE_START_TIME",nullable=true,precision=23,scale=3,length=8)
	public java.util.Date getExeStartTime(){
		return this.exeStartTime;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  exeStartTime
	 */
	public void setExeStartTime(java.util.Date exeStartTime){
		this.exeStartTime = exeStartTime;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  exeEndTime
	 */
	@Column(name ="EXE_END_TIME",nullable=true,precision=23,scale=3,length=8)
	public java.util.Date getExeEndTime(){
		return this.exeEndTime;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  exeEndTime
	 */
	public void setExeEndTime(java.util.Date exeEndTime){
		this.exeEndTime = exeEndTime;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  01- SUCCESS
   02- FILED
   03- UNKNOWN
	 */
	@Column(name ="CTL_STATUS",nullable=true,precision=2,length=2)
	public java.lang.String getCtlStatus(){
		return this.ctlStatus;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  01- SUCCESS
   02- FILED
   03- UNKNOWN
	 */
	public void setCtlStatus(java.lang.String ctlStatus){
		this.ctlStatus = ctlStatus;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  CONTROL TIME(RETURNED BY NMS)
	 */
	@Column(name ="CTL_TIME",nullable=true,precision=23,scale=3,length=8)
	public java.util.Date getCtlTime(){
		return this.ctlTime;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  CONTROL TIME(RETURNED BY NMS)
	 */
	public void setCtlTime(java.util.Date ctlTime){
		this.ctlTime = ctlTime;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  METER SWITCH CONNECTION STATUS(TBD)
   01- CONNECT
   02- SOFT_CONNECT
   03-DISCONNECT
	 */
	@Column(name ="METER_CON_STATUS",nullable=true,precision=2,length=2)
	public java.lang.String getMeterConStatus(){
		return this.meterConStatus;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  METER SWITCH CONNECTION STATUS(TBD)
   01- CONNECT
   02- SOFT_CONNECT
   03-DISCONNECT
	 */
	public void setMeterConStatus(java.lang.String meterConStatus){
		this.meterConStatus = meterConStatus;
	}
//	/**
//	 *方法: 取得java.lang.String
//	 *@return: java.lang.String  disconFileId
//	 */
//	@Column(name ="DISCON_FILE_ID",nullable=true,precision=12,length=12)
//	public java.lang.String getDisconFileId(){
//		return this.disconFileId;
//	}
//
//	/**
//	 *方法: 设置java.lang.String
//	 *@param: java.lang.String  disconFileId
//	 */
//	public void setDisconFileId(java.lang.String disconFileId){
//		this.disconFileId = disconFileId;
//	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  delFlag
	 */
	@Column(name ="DEL_FLAG",nullable=true,precision=2,length=2)
	public java.lang.String getDelFlag(){
		return this.delFlag;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  delFlag
	 */
	public void setDelFlag(java.lang.String delFlag){
		this.delFlag = delFlag;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  meterId
	 */
	@Column(name ="METER_ID",nullable=true,precision=12,length=12)
	public java.lang.String getMeterId(){
		return this.meterId;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  meterId
	 */
	public void setMeterId(java.lang.String meterId){
		this.meterId = meterId;
	}
	
	/**
	 *方法: 取得java.lang.Integer
	 *@return: java.lang.Integer  ctl_no
	 */
	@Column(name ="ctl_no",nullable=false,precision=10,scale=0,length=4)
	public java.lang.Integer getCtlNo(){
		return this.ctlNo;
	}

	/**
	 *方法: 设置java.lang.Integer
	 *@param: java.lang.Integer  ctl_no
	 */
	public void setCtlNo(java.lang.Integer ctlNo){
		this.ctlNo = ctlNo;
	}
	
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  update_flag
	 */
	@Column(name ="update_flag",nullable=false,precision=10,scale=0,length=4)
	public java.lang.String getUpdateFlag(){
		return this.updateFlag;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  update_flag
	 */
	public void setUpdateFlag(java.lang.String updateFlag){
		this.updateFlag = updateFlag;
	}

	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  name
	 */
/*	@Column(name ="name",nullable=false,precision=10,scale=0,length=4)
	public java.lang.String getName(){
		return this.name;
	}

	*//**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  name
	 *//*
	public void setName(java.lang.String name){
		this.name = name;
	}*/
	
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  control_type
	 */
	@Column(name ="control_type",nullable=false,precision=10,scale=0,length=4)
	public java.lang.String getControlType(){
		return this.controlType;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  control_type
	 */
	public void setControlType(java.lang.String controlType){
		this.controlType = controlType;
	}
		
}
