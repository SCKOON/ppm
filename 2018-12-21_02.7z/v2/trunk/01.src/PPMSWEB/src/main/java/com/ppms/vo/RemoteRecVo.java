package com.ppms.vo;

import java.util.Date;

public class RemoteRecVo implements java.io.Serializable {

	private String txnId;
	private String accNo;
	private String meterId;
	private String controlType;
	private String updateFlag;
	private Date genTime;
	private String ctlStatus;
	private Date ctlTime;
	private Date exeStartTime;
	private Date exeEndTime;

	public String getTxnId(){
		return this.txnId;
	}

	public void setTxnId(String txnId){
		this.txnId = txnId;
	}

	public Date getGenTime(){ return this.genTime;	}

	public void setGenTime(Date genTime){
		this.genTime = genTime;
	}

	public String getAccNo(){
		return this.accNo;
	}

	public void setAccNo(String accNo){
		this.accNo = accNo;
	}

	public Date getExeStartTime(){
		return this.exeStartTime;
	}

	public void setExeStartTime(Date exeStartTime){
		this.exeStartTime = exeStartTime;
	}

	public Date getExeEndTime(){
		return this.exeEndTime;
	}

	public void setExeEndTime(Date exeEndTime){
		this.exeEndTime = exeEndTime;
	}

	public String getCtlStatus(){
		return this.ctlStatus;
	}

	public void setCtlStatus(String ctlStatus){
		this.ctlStatus = ctlStatus;
	}

	public Date getCtlTime(){
		return this.ctlTime;
	}

	public void setCtlTime(Date ctlTime){
		this.ctlTime = ctlTime;
	}

	public String getMeterId(){
		return this.meterId;
	}

	public void setMeterId(String meterId){
		this.meterId = meterId;
	}

	public String getUpdateFlag(){
		return this.updateFlag;
	}

	public void setUpdateFlag(String updateFlag){
		this.updateFlag = updateFlag;
	}

	public String getControlType(){
		return this.controlType;
	}

	public void setControlType(String controlType){
		this.controlType = controlType;
	}
		
}
