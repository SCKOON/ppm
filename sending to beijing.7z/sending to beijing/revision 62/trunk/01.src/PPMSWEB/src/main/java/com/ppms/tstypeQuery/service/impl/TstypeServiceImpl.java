package com.ppms.tstypeQuery.service.impl;

import com.ppms.tstypeQuery.dao.TstypeDaoI;
import com.ppms.tstypeQuery.service.TstypeServiceI;
import com.ppms.utils.DataSourceValue;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.service.impl.CommonServiceImpl;
import org.jeecgframework.core.extend.datasource.DataSourceType;
import org.jeecgframework.web.system.pojo.base.TSType;
import org.jeecgframework.web.system.pojo.base.TSTypegroup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liangyadong on 2018/9/18 0018.
 */
@Service("tstypeService")
@DataSourceValue(DataSourceType.dataSource_jeecg)
public class TstypeServiceImpl extends CommonServiceImpl implements TstypeServiceI {

    @Autowired
    private TstypeDaoI tstypeDao;

    //查询字典表
    @Override
    @DataSourceValue(DataSourceType.dataSource_jeecg)
    public List getTstypeList(CriteriaQuery cq) {
        return super.getListByCriteriaQuery(cq,false);
    }

    //根据groupId查询typecode和typename
    @Override
    @DataSourceValue(DataSourceType.dataSource_jeecg)
    public List<Map<String,Object>> getTypeCodeAndNameByGroupId(String typeGroupId){
        CriteriaQuery criteriaQuery = new CriteriaQuery(TSType.class);
        criteriaQuery.eq("TSTypegroup.id", typeGroupId);
        criteriaQuery.add();
        List<TSType> tsTypeList = this.getTstypeList(criteriaQuery);
        List<Map<String, Object>> list = new ArrayList();
        if (tsTypeList != null && tsTypeList.size() > 0) {
            for (TSType tsType : tsTypeList) {
                Map map = new HashMap();
                String typecode = tsType.getTypecode();
                String typename = tsType.getTypename();
                map.put("code",typecode);
                map.put("name",typename);
                list.add(map);
            }
        }
        return list;
    }

    /**
     * 根据groupName查询groupId
     */
    @Override
    @DataSourceValue(DataSourceType.dataSource_jeecg)
    public String getGroupIdByGroupCode(String typegroupcode){
        String typeGroupId = "";
        CriteriaQuery criteriaQuery = new CriteriaQuery(TSTypegroup.class);
        criteriaQuery.eq("typegroupcode",typegroupcode);
        criteriaQuery.add();
        List<TSTypegroup> tsTypegroupList = this.getTstypeList(criteriaQuery);
        if (tsTypegroupList!=null&&tsTypegroupList.size()>0){
            TSTypegroup tsTypegroup = tsTypegroupList.get(0);
            typeGroupId = tsTypegroup.getId();
        }

        return typeGroupId;
    }

    //根据code查询name
    @Override
    @DataSourceValue(DataSourceType.dataSource_jeecg)
    public String getTypeNameByCode(String typeCode) {
        String typeName = "";
        CriteriaQuery criteriaQuery = new CriteriaQuery(TSType.class);
        criteriaQuery.eq("typecode",typeCode);
        criteriaQuery.add();
        List<TSType> tsTypeList = this.getTstypeList(criteriaQuery);
        if (tsTypeList!=null&&tsTypeList.size()>0){
            TSType tsType = tsTypeList.get(0);
            typeName = tsType.getTypename();
        }

        return typeName;
    }

    @Override
    @DataSourceValue(DataSourceType.dataSource_ppms)
    public String getCounterNameByCounterCode(String counterCode) {
        return tstypeDao.getCounterNameByCounterCode(counterCode);
    }

    @Override
    @DataSourceValue(DataSourceType.dataSource_ppms)
    public String getTmnlNameByTmnlCode(String tmnlCode) {
        return tstypeDao.getTmnlNameByTmnlCode(tmnlCode);
    }

    @Override
    @DataSourceValue(DataSourceType.dataSource_ppms)
    public String getChannelNameByChannelCode(String channelCode) {
        return tstypeDao.getChannelNameByChannelCode(channelCode);
    }

    @Override
    public String getTypeNameByGroupCodeAndTypeCode(String groupCode, String typeCode) {
        return tstypeDao.getTypeNameByGroupCodeAndTypeCode(groupCode, typeCode);
    }

    @Override
    @DataSourceValue(DataSourceType.dataSource_jeecg)
    public String getTopupAmtAlmValue(String typeGroupCode) {
        return tstypeDao.getTopupAmtAlmValue(typeGroupCode);
    }

}
