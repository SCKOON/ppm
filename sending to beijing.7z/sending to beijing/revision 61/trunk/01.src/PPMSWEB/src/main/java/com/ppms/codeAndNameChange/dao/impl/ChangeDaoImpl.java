package com.ppms.codeAndNameChange.dao.impl;

import com.alibaba.fastjson.JSONObject;
import com.constants.SiteStatus;
import com.ppms.codeAndNameChange.dao.ChangeDaoI;
import com.ppms.entity.TerminalEntity;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.jeecgframework.core.common.dao.impl.GenericBaseCommonDao;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: liangyadong
 * @Date: 2018/12/7 0007 20:32
 * @Description:
 */
@Repository
public class ChangeDaoImpl extends GenericBaseCommonDao implements ChangeDaoI {
    @Override
    public String getTmnlNameByCode(String tmnlCode) {
        /*默认为--*/
        String tmnlName = "--";
        String sql = "SELECT t.NAME,t.CODE from S_TERMINAL t where t.CODE =:code";
        Map<String, String> map = new HashMap();
        if (oConvertUtils.isNotEmpty(tmnlCode)) {
            map.put("code", tmnlCode);
        } else {
            return tmnlName;
        }
        Query query = getSession().createSQLQuery(sql);
        query.setProperties(map);
        List list = query.list();
        if (list != null && list.size() > 0) {
            Object[] objects = (Object[]) list.get(0);
            tmnlName = oConvertUtils.isNotEmpty(objects[0]) ? objects[0].toString() : tmnlName;
        }

        return tmnlName;
    }

    @Override
    public String getCounterNameByCode(String counterCode) {
        /*默认为--*/
        String counterName = "--";
        String sql = "SELECT c.NAME,c.CODE from S_COUNTER c where c.CODE =:code";
        Map<String, String> map = new HashMap();
        if (oConvertUtils.isNotEmpty(counterCode)) {
            map.put("code", counterCode);
        } else {
            return counterName;
        }
        Query query = getSession().createSQLQuery(sql);
        query.setProperties(map);
        List list = query.list();
        if (list != null && list.size() > 0) {
            Object[] objects = (Object[]) list.get(0);
            counterName = oConvertUtils.isNotEmpty(objects[0]) ? objects[0].toString() : counterName;
        }

        return counterName;
    }

    @Override
    public List<Map<String, String>> getTmnlMapList() {
        String sql = "SELECT t.NAME,t.CODE from S_TERMINAL t";
        Query query = getSession().createSQLQuery(sql);
        Map<String, String> map = new HashMap();
        query.setProperties(map);
        List list = query.list();
        List<Map<String, String>> tmnlList = new ArrayList();
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                HashMap<String, String> tmnlMap = new HashMap();
                Object[] objects = (Object[]) list.get(i);
                tmnlMap.put("name", oConvertUtils.isNotEmpty(objects[0]) ? objects[0].toString() : "");
                tmnlMap.put("code", oConvertUtils.isNotEmpty(objects[1]) ? objects[1].toString() : "");
                tmnlList.add(tmnlMap);
            }
        }

        return tmnlList;
    }

    @Override
    public List<Map<String, String>> getCounterMapList() {
        String sql = "SELECT c.NAME,c.CODE from S_COUNTER c";
        Query query = getSession().createSQLQuery(sql);
        Map<String, String> map = new HashMap();
        query.setProperties(map);
        List list = query.list();
        List<Map<String, String>> counterList = new ArrayList();
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                HashMap<String, String> counterMap = new HashMap();
                Object[] objects = (Object[]) list.get(i);
                counterMap.put("name", oConvertUtils.isNotEmpty(objects[0]) ? objects[0].toString() : "");
                counterMap.put("code", oConvertUtils.isNotEmpty(objects[1]) ? objects[1].toString() : "");
                counterList.add(counterMap);
            }
        }

        return counterList;
    }


}
