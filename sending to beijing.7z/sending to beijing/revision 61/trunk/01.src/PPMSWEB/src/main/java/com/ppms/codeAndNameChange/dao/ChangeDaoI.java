package com.ppms.codeAndNameChange.dao;

import java.util.List;
import java.util.Map;

/**
 * @Author: liangyadong
 * @Date: 2018/12/7 0007 20:21
 * @Description:
 */
public interface ChangeDaoI {
    String getTmnlNameByCode(String tmnlCode);

    String getCounterNameByCode(String counterCode);

    List<Map<String, String>> getTmnlMapList();

    List<Map<String, String>> getCounterMapList();
}
