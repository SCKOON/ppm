function creditApprovesearch(){
    var queryParams = {};
    var flag = true;
    $('#creditApproveForm').find('*').each(function () {
        if ($(this).attr('name') == 'srcAccNo') {
            var accNo = $(this).val();
            var exp = /^[\u4E00-\u9FA5\uf900-\ufa2d\w\.\s]{10,11}$/;
            var reg = new RegExp(exp);
            if (accNo && !reg.test(accNo)) {
                alertTip("[Source Account Number] <br> Please enter 10 to 11 valid characters.");
                flag = false;
                return false;
            }
        }
        if ($(this).attr('name') == 'tgtAccNo') {
            var accNo = $(this).val();
            var exp = /^[\u4E00-\u9FA5\uf900-\ufa2d\w\.\s]{10,11}$/;
            var reg = new RegExp(exp);
            if (accNo && !reg.test(accNo)) {
                alertTip("[Target Account Number] <br> Please enter 10 to 11 valid characters.");
                flag = false;
                return false;
            }
        }
        queryParams[$(this).attr('name')] = $(this).val();
    });
    if (!flag) {
        return false;
    }
    $('#creditApprove').datagrid({
        url: 'creditTransferController.do?getCreditApplyList&field=srcAccNo,tgtAccNo,transferAmt,applyId,applyTime,apprStatus,apprId,apprTime,',
        pageNumber: 1,
        queryParams: queryParams,
        onLoadSuccess: function (data) {
            if (data.total == 0) {
                alertTip("No record found.");
            }
        }
    });
}
/**
 * description 获取所有被批准的余额转移记录，并将每条记录对应的id传到后台
 * author shenchen
 *
 */
function approveOrDecline(){
    var ids = [];
    var rows = $('#creditApprove').datagrid('getSelections');
    if (rows.length == 0) {
        alertTip("At least select one record");
        return false;
    }
    for (var i = 0; i < rows.length; i++) {
        if(rows[i].apprStatus!='01'){
            alertTip("The record had already been audited!");
            return false;
        }
        ids.push(rows[i].id);
    }
    var status = $("select[name='status']").val();
    var content;
    if(status==''){
        alertTip("Invalid Approval Advice");
        return false;
    }else if(status=='02'){
        content = "Confirm to Approve ?";
    }else if(status=='03'){
        content = "Confirm to Decline ?";
    }
    var remark = $("textarea").val();
    if (status == '03' && remark == '') {
        $("textarea").css({"border": "1px red solid"});
        return false;
    }
    layer.confirm(content, function () {
        layer.closeAll();
        $.post("creditTransferController.do?doTransfer", {
                "ids": ids.join(','),
                "status": status,
                "applyReason": remark
            },
            function (data) {
                alertTip(data);
                $("input,textarea").each(
                    function () {
                        $(this).val("");
                    }
                );
                $("select").each(
                    function () {
                        $(this).val("01");
                    });
                $('#creditApprove').datagrid('reload');
            }, "json");
    })
}

function view(id){
    var title = 'detail';
    var addurl = 'creditTransferController.do?goCheck&id=' + id;
    var width = 900;
    var height = 450;
    if (width == "100%" || height == "100%") {
        width = window.top.document.body.offsetWidth;
        height = window.top.document.body.offsetHeight - 100;
    }
    //--author：JueYue---------date：20140427---------for：弹出bug修改,设置了zindex()函数
    if (typeof(windowapi) == 'undefined') {
        $.dialog({
            content: 'url:' + addurl,
            lock: true,
            zIndex: getzIndex(),
            width: width,
            height: height,
            title: title,
            opacity: 0.3,
            cache: false,
            cancelVal: 'close',
            cancel: true /*为true等价于function(){}*/
        });
    } else {

        /*W.*/
        $.dialog({//使用W，即为使用顶级页面作为openner，造成打开的次级窗口获取不到关联的主窗口
            content: 'url:' + addurl,
            lock: true,
            width: width,
            zIndex: getzIndex(),
            height: height,
            parent: windowapi,
            title: title,
            opacity: 0.3,
            cache: false,
            ok: function () {
                iframe = this.iframe.contentWindow;
                return true;
            },
            cancelVal: 'close',
            cancel: true /*为true等价于function(){}*/
        });

    }
}