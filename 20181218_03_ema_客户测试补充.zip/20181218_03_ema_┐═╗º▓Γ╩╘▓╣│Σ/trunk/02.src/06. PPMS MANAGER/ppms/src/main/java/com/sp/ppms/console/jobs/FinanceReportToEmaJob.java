package com.sp.ppms.console.jobs;

import com.sp.ppms.console.domain.FinanceReportToEmaView;
import com.sp.ppms.console.domain.TotalTopupRec;
import com.sp.ppms.console.finance.CSV.CSVUtil;
import com.sp.ppms.console.finance.bean.EMADetailBean;
import com.sp.ppms.console.finance.bean.EMAFooterBean;
import com.sp.ppms.console.finance.bean.FinanceConstants;
import com.sp.ppms.console.finance.bean.RefundHeaderBean;
import com.sp.ppms.console.service.FinanceService;
import com.sp.ppms.console.util.DateUtil;
import com.sp.ppms.console.util.DateUtils;
import com.sp.ppms.console.util.PropertiesUtil;
import com.sp.ppms.console.util.StringUtils;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by liangyadong on 2018/9/2 0002.
 * <p>
 * EMA报表数据生成及传送
 */
@Component
public class FinanceReportToEmaJob implements Job {
    private Logger logger = LoggerFactory.getLogger(FinanceReportToEmaJob.class);
    private SimpleDateFormat YYYYMM = new SimpleDateFormat("yyyyMM");
    private SimpleDateFormat YYYYMMDD = new SimpleDateFormat("yyyyMMdd");
    private SimpleDateFormat YYYYMMDD_HHMMSS = new SimpleDateFormat("yyyyMMdd HHmmss");

    @Autowired
    private FinanceService financeService;

    //生成csv文件
    public void generateReportCSV() {
        //查询结果集
        HashMap<String, Object> filterMap = new HashMap<>();
//        String consumptionStartDate = getConsumptionStartDate();
//        String consumptionEndDate = getconsumptionEndDate();
//        String dataDate = getdataDate();
        String consumptionStartDate = "20181201";
        String consumptionEndDate = "20181231";
        String dataDate = "201812";
        filterMap.put("consumptionStartDate", consumptionStartDate);
        filterMap.put("consumptionEndDate", consumptionEndDate);
        filterMap.put("dataDate", dataDate);
        List<FinanceReportToEmaView> resultList = financeService.selectReportToEma(filterMap);

        String createDate = YYYYMMDD.format(new Date());
        //HEADER
        List<Object> headerList = generateHeader(createDate);
        //Detail
        List<Object> detailList = generateDetail(consumptionStartDate, consumptionEndDate, resultList);
        //TRAILER
        List<Object> trailerList = generateTrailer(resultList);

        generateCSVFile(headerList, createDate, detailList, trailerList);
    }

    private List<Object> generateTrailer(List<FinanceReportToEmaView> resultList) {
        List<Object> trailerList = new ArrayList<>();
        int size = resultList.size();//refund记录数
        size += 2;
        String count = String.valueOf(size);
        EMAFooterBean emaFooterBean = new EMAFooterBean();
        emaFooterBean.setTrailerRecordType("9");
        emaFooterBean.setTotalRecords(count);
        trailerList.add(emaFooterBean);
        return trailerList;
    }

    private List<Object> generateDetail(String consumptionStartDate, String consumptionEndDate, List<FinanceReportToEmaView> resultList) {
        List<Object> detailList = new ArrayList<>();
        if (resultList != null && resultList.size() > 0) {
            for (FinanceReportToEmaView financeView : resultList) {
                EMADetailBean emaDetailBean = new EMADetailBean();
                emaDetailBean.setDetailRecordType("1");//recordtype
                String ppmsAccNo = financeView.getAccNo();//ebsAccNo
                String ebsAccNo = ppmsAccNo.substring(0, ppmsAccNo.length() - 1);
                emaDetailBean.setEbsAccNo(ebsAccNo);
                String txnType = financeView.getTxnType();//txnType
                emaDetailBean.setTxnType(txnType);
                /*if (StringUtils.isNotEmpty(txnType) && txnType.equals(FinanceConstants.TXN_STATUS.TOPUP.getTxnStatus())) {//充值
                    emaDetailBean.setTxnType(FinanceConstants.TXN_TYPE.TOPUP.getTxnType());
                } else if (StringUtils.isNotEmpty(txnType) && txnType.equals(FinanceConstants.TXN_STATUS.ACCOUNT_OPENING.getTxnStatus())) {//开户
                    emaDetailBean.setTxnType(FinanceConstants.TXN_TYPE.NEW_ACCOUNT.getTxnType());
                } else if (StringUtils.isEmpty(txnType)) {//consumption
                    emaDetailBean.setTxnType(FinanceConstants.TXN_TYPE.CONSUMPTION_DETAILS.getTxnType());
                }//没有销户*/
                //sequence
                Long sequence = financeView.getSequence();
                emaDetailBean.setSequence(String.valueOf(sequence));
                //topupAmt
                BigDecimal topupAmt = financeView.getTopupAmt();
                if (topupAmt != null) {
                    emaDetailBean.setTopupAmt(topupAmt.multiply(new BigDecimal(Math.pow(10, 2))).toString());
                }
                //consumption
                BigDecimal consumption = financeView.getConsumption();
                if (consumption != null) {
                    emaDetailBean.setConsumption(consumption.toString());
                }

                Date txnDate = financeView.getTxnDate();
                if (txnDate != null) {
                    String stxnDate = YYYYMMDD_HHMMSS.format(txnDate);
                    List<String> strings = Arrays.asList(stxnDate.split(" "));
                    String sDate = strings.get(0);
                    String sTime = strings.get(1);
                    //txndate
                    emaDetailBean.setTxnDate(sDate);
                    //txntime
                    emaDetailBean.setTxnTime(sTime);
                } else {
                    //查询该户最后一次充值的日期(并未限定是上个月最后一次)
                    HashMap<String, Object> topupRecMap = new HashMap<>();
                    topupRecMap.put("accNo", financeView.getAccNo());
                    List<TotalTopupRec> totalTopupRecs = financeService.selectLatestTopupDateByAccNo(topupRecMap);
                    if (totalTopupRecs != null && totalTopupRecs.size() > 0) {
                        TotalTopupRec totalTopupRec = totalTopupRecs.get(0);
                        Date latestTopupTxnDate = totalTopupRec.getTxnDate();
                        String slatestTopupTxnDate = YYYYMMDD_HHMMSS.format(latestTopupTxnDate);
                        List<String> strings = Arrays.asList(slatestTopupTxnDate.split(" "));
                        String date = strings.get(0);
                        String time = strings.get(1);
                        emaDetailBean.setTxnDate(date);
                        emaDetailBean.setTxnTime(time);
                    }
                    emaDetailBean.setConsumptionStartDate(consumptionStartDate);
                    emaDetailBean.setConsumptionEndDate(consumptionEndDate);
                }

                detailList.add(emaDetailBean);
            }
        }
        return detailList;
    }

    private List<Object> generateHeader(String createDate) {
        List<Object> headerList = new ArrayList<>();
        RefundHeaderBean refundHeaderBean = new RefundHeaderBean();
        refundHeaderBean.setHeaderRecordType("0");
        refundHeaderBean.setCreateDate(createDate);
        headerList.add(refundHeaderBean);
        return headerList;
    }

    private void generateCSVFile(List<Object> headerList, String createDate, List<Object> detailList, List<Object> trailerList) {
        if (detailList != null && detailList.size() > 0) {
            Properties properties = PropertiesUtil.readProperties("finance.properties");
            String tomorrow = DateUtils.format(DateUtil.getSettedDay(new Date(), 1), DateUtils.DATE_PATTERN_EASY);
            String path = properties.getProperty("FinanceReportToEmaJobRoot") + tomorrow;
            String fileName = "mema2_" + tomorrow + ".csv";
            String filePath = path + "/" + fileName;

            long start = System.currentTimeMillis();
            String startTime = DateUtils.format(new Date(), DateUtils.DATE_TIME_PATTERN);
            logger.info("::::::生成ema文件开始时间::" + startTime);

            CSVUtil.createFile(filePath, headerList, detailList, trailerList);//路径,header,detail,trailer
            logger.info("::::::Transfer data to EBS for finance report to EMA CSV文件已生成, 路径为::" + filePath);

            String endTime = DateUtils.format(new Date(), DateUtils.DATE_TIME_PATTERN);
            logger.info("::::::生成ema文件结束时间::" + endTime);
            logger.info("::::::生成ema文件总耗时::" + ((System.currentTimeMillis() - start)) + "ms");
        } else {
            logger.info(createDate + "::::::Transfer data to EBS for finance report to EMA记录为空,不生成文件.");
        }
    }

    private String getdataDate() {
        //获取上月月份dataDate 格式yyyyMM
        Calendar calendar3 = Calendar.getInstance();
        calendar3.add(Calendar.MONTH, -1);
        return YYYYMM.format(calendar3.getTime());
    }

    private String getconsumptionEndDate() {
        //获取系统当前时间上月的最后一天consumptionEndDate 格式yyyy-MM-dd
        Calendar calendar2 = Calendar.getInstance();
        calendar2.set(Calendar.DAY_OF_MONTH, 0);
        return YYYYMMDD.format(calendar2.getTime());
    }

    private String getConsumptionStartDate() {
        //获取系统当前时间上月的第一天consumptionStartDate 格式yyyy-MM-dd
        Calendar calendar1 = Calendar.getInstance();
        calendar1.add(Calendar.MONTH, -1);
        calendar1.set(Calendar.DAY_OF_MONTH, 1);//设置为1号,当前日期既为本月第一天
        return YYYYMMDD.format(calendar1.getTime());
    }

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        try {
            generateReportCSV();
        } catch (Exception e) {
            logger.error("::::::Transfer data to EBS for finance report to EMA CSV文件失败::" + e);
        }
    }

}
