package com.ppms.accountInfoUpdate.dao;

import org.jeecgframework.core.common.model.json.DataGrid;

import javax.servlet.http.HttpServletRequest;

/**
 * @Auther: liangyadong
 * @Date: 2018/11/19 0019 17:17
 * @Description:
 */
public interface AccountInfoUpdateDaoI {
    void queryInfoForUpdateMobilephone(HttpServletRequest request, DataGrid dataGrid);

    void queryInfoForUpdatePercentage(HttpServletRequest request, DataGrid dataGrid);

    void queryInfoForUpdateAccountStatus(HttpServletRequest request, DataGrid dataGrid);
}
