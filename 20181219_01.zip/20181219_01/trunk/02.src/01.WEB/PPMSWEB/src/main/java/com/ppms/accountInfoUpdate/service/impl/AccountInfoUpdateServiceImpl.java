package com.ppms.accountInfoUpdate.service.impl;

import com.constants.AccountStatusEnum;
import com.ppms.accountInfoUpdate.dao.AccountInfoUpdateDaoI;
import com.ppms.accountInfoUpdate.service.AccountInfoUpdateServiceI;
import com.ppms.accountInfoUpdate.vo.CustomerVo;
import com.ppms.entity.CustomerInfoEntity;
import com.ppms.utils.DataSourceValue;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.common.service.impl.CommonServiceImpl;
import org.jeecgframework.core.extend.datasource.DataSourceType;
import org.jeecgframework.core.util.oConvertUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @Auther: liangyadong
 * @Date: 2018/11/19 0019 17:12
 * @Description:
 */
@Service
@DataSourceValue(DataSourceType.dataSource_ppms)
public class AccountInfoUpdateServiceImpl extends CommonServiceImpl implements AccountInfoUpdateServiceI {

    @Autowired
    private AccountInfoUpdateDaoI accountInfoUpdateDao;

    @Override
    public void queryInfoForUpdateMobilephone(HttpServletRequest request, DataGrid dataGrid) {
        accountInfoUpdateDao.queryInfoForUpdateMobilephone(request, dataGrid);
        List list = dataGrid.getResults();
        List<CustomerVo> resultList = new ArrayList();
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                Object[] obj = (Object[]) list.get(i);
                CustomerVo customerVo = new CustomerVo();
                customerVo.setAccNo(oConvertUtils.isEmpty(obj[0]) ? "--" : obj[0].toString());
                customerVo.setTelephoneNumber(oConvertUtils.isEmpty(obj[1]) ? "--" : obj[1].toString());
                customerVo.setAccountStatus(oConvertUtils.isEmpty(obj[2]) ? "" : obj[2].toString());
                customerVo.setAddress(oConvertUtils.isEmpty(obj[3]) ? "--" : obj[3].toString());
                customerVo.setMeterId(oConvertUtils.isEmpty(obj[4]) ? "--" : obj[4].toString());
                resultList.add(customerVo);
            }
        }

        dataGrid.setResults(resultList);
    }

    @Override
    public void queryInfoForUpdatePercentage(HttpServletRequest request, DataGrid dataGrid) {
        accountInfoUpdateDao.queryInfoForUpdatePercentage(request, dataGrid);
        List list = dataGrid.getResults();
        List<CustomerVo> resultList = new ArrayList();
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                Object[] obj = (Object[]) list.get(i);
                CustomerVo customerVo = new CustomerVo();
                customerVo.setAccNo(oConvertUtils.isEmpty(obj[0]) ? "--" : obj[0].toString());
                customerVo.setTelephoneNumber(oConvertUtils.isEmpty(obj[1]) ? "--" : obj[1].toString());
                customerVo.setAccountStatus(oConvertUtils.isEmpty(obj[2]) ? "" : obj[2].toString());
                BigDecimal revertPct = null;
                if (oConvertUtils.isNotEmpty(obj[3])) {
                    revertPct = new BigDecimal(obj[3].toString()).multiply(new BigDecimal(100)).setScale(0);
                }
                customerVo.setArrearPct(revertPct);
                customerVo.setMeterId(oConvertUtils.isEmpty(obj[4]) ? "--" : obj[4].toString());
                customerVo.setAddress(oConvertUtils.isEmpty(obj[5]) ? "--" : obj[5].toString());
                resultList.add(customerVo);
            }
        }

        dataGrid.setResults(resultList);
    }

    @Override
    public void queryInfoForUpdateAccountStatus(HttpServletRequest request, DataGrid dataGrid) {
        accountInfoUpdateDao.queryInfoForUpdateAccountStatus(request, dataGrid);
        List list = dataGrid.getResults();
        List<CustomerVo> resultList = new ArrayList();
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                Object[] obj = (Object[]) list.get(i);
                CustomerVo customerVo = new CustomerVo();
                customerVo.setAccNo(oConvertUtils.isEmpty(obj[0]) ? "--" : obj[0].toString());
                customerVo.setTelephoneNumber(oConvertUtils.isEmpty(obj[1]) ? "--" : obj[1].toString());
                customerVo.setAccountStatus(oConvertUtils.isEmpty(obj[2]) ? "" : obj[2].toString());
                customerVo.setMeterId(oConvertUtils.isEmpty(obj[3]) ? "--" : obj[3].toString());
                customerVo.setZ3Number(oConvertUtils.isEmpty(obj[4]) ? "--" : obj[4].toString());
                customerVo.setOpenDate((Date) obj[5]);
                customerVo.setActivationDate((Date) obj[6]);
                customerVo.setAddress(oConvertUtils.isEmpty(obj[7]) ? "--" : obj[7].toString());
                resultList.add(customerVo);
            }
        }

        dataGrid.setResults(resultList);
    }

    @Override
    public CustomerInfoEntity getAccountById(String accNo) {
        CustomerInfoEntity customerInfoEntity = this.getEntity(CustomerInfoEntity.class, accNo);
        return customerInfoEntity;
    }

    /**
     * @description: 更新telephone number
     * @auther: liangyadong
     * @date: 2018/11/21 0021 上午 9:30
     */
    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ, rollbackForClassName = {"Exception.class"})
    public String doUpdateTel(HttpServletRequest request) {
        String message = "";
        //更新记录A_CUSTOMER_INFO
        String accNo = request.getParameter("accNo");
        String telephoneNumber = request.getParameter("telephoneNumber");
        CustomerInfoEntity customerEntity = this.getAccountById(accNo);
        String oldNumber = customerEntity.getTelephoneNumber();

        //校验accountStatus
        String accountStatus = customerEntity.getAccountStatus();
        if (accountStatus.equals(AccountStatusEnum.CLOSED.getStatus())) {
            message = "Account closed, refused to modify";
            return message;
        }

        //校验telephoneNumber
        boolean telReg = telephoneNumber.matches("^[0-9]{8}$");
        if (!telReg) {
            message = "Incorrect format, please re-enter";
            return message;
        }

        customerEntity.setTelephoneNumber(telephoneNumber);
        super.save(customerEntity);
        message = "Mobilephone number update successful.";
        return message;
    }

    /**
     * @description: 更新arrear percentage
     * @auther: liangyadong
     * @date: 2018/11/21 0021 上午 10:33
     */
    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ, rollbackForClassName = {"Exception.class"})
    public String doUpdatePerc(HttpServletRequest request) {
        String message = "";
        //更新记录A_CUSTOMER_INFO
        String accNo = request.getParameter("accNo");
        String sarrearPct = request.getParameter("arrearPct");
        BigDecimal arrearPct = new BigDecimal(sarrearPct).divide(new BigDecimal(100));
        CustomerInfoEntity customerEntity = this.getAccountById(accNo);

        //校验accountStatus
        String accountStatus = customerEntity.getAccountStatus();
        if (accountStatus.equals(AccountStatusEnum.CLOSED.getStatus())) {
            message = "Account closed, refused to modify";
            return message;
        }

        //校验arrearPct
        /*boolean pctReg = sarrearPct.matches("^0\\.\\d*[1-9]\\d*$");//0-1小数
        if(!pctReg){
            message = "Incorrect format, please re-enter";
            return message;
        }*/

        BigDecimal oldPerc = customerEntity.getArrearPct();
        customerEntity.setArrearPct(arrearPct);
        super.save(customerEntity);
        message = "Arrear percentage update successful.";
        return message;
    }

    /**
     * @description: 终止激活
     * @auther: liangyadong
     * @date: 2018/11/21 0021 上午 10:33
     */
    @Override
    public String doTerminal(HttpServletRequest request) {
        String message = "";
        //更新记录A_CUSTOMER_INFO
        String accNo = request.getParameter("accNo");
        CustomerInfoEntity customerEntity = this.getAccountById(accNo);

        //校验accountStatus
        String accountStatus = customerEntity.getAccountStatus();
        if (accountStatus.equals(AccountStatusEnum.CLOSED.getStatus())) {
            message = "Account closed, refused to modify";
            return message;
        } else if (accountStatus.equals(AccountStatusEnum.ACTIVATED.getStatus())) {
            message = "Account activated, refused to modify.";
            return message;
        }

        customerEntity.setAccountStatus(AccountStatusEnum.CANCELLED.getStatus());
        super.save(customerEntity);
        message = "Account activation cancel successful.";
        return message;
    }

}
