package com.ppms.accountInfoUpdate.controller;

import com.ppms.accountInfoUpdate.service.AccountInfoUpdateServiceI;
import com.ppms.entity.CustomerInfoEntity;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;

/**
 * @Auther: liangyadong
 * @Date: 2018/11/19 0019 16:59
 * @Description:
 */
@Controller
@RequestMapping("/accountInfoUpdateController")
public class AccountInfoUpdateController {

    @Autowired
    private AccountInfoUpdateServiceI accountInfoUpdateService;

    @RequestMapping(params = "telnumberUpdate")
    public ModelAndView telnumberUpdate() {
        return new ModelAndView("ppms/customerManagement/telnumberUpdate/telnumber_update");
    }

    @RequestMapping(params = "percentageUpdate")
    public ModelAndView percentageUpdate() {
        return new ModelAndView("ppms/customerManagement/percentageUpdate/percentage_update");
    }

    @RequestMapping(params = "accountStatusUpdate")
    public ModelAndView accountStatusUpdate() {
        return new ModelAndView("ppms/customerManagement/accountStatusUpdate/account_status_update");
    }

    @RequestMapping(params = "goUpdateTel")
    public ModelAndView goUpdateTel(HttpServletRequest request) {
        String accNo = request.getParameter("accNo");
        CustomerInfoEntity customerEntity = accountInfoUpdateService.getAccountById(accNo);
        ModelAndView mv = new ModelAndView("ppms/customerManagement/telnumberUpdate/go_update_tel");
        mv.addObject("customerEntity", customerEntity);
        return mv;
    }

    @RequestMapping(params = "goUpdatePerc")
    public ModelAndView goUpdatePerc(HttpServletRequest request) {
        String accNo = request.getParameter("accNo");
        CustomerInfoEntity customerEntity = accountInfoUpdateService.getAccountById(accNo);
        customerEntity.setArrearPct(customerEntity.getArrearPct().multiply(new BigDecimal(100)).setScale(0));
        ModelAndView mv = new ModelAndView("ppms/customerManagement/percentageUpdate/go_update_percentage");
        mv.addObject("customerEntity", customerEntity);
        return mv;
    }

    /*修改mobilePhone*/
    @RequestMapping(params = "accountInfoForUpdateMobilephone")
    public void accountInfoForUpdateMobilephone(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        accountInfoUpdateService.queryInfoForUpdateMobilephone(request, dataGrid);
        TagUtil.datagrid(response, dataGrid);
    }

    /*修改arrrear percentage*/
    @RequestMapping(params = "accountInfoForUpdatePercentage")
    public void accountInfoForUpdateArrearPercentage(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        accountInfoUpdateService.queryInfoForUpdatePercentage(request, dataGrid);
        TagUtil.datagrid(response, dataGrid);
    }

    /*修改account status*/
    @RequestMapping(params = "accountInfoForUpdateAccountStatus")
    public void accountInfoForUpdateAccountStatus(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        accountInfoUpdateService.queryInfoForUpdateAccountStatus(request, dataGrid);
        TagUtil.datagrid(response, dataGrid);
    }

    @RequestMapping(params = "doUpdateTel")
    @ResponseBody
    public AjaxJson doUpdateTel(HttpServletRequest request) {
        AjaxJson j = new AjaxJson();
        String message = accountInfoUpdateService.doUpdateTel(request);
        j.setMsg(message);
        return j;
    }

    @RequestMapping(params = "doUpdatePerc")
    @ResponseBody
    public AjaxJson doUpdatePerc(HttpServletRequest request) {
        AjaxJson j = new AjaxJson();
        String message = accountInfoUpdateService.doUpdatePerc(request);
        j.setMsg(message);
        return j;
    }

    @RequestMapping(params = "doTerminal")
    @ResponseBody
    public AjaxJson doTerminal(HttpServletRequest request) {
        AjaxJson j = new AjaxJson();
        String message = accountInfoUpdateService.doTerminal(request);
        j.setMsg(message);
        return j;
    }
}
