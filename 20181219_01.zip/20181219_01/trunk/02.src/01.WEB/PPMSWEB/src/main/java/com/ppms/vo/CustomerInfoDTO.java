package com.ppms.vo;

import com.ppms.entity.AcctBalEntity;
import com.ppms.entity.MeterInfoEntity;
import org.codehaus.jackson.annotate.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;

public class CustomerInfoDTO {

    private String accNo;
    /**name*/
    private String name;
    /**nric*/
    private String nric;
    /**installationNumber*/
    private String installationNumber;
    /**salutation*/
    private String salutation;
    /**address*/
    private String address;
    /**premiseType*/
    private String premiseType;
    /**blockNumber*/
    private String blockNumber;
    /**streetName*/
    private String streetName;
    /**unitNumber*/
    private String unitNumber;
    /**postalCode*/
    private String postalCode;
    /**mailAddr*/
    private String mailAddr;
    /**emailAddr*/
    private String emailAddr;
    /**telephoneNumber*/
    private String telephoneNumber;
    /**faxNumber*/
    private String faxNumber;
    /**mobileNumber*/
    private String mobileNumber;
    /**tariffCode*/
    private String tariffCode;
    /**gstCode*/
    private String gstCode;
    /**presetCredit*/
    private BigDecimal presetCredit;
    /**emergencyCredit*/
    private BigDecimal emergencyCredit;
    /**emergencyState*/
    private String emergencyState;
    /**lowCreditAlarm*/
    private BigDecimal lowCreditAlarm;
    /**disconnectAlarm*/
    private BigDecimal disconnectAlarm;
    /** '01：创建（待激活）
     02：激活（允许充值）
     03：暂停
     99：销户;',*/
    private String accountStatus;
    /**openDate*/
    private Date openDate;
    /**sheduledActivationDate*/
    private Date sheduledActivationDate;
    /**activationDate*/
    private Date activationDate;
    /**closeDate*/
    private Date closeDate;
    /**initReads*/
    private BigDecimal initReads;
    /**finalReads*/
    private BigDecimal finalReads;
    /**customer type
     01- EBS (Postpaid - prepaid)
     02- PAYU*/
    private String type;
    /**delFlag*/
    private String delFlag;
    /**arrear percentage
     */
    private BigDecimal arrearPct;

    private java.lang.Integer printCardTimes;

    private String meterId;

    private String balance;

    private String errorMsg;

    private boolean succeed;

    private Date minActivationDate;

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public boolean isSucceed() {
        return succeed;
    }

    public void setSucceed(boolean succeed) {
        this.succeed = succeed;
    }

    public String getAccNo() {
        return accNo;
    }

    public void setAccNo(String accNo) {
        this.accNo = accNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNric() {
        return nric;
    }

    public void setNric(String nric) {
        this.nric = nric;
    }

    public String getInstallationNumber() {
        return installationNumber;
    }

    public void setInstallationNumber(String installationNumber) {
        this.installationNumber = installationNumber;
    }

    public String getSalutation() {
        return salutation;
    }

    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPremiseType() {
        return premiseType;
    }

    public void setPremiseType(String premiseType) {
        this.premiseType = premiseType;
    }

    public String getBlockNumber() {
        return blockNumber;
    }

    public void setBlockNumber(String blockNumber) {
        this.blockNumber = blockNumber;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getUnitNumber() {
        return unitNumber;
    }

    public void setUnitNumber(String unitNumber) {
        this.unitNumber = unitNumber;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getMailAddr() {
        return mailAddr;
    }

    public void setMailAddr(String mailAddr) {
        this.mailAddr = mailAddr;
    }

    public String getEmailAddr() {
        return emailAddr;
    }

    public void setEmailAddr(String emailAddr) {
        this.emailAddr = emailAddr;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getTariffCode() {
        return tariffCode;
    }

    public void setTariffCode(String tariffCode) {
        this.tariffCode = tariffCode;
    }

    public String getGstCode() {
        return gstCode;
    }

    public void setGstCode(String gstCode) {
        this.gstCode = gstCode;
    }

    public BigDecimal getPresetCredit() {
        return presetCredit;
    }

    public void setPresetCredit(BigDecimal presetCredit) {
        this.presetCredit = presetCredit;
    }

    public BigDecimal getEmergencyCredit() {
        return emergencyCredit;
    }

    public void setEmergencyCredit(BigDecimal emergencyCredit) {
        this.emergencyCredit = emergencyCredit;
    }

    public String getEmergencyState() {
        return emergencyState;
    }

    public void setEmergencyState(String emergencyState) {
        this.emergencyState = emergencyState;
    }

    public BigDecimal getLowCreditAlarm() {
        return lowCreditAlarm;
    }

    public void setLowCreditAlarm(BigDecimal lowCreditAlarm) {
        this.lowCreditAlarm = lowCreditAlarm;
    }

    public BigDecimal getDisconnectAlarm() {
        return disconnectAlarm;
    }

    public void setDisconnectAlarm(BigDecimal disconnectAlarm) {
        this.disconnectAlarm = disconnectAlarm;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public Date getOpenDate() {
        return openDate;
    }

    public void setOpenDate(Date openDate) {
        this.openDate = openDate;
    }

    public Date getSheduledActivationDate() {
        return sheduledActivationDate;
    }

    public void setSheduledActivationDate(Date sheduledActivationDate) {
        this.sheduledActivationDate = sheduledActivationDate;
    }

    public Date getActivationDate() {
        return activationDate;
    }

    public void setActivationDate(Date activationDate) {
        this.activationDate = activationDate;
    }

    public Date getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(Date closeDate) {
        this.closeDate = closeDate;
    }

    public BigDecimal getInitReads() {
        return initReads;
    }

    public void setInitReads(BigDecimal initReads) {
        this.initReads = initReads;
    }

    public BigDecimal getFinalReads() {
        return finalReads;
    }

    public void setFinalReads(BigDecimal finalReads) {
        this.finalReads = finalReads;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public BigDecimal getArrearPct() {
        return arrearPct;
    }

    public void setArrearPct(BigDecimal arrearPct) {
        this.arrearPct = arrearPct;
    }

    public Integer getPrintCardTimes() {
        return printCardTimes;
    }

    public void setPrintCardTimes(Integer printCardTimes) {
        this.printCardTimes = printCardTimes;
    }

    public String getMeterId() {
        return meterId;
    }

    public void setMeterId(String meterId) {
        this.meterId = meterId;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public Date getMinActivationDate() {
        return minActivationDate;
    }

    public void setMinActivationDate(Date minActivationDate) {
        this.minActivationDate = minActivationDate;
    }
}
