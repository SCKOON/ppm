package com.ppms.accountInfoUpdate.vo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Auther: liangyadong
 * @Date: 2018/11/20 0020 11:06
 * @Description:
 */
public class CustomerVo {
    private String accNo;
    private String premiseType;
    private String blockNumber;
    private String streetName;
    private String unitNumber;
    private String telephoneNumber;
    private String accountStatus;
    private BigDecimal arrearPct;
    private String address;
    private String meterId;
    private Date openDate;
    private Date activationDate;
    private String z3Number;

    public String getAccNo() {
        return accNo;
    }

    public void setAccNo(String accNo) {
        this.accNo = accNo;
    }

    public String getPremiseType() {
        return premiseType;
    }

    public void setPremiseType(String premiseType) {
        this.premiseType = premiseType;
    }

    public String getBlockNumber() {
        return blockNumber;
    }

    public void setBlockNumber(String blockNumber) {
        this.blockNumber = blockNumber;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getUnitNumber() {
        return unitNumber;
    }

    public void setUnitNumber(String unitNumber) {
        this.unitNumber = unitNumber;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public BigDecimal getArrearPct() {
        return arrearPct;
    }

    public void setArrearPct(BigDecimal arrearPct) {
        this.arrearPct = arrearPct;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMeterId() {
        return meterId;
    }

    public void setMeterId(String meterId) {
        this.meterId = meterId;
    }

    public Date getOpenDate() {
        return openDate;
    }

    public void setOpenDate(Date openDate) {
        this.openDate = openDate;
    }

    public Date getActivationDate() {
        return activationDate;
    }

    public void setActivationDate(Date activationDate) {
        this.activationDate = activationDate;
    }

    public String getZ3Number() {
        return z3Number;
    }

    public void setZ3Number(String z3Number) {
        this.z3Number = z3Number;
    }
}
