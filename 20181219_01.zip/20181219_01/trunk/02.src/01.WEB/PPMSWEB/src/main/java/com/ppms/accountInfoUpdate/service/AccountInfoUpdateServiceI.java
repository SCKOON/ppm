package com.ppms.accountInfoUpdate.service;

import com.ppms.entity.CustomerInfoEntity;
import org.jeecgframework.core.common.model.json.DataGrid;

import javax.servlet.http.HttpServletRequest;

/**
 * @Auther: liangyadong
 * @Date: 2018/11/19 0019 17:12
 * @Description:
 */
public interface AccountInfoUpdateServiceI {
    void queryInfoForUpdateMobilephone(HttpServletRequest request, DataGrid dataGrid);

    void queryInfoForUpdatePercentage(HttpServletRequest request, DataGrid dataGrid);

    void queryInfoForUpdateAccountStatus(HttpServletRequest request, DataGrid dataGrid);

    CustomerInfoEntity getAccountById(String accNo);

    String doUpdateTel(HttpServletRequest request);

    String doUpdatePerc(HttpServletRequest request);

    String doTerminal(HttpServletRequest request);

}
