package com.ppms.creditTopup.dao.impl;

import com.ppms.creditTopup.dao.TopupDao;
import com.ppms.entity.*;
import com.ppms.ldapLogin.util.ResourceUtils;
import com.ppms.utils.DataReturn;
import com.ppms.utils.MathMoneyUtils;
import com.ppms.vo.RefundApplyListVo;
import com.ppms.vo.ResultVo;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.jeecgframework.core.common.dao.impl.GenericBaseCommonDao;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.util.StringUtil;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.p3.core.logger.Logger;
import org.jeecgframework.p3.core.logger.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by yadongliang on 2018/5/7 0007.
 */
@Repository
public class TopupDaoImpl extends GenericBaseCommonDao implements TopupDao {
    private static Logger logger = LoggerFactory.getLogger(TopupDaoImpl.class);
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * @description: 查询客户信息
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 4:46
     */
    @Override
    public DataReturn getAllEntities(ResultVo resultVo, int page, int rows, HttpServletRequest request) {

        StringBuilder sql = new StringBuilder(
                " SELECT " +
                " a.acc_no as accNo, " +
                " a.address as address, " +
                " a.premise_type as premiseType, " +
                " b.BALANCE as balance, " +
                " m.meter_id as meterId, " +
                " a.account_status, " +
                " a.arrear_pct " +
                " FROM " +
                " A_CUSTOMER_INFO a " +
                " LEFT JOIN A_ACCT_BAL b ON a.acc_no = b.ACC_NO " +
                " LEFT JOIN A_METER_INFO m ON a.acc_no = m.acc_no " +
                " WHERE a.account_status = '90' "+//90  -  已激活
                " and m.meter_status = '03'"
        );

        StringBuilder condition = new StringBuilder("");
        ArrayList params = new ArrayList();
        String accNo = request.getParameter("accNo");
//        String accNo = resultVo.getAccNo();
        String address = resultVo.getAddress();
        String premiseType = resultVo.getPremiseType();
        String meterId = resultVo.getMeterId();
        if (accNo != null && !"".equals(accNo)) {
            condition.append(" and a.acc_no like ? ");
            params.add("%" + accNo + "%");
        }
        if (address != null && !"".equals(address)) {
            condition.append(" and a.address = ? ");
            params.add(address);
        }
        if (premiseType != null && !"".equals(premiseType)) {
            condition.append(" and a.premise_type = ? ");
            params.add(premiseType);
        }
        if (meterId != null && !"".equals(meterId)) {
            condition.append(" and m.meter_id like ? ");
            params.add("%" + meterId + "%");
        }
        String sqlQuery = sql.append(condition.toString()).toString();
        Query q = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }

        List objectList = q.list();
        int count = 0;
        if (objectList != null && objectList.size() > 0) {
            count = objectList.size();
        }

        q.setFirstResult((page - 1) * rows).setMaxResults(rows);
        List<Object[]> list = q.list();

        List<ResultVo> resultVos = new ArrayList<>();

        DecimalFormat df = new DecimalFormat("0.00");
        if (list != null && list.size() > 0) {
            ResultVo resultVo1 = null;
            for (int i = 0; i < list.size(); i++) {
                resultVo1 = new ResultVo();
                Object[] objects = list.get(i);
                if (objects != null) {
                    resultVo1.setAccNo(objects[0] != null ? (String) objects[0] : "--");
                    resultVo1.setAddress(objects[1] != null ? (String) objects[1] : "--");
                    resultVo1.setPremiseType(objects[2] != null ? (String) objects[2] : "--");
                    if (objects[3] != null) {
                        BigDecimal big3 = ((BigDecimal) objects[3]).setScale(2, BigDecimal.ROUND_DOWN);
                        double db3 = big3.doubleValue();
                        String format = df.format(db3);
                        BigDecimal bigbal = new BigDecimal(format);
                        resultVo1.setBalance(bigbal);
                    }
                    resultVo1.setMeterId(objects[4] != null ? (String) objects[4] : "--");
                    resultVo1.setAccountStatus(objects[5] != null ? (String) objects[5] : "--");
                    resultVo1.setArrearPct(objects[6] != null ? (BigDecimal) objects[6] : new BigDecimal(0));
                    resultVos.add(resultVo1);
                }
            }
        }

        DataReturn data = new DataReturn();
        data.setRows(resultVos);
        data.setTotal(count);

        return data;
    }

    /**
     * @description: 冲正/充值记录查询-充值记录查询
     * @auther: liangyadong
     * @date: 2018/9/30 0030 上午 9:18
     */
    @Override
    public void getTopupRecord(DataGrid dataGrid, HttpServletRequest request, String curLoginName) {

        /*01- Top-up 02- 已冲正 03- reverse*/
        StringBuilder hql = new StringBuilder("from SpTopUpRecEntity where txnStatus in ('01','02','03') ");
        Map<String, Object> map = new HashMap();
        if (oConvertUtils.isNotEmpty(curLoginName)) {
            hql.append(" and cashierId = :cashierId ");
            map.put("cashierId", curLoginName);
        }

        String accNo = request.getParameter("accNo");
        if (oConvertUtils.isNotEmpty(accNo)) {
            hql.append(" and accNo like :accNo ");
            map.put("accNo","%" + accNo + "%");
        }
        String txnDate1 = request.getParameter("txnDate1");
        if (oConvertUtils.isNotEmpty(txnDate1)) {
            hql.append(" and txnDate >= :txnDate1 ");
            try {
                map.put("txnDate1",sdf.parse(txnDate1));
            } catch (ParseException e) {
                logger.error(e.getMessage(),e);
            }
        }
        String txnDate2 = request.getParameter("txnDate2");
        if (oConvertUtils.isNotEmpty(txnDate2)) {
            hql.append(" and txnDate <= :txnDate2 ");
            try {
                map.put("txnDate2",sdf.parse(txnDate2));
            } catch (ParseException e) {
                logger.error(e.getMessage(),e);
            }
        }
        String stopupAmt = request.getParameter("topupAmt");
        if (oConvertUtils.isNotEmpty(stopupAmt)) {
            BigDecimal topupAmt = new BigDecimal(stopupAmt);
            hql.append(" and topupAmt = :topupAmt ");
            map.put("topupAmt",topupAmt);
        }
        String counterId = request.getParameter("counterId");
        if (oConvertUtils.isNotEmpty(counterId)) {
            hql.append(" and counterId = :counterId ");
            map.put("counterId",counterId);
        }
        String tmnlCode = request.getParameter("tmnlCode");
        if (oConvertUtils.isNotEmpty(tmnlCode)) {
            hql.append(" and tmnlCode = :tmnlCode ");
            map.put("tmnlCode",tmnlCode);
        }
        String cashierId = request.getParameter("cashierId");
        if (cashierId != null && !"".equals(cashierId)) {
            hql.append(" and cashierId like :cashierId ");
            map.put("cashierId","%" + cashierId + "%");
        }
        String refNo = request.getParameter("refNo");
        if (oConvertUtils.isNotEmpty(refNo)) {
            hql.append(" and refNo = :refNo ");
            map.put("refNo",refNo);
        }

        if (oConvertUtils.isNotEmpty(dataGrid.getSort())) {
            hql.append(" order by " + dataGrid.getSort() + " " + dataGrid.getOrder());
        }

        String hqlQuery = hql.toString();
        Query query = getSession().createQuery(hqlQuery);
        query.setProperties(map);
        List<SpTopUpRecEntity> list = query.list();
        super.paginateDataGrid(list,dataGrid,query);
    }

    /**
     * @description: 充值-充值记录查询
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 2:33
     */
    @Override
    public void getCreditTopupRec(DataGrid dataGrid, HttpServletRequest request) {
        StringBuilder sql = new StringBuilder(
                " SELECT * FROM (SELECT " +
                " s.acc_no as accNo, " +
                " s.topup_amt as topupAmt, " +
                " s.prepaid_amt as prepaidAmt, " +
                " s.arrear_amt as arrearAmt, " +
                " s.cur_bal as curBal, " +
                " s.txn_date as txnDate, " +
                " s.pay_mode as payMode, " +
                " s.pay_no as payNo, " +
                " s.tmnl_code as tmnlCode, " +
                " s.counter_id as counterId, " +
                " s.cashier_id as cashierId, " +
                " s.txn_status as txnStatus " +
                " FROM " +
                " SP_TOPUP_REC s " +
                " UNION ALL " +
                " SELECT " +
                " c.acc_no as accNo, " +
                " c.topup_amt as topupAmt, " +
                " c.prepaid_amt as prepaidAmt, " +
                " c.arrear_amt as arrearAmt, " +
                " c.cur_bal as curBal, " +
                " c.txn_date as txnDate, " +
                " c.pay_mode as payMode, " +
                " c.pay_no as payNo, " +
                " c.tmnl_code as tmnlCode, " +
                " c.counter_id as counterId, " +
                " c.cashier_id as cashierId, " +
                " c.txn_status as txnStatus " +
                " FROM " +
                " CA_TOPUP_REC c) result " +
                " WHERE txnStatus in ('01','02','03') "//<> '06'
        );
        Map<String, Object> map = new HashMap();
        String accNo = request.getParameter("accNo");
        if (oConvertUtils.isNotEmpty(accNo)) {
            sql.append(" and accNo like :accNo ");
            map.put("accNo","%" + accNo + "%");
        }
        if (oConvertUtils.isNotEmpty(dataGrid.getSort())) {
            sql.append(" order by " + dataGrid.getSort() + " " + dataGrid.getOrder());
        }

        String sqlQuery = sql.toString();
        Query query = getSession().createSQLQuery(sqlQuery);
        query.setProperties(map);
        List list = query.list();
        super.paginateDataGrid(list,dataGrid,query);
    }

    /***
     * 更改txnStatus
     * @param topupRecord
     * @param status
     * @return
     * @throws Exception
     */
    @Override
    public Integer updateTxnStatus(SpTopUpRecEntity topupRecord, String status) throws Exception {
        String refNo = topupRecord.getRefNo();
        StringBuilder hql = new StringBuilder("update SpTopUpRecEntity set txnStatus= '").append(status).append("' where refNo = '").append(refNo).append("'");

        String hqlQuery = hql.toString();
        return this.executeHql(hqlQuery);
    }

    /**
     * @description: 退款申请-查询客户信息
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 4:47
     */
    @Override
    public DataReturn getCustomerInfo(CustomerInfoEntity customerInfoEntity, AcctBalEntity acctBalEntity, int page, int rows, HttpServletRequest request) {
        StringBuilder hql = new StringBuilder("from CustomerInfoEntity as c, AcctBalEntity as a where c.accNo = a.accNo");
        StringBuilder condition = new StringBuilder("");
        ArrayList params = new ArrayList();
        String accNo = customerInfoEntity.getAccNo();
        if (accNo != null && !"".equals(accNo)) {
            condition.append(" and c.accNo like ?");
            params.add("%" + accNo + "%");
        }
        String hqlQuery = hql.append(condition).toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        q.setFirstResult((page - 1) * rows).setMaxResults(rows);
        int count = this.findHql(hqlQuery, params.toArray()).size();
        List list = q.list();
        List<ResultVo> resultVoList = new ArrayList<>();
        DecimalFormat df = new DecimalFormat("0.00");

        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                ResultVo resultVo = new ResultVo();
                Object[] o = (Object[]) list.get(i);
                CustomerInfoEntity centity = (CustomerInfoEntity) o[0];
                AcctBalEntity aentity = (AcctBalEntity) o[1];
                resultVo.setAccNo(centity.getAccNo());
                resultVo.setAddress(centity.getAddress());
                resultVo.setAccountStatus(centity.getAccountStatus());
                resultVo.setTelephoneNumber(centity.getTelephoneNumber());
                //balance保留小数点后2位
                BigDecimal abalance = aentity.getBalance();
                double v = abalance.setScale(2, BigDecimal.ROUND_DOWN).doubleValue();
                String format1 = df.format(v);
                BigDecimal balance = new BigDecimal(format1);
                resultVo.setBalance(balance);
                resultVoList.add(resultVo);
            }
        }

        DataReturn data = new DataReturn();
        data.setRows(resultVoList);
        data.setTotal(count);

        return data;
    }

    /**
     * @description: 退款申请列表
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 4:47
     */
    @Override
    public DataReturn getRefundApplyDatagrid(RefundRecordEntity refundRecordEntity, CustomerInfoEntity customerInfoEntity, int page, int rows, HttpServletRequest request) {
        StringBuilder sql = new StringBuilder(
                " SELECT " +
                " c.acc_no, " +
                " c.telephone_number, " +
                " c.address, " +
                " r.last_bal, " +
                " r.cur_bal, " +
                " r.refund_amt, " +
                " r.apply_time, " +
                " r.apply_reason, " +
                " r.appr_status, " +
                " r.ID " +
                " FROM " +
                " A_CUSTOMER_INFO c, " +
                " REFUND_REC r where c.acc_no = r.acc_no "
        );

        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        String accNo = customerInfoEntity.getAccNo();
        if (accNo != null && !"".equals(accNo)) {
            condition.append(" and c.acc_no like ?");
            params.add("%" + accNo + "%");
        }
        String apprStatus = refundRecordEntity.getApprStatus();
        if (apprStatus != null && !"".equals(apprStatus)) {
            condition.append(" and r.appr_status = ?");
            params.add(apprStatus);
        }
        String applyTime1 = request.getParameter("applyTime1");
        if (applyTime1 != null && !"".equals(applyTime1)) {
            condition.append(" and r.apply_time >= ? ");
            try {
                params.add(sdf.parse(applyTime1));
            } catch (ParseException e) {
                logger.error(e.getMessage(),e);
            }
        }
        String applyTime2 = request.getParameter("applyTime2");
        if (applyTime2 != null && !"".equals(applyTime2)) {
            condition.append(" and r.apply_time <= ? ");
            Calendar calendar = Calendar.getInstance();
            try {
                calendar.setTime(sdf.parse(applyTime2));
            } catch (ParseException e) {
                logger.error(e.getMessage(),e);
            }
            calendar.add(Calendar.DAY_OF_MONTH, 1);
            params.add(calendar.getTime());
        }

        String sqlQuery = sql.append(condition.toString()).append(" ORDER BY apply_time DESC ").toString();
        Query q = getSession().createSQLQuery(sqlQuery);

        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }

        List objectList = q.list();
        int count = 0;
        if (objectList != null && objectList.size() > 0) {
            count = objectList.size();
        }

        q.setFirstResult((page - 1) * rows).setMaxResults(rows);
        List list = q.list();
        List<RefundApplyListVo> refundApplyListVos = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            RefundApplyListVo refundApplyListVo = new RefundApplyListVo();
            Object[] objects = (Object[]) list.get(i);
            refundApplyListVo.setAccNo(objects[0]==null?"--":objects[0].toString());
            refundApplyListVo.setTelephoneNumber(objects[1]==null?"--":objects[1].toString());
            refundApplyListVo.setAddress(objects[2]==null?"--":objects[2].toString());
            refundApplyListVo.setLastBal(((BigDecimal) objects[3]).setScale(2, BigDecimal.ROUND_DOWN));
            refundApplyListVo.setCurBal(((BigDecimal) objects[4]).setScale(2, BigDecimal.ROUND_DOWN));
            refundApplyListVo.setRefundAmt(((BigDecimal) objects[5]).setScale(2, BigDecimal.ROUND_DOWN));
            refundApplyListVo.setApplyTime((Date) objects[6]);
            Object o7 = objects[7];
            if(StringUtil.isNotEmpty(o7)){
                refundApplyListVo.setApplyReason(objects[7]==null?"--":objects[7].toString());
            }else{
                refundApplyListVo.setApplyReason("--");
            }
            refundApplyListVo.setApprStatus(objects[8]==null?"--":objects[8].toString());
            refundApplyListVo.setId(Integer.parseInt((objects[9]).toString()));
            refundApplyListVos.add(refundApplyListVo);
        }

        DataReturn data = new DataReturn();
        data.setRows(refundApplyListVos);
        data.setTotal(count);
        return data;
    }

    /**
     * @description: 凭证打印列表查询
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 3:36
     */
    @Override
    public void getReceiptPrintDatagrid(HttpServletRequest request, DataGrid dataGrid) {
        StringBuilder sql = new StringBuilder(
                " SELECT " +
                " t.acc_no, " +
                " t.topup_amt, " +
                " t.txn_date, " +
                " t.arrear_amt, " +
                " r.oper_id, " +
                " r.Receipt_Type, " +
                " r.Print_times, " +
                " r.ref_no " +
                " FROM " +
                " Receipt_Info AS r " +
                " LEFT JOIN SP_TOPUP_REC AS t ON t.ref_no = r.ref_no " +
                " WHERE " +
                " 1 = 1 "
        );
        Map map = new HashMap();
        String accNo = request.getParameter("accNo");
        if (oConvertUtils.isNotEmpty(accNo)) {
            sql.append(" and t.acc_no like :accNo ");
            map.put("accNo","%" + accNo + "%");
        }
        String txnDate1 = request.getParameter("txnDate1");
        if (oConvertUtils.isNotEmpty(txnDate1)) {
            sql.append(" and t.txn_date >= :txnDate1 ");
            try {
                map.put("txnDate1",sdf.parse(txnDate1));
            } catch (ParseException e) {
                logger.error(e.getMessage(),e);
            }
        }
        String txnDate2 = request.getParameter("txnDate2");
        if (oConvertUtils.isNotEmpty(txnDate2)) {
            sql.append(" and t.txn_date <= :txnDate2 ");
            try {
                map.put("txnDate2",sdf.parse(txnDate2));
            } catch (ParseException e) {
                logger.error(e.getMessage(),e);
            }
        }
        String topupAmt = request.getParameter("topupAmt");
        if (oConvertUtils.isNotEmpty(topupAmt)) {
            sql.append(" and t.topup_amt = :topupAmt");
            map.put("topupAmt",topupAmt);
        }
        String printTimes = request.getParameter("printTimes");
        if (oConvertUtils.isNotEmpty(printTimes) && printTimes.equals("0")) {//未打印
            sql.append(" and r.Print_times = '0' or r.Print_times = '' ");
        }else if(oConvertUtils.isNotEmpty(printTimes) && printTimes.equals("1")){//已打印
            sql.append(" and r.Print_times <> '0' and r.Print_times <> '1' ");
        }

        if (oConvertUtils.isNotEmpty(dataGrid.getSort())) {
            sql.append(" order by " + dataGrid.getSort() + " " + dataGrid.getOrder());
        }

        String sqlQuery = sql.toString();
        Query query = getSession().createSQLQuery(sqlQuery);
        query.setProperties(map);
        List list = query.list();

        super.paginateDataGrid(list,dataGrid,query);
    }

    /**
     * @description: 查询receiptInfo,查看打印次数
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 5:35
     */
    @Override
    public ReceiptInfoEntity getReceiptInfo(ReceiptInfoEntity receiptInfoEntity) {
        StringBuilder sql = new StringBuilder(
                " SELECT " +
                " r.RECEIPT_NO, " +
                " r.REF_NO, " +
                " r.PRINT_DATE, " +
                " r.OPER_ID, " +
                " r.RECEIPT_TYPE, " +
                " r.PRINT_TIMES " +
                " FROM " +
                " Receipt_Info r " +
                " WHERE " +
                " 1 = 1 "
        );
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        String refNo = receiptInfoEntity.getRefNo();
        if (refNo != null && !"".equals(refNo)) {
            condition.append(" and r.ref_no = ? ");
            params.add(refNo);
        }
        String sqlQuery = sql.append(condition.toString()).toString();
        SQLQuery q = getSession().createSQLQuery(sqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List list = q.list();
        List<ReceiptInfoEntity> receiptInfoEntityList = new ArrayList<>();
        if(list!=null&&list.size()>0){
            for (int i = 0; i < list.size(); i++) {
                Object[] o = (Object[]) list.get(i);
                ReceiptInfoEntity receiptInfo = new ReceiptInfoEntity();
                receiptInfo.setReceiptNo((String) o[0]);
                receiptInfo.setRefNo((String) o[1]);
                receiptInfo.setPrintDate((Date) o[2]);
                receiptInfo.setOperId((String) o[3]);
                receiptInfo.setReceiptType((String) o[4]);
                receiptInfo.setPrintTimes((String) o[5]);
                receiptInfoEntityList.add(receiptInfo);
            }
        }
        if (receiptInfoEntityList.size() > 0) {
            receiptInfoEntity = receiptInfoEntityList.get(0);
        }

        return receiptInfoEntity;
    }

    /**
     * @description: 充值
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 4:47
     */
    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ, rollbackForClassName = {"Exception.class"})
    public Integer topup(SpTopUpRecEntity topupRecordEntity) {
        Serializable save = save(topupRecordEntity);
        return (Integer) save;
    }

    /**
     * @description: 根据accNo查询AcctBalAccNo list
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 4:48
     */
    @Override
    public List getAcctBalByAccNo(String accNo) {
        StringBuilder hql = new StringBuilder("from AcctBalEntity where 1=1 ");
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        if (accNo != null && !"".equals(accNo)) {
            condition.append(" and accNo = ? ");
            params.add(accNo);
        }
        String hqlQuery = hql.append(condition.toString()).toString();
        Query q = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List<AcctBalEntity> acctBalEntityList = q.list();
        return acctBalEntityList;
    }

    /**
     * @description: 查询账户当日缴费总额
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 4:48
     */
    @Override
    public BigDecimal getOneDayTopupAmt(String accNo, String batchNo) {

        StringBuilder sql = new StringBuilder(
                " SELECT " +
                " SUM (s.topup_amt) " +
                " FROM " +
                " SP_TOPUP_REC s " +
                " WHERE " +
                " 1 = 1 "
        );
        StringBuilder condition = new StringBuilder("");
        List params = new ArrayList();
        if (accNo != null && !"".equals(accNo)) {
            condition.append(" AND s.acc_no = ? ");
            params.add(accNo);
        }
        if (!StringUtil.isEmpty(batchNo)) {
            condition.append(" AND batch_no = ? ");
            params.add(batchNo);
        }
        String sqlQuery = sql.append(condition.toString()).toString();
        SQLQuery q = getSession().createSQLQuery(sqlQuery);

        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List list = q.list();
        BigDecimal oneDayTopupAmt = MathMoneyUtils.str2Bigdecimal("0");
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i) != null) { //若当日未充值记录,则查询缴费总额结果为null
                oneDayTopupAmt = MathMoneyUtils.str2Bigdecimal(list.get(i).toString());//仅此一条
            }
        }

        return oneDayTopupAmt;
    }

    /**
     * @description: 根据refNo查询充值记录
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 4:48
     */
    @Override
    public SpTopUpRecEntity getTopupRecordByRefNo(String refNo) {
        CriteriaQuery cq = new CriteriaQuery(SpTopUpRecEntity.class);
        cq.eq("refNo", refNo);
        cq.add();
        List<SpTopUpRecEntity> list = getListByCriteriaQuery(cq, false);
        if (list != null && list.size() > 0) {
            SpTopUpRecEntity topupRecordEntity = list.get(0);
            return topupRecordEntity;
        }
        return null;
    }

    /**
     * @description: 根据refNo查询receiptInfo
     * @auther: liangyadong
     * @date: 2018/10/9 0009 上午 10:41
     */
    @Override
    public ReceiptInfoEntity getReceiptInfo(String refNo) {
        CriteriaQuery cq = new CriteriaQuery(ReceiptInfoEntity.class);
        cq.eq("refNo", refNo);
        cq.add();
        List<ReceiptInfoEntity> list = getListByCriteriaQuery(cq, false);
        if (list != null && list.size() > 0) {
            ReceiptInfoEntity receiptInfoEntity = list.get(0);
            return receiptInfoEntity;
        }
        return null;
    }

    /**
     * @description: 更新A_ACCT_BAL最新记录
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 4:48
     */
    @Override
    public void updateAccountBalance(String accNo, BigDecimal currentBal, Date txnDate) {
        AcctBalEntity acctBalEntity = new AcctBalEntity();
        acctBalEntity.setAccNo(accNo);
        acctBalEntity.setBalance(currentBal);
        acctBalEntity.setUpdateTime(txnDate);

        saveOrUpdate(acctBalEntity);
    }

    /**
     * @description: 查询counter信息
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 4:48
     */
    @Override
    public CounterEntity getCounterInfo(String macAddr) {
        StringBuilder hql = new StringBuilder(" from CounterEntity c where 1=1 ");
        StringBuilder condition = new StringBuilder();
        List params = new ArrayList<>();
        CounterEntity counterEntity = null;

        if (macAddr != null && !"".equals(macAddr)) {
            condition.append(" and c.macAddr = ? ");
            params.add(macAddr);
        } else {
            return counterEntity;
        }
        String hqlQuery = hql.append(condition).toString();
        Query query = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                query.setParameter(i, params.get(i));
            }
        }
        List<CounterEntity> list = query.list();
        if (list.size() > 0) {
            counterEntity = list.get(0);
        }
        return counterEntity;
    }

    /**
     * @description: 根据ip查询counter信息
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 4:48
     */
    @Override
    public CounterEntity getCounterByIP(String clientIP) {
        StringBuilder hql = new StringBuilder(" from CounterEntity c where 1=1 ");
        StringBuilder condition = new StringBuilder();
        List params = new ArrayList<>();
        CounterEntity counterEntity = null;
        if (clientIP != null && !"".equals(clientIP)) {
            condition.append(" and c.ip = ? ");
            params.add(clientIP);
        } else {
            return counterEntity;
        }
        String hqlQuery = hql.append(condition).toString();
        Query query = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                query.setParameter(i, params.get(i));
            }
        }
        List<CounterEntity> list = query.list();
        if (list.size() > 0) {
            counterEntity = list.get(0);
        }
        return counterEntity;
    }

    /**
     * @description: 查询terminal信息
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 4:49
     */
    @Override
    public TerminalEntity getTerminalInfo(int terminalId) {//terminalId是counter表中的外键对应terminal表中的id
        StringBuilder hql = new StringBuilder(" from TerminalEntity t where 1=1 ");
        StringBuilder condition = new StringBuilder();
        List params = new ArrayList<>();
        TerminalEntity terminalEntity = null;

        condition.append(" and t.id = ? ");
        params.add(terminalId);

        String hqlQuery = hql.append(condition).toString();
        Query query = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                query.setParameter(i, params.get(i));
            }
        }
        List<TerminalEntity> list = query.list();
        if (list.size() > 0) {
            terminalEntity = list.get(0);
        }
        return terminalEntity;
    }

    /**
     * @description: 查询channel信息
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 4:49
     */
    @Override
    public ChannelEntity getChannelInfo(int channelId) {//channelId是terminal表中的外键对应channel表中的id
        StringBuilder hql = new StringBuilder(" from ChannelEntity c where 1=1 ");
        StringBuilder condition = new StringBuilder();
        List params = new ArrayList<>();
        ChannelEntity channelEntity = null;

        if (channelId > 0) {
            condition.append(" and c.id = ? ");
            params.add(channelId);
        }
        String hqlQuery = hql.append(condition).toString();
        Query query = getSession().createQuery(hqlQuery);
        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                query.setParameter(i, params.get(i));
            }
        }
        List<ChannelEntity> list = query.list();
        if (list.size() > 0) {
            channelEntity = list.get(0);
        }
        return channelEntity;
    }

    /**
     * @description: 充值界面查询用户信息
     * @auther: liangyadong
     * @date: 2018/9/30 0030 下午 4:49
     */
    @Override
    public ResultVo getCustInfo(HttpServletRequest request){
        StringBuilder sql = new StringBuilder(
                " SELECT " +
                " a.acc_no as accNo, " +
                " a.address as address, " +
                " b.BALANCE as balance, " +
                " m.meter_id as meterId, " +
                " a.account_status as accountStatus, " +
                " a.arrear_pct " +
                " FROM " +
                " A_CUSTOMER_INFO a " +
                " LEFT JOIN A_ACCT_BAL b ON a.acc_no = b.ACC_NO " +
                " LEFT JOIN A_METER_INFO m ON a.acc_no = m.acc_no " +
                " WHERE a.acc_no = ? "
        );
        StringBuilder condition = new StringBuilder("");
        ArrayList params = new ArrayList();
        String accNo = request.getParameter("accNo");
        if(StringUtils.isNotEmpty(accNo)){
            if(accNo.length()==10){
                accNo+="P";
            }
            params.add(accNo);
        }else{
            return new ResultVo();
        }
        String sqlQuery = sql.append(condition.toString()).toString();
        Query q = getSession().createSQLQuery(sqlQuery);

        if (params != null && params.size() > 0) {
            for (int i = 0; i < params.size(); i++) {
                q.setParameter(i, params.get(i));
            }
        }
        List<Object[]> list = q.list();
        DecimalFormat df = new DecimalFormat("0.00");
        ResultVo resultVo = null;
        if(list!=null&&list.size()>0){
            Object[] objects = list.get(0);
            resultVo = new ResultVo();
            if (objects != null) {
                resultVo.setAccNo(objects[0] != null ? (String) objects[0] : "");
                resultVo.setAddress(objects[1] != null ? (String) objects[1] : "");
                if (objects[2] != null) {
                    BigDecimal big3 = ((BigDecimal) objects[2]).setScale(2, BigDecimal.ROUND_DOWN);
                    double db3 = big3.doubleValue();
                    String format = df.format(db3);
                    BigDecimal bigbal = new BigDecimal(format);
                    resultVo.setBalance(bigbal);
                }
                resultVo.setMeterId(objects[3] != null ? (String) objects[3] : "");
                resultVo.setAccountStatus(objects[4] != null ? (String) objects[4] : "");
                resultVo.setArrearPct(objects[5] != null ? (BigDecimal)objects[5] : new BigDecimal(0));
            }
        }

        return resultVo;
    }

    @Override
    public BigDecimal getTotalRefundAmtByAccNo(String accNo) {
        String sql =
                " SELECT " +
                        " re.acc_no, " +
                        " SUM (re.refund_amt) " +
                        " FROM " +
                        " REFUND_REC re " +
                        " WHERE " +
                        " re.appr_status = '01' " +
                        " AND re.acc_no = :accNo " +
                        " GROUP BY " +
                        " re.acc_no ";

        Map<String, String> map = new HashMap();
        if(oConvertUtils.isNotEmpty(accNo)){
            map.put("accNo", accNo);
        }

        Query query = getSession().createSQLQuery(sql);
        query.setProperties(map);
        List list = query.list();

        BigDecimal totalRefundAmt = new BigDecimal(0);
        if (list != null && list.size() > 0) {
            Object[] objects = (Object[]) list.get(0);
            totalRefundAmt = oConvertUtils.isEmpty(objects[1]) ? totalRefundAmt : (BigDecimal) objects[1];
        }

        return totalRefundAmt;
    }

}
