package com.ppms.entity;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.util.Date;

/**   
 * @Title: Entity
 * @Description: CHG_ACTIVATION_DATE_LOG
 * @author zhangdaihao
 * @date 2018-12-24 15:04:32
 * @version V1.0   
 *
 */
@Entity
@Table(name = "CHG_ACTIVATION_DATE_LOG", schema = "")
@DynamicUpdate(true)
@DynamicInsert(true)
@SuppressWarnings("serial")
public class ChgActivationDateLogEntity implements java.io.Serializable {
	/**accNo*/
	private String accNo;
	/**oldScheduleActivationDate*/
	private Date oldScheduleActivationDate;
	/**newScheduleActivationDate*/
	private Date newScheduleActivationDate;
	/**changeReason*/
	private String changeReason;
	/**operator*/
	private String operator;
	/**operateTime*/
	private Date operateTime;
	/**remark*/
	private byte[] remark;
	/**id*/
	private Integer id;

	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  accNo
	 */
	@Column(name ="ACC_NO",nullable=true,precision=12,length=12)
	public String getAccNo(){
		return this.accNo;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  accNo
	 */
	public void setAccNo(String accNo){
		this.accNo = accNo;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  oldScheduleActivationDate
	 */
	@Column(name ="OLD_SCHEDULE_ACTIVATION_DATE",nullable=true,precision=23,scale=3,length=8)
	public Date getOldScheduleActivationDate(){
		return this.oldScheduleActivationDate;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  oldScheduleActivationDate
	 */
	public void setOldScheduleActivationDate(Date oldScheduleActivationDate){
		this.oldScheduleActivationDate = oldScheduleActivationDate;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  newScheduleActivationDate
	 */
	@Column(name ="NEW_SCHEDULE_ACTIVATION_DATE",nullable=true,precision=23,scale=3,length=8)
	public Date getNewScheduleActivationDate(){
		return this.newScheduleActivationDate;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  newScheduleActivationDate
	 */
	public void setNewScheduleActivationDate(Date newScheduleActivationDate){
		this.newScheduleActivationDate = newScheduleActivationDate;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  changeReason
	 */
	@Column(name ="CHANGE_REASON",nullable=true,precision=2,length=2)
	public String getChangeReason(){
		return this.changeReason;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  changeReason
	 */
	public void setChangeReason(String changeReason){
		this.changeReason = changeReason;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  operator
	 */
	@Column(name ="OPERATOR",nullable=true,precision=64,length=64)
	public String getOperator(){
		return this.operator;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  operator
	 */
	public void setOperator(String operator){
		this.operator = operator;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  operateTime
	 */
	@Column(name ="OPERATE_TIME",nullable=true,precision=23,scale=3,length=8)
	public Date getOperateTime(){
		return this.operateTime;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  operateTime
	 */
	public void setOperateTime(Date operateTime){
		this.operateTime = operateTime;
	}
	/**
	 *方法: 取得java.lang.Object
	 *@return: java.lang.Object  remark
	 */
	@Column(name ="REMARK",nullable=true,precision=256,length=256)
	public byte[] getRemark(){
		return this.remark;
	}

	/**
	 *方法: 设置java.lang.Object
	 *@param: java.lang.Object  remark
	 */
	public void setRemark(byte[] remark) {
		this.remark = remark;
	}

	/**
	 *方法: 取得java.lang.Integer
	 *@return: java.lang.Integer  id
	 */

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="ID",nullable=false,precision=10,scale=0,length=4)
	public Integer getId(){
		return this.id;
	}

	/**
	 *方法: 设置java.lang.Integer
	 *@param: java.lang.Integer  id
	 */
	public void setId(Integer id){
		this.id = id;
	}
}
