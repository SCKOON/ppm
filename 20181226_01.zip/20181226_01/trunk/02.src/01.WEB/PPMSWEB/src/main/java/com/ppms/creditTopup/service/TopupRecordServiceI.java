package com.ppms.creditTopup.service;

import com.ppms.creditTopup.bean.TopupPreviewVO;
import com.ppms.entity.*;
import com.ppms.utils.DataReturn;
import com.ppms.vo.ResultVo;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.common.service.CommonService;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.Map;

public interface TopupRecordServiceI extends CommonService{

    //查询账户信息(弹框查询Query)
    DataReturn getAllEntities(ResultVo resultVo, int page, int rows, HttpServletRequest request);

    //冲正页面-充值记录查询
    void getTopupRecordForReverse(DataGrid datagrid, HttpServletRequest request, String curLoginName);

    //充值记录查询页面-充值记录查询
    void getTopupRecordList(DataGrid datagrid, HttpServletRequest request, String curLoginName);

    //充值页面-查询充值记录
    void getCreditTopupRec(DataGrid datagrid, HttpServletRequest request);

    //冲正 更改状态
    Integer updateTxnStatus(SpTopUpRecEntity topupRecord, String status) throws Exception;

    //查询账户信息
    DataReturn getCustomerInfo(CustomerInfoEntity customerInfoEntity, AcctBalEntity acctBalEntity, int page, int rows, HttpServletRequest request);

    //查询退款申请列表信息
    void getRefundApplyDatagrid(RefundRecordEntity refundRecordEntity, CustomerInfoEntity customerInfoEntity, DataGrid dataGrid, HttpServletRequest request);

    //查询凭证打印列表信息
    void getReceiptPrintDatagrid(HttpServletRequest request, DataGrid dataGrid);

    //查询凭证信息
    ReceiptInfoEntity getReceiptInfo(ReceiptInfoEntity receiptInfoEntity);

    //充值
    Map<String,Object> topup(SpTopUpRecEntity topupRecordEntity, String clientIP, CustomerInfoEntity customerInfoEntity);

    //账户状态校验
    boolean checkActiveOrNot(CustomerInfoEntity customerInfoEntity);

    //冲正
    String doReverse(HttpServletRequest request);

    //退款申请
    String refundApply(RefundRecordEntity refundRecordEntity, HttpServletRequest request);

    //退款审批
    String refundApproval(HttpServletRequest request);

    //更新receiptInfo信息
    void updateReceiptInfo(HttpServletRequest request);

    //充值页面查询用户信息
    ResultVo getCustInfo(HttpServletRequest request);

    //根据refNo查询充值记录
    SpTopUpRecEntity getTopupRecordByRefNo(String refNo);

    //充值预览
    TopupPreviewVO getPreviewVO(HttpServletRequest request);

    //查询当日充值合计金额
    BigDecimal getOneDayTopupAmt(String accNo, String batchNo);

    //根据ip查询counter信息
    CounterEntity getCounterByIP(String clientIP);

    //查询terminal信息 根据counter信息对应的terminalId(外键)
    TerminalEntity getTerminalInfo(int terminalId);

    //查询channel信息 根据terminal信息对应的channelId(外键)
    ChannelEntity getChannelInfo(int channelId);

    //退款申请前 校验是否满足退款条件: 当前余额-退款申请总金额是否大于0
    boolean checkRefundCondition(String accNo, BigDecimal refundAmt);
}
