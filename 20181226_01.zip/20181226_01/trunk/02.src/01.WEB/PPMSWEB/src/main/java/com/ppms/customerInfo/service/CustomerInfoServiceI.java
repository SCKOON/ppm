package com.ppms.customerInfo.service;

import com.ppms.customerInfo.bean.EBSArrearsInfoBean;
import com.ppms.customerInfo.vo.ClosingDetailVo;
import com.ppms.entity.AClosingRecordEntity;
import com.ppms.entity.CustomerInfoEntity;
import com.ppms.customerInfo.vo.ResultVo;
import com.ppms.entity.ProcessChargeEntity;
import com.ppms.utils.DataReturn;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.common.service.CommonService;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;

public interface CustomerInfoServiceI extends CommonService{
    //激活-保存激活日期
    String goUpdateActivationDate(HttpServletRequest request);

    CustomerInfoEntity saveQ(CustomerInfoEntity entity, String id) throws Exception;

    DataReturn getAllEntities(ResultVo resultVo, int page, int rows, HttpServletRequest request);

    //销户申请-查询客户信息
    DataReturn getCustomerInfo(int page, int rows, HttpServletRequest request);

    //销户申请-插入申请记录
    String goApplyClosing(HttpServletRequest request);

    //销户申请-查询申请记录
    AClosingRecordEntity getClosingRecord(HttpServletRequest request);

    //销户申请-查看销户详情
    ClosingDetailVo lookClosingDetail(HttpServletRequest request);

    //开户
    String accountOpening(CustomerInfoEntity databaseEntity, HttpServletRequest request);

    //payu开户
    String payuAccountOpening(CustomerInfoEntity databaseEntity, HttpServletRequest request);

    //查询jeecg库tstype
    List getTstTypeList(CriteriaQuery cq);

    //账户激活-修改档案信息
    String doUpdateCreditBalance(HttpServletRequest request);

    //获取holiday的list
    List getHolidayList();

    List getTarifCode(Date date);

    //由tariffCode查询tariffrate
    String getTariffInfoGroupByCode(Date date, String tariffCode);

    //查询gst(code和value)
    List getGstCodeAndValue(Date date);

    //通过tariffCode组装list<map<string,object>>
    List generateTariffList(List list);

    void queryCustomerForCreditTransfer(String accno, DataGrid dataGrid);

    void queryCustomerInfoForActivation(HttpServletRequest request, DataGrid dataGrid, String accountType);

    EBSArrearsInfoBean EBSArrearsInfo(HttpServletRequest request);

    //校验账户状态是否激活
    boolean validPrintCardTimes(String accno);

    //保存打印电卡的次数
    void updatePrintCardTimes(String accno);

    //销户前校验是否有未处理完成的销户流程
    List queryClosingRec(HttpServletRequest request);
}
