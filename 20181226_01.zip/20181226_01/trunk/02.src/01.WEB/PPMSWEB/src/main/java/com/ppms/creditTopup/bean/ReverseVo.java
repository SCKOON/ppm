package com.ppms.creditTopup.bean;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: liangyadong
 * @Date: 2018/12/11 0011 14:05
 * @Description:
 */
public class ReverseVo {
    private String accNo;
    private String tmnlCode;
    private String counterId;
    private BigDecimal topupAmt;
    private BigDecimal prepaidAmt;
    private BigDecimal curBal;
    private Date txnDate;
    private String payMode;
    private String payNo;
    private String txnStatus;
    private String cashierId;
    private String refNo;
    private Integer id;

    public String getAccNo() {
        return accNo;
    }

    public void setAccNo(String accNo) {
        this.accNo = accNo;
    }

    public String getTmnlCode() {
        return tmnlCode;
    }

    public void setTmnlCode(String tmnlCode) {
        this.tmnlCode = tmnlCode;
    }

    public String getCounterId() {
        return counterId;
    }

    public void setCounterId(String counterId) {
        this.counterId = counterId;
    }

    public BigDecimal getTopupAmt() {
        return topupAmt;
    }

    public void setTopupAmt(BigDecimal topupAmt) {
        this.topupAmt = topupAmt;
    }

    public BigDecimal getPrepaidAmt() {
        return prepaidAmt;
    }

    public void setPrepaidAmt(BigDecimal prepaidAmt) {
        this.prepaidAmt = prepaidAmt;
    }

    public BigDecimal getCurBal() {
        return curBal;
    }

    public void setCurBal(BigDecimal curBal) {
        this.curBal = curBal;
    }

    public Date getTxnDate() {
        return txnDate;
    }

    public void setTxnDate(Date txnDate) {
        this.txnDate = txnDate;
    }

    public String getPayMode() {
        return payMode;
    }

    public void setPayMode(String payMode) {
        this.payMode = payMode;
    }

    public String getPayNo() {
        return payNo;
    }

    public void setPayNo(String payNo) {
        this.payNo = payNo;
    }

    public String getTxnStatus() {
        return txnStatus;
    }

    public void setTxnStatus(String txnStatus) {
        this.txnStatus = txnStatus;
    }

    public String getCashierId() {
        return cashierId;
    }

    public void setCashierId(String cashierId) {
        this.cashierId = cashierId;
    }

    public String getRefNo() {
        return refNo;
    }

    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
