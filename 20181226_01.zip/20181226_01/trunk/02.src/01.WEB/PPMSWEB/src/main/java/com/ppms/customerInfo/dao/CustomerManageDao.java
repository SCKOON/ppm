package com.ppms.customerInfo.dao;

import com.ppms.customerInfo.vo.ClosingDetailVo;
import com.ppms.entity.AClosingRecordEntity;
import com.ppms.entity.CustomerInfoEntity;
import com.ppms.customerInfo.vo.ResultVo;
import com.ppms.entity.ProcessChargeEntity;
import com.ppms.utils.DataReturn;
import org.jeecgframework.core.common.dao.IGenericBaseCommonDao;
import org.jeecgframework.core.common.model.json.DataGrid;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;

/**
 * Created by yadongliang on 2018/5/8 0008.
 */
public interface CustomerManageDao extends IGenericBaseCommonDao {
    DataReturn getAllEntities(ResultVo resultVo, int page, int rows, HttpServletRequest request);
    DataReturn getCustomerInfo(int page, int rows, HttpServletRequest request);
    //销户申请
    void goApplyClosing(HttpServletRequest request);

    //销户申请记录查询
    AClosingRecordEntity getClosingRecord(HttpServletRequest request);

    //销户详情
    ClosingDetailVo getClosingDetail(HttpServletRequest request);

    //查询节假日
    List getHolidayList();

    //查询账户信息-主键
    CustomerInfoEntity selectByPrimaryKey(String accountNo);

    //更新账户信息
    void update(CustomerInfoEntity customerInfo);

    //查询电价类别和电价等信息code和rate
    List getTariffInfo(Date date);

    //查询gst信息code和rate
    List getGstInfo(Date date);

    void queryCustomerInfoForActivation(HttpServletRequest request, DataGrid dataGrid, String accountType);

    //查询未处理完成的销户流程的记录条数
    List queryClosingRec(HttpServletRequest request);
}
