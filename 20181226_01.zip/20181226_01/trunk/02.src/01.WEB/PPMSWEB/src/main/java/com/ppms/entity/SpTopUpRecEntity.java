package com.ppms.entity;

import java.math.BigDecimal;

import javax.persistence.*;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;

/**   
 * @Title: Entity
 * @Description: SP_TOPUP_REC
 * @author zhangdaihao
 * @date 2018-05-10 15:21:05
 * @version V1.0   
 *
 */
@Entity
@Table(name = "SP_TOPUP_REC", schema = "")
@DynamicUpdate(true)
@DynamicInsert(true)
@SuppressWarnings("serial")
public class SpTopUpRecEntity implements java.io.Serializable {
	/**refNo*/
	private java.lang.String refNo;
	/**accNo*/
	private java.lang.String accNo;
	/**txnDate*/
	private java.util.Date txnDate;
	/**YYYYMMDD+01*/
	private java.lang.String batchNo;
	/**??λ????*/
	private BigDecimal topupAmt;
	/**arrearAmt*/
	private BigDecimal arrearAmt;
	/**01	Cash
	 02	Credit Card
	 03	Debit
	 04	Nets
	 05	Cheque
	 06	Voucher*/
	private java.lang.String payMode;
	/**??λ????*/
	private BigDecimal prepaidAmt;
	/**??λ????*/
	private BigDecimal lastBal;
	/**??λ????*/
	private BigDecimal curBal;
	/**channelCode*/
	private java.lang.String channelCode;
	/**tmnlCode*/
	private java.lang.String tmnlCode;
	/**counterId*/
	private java.lang.String counterId;
	/**cashierId*/
	private java.lang.String cashierId;
	/**01- Top-up
	 02- ?????
	 03- reverse
	 04- ???????
	 05- ???????*/
	private java.lang.String txnStatus;
	/**01- δ????
	 02- ??????
	 03- ?????????????
	 11- ???????*/
	private java.lang.String reconStatus;
	/**?????????voucher????洢voucher number??
	 ??????????????credit card????洢??????????*/
	private java.lang.String payNo;
	/**01- VISA
	 02- MASTER CARD*/
	private java.lang.String creditType;
	/**remark*/
	private java.lang.String remark;
	/**payment mode change flag.
	 01- ?????
	 */
	private java.lang.String pmchgFlag;
	/**id*/
	private java.lang.Integer id;
	/**gstAmt*/
	private BigDecimal gstAmt;
	/**grosssAmt*/
	private BigDecimal grosssAmt;

	private String refNoId;

	public void setRefNoId(java.lang.String refNoId){
		this.refNoId = refNoId;
	}

	@Column(name ="REF_NO_ID",nullable=true,precision=54,length=54)
	public java.lang.String getRefNoId(){
		return this.refNoId;
	}

	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  refNo
	 */
	@Column(name ="REF_NO",nullable=false,precision=32,length=32)
	public java.lang.String getRefNo(){
		return this.refNo;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  refNo
	 */
	public void setRefNo(java.lang.String refNo){
		this.refNo = refNo;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  accNo
	 */
	@Column(name ="ACC_NO",nullable=true,precision=12,length=12)
	public java.lang.String getAccNo(){
		return this.accNo;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  accNo
	 */
	public void setAccNo(java.lang.String accNo){
		this.accNo = accNo;
	}
	/**
	 *方法: 取得java.util.Date
	 *@return: java.util.Date  txnDate
	 */
	@Column(name ="TXN_DATE",nullable=true,precision=23,scale=3,length=8)
	public java.util.Date getTxnDate(){
		return this.txnDate;
	}

	/**
	 *方法: 设置java.util.Date
	 *@param: java.util.Date  txnDate
	 */
	public void setTxnDate(java.util.Date txnDate){
		this.txnDate = txnDate;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  YYYYMMDD+01
	 */
	@Column(name ="BATCH_NO",nullable=true,precision=10,length=10)
	public java.lang.String getBatchNo(){
		return this.batchNo;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  YYYYMMDD+01
	 */
	public void setBatchNo(java.lang.String batchNo){
		this.batchNo = batchNo;
	}
	/**
	 *方法: 取得BigDecimal
	 *@return: BigDecimal  ??λ????
	 */
	@Column(name ="TOPUP_AMT",nullable=true,precision=10,scale=2,length=9)
	public BigDecimal getTopupAmt(){
		return this.topupAmt;
	}

	/**
	 *方法: 设置BigDecimal
	 *@param: BigDecimal  ??λ????
	 */
	public void setTopupAmt(BigDecimal topupAmt){
		this.topupAmt = topupAmt;
	}
	/**
	 *方法: 取得BigDecimal
	 *@return: BigDecimal  arrearAmt
	 */
	@Column(name ="ARREAR_AMT",nullable=true,precision=10,scale=2,length=9)
	public BigDecimal getArrearAmt(){
		return this.arrearAmt;
	}

	/**
	 *方法: 设置BigDecimal
	 *@param: BigDecimal  arrearAmt
	 */
	public void setArrearAmt(BigDecimal arrearAmt){
		this.arrearAmt = arrearAmt;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  01	Cash
	02	Credit Card
	03	Debit
	04	Nets
	05	Cheque
	06	Voucher
	 */
	@Column(name ="PAY_MODE",nullable=true,precision=2,length=2)
	public java.lang.String getPayMode(){
		return this.payMode;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  01	Cash
	02	Credit Card
	03	Debit
	04	Nets
	05	Cheque
	06	Voucher
	 */
	public void setPayMode(java.lang.String payMode){
		this.payMode = payMode;
	}
	/**
	 *方法: 取得BigDecimal
	 *@return: BigDecimal  ??λ????
	 */
	@Column(name ="PREPAID_AMT",nullable=true,precision=10,scale=2,length=9)
	public BigDecimal getPrepaidAmt(){
		return this.prepaidAmt;
	}

	/**
	 *方法: 设置BigDecimal
	 *@param: BigDecimal  ??λ????
	 */
	public void setPrepaidAmt(BigDecimal prepaidAmt){
		this.prepaidAmt = prepaidAmt;
	}
	/**
	 *方法: 取得BigDecimal
	 *@return: BigDecimal  ??λ????
	 */
	@Column(name ="LAST_BAL",nullable=true,precision=10,scale=2,length=9)
	public BigDecimal getLastBal(){
		return this.lastBal;
	}

	/**
	 *方法: 设置BigDecimal
	 *@param: BigDecimal  ??λ????
	 */
	public void setLastBal(BigDecimal lastBal){
		this.lastBal = lastBal;
	}
	/**
	 *方法: 取得BigDecimal
	 *@return: BigDecimal  ??λ????
	 */
	@Column(name ="CUR_BAL",nullable=true,precision=10,scale=2,length=9)
	public BigDecimal getCurBal(){
		return this.curBal;
	}

	/**
	 *方法: 设置BigDecimal
	 *@param: BigDecimal  ??λ????
	 */
	public void setCurBal(BigDecimal curBal){
		this.curBal = curBal;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  channelCode
	 */
	@Column(name ="CHANNEL_CODE",nullable=true,precision=12,length=12)
	public java.lang.String getChannelCode(){
		return this.channelCode;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  channelCode
	 */
	public void setChannelCode(java.lang.String channelCode){
		this.channelCode = channelCode;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  tmnlCode
	 */
	@Column(name ="TMNL_CODE",nullable=true,precision=12,length=12)
	public java.lang.String getTmnlCode(){
		return this.tmnlCode;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  tmnlCode
	 */
	public void setTmnlCode(java.lang.String tmnlCode){
		this.tmnlCode = tmnlCode;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  counterId
	 */
	@Column(name ="COUNTER_ID",nullable=true,precision=12,length=12)
	public java.lang.String getCounterId(){
		return this.counterId;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  counterId
	 */
	public void setCounterId(java.lang.String counterId){
		this.counterId = counterId;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  cashierId
	 */
	@Column(name ="CASHIER_ID",nullable=true,precision=8,length=8)
	public java.lang.String getCashierId(){
		return this.cashierId;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  cashierId
	 */
	public void setCashierId(java.lang.String cashierId){
		this.cashierId = cashierId;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  01- Top-up
	02- ?????
	03- reverse
	04- ???????
	05- ???????
	 */
	@Column(name ="TXN_STATUS",nullable=true,precision=2,length=2)
	public java.lang.String getTxnStatus(){
		return this.txnStatus;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  01- Top-up
	02- ?????
	03- reverse
	04- ???????
	05- ???????
	 */
	public void setTxnStatus(java.lang.String txnStatus){
		this.txnStatus = txnStatus;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  01- δ????
	02- ??????
	03- ?????????????
	11- ???????
	 */
	@Column(name ="RECON_STATUS",nullable=true,precision=2,length=2)
	public java.lang.String getReconStatus(){
		return this.reconStatus;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  01- δ????
	02- ??????
	03- ?????????????
	11- ???????
	 */
	public void setReconStatus(java.lang.String reconStatus){
		this.reconStatus = reconStatus;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  ?????????voucher????洢voucher number??
	??????????????credit card????洢??????????
	 */
	@Column(name ="PAY_NO",nullable=true,precision=20,length=20)
	public java.lang.String getPayNo(){
		return this.payNo;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  ?????????voucher????洢voucher number??
	??????????????credit card????洢??????????
	 */
	public void setPayNo(java.lang.String payNo){
		this.payNo = payNo;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  01- VISA
	02- MASTER CARD
	 */
	@Column(name ="CREDIT_TYPE",nullable=true,precision=2,length=2)
	public java.lang.String getCreditType(){
		return this.creditType;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  01- VISA
	02- MASTER CARD
	 */
	public void setCreditType(java.lang.String creditType){
		this.creditType = creditType;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  remark
	 */
	@Column(name ="REMARK",nullable=true,precision=2,length=2)
	public java.lang.String getRemark(){
		return this.remark;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  remark
	 */
	public void setRemark(java.lang.String remark){
		this.remark = remark;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  payment mode change flag.
	01- ?????

	 */
	@Column(name ="PMCHG_FLAG",nullable=true,precision=2,length=2)
	public java.lang.String getPmchgFlag(){
		return this.pmchgFlag;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  payment mode change flag.
	01- ?????

	 */
	public void setPmchgFlag(java.lang.String pmchgFlag){
		this.pmchgFlag = pmchgFlag;
	}
	/**
	 *方法: 取得java.lang.Integer
	 *@return: java.lang.Integer  id
	 */

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="ID",nullable=false,precision=10,scale=0,length=4)
	public java.lang.Integer getId(){
		return this.id;
	}

	/**
	 *方法: 设置java.lang.Integer
	 *@param: java.lang.Integer  id
	 */
	public void setId(java.lang.Integer id){
		this.id = id;
	}
	/**
	 *方法: 取得BigDecimal
	 *@return: BigDecimal  gstAmt
	 */
	@Column(name ="GST_AMT",nullable=true,precision=10,scale=2,length=9)
	public BigDecimal getGstAmt(){
		return this.gstAmt;
	}

	/**
	 *方法: 设置BigDecimal
	 *@param: BigDecimal  gstAmt
	 */
	public void setGstAmt(BigDecimal gstAmt){
		this.gstAmt = gstAmt;
	}
	/**
	 *方法: 取得BigDecimal
	 *@return: BigDecimal  grosssAmt
	 */
	@Column(name ="GROSSS_AMT",nullable=true,precision=10,scale=2,length=9)
	public BigDecimal getGrosssAmt(){
		return this.grosssAmt;
	}

	/**
	 *方法: 设置BigDecimal
	 *@param: BigDecimal  grosssAmt
	 */
	public void setGrosssAmt(BigDecimal grosssAmt){
		this.grosssAmt = grosssAmt;
	}
}
