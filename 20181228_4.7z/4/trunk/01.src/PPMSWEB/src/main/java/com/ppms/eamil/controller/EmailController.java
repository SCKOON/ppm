package com.ppms.eamil.controller;

import com.alibaba.fastjson.JSONObject;
import com.constants.Constants;
import com.ppms.dictionary.service.DictServiceI;
import com.ppms.eamil.dto.EmailTemplateDTO;
import com.ppms.entity.EmailEntity;
import com.ppms.entity.EmailInfoEntity;
import com.ppms.eamil.service.EmailServiceI;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.exception.BusinessException;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.common.model.json.DataGrid;

import org.jeecgframework.core.util.DateUtils;
import org.jeecgframework.core.util.MyBeanUtils;
import org.jeecgframework.core.util.StringUtil;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.tag.core.easyui.TagUtil;

import org.jeecgframework.web.system.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.util.*;

@Controller
@RequestMapping("/emailController")
public class EmailController extends BaseController {

    private static final Logger logger = Logger.getLogger(EmailController.class);

    private static final String TYPEGROUPKEY = "EMAIL_TYPE";

    private static final String SENDTIMESKEY = "DEFAULT_EMAIL_LIMIT_TIMES";

    private static final String SENDTIMESTYPEKEY = "DEFAULT_EMAIL_LIMIT_TIMES";

    @Autowired
    private EmailServiceI emailServiceI;

    @Autowired
    private DictServiceI dictServiceI;

    @Autowired
    private SystemService systemService;

    @RequestMapping(params = "toView")
    public ModelAndView toView() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("ppms/email/emailTemplateView");
        modelAndView.addObject("emailList", searchTypeForView());
        return modelAndView;
    }

    @RequestMapping(params = "datagrid")
    public void datagrid(HttpServletRequest request, HttpServletResponse response, DataGrid datagrid) {
        logger.error("-----end logger query the email list information----");
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.EMAIL_TEMPLATE_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        String emailType = request.getParameter("emailType");
        Map<String, String> map = new HashMap<>();
        try {
            this.emailServiceI.queryEmailListToPage(datagrid, emailType);
            map = this.dictServiceI.queryForOptions(TYPEGROUPKEY, null);
        } catch (Exception e) {
            logger.error(e);
        }
        if (datagrid.getResults() != null && datagrid.getResults().size() > 0) {
            //将查询出的结果中emailType数据库字典表获取对应的showname
            List<EmailEntity> list = datagrid.getResults();
            List<EmailTemplateDTO> dtoList = new LinkedList<>();
            for (EmailEntity entity : list) {
                EmailTemplateDTO dto = new EmailTemplateDTO();
                try {
                    MyBeanUtils.copyBeanNotNull2Bean(entity, dto);
                } catch (Exception e) {
                    logger.error(e);
                }
                dto.setEmailType(map.get(entity.getEmailType()));
                dtoList.add(dto);
            }
            //将查询出来的结果集中的emailtype和发送邮件次数替换为数据字典中配置的数据
            datagrid.setResults(dtoList);
        }
        logger.error("-----start logger query the email list information----");
        TagUtil.datagrid(response, datagrid);
    }


    @RequestMapping(params = "toAdd")
    public ModelAndView toAdd(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.EMAIL_TEMPLATE_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("ppms/email/email_add");
        String times = "";
        try {
            modelAndView.addObject("emailForAddList", searchTypeForAdd());
            Map<String, String> map = this.dictServiceI.queryForOptions(SENDTIMESKEY, SENDTIMESTYPEKEY);
            if (null != map && map.size() > 0) {
                times = ((String) (map.keySet().toArray())[0]);
            }
        } catch (Exception e) {
            logger.error(e);
        }
        modelAndView.addObject("sendTimes", times);
        return modelAndView;
    }

    @RequestMapping(params = "doSave")
    @ResponseBody
    public AjaxJson save(EmailTemplateDTO dto,HttpServletRequest request, HttpServletResponse response) {
        logger.info("----add Email Template:" + dto.getEmailType() + " start---");
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.EMAIL_TEMPLATE_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson j = new AjaxJson();
        String message = "Add failed";
        Map<String, String> stringMap;
        try {
            //查询邮件字典表中配置的邮件模板
            stringMap = this.dictServiceI.queryForOptions(TYPEGROUPKEY, null);
            this.emailServiceI.saveEmailTemplate(dto, stringMap);
            message = "Add successfully";
        } catch (Exception e) {
            logger.error(e);
            if (e instanceof BusinessException) {
                message = e.getMessage();
            }
        }
        j.setMsg(message);
        logger.info("----add Email Template:" + dto.getEmailType() + " end---:" + message);
        return j;
    }

    @RequestMapping(params = "doUpdate")
    @ResponseBody
    public AjaxJson update(EmailTemplateDTO dto,HttpServletRequest request, HttpServletResponse response) {
        logger.info("----update Email Template:" + dto.getEmailType() + " start---");
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.EMAIL_TEMPLATE_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson j = new AjaxJson();
        String message = "Update failed";
        Map<String, String> stringMap;
        try {
            //查询邮件字典表中配置的邮件模板
            stringMap = this.dictServiceI.queryForOptions(TYPEGROUPKEY, null);
            this.emailServiceI.updateEmailTemplate(dto, stringMap);
            message = " Update successfully";
        } catch (Exception e) {
            logger.error(e);
            if (e instanceof BusinessException) {
                message = e.getMessage();
            }
        }
        j.setMsg(message);
        logger.info("----add Email Template:" + dto.getEmailType() + " end---:" + message);
        return j;
    }

    @RequestMapping(params = "toUpdate")
    public ModelAndView update(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.EMAIL_TEMPLATE_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        ModelAndView modelAndView = new ModelAndView("ppms/email/email_edit");
        String id = request.getParameter("id");
        if (StringUtil.isNotEmpty(id)) {
            try {
                EmailEntity emailEntity = emailServiceI.getEntity(EmailEntity.class, Integer.parseInt(id));
                EmailTemplateDTO dto = new EmailTemplateDTO();
                MyBeanUtils.copyBeanNotNull2Bean(emailEntity, dto);
                modelAndView.addObject("emailEntity", dto);
                modelAndView.addObject("updateEmailEntity", searchType(emailEntity.getEmailType()));
            } catch (Exception e) {
                logger.error(e);
            }
        }
        return modelAndView;
    }

    @RequestMapping(params = "typeForAdd")
    @ResponseBody
    public String searchTypeForAdd() {
        Map<String, String> map = new HashMap<>();
        List<EmailEntity> emailEntityList = null;
        try {
            //查询字典表中配置的所有邮件模板类型
            map = this.dictServiceI.queryForOptions(TYPEGROUPKEY, null);
            //查询数据库中已存在的邮件模板
            emailEntityList = this.emailServiceI.getList(EmailEntity.class);
        } catch (Exception e) {
            logger.error(e);
        }
        if (emailEntityList != null && emailEntityList.size() > 0) {
            for (EmailEntity entity : emailEntityList) {
                map.remove(entity.getEmailType());
            }
        }
        List<Map<String, String>> maplist = new ArrayList();
        Set<Map.Entry<String, String>> entrySet = map.entrySet();
        for (Map.Entry<String, String> m : entrySet) {
            Map<String, String> stringMap = new HashMap();
            stringMap.put("name", m.getValue());
            stringMap.put("code", m.getKey());
            maplist.add(stringMap);
        }
        return JSONObject.toJSONString(maplist);
    }

    private String searchTypeForView() {
        Map<String, String> map = new HashMap<>();
        try {
            map = this.dictServiceI.queryForOptions(TYPEGROUPKEY, null);
        } catch (Exception e) {
            logger.error(e);
        }
        List<Map<String, String>> maplist = new ArrayList();
        if (map.size() > 0) {
            //清除历史列表，刷新,防止多个用户同时查询造成map出现问题
            Set<Map.Entry<String, String>> entrySet = map.entrySet();
            for (Map.Entry<String, String> m : entrySet) {
                Map<String, String> stringMap = new HashMap();
                stringMap.put("code", m.getKey());
                stringMap.put("name", m.getValue());
                maplist.add(stringMap);
            }

        }
        return JSONObject.toJSONString(maplist);
    }

    //查询字典表中配置的触发邮件的事件和邮件发送的状态
    private String searchType(String typecode) {
        Map map = new HashMap();
        if (oConvertUtils.isNotEmpty(typecode)) {
            Map<String, String> stringMap = null;
            try {
                stringMap = this.dictServiceI.queryForOptions(TYPEGROUPKEY, null);
            } catch (Exception e) {
                logger.error(e);
            }
            List<Map<String, String>> mapList = new ArrayList<>(10);
            if (stringMap != null && stringMap.size() > 0) {
                if (stringMap.containsKey(typecode)) {
                    Map map1 = new HashMap();
                    map1.put("code", typecode);
                    map1.put("name", stringMap.get(typecode));
                    mapList.add(map1);
                }

                map.put("email_type", mapList);
            }
        }
        List<Map<String, List>> list = new ArrayList<>();
        list.add(map);
        return JSONObject.toJSONString(list);
    }

    @RequestMapping(params = "doDel")
    @ResponseBody
    public AjaxJson doDel(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.EMAIL_TEMPLATE_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson j = new AjaxJson();
        String message = "Delete failed";
        String id = request.getParameter("id");
        try {
            EmailEntity emailEntity = emailServiceI.getEntity(EmailEntity.class, Integer.parseInt(id));
            emailServiceI.delete(emailEntity);
            message = "Delete successfully";
        } catch (Exception e) {
            logger.error(e);
        }
        j.setMsg(message);
        return j;
    }

    @RequestMapping(params = "toRecordView")
    public ModelAndView toRecodeView() {
        return new ModelAndView("ppms/email/emailRecord");
    }


    @RequestMapping(params = "getEmails")
    public void getEmails(HttpServletRequest request, HttpServletResponse response, DataGrid datagrid) {
        CriteriaQuery cq = new CriteriaQuery(EmailInfoEntity.class, datagrid);

        String type = request.getParameter("type");
        if (type != null && !"".equals(type)) {
            cq.eq("type", org.jeecgframework.core.util.oConvertUtils.getString(type));
        }
        String status = request.getParameter("status");
        if (status != null && !"".equals(status)) {
            cq.eq("status", org.jeecgframework.core.util.oConvertUtils.getString(status));
        }
        //时间范围查询条件
        String sendTime_begin = request.getParameter("sendTime_begin");
        String sendTime_end = request.getParameter("sendTime_end");
        if (oConvertUtils.isNotEmpty(sendTime_begin)) {
            try {
                cq.ge("sendTime", DateUtils.parseDate(sendTime_begin, "yyyy-MM-dd"));
            } catch (ParseException e) {
                logger.error(e);
                throw new RuntimeException(e);
            }
        }
        if (oConvertUtils.isNotEmpty(sendTime_end)) {
            try {
                cq.le("sendTime", DateUtils.parseDate(sendTime_end, "yyyy-MM-dd"));
            } catch (ParseException e) {
                logger.error(e);
                throw new RuntimeException(e);
            }
        }
        cq.add();
        try {
            this.emailServiceI.getDataGridReturn(cq, true);
        } catch (Exception e) {
            logger.error(e);
        }
        TagUtil.datagrid(response, datagrid);
    }

    @RequestMapping(params = "toRecordUpdate")
    public ModelAndView toRecordUpdate(EmailInfoEntity emailInfoEntity, HttpServletRequest request) {
        ModelAndView modelAndView = new ModelAndView("ppms/email/email_detail");
        if (StringUtil.isNotEmpty(emailInfoEntity.getId())) {
            emailInfoEntity = emailServiceI.getEntity(EmailInfoEntity.class, emailInfoEntity.getId());
            modelAndView.addObject("emailInfoEntity", emailInfoEntity);
        }
        return modelAndView;
    }
}
