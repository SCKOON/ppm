package com.ppms.connection.controller;

import com.alibaba.fastjson.JSONObject;
import com.constants.Constants;
import com.ppms.dictionary.service.DictServiceI;
import com.ppms.entity.RemoteReconRecEntity;
import com.ppms.connection.service.RemoteReconRecServiceI;
import com.ppms.entity.AcctBalEntity;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.exception.BusinessException;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.p3.core.util.oConvertUtils;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.jeecgframework.web.system.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;;import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.*;

@Controller
@RequestMapping(value = "/remoteReconRecController")
public class RemoteReconRecController extends BaseController {

    @Autowired
    private RemoteReconRecServiceI remoteReconRecServiceI;

    @Autowired
    private DictServiceI dictServiceI;

    @Autowired
    private SystemService systemService;

    private static final String TYPEKEY = "REC_OPERATION_STATUS";
    private static final String CONTROL_STATUS_TYPEGROUP_KEY = "METER_CONTROL_STATUS";

    private static final Logger logger = Logger.getLogger(RemoteReconRecController.class);

    @RequestMapping(params = {"view"})
    public ModelAndView toMainView() {
        ModelAndView mav = new ModelAndView("ppms/reconnection/reconRecord");
        mav.addObject("operStatus", searchTypeForView(TYPEKEY));
        mav.addObject("ctlStatus", searchTypeForView(CONTROL_STATUS_TYPEGROUP_KEY));
        return mav;
    }

    private String searchTypeForView(String key) {
        Map<String, String> map = null;
        try {
            map = this.dictServiceI.queryForOptions(key, null);
            logger.info(map.size());
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
        List<Map<String, String>> maplist = new ArrayList();
        if (map != null && map.size() > 0) {
            //清除历史列表，刷新,防止多个用户同时查询造成map出现问题
            Set<Map.Entry<String, String>> entrySet = map.entrySet();
            for (Map.Entry<String, String> m : entrySet) {
                Map<String, String> stringMap = new HashMap();
                stringMap.put("name", m.getValue());
                logger.info("name:"+m.getValue());
                stringMap.put("code", m.getKey());
                logger.info("code:"+m.getKey());
                maplist.add(stringMap);
            }

        }
        logger.info(maplist.size());
        return JSONObject.toJSONString(maplist);
    }

    @RequestMapping(params = {"datagrid"})
    public void datagrid(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.REMOTE_RECONNECTION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        this.remoteReconRecServiceI.queryReconRecord(dataGrid, request);
        if(dataGrid.getResults()!=null&&dataGrid.getResults().size()>0){
            List<RemoteReconRecEntity> recEntitie = dataGrid.getResults();
            for(RemoteReconRecEntity entity : recEntitie){
                System.out.println(entity.toString());
            }
        }
        TagUtil.datagrid(response, dataGrid);
    }

    /**
     * 页面发来重连合闸请求时，需要将remote_recon_rec表中的oper_status置空，oper_tims加1
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(params = {"reconnect"})
    @ResponseBody
    public AjaxJson updateReconRecordStatus(HttpServletRequest request, HttpServletResponse response) {
        logger.info(new String("---prepare to reconnect----"));
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.REMOTE_RECONNECTION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson json = new AjaxJson();
        json.setMsg("operate failed");
        String id = request.getParameter("id");
        if (oConvertUtils.isNotEmpty(id)) {
            RemoteReconRecEntity entity = new RemoteReconRecEntity();
            try {
                int ids = Integer.parseInt(id);
                entity.setId(ids);
                remoteReconRecServiceI.markReconnect(entity);
                json.setMsg("Operate successfully");
            } catch (BusinessException e){
                logger.error(e.getMessage());
                json.setMsg(e.getMessage());
            } catch (Exception e) {
                logger.error(e.getMessage());
            }
        }
        logger.info(new String("---end reconnect----"));
        return json;
    }

    @RequestMapping(params = {"detailWindow"})
    public ModelAndView detailBalance(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.REMOTE_RECONNECTION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        ModelAndView mav = new ModelAndView();
        String id = request.getParameter("id");
        mav.setViewName("ppms/reconnection/detailBalance");
        RemoteReconRecEntity reconRecEntity = null;
        try {
            reconRecEntity = remoteReconRecServiceI.getEntity(RemoteReconRecEntity.class, Integer.parseInt(id));
        } catch (NumberFormatException e) {
            logger.error(e);
        }
        if (reconRecEntity != null) {
            if (reconRecEntity.getCustomerInfoEntity() != null && !StringUtils.isEmpty(reconRecEntity.getCustomerInfoEntity().getAccNo())) {
                AcctBalEntity balEntity = null;
                try {
                    balEntity = remoteReconRecServiceI.getEntity(AcctBalEntity.class, reconRecEntity.getCustomerInfoEntity().getAccNo());
                } catch (Exception e) {
                    logger.error(e);
                }
                if (balEntity != null) {
                    mav.getModel().put("accNo", balEntity.getAccNo());
                    if (balEntity.getBalance() != null) {
                        mav.getModel().put("balance", balEntity.getBalance());
                        if (balEntity.getBalance().compareTo(new BigDecimal(0)) >= 0) {
                            mav.getModel().put("remark", "Permit reconnect");
                        } else {
                            mav.getModel().put("remark", "Refuse reconnect");
                        }

                    }
                }
            }
        }
        return mav;
    }
}
