package com.ppms.smsTemplate.controller;

import com.alibaba.fastjson.JSONObject;
import com.constants.Constants;
import com.ppms.dictionary.service.DictServiceI;
import com.ppms.smsTemplate.dto.SmsTemplateDTO;
import com.ppms.entity.MessageEntity;
import com.ppms.smsTemplate.service.SMSTemplateServiceI;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.exception.BusinessException;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.util.MyBeanUtils;
import org.jeecgframework.core.util.StringUtil;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.jeecgframework.web.system.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

@Controller
@RequestMapping("/smsTemplateController")
public class SMSTemplateController extends BaseController {

    @Autowired
    private SMSTemplateServiceI smsTemplateServiceI;

    @Autowired
    private DictServiceI dictServiceI;

    @Autowired
    private SystemService systemService;

    private static final String TYPEKEY = "SMS_TYPE";

    private static final String SENDTIMESKEY = "SMS_DEFAULT_LIMIT_TIMES";

    private static final String SENDTIMESTYPEKEY = "SMS_DEFAULT_LIMIT_TIMES";

    private static final Logger logger = Logger.getLogger(SMSTemplateController.class);

    @RequestMapping(params = "toSMS")
    public ModelAndView goToView() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("ppms/smsTemplate/smsView");
        modelAndView.addObject("smsList", searchTypeForView());
        return modelAndView;
    }

    @RequestMapping(params = "datagrid")
    public void datagrid(HttpServletRequest request, HttpServletResponse response, DataGrid datagrid) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.SMS_TEMPLATE_CONFIGURATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        String smsType = request.getParameter("smsType");
        Map<String, String> map = new HashMap<>();
        try {
            this.smsTemplateServiceI.queryListByCondition(datagrid, smsType);
            map = this.dictServiceI.queryForOptions(TYPEKEY, null);
        } catch (Exception e) {
            logger.error(e);
        }
        List<MessageEntity> messageEntityList = datagrid.getResults();
        if (messageEntityList != null && messageEntityList.size() > 0) {
            List<SmsTemplateDTO> dtoList = new LinkedList<>();
            for (MessageEntity message : messageEntityList) {
                SmsTemplateDTO dto = new SmsTemplateDTO();
                try {
                    MyBeanUtils.copyBeanNotNull2Bean(message, dto);
                } catch (Exception e) {
                    logger.error(e);
                }
                dto.setSmsType(map.get(message.getSmsType()));
                dtoList.add(dto);
            }
            datagrid.setResults(dtoList);
        }
        TagUtil.datagrid(response, datagrid);
    }

    /**
     * 新增/修改
     *
     * @param dto
     * @return
     */
    @RequestMapping(params = "saveRows")
    @ResponseBody
    public AjaxJson saveRows(SmsTemplateDTO dto,HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.SMS_TEMPLATE_CONFIGURATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson j = new AjaxJson();
        String message = "";
        Map<String, String> stringMap = new HashMap<>();
        try {
            stringMap = this.dictServiceI.queryForOptions(TYPEKEY, null);
        } catch (Exception e) {
            logger.error(e);
        }
        if (dto.getId() != null) {
            try {
                smsTemplateServiceI.updateMessage(dto,stringMap);
                message = "Update successfully";
            } catch (Exception e) {
                logger.error(e);
                if (e instanceof BusinessException) {
                    message = e.getMessage();
                } else {
                    message = "Update failed";
                }
            }
        } else {
            try {
                smsTemplateServiceI.save(dto,stringMap);
                message = "Add successfully";
            } catch (Exception e) {
                logger.error(e);
                if (e instanceof BusinessException) {
                    message = e.getMessage();
                } else {
                    message = "Add failed";
                }
            }
        }
        j.setMsg(message);
        return j;
    }

    /**
     * 跳转到修改页面
     *
     * @param request
     * @return
     */
    @RequestMapping(params = "toUpdate")
    public ModelAndView tabDemo(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.SMS_TEMPLATE_CONFIGURATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("ppms/smsTemplate/sms_edit");
        String id = request.getParameter("id");
        if (StringUtil.isNotEmpty(id)) {
            try {
                MessageEntity messageEntity = smsTemplateServiceI.getEntity(MessageEntity.class, Integer.parseInt(id));
                SmsTemplateDTO dto = new SmsTemplateDTO();
                MyBeanUtils.copyBeanNotNull2Bean(messageEntity, dto);
                request.setAttribute("smsentity", dto);
                modelAndView.addObject("smsTemplateType", searchType(messageEntity.getSmsType()));
            } catch (Exception e) {
                logger.error(e);
            }
        }
        return modelAndView;
    }

    //查询字典表中配置的邮件的模板名和code
    private String searchType(String typecode) {
        Map map = new HashMap();
        if (oConvertUtils.isNotEmpty(typecode)) {
            Map<String, String> stringMap = null;
            try {
                stringMap = this.dictServiceI.queryForOptions(TYPEKEY, null);
            } catch (Exception e) {
                logger.error(e);
            }
            List<Map<String, String>> mapList = new ArrayList<>(10);
            if (stringMap != null && stringMap.size() > 0) {
                Map map1 = new HashMap();
                if(stringMap.containsKey(typecode)){
                    map1.put("code", typecode);
                    map1.put("name", stringMap.get(typecode));
                    mapList.add(map1);
                }
                map.put("sms_type", mapList);
            }
        }
        List<Map<String, List>> list = new ArrayList<>();
        list.add(map);
        return JSONObject.toJSONString(list);
    }

    @RequestMapping(params = "toAdd")
    public ModelAndView toAdd(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.SMS_TEMPLATE_CONFIGURATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("ppms/smsTemplate/sms_add");
        modelAndView.addObject("smsForAddList", searchTypeForAdd());
        String times = "";
        try {
                Map<String, String> map = this.dictServiceI.queryForOptions(SENDTIMESKEY, SENDTIMESTYPEKEY);
                if (null != map && map.size() > 0) {
                    times = ((String) (map.values().toArray())[0]);
                }
        } catch (Exception e) {
            logger.error(e);
        }
        modelAndView.addObject("sendTimes", times);
        return modelAndView;
    }

    @RequestMapping(params = "doDel")
    @ResponseBody
    public AjaxJson doDel(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.SMS_TEMPLATE_CONFIGURATION.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson j = new AjaxJson();
        String message = "Delete failed";
        String id = request.getParameter("id");
        try {
            if (oConvertUtils.isNotEmpty(id)) {
                MessageEntity messageEntity = smsTemplateServiceI.getEntity(MessageEntity.class, Integer.parseInt(id));
                smsTemplateServiceI.delete(messageEntity);
                message = "Delete successfully";
            }
        } catch (Exception e) {
            logger.error(e);
        }
        j.setMsg(message);
        return j;
    }

    private String searchTypeForAdd() {
        Map<String, String> map = new HashMap<>();
        List<MessageEntity> messageEntityList = null;
        try {
            map = this.dictServiceI.queryForOptions(TYPEKEY, null);
            messageEntityList = this.smsTemplateServiceI.getList(MessageEntity.class);
        } catch (Exception e) {
            logger.error(e);
        }
        if (messageEntityList != null && messageEntityList.size() > 0) {
            for (MessageEntity entity : messageEntityList) {
                map.remove(entity.getSmsType());
            }
        }
        List<Map<String, String>> maplist = new ArrayList();
        Set<Map.Entry<String, String>> entrySet = map.entrySet();
        for (Map.Entry<String, String> m : entrySet) {
            Map<String, String> stringMap = new HashMap();
            stringMap.put("name", m.getValue());
            stringMap.put("code", m.getKey());
            maplist.add(stringMap);
        }
        return JSONObject.toJSONString(maplist);
    }

    private String searchTypeForView() {
        Map<String, String> map = this.dictServiceI.queryForOptions(TYPEKEY, null);
        List<Map<String, String>> elist = new ArrayList(10);
        if (map != null && map.size() > 0) {
            Set<Map.Entry<String, String>> entrySet = map.entrySet();
            Iterator iterator = entrySet.iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, String> entry = (Map.Entry<String, String>) iterator.next();
                Map map1 = new HashMap();
                map1.put("name", entry.getValue());
                map1.put("code", entry.getKey());
                elist.add(map1);
            }
        }
        return JSONObject.toJSONString(elist);
    }
}
