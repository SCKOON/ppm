package com.ppms.collectionComputationQuery.controller;

import com.constants.Constants;
import com.ppms.collectionComputationQuery.service.CollectionComputationServiceI;
import com.ppms.utils.DataReturn;
import com.ppms.vo.CalFailedResultVo;
import com.ppms.vo.CollectionComputationResultVo;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.jeecgframework.web.system.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;

/**   
 * @Title: Controller
 * @Description: M_METER_DATA
 * @author zhangdaihao
 * @date 2018-05-15 15:04:46
 * @version V1.0   
 *
 */
@Controller
@RequestMapping("/collectionComputationController")
public class CollectionComputationController extends BaseController {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = Logger.getLogger(CollectionComputationController.class);

	@Autowired
	private CollectionComputationServiceI collectionComputationService;

	@Autowired
	private SystemService systemService;
	/**
	 * 
	 * 
	 * @return
	 */
	@RequestMapping(params = "list")
	public ModelAndView mainlist(HttpServletRequest request) {
		return new ModelAndView("ppms/collectionComputationQuery/collectionComputationMainList");
	}
	

	/**
	 *
	 * 
	 * @return
	 */
	@RequestMapping(params = "mainlist")
	public ModelAndView list(HttpServletRequest request) {
		return new ModelAndView("ppms/collectionComputationQuery/collectionComputationList");
	}
	

	/**
	 *
	 * @return
	 */
	@RequestMapping(params = "tabs")
	public ModelAndView tabs(HttpServletRequest request) {
		return new ModelAndView("ppms/collectionComputationQuery/collectionComputationTabs");
	}
	
	/**
	 * 
	 * @return
	 */
	@RequestMapping(params = "calFailedlist")
	public ModelAndView smslist(HttpServletRequest request) {
		return new ModelAndView("ppms/collectionComputationQuery/calFailedListBase");
	}
	
	
	
	

	/**
	 * easyui AJAX请求数据
	 * 
	 * @param request
	 * @param response
	 * @param dataGrid
	 * @param
	 */

	@RequestMapping(params = "datagrid")
	public void datagrid(CollectionComputationResultVo resultVo,HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
		try{
			if(!systemService.hasPrivilege(request.getSession().getId(),Constants.FUNCTION_URL.METER_COMPUTION_QUERY.getStatus())){
				request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
			}else{
				DataReturn dataReturn;
				try {
					dataReturn = this.collectionComputationService.getAllEntities(resultVo,dataGrid.getPage(),dataGrid.getRows(),request);
					dataGrid.setResults(dataReturn.getRows());
					dataGrid.setTotal((int)dataReturn.getTotal());
				} catch (ParseException e) {
					logger.error(e.getMessage(),e);
				}
				TagUtil.datagrid(response, dataGrid);
			}
		}catch (Exception e){
			logger.error(e.getMessage(),e);
		}
	}



	@RequestMapping(params = "calFaileddatagrid")
	public void calFaileddatagrid(CalFailedResultVo resultVo,HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
		try{
			if(!systemService.hasPrivilege(request.getSession().getId(),Constants.FUNCTION_URL.METER_COMPUTION_QUERY.getStatus())){
				request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
			}else{
				DataReturn dataReturn;
				try {
					dataReturn = this.collectionComputationService.getAllCalFailed(resultVo,dataGrid.getPage(),dataGrid.getRows(),request);
					if(dataReturn.getTotal()== 0){
						dataGrid = null;
					}else{
						dataGrid.setResults(dataReturn.getRows());
						dataGrid.setTotal((int)dataReturn.getTotal());
					}
				} catch (ParseException e) {
					logger.error(e.getMessage(),e);
				}
				TagUtil.datagrid(response, dataGrid);
			}
		}catch (Exception e){
			logger.error(e.getMessage(),e);
		}

	}
	
	
}
