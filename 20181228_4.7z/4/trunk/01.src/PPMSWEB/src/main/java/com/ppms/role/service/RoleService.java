package com.ppms.role.service;

import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.web.system.pojo.base.TSRole;

import java.util.List;

public interface RoleService {

    /**
     * @Description 实现用户在jsp端输入查询参数，返回参数的查询结果
     * @param tsRole
     * @return
     */
    public List<TSRole> queryListByContion(TSRole tsRole, DataGrid dataGrid);

    /**
     * @Description 用于校验用户新增和修改角色时 角色name和角色code是否已存在
     * @param tsRole
     * @return 是否可以新增或者修改
     */
    public boolean queryListByConditionForCheck(TSRole tsRole);

    /**
     * @Description 主要用来当用户登录成功之后，维护用户和角色关系
     * @param roleName
     * @return
     */
    public TSRole queryRoleByName(String roleName);

    public void delRole(TSRole role);

    public void saveRole(TSRole role);

    public void update(TSRole role);


    public void updateAuthority(String roleId, String rolefunction);
}
