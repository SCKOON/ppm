package com.ppms.channelManagement.controller;

import com.constants.Constants;
import com.ppms.channelManagement.dto.ChannelDTO;
import com.ppms.entity.ChannelEntity;
import com.ppms.channelManagement.service.ChannelServiceI;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.exception.BusinessException;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.common.model.json.ValidForm;
import org.jeecgframework.core.util.MyBeanUtils;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.jeecgframework.web.system.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = {"/channelController"})
public class ChannelController extends BaseController {

    @Autowired
    private ChannelServiceI channelService;

    @Autowired
    private SystemService systemService;

    private static final Logger logger = Logger.getLogger(ChannelController.class);

    @RequestMapping(params = "goChannel")
    public ModelAndView goChannelManage() {
        return new ModelAndView("ppms/channel/channelView");
    }

    @RequestMapping(params = "datagrid")
    public void datagridList(HttpServletRequest request, HttpServletResponse response, DataGrid datagrid) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.CHANNEL_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        channelService.queryListForView(datagrid, request);
        List<ChannelEntity> channelEntityList = datagrid.getResults();
        List<ChannelDTO> dtoList = new ArrayList<>();
        if (null != channelEntityList && channelEntityList.size() > 0) {
            for (ChannelEntity entity : channelEntityList) {
                ChannelDTO dto = new ChannelDTO();
                try {
                    MyBeanUtils.copyBeanNotNull2Bean(entity, dto);
                    dtoList.add(dto);
                } catch (Exception e) {
                    logger.error(e);
                }
            }
        }
        datagrid.setResults(dtoList);
        TagUtil.datagrid(response, datagrid);
    }

    @RequestMapping(params = "goAdd")
    public ModelAndView goAdd(HttpServletRequest request,HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.CHANNEL_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        return new ModelAndView("ppms/channel/channel-add");
    }

    @RequestMapping(params = "goUpdate")
    public ModelAndView goUpdate(ChannelDTO channel, HttpServletRequest req, HttpServletResponse response) {
        if(!systemService.hasPrivilege(req.getSession().getId(), Constants.FUNCTION_URL.CHANNEL_MANAGEMENT.getStatus())){
            try {
                req.getRequestDispatcher("/webpage/common/401.htm").forward(req,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        ChannelEntity channelEntity;
        try {
            channelEntity = channelService.getEntity(ChannelEntity.class, channel.getId());
            MyBeanUtils.copyBeanNotNull2Bean(channelEntity, channel);
            req.setAttribute("channelUpdatePage", channel);
        } catch (Exception e) {
            logger.error(e);
        }
        return new ModelAndView("ppms/channel/channel-edit");
    }


    @RequestMapping(params = "doAdd")
    @ResponseBody
    public AjaxJson doAdd(ChannelDTO channel, HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.CHANNEL_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson j = new AjaxJson();
        String message = "Add channel [" + channel.getName() + "] successfully";
        ChannelEntity channelEntity = new ChannelEntity();
        try {
            MyBeanUtils.copyBean2Bean(channelEntity, channel);
            channelService.save(channelEntity);
        } catch (Exception e) {
            logger.error(e);
            message = "Add channel [" + channel.getName() + "] failed";
            if (e instanceof BusinessException) {
                message = e.getMessage();
            }
        }
        j.setMsg(message);
        return j;
    }

    @RequestMapping(params = "doUpdate")
    @ResponseBody
    public AjaxJson doUpdate(ChannelDTO channelDTO, HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.CHANNEL_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        logger.info("---start update channel---");
        AjaxJson j = new AjaxJson();
        String message = "Update channel [" + channelDTO.getName() + "] failed";
        ChannelEntity channelEntity = new ChannelEntity();
        try {
            MyBeanUtils.copyBeanNotNull2Bean(channelDTO,channelEntity);
            channelService.saveOrUpdate(channelEntity);
            message = "Update channel [" + channelDTO.getName() + "] successfully";
        } catch (BusinessException e){
            message = e.getMessage();
            logger.error(e);
        } catch (Exception e) {
            logger.error(e);
        }

        j.setMsg(message);
        logger.info("end update channel:" + message);
        return j;
    }

    @RequestMapping(params = "doDel")
    @ResponseBody
    public AjaxJson doDel(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.CHANNEL_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson j = new AjaxJson();
        String message = "Delete channel failed";
        String id = request.getParameter("id");
        if (oConvertUtils.isNotEmpty(id)) {
            ChannelDTO channel = new ChannelDTO();
            try {
                channel.setId(Integer.parseInt(id));
                channelService.delete(channel);
                message = "Delete channel successfully";
            } catch (Exception e) {
                logger.error(e);
                if (e instanceof BusinessException) {
                    message = e.getMessage();
                }
            }
        }
        j.setMsg(message);
        return j;
    }

    @RequestMapping(params = "doBatchDel")
    @ResponseBody
    public AjaxJson doBatchDel(String ids, HttpServletRequest request,HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.CHANNEL_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson j = new AjaxJson();
        String message = "Delete channel failed";
        try {
            channelService.batchDelete(ids);
            message = "Delete channel successfully";
        } catch (Exception e) {
            logger.error(e);
            if (e instanceof BusinessException) {
                message = e.getMessage();
            }
        }
        j.setMsg(message);
        return j;
    }

    @RequestMapping(params = "queryTerminalStatus")
    @ResponseBody
    public AjaxJson queryTerminalStatus(HttpServletRequest request) {
        AjaxJson json = new AjaxJson();
        Integer channelid = Integer.parseInt(request.getParameter("id"));
        String status = request.getParameter("status");
        if (channelid != null && oConvertUtils.isNotEmpty(status)) {
            ChannelEntity channelEntity = new ChannelEntity();
            channelEntity.setStatus(status);
            channelEntity.setId(channelid);
            try {
                json.setSuccess(channelService.queryTerminalStatusIsValidByChannelId(channelEntity));
            } catch (Exception e) {
                logger.error(e);
                json.setSuccess(false);
            }
        }
        return json;
    }

    /**
     * 查询name是否有重名的
     *
     * @param request
     * @return
     */
    @RequestMapping(params = "queryNameExistOrNot")
    @ResponseBody
    public ValidForm queryNameExistOrNot(HttpServletRequest request) {
        ValidForm v = new ValidForm();
        String name = oConvertUtils.getString(request.getParameter("param"));
        String oldName = oConvertUtils.getString(request.getParameter("name"));
        List<ChannelEntity> channelEntityList = new ArrayList<>();
        if (!StringUtils.isEmpty(name)) {
            CriteriaQuery criteriaQuery = new CriteriaQuery(ChannelEntity.class);
            criteriaQuery.eq("name", name);
            criteriaQuery.add();
            try {
                channelEntityList = this.channelService.getListByCriteriaQuery(criteriaQuery, false);
            } catch (Exception e) {
                logger.error(e);
            }
        }
        if (channelEntityList != null && channelEntityList.size() > 0 && !name.equals(oldName)) {
            v.setInfo("name is already existe");
            v.setStatus("n");
        }
        return v;
    }

    /**
     * 查询channel_code是否有重名的
     *
     * @param request
     * @return
     */
    @RequestMapping(params = "queryCodeExistOrNot")
    @ResponseBody
    public ValidForm queryCodeExistOrNot(HttpServletRequest request) {

        ValidForm v = new ValidForm();
        String code = oConvertUtils.getString(request.getParameter("param"));
        String oldCode = oConvertUtils.getString(request.getParameter("code"));
        List<ChannelEntity> channelEntityList = new ArrayList<>();
        if (!StringUtils.isEmpty(code)) {
            CriteriaQuery criteriaQuery = new CriteriaQuery(ChannelEntity.class);
            criteriaQuery.eq("code", code);
            criteriaQuery.add();
            try {
                channelEntityList = this.channelService.getListByCriteriaQuery(criteriaQuery, false);
            } catch (Exception e) {
                logger.error(e);
            }
        }
        if (channelEntityList != null && channelEntityList.size() > 0 && !oldCode.equals(code)) {
            v.setInfo("code is already existe");
            v.setStatus("n");
        }
        return v;
    }

    //add by yangyong 20180802 start
    @RequestMapping(params = "goNewChannel")
    public ModelAndView goNewChannelManage() {
        return new ModelAndView("ppms/channel/channel-query");
    }

    @RequestMapping(params = "newDatagrid")
    public void datagrid(ChannelEntity channelEntity, HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) throws ParseException {
        channelService.queryListForView(dataGrid, request);
        List<ChannelEntity> channelEntityList = dataGrid.getResults();
        List<ChannelDTO> dtoList = new ArrayList<>();
        if (null != channelEntityList && channelEntityList.size() > 0) {
            for (ChannelEntity entity : channelEntityList) {
                ChannelDTO dto = new ChannelDTO();
                try {
                    MyBeanUtils.copyBeanNotNull2Bean(entity, dto);
                    dtoList.add(dto);
                } catch (Exception e) {
                    logger.error(e);
                }
            }
        }
        dataGrid.setResults(dtoList);
        TagUtil.datagrid(response, dataGrid);
    }

}
