package com.ppms.creditTransfer;

import com.constants.ApproveStatusEnum;
import com.constants.Constants;
import com.ppms.creditTransfer.dto.CreditTransferDetail;
import com.ppms.dictionary.service.DictServiceI;
import com.ppms.entity.CounterEntity;
import com.ppms.entity.CreditTransferEntity;
import com.ppms.creditTransfer.service.CreditTransferServiceI;


import com.ppms.ldapLogin.util.ResourceUtils;
import com.ppms.utils.DataReturn;
import com.ppms.utils.GetClientIPUtil;
import com.ppms.vo.CreditTransferQueryVo;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.exception.BusinessException;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.DataGrid;

import org.jeecgframework.core.util.MyBeanUtils;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.jeecgframework.web.system.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(value = {"/creditTransferController"})
public class CreditTransferController extends BaseController {

    private static final Logger logger = Logger.getLogger(CreditTransferController.class);

    @Autowired
    private CreditTransferServiceI creditTransferServiceI;

    @Autowired
    private SystemService systemService;

    @Autowired
    private DictServiceI dictServiceI;

    private final static String LOW_CREDIT_ALARM_GROUP = "LOW_CREDIT_ALARM";

    private final static String LOW_CREDIT_ALARM_TYPE = "LOW CREDIT ALARM";

    @RequestMapping(params = {"toview"})
    @ResponseBody
    public ModelAndView toview() {
        return new ModelAndView("ppms/creditTransfer/creditTransferApply");
    }

    @RequestMapping(params = {"creditApprove"})
    @ResponseBody
    public ModelAndView toApproveview() {
        return new ModelAndView("ppms/creditTransfer/creditTransferApprove");
    }

    @RequestMapping(params = {"toDetailView"})
    @ResponseBody
    public ModelAndView toDetailview(HttpServletRequest request, HttpServletResponse response, CreditTransferDetail detail) {
        logger.info("-------start To credit transfer record detail view --------");
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.CREDIT_TRANSFER_APPLY.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("ppms/creditTransfer/creditTransferView");
        detail = creditTransferServiceI.generateDetailInformation(detail);
        modelAndView.addObject("jsonData", detail);
        logger.info("-------end To credit transfer record detail view --------");
        return modelAndView;
    }

    /**
     * 审批员查看所有的余额转移记录
     *
     * @param request
     * @param response
     * @param dataGrid
     */
    @RequestMapping(params = {"getCreditApplyList"})
    @ResponseBody
    public void getCreditApplyList(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        logger.info("------- To query credit transfer record view --------");
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.CREDIT_TRANSFER_APPROVAL.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        //先查询当前用户对应的角色，以及对应的柜台人员的名称
        //因为登录时保存的是String类型，所以instanceof判断对象就没必要了
        String terminalId = (String) request.getSession().getAttribute("terminalId");
        if (StringUtils.isEmpty(terminalId)) {
            logger.error("---current user" + ResourceUtils.getSessionUser().getName() + " no select terminal when to access credit transfer approve!");

        } else {
            CreditTransferQueryVo vo = new CreditTransferQueryVo();
            String srcAccNo = request.getParameter("srcAccNo");
            String tgtAccNo = request.getParameter("tgtAccNo");
            String applyDate_begin1 = request.getParameter("applyDate_begin1");
            String applyDate_end2 = request.getParameter("applyDate_end2");
            String apprStatus = request.getParameter("apprStatus");
            if (oConvertUtils.isNotEmpty(srcAccNo) || oConvertUtils.isNotEmpty(applyDate_begin1) || oConvertUtils.isNotEmpty(tgtAccNo) || oConvertUtils.isNotEmpty(applyDate_end2) || oConvertUtils.isNotEmpty(apprStatus)) {
                vo.setSrcAccNo(srcAccNo);
                vo.setTgtAccNo(tgtAccNo);
                vo.setApplyDate_begin(applyDate_begin1);
                vo.setApplyDate_end(applyDate_end2);
                vo.setApprStatus(apprStatus);

                DataReturn data = new DataReturn();
                try {
                    data = creditTransferServiceI.getApplyCreditTransferRecord(vo, dataGrid.getPage(), dataGrid.getRows(), terminalId);
                } catch (Exception e) {
                    logger.error(e);
                }
                dataGrid.setTotal((int) data.getTotal());
                dataGrid.setResults(data.getRows());
            }
        }
        logger.info("------- end query credit transfer record view --------");
        TagUtil.datagrid(response, dataGrid);
    }

    /**
     * 余额转移申请
     *
     * @param detail
     * @param request
     * @param dataGrid
     * @return
     */
    @ResponseBody
    @RequestMapping(params = "transfer")
    public String applyTransferAmount(CreditTransferDetail detail, HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.CREDIT_TRANSFER_APPLY.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return "";
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        String message = "Transfer Apply failed";

        String ip = GetClientIPUtil.getIpAddr(request);
        //1.通过IP获取当前操作人所在的柜台 terminal counter
        CriteriaQuery criteriaQuery = new CriteriaQuery(CounterEntity.class);
        criteriaQuery.eq("ip", ip);
        criteriaQuery.add();
        List<CounterEntity> counterEntities = null;
        try {
            counterEntities = creditTransferServiceI.getListByCriteriaQuery(criteriaQuery, false);
        } catch (Exception e) {
            logger.error(e);
        }
        if (counterEntities == null || counterEntities.size() != 1) {
            message = " No unique counter correspond to Your Ip";
            logger.error("---No counter or Much counter exist correspond to the Ip---");
            return message;
        }
        CounterEntity counterEntity = counterEntities.get(0);

        //2.获取页面用户转移的信息
        String transferAmount = request.getParameter("amount");
        CreditTransferEntity creditTransferEntity = new CreditTransferEntity();
        try {
            MyBeanUtils.copyBeanNotNull2Bean(detail, creditTransferEntity);
        } catch (Exception e) {
            logger.error(e);
        }
        creditTransferEntity.setCounterid(counterEntity.getId());
        creditTransferEntity.setTerminalid(counterEntity.getTerminalEntity().getId());
        try {
            creditTransferEntity.setTransferAmt(new BigDecimal(transferAmount));
            //3.查询低余额预警值，转移之后余额如果低于预警值需要发送短信。
            Map<String, String> paramMap = dictServiceI.queryForOptions(LOW_CREDIT_ALARM_GROUP, LOW_CREDIT_ALARM_TYPE);
            String lowCredit = null;
            if (null != paramMap && paramMap.size() > 0) {
                lowCredit = (String) paramMap.values().toArray()[0];
            }
            //4.向系统申请余额转移
            creditTransferServiceI.applyTransfer(creditTransferEntity, request, lowCredit);
            message = "Transfer Apply Successfully";
        } catch (BusinessException e) {
            logger.error(e.getMessage());
            message = e.getMessage();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return message;
    }

    /**
     * @param request
     * @return
     * @description 获取选中的所有行，approveOrNot and decline reason etc.
     * 主要
     * @author shenchen
     */
    @RequestMapping(params = {"doTransfer"})
    @ResponseBody
    public String confirmTransfer(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.CREDIT_TRANSFER_APPROVAL.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        String message = "";
        String ids = request.getParameter("ids");
        if ("".equals(oConvertUtils.getString(ids))) {
            return "Transfer failed ";
        }
        String status = oConvertUtils.getString(request.getParameter("status"));
        String reason = oConvertUtils.getString(request.getParameter("applyReason"));
        if (oConvertUtils.isNotEmpty(ids)) {
            try {
                int entityId = Integer.parseInt(ids);
                CreditTransferEntity creditTransferEntity = new CreditTransferEntity();
                creditTransferEntity.setId(entityId);
                creditTransferServiceI.doTransfer(creditTransferEntity, status, reason);
                message = (status.equals(ApproveStatusEnum.APPROVED.getStatus())?"[Approve]":"[Decline]") + " successfully.";
            } catch (BusinessException e){
                logger.error(e.getMessage(), e);
                message = e.getMessage();
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
                message = (status.equals(ApproveStatusEnum.APPROVED.getStatus())?"[Approve]":"[Decline]") + " failed.";
            }
        }
        return message;
    }

    @RequestMapping(params = {"goCheck"})
    @ResponseBody
    public ModelAndView toApproveDetailview(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.CREDIT_TRANSFER_APPROVAL.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        CreditTransferDetail detail = new CreditTransferDetail();
        String transferId = request.getParameter("id");
        try {
            detail = creditTransferServiceI.queryForDetail(transferId);
        } catch (Exception e) {
            logger.error(e);
        }
        request.setAttribute("jsonData", detail);
        return new ModelAndView("ppms/creditTransfer/creditTransferApprovalDetail");
    }

}
