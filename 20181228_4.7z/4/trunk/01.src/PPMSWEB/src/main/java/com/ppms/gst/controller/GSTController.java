package com.ppms.gst.controller;

import com.constants.Constants;
import com.ppms.entity.GstLogEntity;
import com.ppms.gst.dto.GSTdto;
import com.ppms.entity.GSTEntity;
import com.ppms.gst.service.GSTServiceI;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.exception.BusinessException;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.util.DateUtils;
import org.jeecgframework.core.util.MyBeanUtils;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.jeecgframework.web.system.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping(value = {"/gstController"})
public class GSTController extends BaseController {

    /**
     * Logger for this class
     */
    private static final Logger logger = Logger.getLogger(GSTController.class);

    @Autowired
    private GSTServiceI gstServiceI;

    @Autowired
    private SystemService systemService;

    @RequestMapping(params = "toGst")
    public ModelAndView goToView() {
        return new ModelAndView("/ppms/gst/gstview");
    }

    @RequestMapping(params = "toGstLog")
    public ModelAndView goToLogView() {
        return new ModelAndView("/ppms/gst/gstLogView");
    }

    @RequestMapping(params = "datagrid")
    public void datagrid(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.GST_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        gstServiceI.queryListByCondition(dataGrid, request);
        List<GSTdto> gsTdtoList = new ArrayList<>();
        if (null != dataGrid.getResults() && dataGrid.getResults().size() > 0) {
            for (GSTEntity entity : (List<GSTEntity>) dataGrid.getResults()) {
                GSTdto dto = new GSTdto();
                BigDecimal rate = entity.getRate();
                if (null != rate) {
                    entity.setRate(rate.movePointRight(2));
                }
                try {
                    MyBeanUtils.copyBeanNotNull2Bean(entity,dto);
                } catch (Exception e) {
                    logger.error(e);
                }
                gsTdtoList.add(dto);
            }
        }
        dataGrid.setResults(gsTdtoList);
        TagUtil.datagrid(response, dataGrid);
    }

    /**
     * @param gsTdto
     * @param request
     * @return
     * @description 新增tariff
     */
    @RequestMapping(params = "doSave")
    @ResponseBody
    public AjaxJson save(GSTdto gsTdto, HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.GST_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson j = new AjaxJson();
        String message = "save Gst version:" + gsTdto.getVersion() + " failed";
        GSTEntity gstEntity = new GSTEntity();
        try {
            MyBeanUtils.copyBeanNotNull2Bean(gsTdto, gstEntity);
            gstServiceI.saveAndLog(gstEntity);
            message = "save Gst version:" + gstEntity.getVersion() + " successfully";
        } catch(BusinessException e){
            message = e.getMessage();
            logger.error(e.getMessage(),e);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
        j.setMsg(message);
        return j;
    }

    /**
     * @param gsTdto
     * @param request
     * @return
     * @description 修改tariff
     */
    @RequestMapping(params = "doUpdate")
    @ResponseBody
    public AjaxJson update(GSTdto gsTdto, HttpServletRequest request, HttpServletResponse response) {
        logger.info("--start update gst--");
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.GST_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson j = new AjaxJson();
        String message = "";
        GSTEntity gstEntity = new GSTEntity();
        if (oConvertUtils.isNotEmpty(gsTdto.getId())) {
            try {
                MyBeanUtils.copyBeanNotNull2Bean(gsTdto, gstEntity);
                gstServiceI.updateAndLog(gstEntity);
                message = "update Gst version:" + gstEntity.getVersion() + " successfully";
            } catch (Exception e) {
                logger.error(e);
                message = "update Gst version:" + gstEntity.getVersion() + " failed";
                if (e instanceof BusinessException) {
                    message = e.getMessage();
                }
            }
        } else {
            message = "update Gst version:" + gstEntity.getVersion() + " failed";
        }
        j.setMsg(message);
        logger.info("--complete gst update--:" + message);
        return j;
    }

    /**
     * 前端ajax校验日期是否与别的记录日期间隔重复
     *
     * @param request
     * @return
     */
    @RequestMapping(params = "queryTimeIsInUse")
    @ResponseBody
    public AjaxJson queryTimeIsInUse(HttpServletRequest request) {
        logger.info("---verify tariff execu date is confict ---");
        AjaxJson j = new AjaxJson();
        String version = request.getParameter("version");
        String code = request.getParameter("code");
        //校验同一种code 起始时间-结束时间是否重叠
        String beginTime = request.getParameter("startTime");
        String endTime = request.getParameter("endTime");

        CriteriaQuery criteriaQuery = new CriteriaQuery(GSTEntity.class);
        if (oConvertUtils.isNotEmpty(code)) {
            criteriaQuery.eq("code", code);
        }
        criteriaQuery.isNotNull("startTime");
        criteriaQuery.isNotNull("endTime");
        if (oConvertUtils.isNotEmpty(version)) {
            criteriaQuery.notEq("version", version);
        }
        criteriaQuery.add();
        List<GSTEntity> gstEntityList = this.gstServiceI.getListByCriteriaQuery(criteriaQuery, false);
        if (gstEntityList != null && gstEntityList.size() > 0) {
            try {
                Date beginDate = DateUtils.parseDate(beginTime, "yyyy-MM-dd");
                Date endDate = DateUtils.parseDate(endTime, "yyyy-MM-dd");
                List<GSTEntity> gstEntities1 = gstEntityList.stream().filter(gstEntity -> beginDate.compareTo(gstEntity.getEndTime()) <= 0 && endDate.compareTo(gstEntity.getEndTime()) >= 0)
                        .collect(Collectors.toList());
                if (gstEntities1 != null && gstEntities1.size() > 0) {
                    j.setSuccess(false);
                    j.setMsg(" time comflict with other records");
                } else {
                    List<GSTEntity> gstEntities2 = gstEntityList.stream().filter(gstEntity -> beginDate.compareTo(gstEntity.getStartTime()) <= 0 && endDate.compareTo(gstEntity.getStartTime()) >= 0)
                            .collect(Collectors.toList());
                    if (gstEntities2 != null && gstEntities2.size() > 0) {
                        j.setSuccess(false);
                        j.setMsg("time comflict with other records");
                    } else {
                        List<GSTEntity> gstEntities3 = gstEntityList.stream().filter(gstEntity -> beginDate.compareTo(gstEntity.getStartTime()) >= 0 && beginDate.compareTo(gstEntity.getEndTime()) <= 0)
                                .collect(Collectors.toList());
                        if (gstEntities3 != null && gstEntities3.size() > 0) {
                            j.setSuccess(false);
                            j.setMsg(" time comflict with other records");
                        }
                    }
                }
            } catch (ParseException e) {
                logger.error(e);
                j.setSuccess(false);
                j.setMsg("startTime or endTime is invalid value");
                logger.info("---verify tariff execu date---:" + j.getMsg());
                return j;
            }
        }

        logger.info("---verify tariff execu date---:" + j.getMsg());
        return j;
    }

    @RequestMapping(params = "toUpdate")
    public ModelAndView update(HttpServletRequest request, HttpServletResponse response) {
        logger.info("---to gst update page---");
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.GST_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        String sid = request.getParameter("id");
        if (oConvertUtils.isNotEmpty(sid)) {
            try {
                int id = Integer.parseInt(sid);
                GSTEntity gstEntity = gstServiceI.getEntity(GSTEntity.class, id);
                BigDecimal rate = gstEntity.getRate();
                if (null != rate) {
                    //因为直接使用BigDecimal进行100倍乘积的话会有精度丢失问题，结果可能不对
                    gstEntity.setRate(rate.movePointRight(2));
                }
                request.setAttribute("entity", gstEntity);
            } catch (Exception e) {
                logger.error(e);
            }
        }
        logger.info("---to gst update page end---");
        return new ModelAndView("ppms/gst/gst_edit");
    }

    @RequestMapping(params = "toDetail")
    public ModelAndView detailView(HttpServletRequest request, HttpServletResponse response) {
        logger.info("---to gst detail page---");
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.GST_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        String sid = request.getParameter("id");
        if (oConvertUtils.isNotEmpty(sid)) {
            try {
                int id = Integer.parseInt(sid);
                GSTEntity gstEntity = gstServiceI.getEntity(GSTEntity.class, id);
                BigDecimal rate = gstEntity.getRate();
                if (null != rate) {
                    //因为直接使用BigDecimal进行100倍乘积的话会有精度丢失问题，结果可能不对
                    gstEntity.setRate(rate.movePointRight(2));
                }
                request.setAttribute("entity", gstEntity);
            } catch (Exception e) {
                logger.error(e);
            }
        }
        logger.info("---to gst detail page end---");
        return new ModelAndView("ppms/gst/gst_detail");
    }

    @RequestMapping(params = "toAdd")
    public ModelAndView toAdd(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.GST_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("ppms/gst/gst_add");
        modelAndView.addObject("version", genereateVersion());
        return modelAndView;
    }

    @RequestMapping(params = "logdatagrid")
    public void datagridLog(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        logger.info("---start query gst operation log---");
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.GST_AUDIT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        this.gstServiceI.queryListRecordByCondition(dataGrid, request);
        List<GSTdto> gsTdtoList = new ArrayList<>();
        if (null != dataGrid.getResults() && dataGrid.getResults().size() > 0) {
            for (GstLogEntity entity : (List<GstLogEntity>) dataGrid.getResults()) {
                GSTdto dto = new GSTdto();
                BigDecimal rate = entity.getRate();
                if (null != rate) {
                    entity.setRate(rate.setScale(2, RoundingMode.DOWN));
                }
                try {
                    MyBeanUtils.copyBeanNotNull2Bean(entity,dto);
                } catch (Exception e) {
                    logger.error(e.getMessage(),e);
                }
                gsTdtoList.add(dto);
            }
        }
        dataGrid.setResults(gsTdtoList);
        logger.info("---complete query gst operation log---");
        TagUtil.datagrid(response, dataGrid);

    }

    @RequestMapping(params = "doDel")
    @ResponseBody
    public AjaxJson doDel(HttpServletRequest request, HttpServletResponse response) {
        logger.info("---start delete gst---");
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.GST_MANAGEMENT.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson j = new AjaxJson();
        String message = "";
        String sid = request.getParameter("id");
        try {
            int id = Integer.parseInt(sid);
            GSTEntity gstEntity = new GSTEntity();
            gstEntity.setId(id);
            gstServiceI.delete(gstEntity);
            message = "Delete successfully";
        } catch (Exception e) {
            logger.error(e);
            message = "Delete failed";
            if(e instanceof BusinessException){
                message = e.getMessage();
            }
        }
        j.setMsg(message);
        logger.info("---complete delete gst---:" + message);
        return j;
    }


    /**
     * 2018V_1
     *
     * @return
     */
    private String genereateVersion() {
        String value = "";
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        //获取当前日期的年月
        int year = calendar.get(Calendar.YEAR);

        int num = gstServiceI.queryLastVersionNum(year) + 1;

        value = year + "V" + num;

        return value;
    }
}
