package com.ppms.role.service.impl;

import com.ppms.role.dao.RoleDao;
import com.ppms.role.service.RoleService;
import com.ppms.utils.DataSourceValue;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.common.service.impl.CommonServiceImpl;
import org.jeecgframework.core.extend.datasource.DataSourceType;
import org.jeecgframework.core.util.StringUtil;
import org.jeecgframework.web.system.pojo.base.TSFunction;
import org.jeecgframework.web.system.pojo.base.TSRole;
import org.jeecgframework.web.system.pojo.base.TSRoleFunction;
import org.jeecgframework.web.system.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional
@DataSourceValue(DataSourceType.dataSource_jeecg)
public class RoleServiceImpl extends CommonServiceImpl implements RoleService {

    @Autowired
    private RoleDao roleDao;

    @Autowired
    private SystemService systemService;

    private static final Logger logger = Logger.getLogger(RoleServiceImpl.class);

    @Override
    public List<TSRole> queryListByContion(TSRole tsRole, DataGrid dataGrid) {

        return roleDao.queryListByContion(tsRole,dataGrid);
    }

    /**
     * @Description 查询用户新增或修改角色时 角色名和角色code是否重名，如果重名 返回false，如果没有记录则返回true
     * @param tsRole
     * @return
     */
    @Override
    public boolean queryListByConditionForCheck(TSRole tsRole) {
        boolean flag = true;
        List<TSRole> roleList = roleDao.queryListByConditionForCheck(tsRole);
        if(roleList!=null&&roleList.size()>0) flag = false;

        return flag;
    }

    @Override
    public TSRole queryRoleByName(String roleName) {
        return roleDao.queryRoleByName(roleName);
    }

    @Override
    public void delRole(TSRole role) {
        delRoleFunction(role);
        role = systemService.getEntity(TSRole.class, role.getId());
        systemService.delete(role);
    }

    @Override
    public void saveRole(TSRole role) {
        super.save(role);
    }

    @Override
    public void update(TSRole role) {
        super.saveOrUpdate(role);
    }

    @Override
    public void updateAuthority(String roleId, String rolefunction) {
        TSRole role = this.systemService.get(TSRole.class, roleId);
        List<TSRoleFunction> roleFunctionList = systemService
                .findByProperty(TSRoleFunction.class, "TSRole.id",
                        role.getId());
        Map<String, TSRoleFunction> map = new HashMap<String, TSRoleFunction>();
        for (TSRoleFunction functionOfRole : roleFunctionList) {
            map.put(functionOfRole.getTSFunction().getId(), functionOfRole);
        }

        Set<String> set = new HashSet<String>();
        if (StringUtil.isNotEmpty(rolefunction)) {
            String[] roleFunctions = rolefunction.split(",");
            for (String s : roleFunctions) {
                set.add(s);
            }
        }

        List<TSRoleFunction> entitys = new ArrayList<TSRoleFunction>();
        List<TSRoleFunction> deleteEntitys = new ArrayList<TSRoleFunction>();
        for (String s : set) {
            if (map.containsKey(s)) {
                map.remove(s);
            } else {
                TSRoleFunction rf = new TSRoleFunction();
                TSFunction f = this.systemService.get(TSFunction.class, s);
                rf.setTSFunction(f);
                rf.setTSRole(role);
                entitys.add(rf);
            }
        }
        Collection<TSRoleFunction> collection = map.values();
        Iterator<TSRoleFunction> it = collection.iterator();
        for (; it.hasNext(); ) {
            deleteEntitys.add(it.next());
        }
        systemService.batchSave(entitys);
        systemService.deleteAllEntitie(deleteEntitys);
    }

    /**
     * 删除角色权限
     *
     * @param role
     */
    protected void delRoleFunction(TSRole role) {
        try {
            List<TSRoleFunction> roleFunctions = systemService.findByProperty(
                    TSRoleFunction.class, "TSRole.id", role.getId());
            if (roleFunctions.size() > 0) {
                for (TSRoleFunction tsRoleFunction : roleFunctions) {
                    systemService.delete(tsRoleFunction);
                }
            }
        } catch (Exception e) {
            logger.error(e);
        }
    }
}
