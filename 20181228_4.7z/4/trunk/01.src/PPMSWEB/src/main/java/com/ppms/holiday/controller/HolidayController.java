package com.ppms.holiday.controller;

import com.alibaba.fastjson.JSONObject;
import com.constants.Constants;
import com.ppms.dictionary.service.DictServiceI;
import com.ppms.holiday.dto.HolidayDTO;
import com.ppms.entity.HolidayInfoEntity;
import com.ppms.entity.HolidayLogEntity;
import com.ppms.holiday.service.HolidayInfoServiceI;
import org.apache.log4j.Logger;
import org.jeecgframework.core.common.controller.BaseController;
import org.jeecgframework.core.common.exception.BusinessException;
import org.jeecgframework.core.common.hibernate.qbc.CriteriaQuery;
import org.jeecgframework.core.common.model.json.AjaxJson;
import org.jeecgframework.core.common.model.json.DataGrid;
import org.jeecgframework.core.common.model.json.ValidForm;
import org.jeecgframework.core.util.MyBeanUtils;
import org.jeecgframework.core.util.StringUtil;
import org.jeecgframework.core.util.oConvertUtils;
import org.jeecgframework.tag.core.easyui.TagUtil;
import org.jeecgframework.web.system.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Controller
@RequestMapping(value = ("/holidayController"))
public class HolidayController extends BaseController {

    @Autowired
    private HolidayInfoServiceI holidayInfoServiceI;

    @Autowired
    private DictServiceI dictServiceI;

    @Autowired
    private SystemService systemService;

    private static final String TYPEKEY = "HOLIDAY";

    private static final Logger logger = Logger.getLogger(HolidayController.class);

    @RequestMapping(params = "toHoliday")
    public ModelAndView goToView() {
        ModelAndView modelAndView = new ModelAndView("ppms/holiday/holidayView");
        modelAndView.addObject("holidayList", JSONObject.toJSONString(searchTypeForView()));
        return modelAndView;
    }

    @RequestMapping(params = "datagrid")
    public void datagrid(HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.HOLIDAY.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        this.holidayInfoServiceI.queryListByCondition(dataGrid, request);
        List<HolidayDTO> holidayDTOList = new ArrayList();
        if (dataGrid.getResults() != null && dataGrid.getResults().size() > 0) {
            List<HolidayInfoEntity> holidayInfoEntityList = dataGrid.getResults();
            for (HolidayInfoEntity holidayInfoEntity : holidayInfoEntityList) {
                HolidayDTO dto = new HolidayDTO();
                try {
                    MyBeanUtils.copyBeanNotNull2Bean(holidayInfoEntity, dto);
                    //获取节假日所在的年份
                    if (null != holidayInfoEntity.getStartTime()) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(holidayInfoEntity.getStartTime());
                        dto.setYear(calendar.get(Calendar.YEAR) + "");
                    }
                    holidayDTOList.add(dto);
                } catch (Exception e) {
                    logger.error(e);
                }
            }
        }
        dataGrid.setResults(holidayDTOList);
        TagUtil.datagrid(response, dataGrid);
    }

    @RequestMapping(params = "doDel")
    @ResponseBody
    public AjaxJson doDel(HolidayDTO holiday, HttpServletRequest request, HttpServletResponse response) {
        logger.info("delete holiday start:holiday[" + holiday.toString() + "]");
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.HOLIDAY.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson j = new AjaxJson();
        String message = "Delete holiday failed";
        HolidayInfoEntity holidayInfoEntity = new HolidayInfoEntity();
        try {
            if (holiday.getId() != null) {
                holidayInfoEntity = holidayInfoServiceI.getEntity(HolidayInfoEntity.class, holiday.getId());
                holidayInfoServiceI.deleteNoTrue(holidayInfoEntity);
                message = "Delete holiday successfully";
            }
        } catch (Exception e) {
            logger.error(e);
            message = "Delete holiday failed";
        }
        j.setMsg(message);
        logger.info("----delete holiday end---,result:" + message);
        return j;
    }

    @RequestMapping(params = "doSave")
    @ResponseBody
    public AjaxJson save(HolidayDTO holiday, HttpServletRequest request, HttpServletResponse response) {
        logger.info("----add holiday start---,holiday[" + holiday.toString() + "]");
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.HOLIDAY.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson j = new AjaxJson();
        String message = "Add holiday failed";
        HolidayInfoEntity holidayInfoEntity = new HolidayInfoEntity();
        try {
            MyBeanUtils.copyBeanNotNull2Bean(holiday, holidayInfoEntity);
            holidayInfoServiceI.saveAndLog(holidayInfoEntity);
            message = "Add holiday successfully";
        } catch (Exception e) {
            logger.error(e);
            if (e instanceof BusinessException) {
                message = e.getMessage();
            }
        }
        j.setMsg(message);
        logger.info("----add holiday end---,result:" + message);
        return j;
    }


    /**
     * @param holiday
     * @param request
     * @return
     * @Description 正常操作的话，holidayInfoEntity肯定不是null
     */
    @RequestMapping(params = "doUpdate")
    @ResponseBody
    public AjaxJson update(HolidayDTO holiday, HttpServletRequest request, HttpServletResponse response) {
        logger.info("----update holiday start---,holiday[" + holiday.toString() + "]");
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.HOLIDAY.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        AjaxJson j = new AjaxJson();
        String message = "Update holiday Failed";
        HolidayInfoEntity holidayInfoEntity = new HolidayInfoEntity();
        try {
            MyBeanUtils.copyBeanNotNull2Bean(holiday, holidayInfoEntity);
            //校验是否在字典表中存在该holiday code
            if (holidayInfoServiceI.queryHolidayByCode(holidayInfoEntity.getCode()).size() > 0) {
                holidayInfoServiceI.saveAndLog(holidayInfoEntity);
                message = "Update holiday successfully";
            }
        } catch (Exception e) {
            logger.error(e);
            if (e instanceof BusinessException) {
                message = e.getMessage();
            }
        }
        j.setMsg(message);
        logger.info("----update holiday end---,result:" + message);
        return j;
    }

    @RequestMapping(params = "toAdd")
    public ModelAndView toAdd(HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.HOLIDAY.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        ModelAndView modelAndView = new ModelAndView("ppms/holiday/holiday_add");
        modelAndView.addObject("holidayList", searchTypeForAdd());
        return modelAndView;
    }

    /**
     * @return
     * @description 查询字典表中记录的节假日
     */
    private List<Map<String, String>> searchTypeForView() {
        Map<String, String> map = null;
        try {
            map = this.dictServiceI.queryForOptions(TYPEKEY, null);
        } catch (Exception e) {
            logger.error(e);
        }
        List<Map<String, String>> maplist = new ArrayList();
        if (map != null && map.size() > 0) {
            //清除历史列表，刷新
            Set<Map.Entry<String, String>> entrySet = map.entrySet();
            for (Map.Entry<String, String> m : entrySet) {
                Map<String, String> stringMap = new HashMap();
                stringMap.put("code", m.getKey());
                stringMap.put("name", m.getValue());
                maplist.add(stringMap);
            }
        }
        return maplist;
    }

    /**
     * @return
     * @description 新增节假日时，从字典表和数据库中查询还未添加的节假日
     */
    public String searchTypeForAdd() {
        List<Map<String, String>> maplist = new ArrayList();
        Map<String, String> map = new HashMap<>();
        List<HolidayInfoEntity> holidayInfoEntityList = null;
        try {
            map = this.dictServiceI.queryForOptions(TYPEKEY, null);
            holidayInfoEntityList = this.holidayInfoServiceI.getList(HolidayInfoEntity.class);
        } catch (Exception e) {
            logger.error(e);
        }
        if (holidayInfoEntityList != null && holidayInfoEntityList.size() > 0) {
            for (HolidayInfoEntity holidayInfoEntity : holidayInfoEntityList) {
                String code = holidayInfoEntity.getCode();
                if (map.containsKey(code)) {
                    map.remove(code);
                }
            }
        }
        Set<Map.Entry<String, String>> entrySet = map.entrySet();
        for (Map.Entry<String, String> m : entrySet) {
            Map<String, String> stringMap = new HashMap();
            stringMap.put("code", m.getKey());
            stringMap.put("name", m.getValue());
            maplist.add(stringMap);
        }
        return JSONObject.toJSONString(maplist);
    }

    //holiday code查询字典表中配置的节假日
    private String searchType(String typecode) {
        Map map = new HashMap();
        if (oConvertUtils.isNotEmpty(typecode)) {
            Map<String, String> stringMap = null;
            try {
                stringMap = this.holidayInfoServiceI.queryHolidayByCode(typecode);
            } catch (Exception e) {
                logger.error(e);
            }
            List<Map<String, String>> mapList = new ArrayList();
            if (stringMap != null && stringMap.size() > 0) {
                Set<Map.Entry<String, String>> entrySet = stringMap.entrySet();
                Iterator iterator = entrySet.iterator();
                while (iterator.hasNext()) {
                    Map.Entry<String, String> entry = (Map.Entry<String, String>) iterator.next();
                    Map map1 = new HashMap();
                    map1.put("name", entry.getKey());
                    map1.put("code", entry.getValue());
                    mapList.add(map1);
                }
                map.put("holidayList", mapList);
            }
        }
        List<Map<String, List>> list = new ArrayList<>();
        list.add(map);
        return JSONObject.toJSONString(list);
    }

    @RequestMapping(params = "toUpdate")
    public ModelAndView toUpdate(HolidayDTO holidayInfoEntity, HttpServletRequest request, HttpServletResponse response) {
        if(!systemService.hasPrivilege(request.getSession().getId(), Constants.FUNCTION_URL.HOLIDAY.getStatus())){
            try {
                request.getRequestDispatcher("/webpage/common/401.htm").forward(request,response);
                return null;
            } catch (Exception e) {
                logger.error(e.getMessage(),e);
            }
        }
        if (StringUtil.isNotEmpty(holidayInfoEntity.getId())) {
            try {
                HolidayInfoEntity entity = holidayInfoServiceI.getEntity(HolidayInfoEntity.class, holidayInfoEntity.getId());
                request.setAttribute("entity", entity);
                if (entity != null) {
                    request.setAttribute("holidayList", searchType(entity.getCode()));
                }
            } catch (Exception e) {
                logger.error(e);
            }
        }
        return new ModelAndView("ppms/holiday/holiday_edit");
    }

    @RequestMapping(params = "queryNameExistOrNot")
    @ResponseBody
    public ValidForm queryNameExistOrNot(HttpServletRequest request) {
        ValidForm v = new ValidForm();
        String name = oConvertUtils.getString(request.getParameter("param"));
        String oldName = oConvertUtils.getString(request.getParameter("name"));
        logger.info("add/update holidayInfo holidayName newName:[" + name + "]，oldname[" + oldName + "]");
        List<HolidayInfoEntity> holidayInfoEntityList = new ArrayList<>();
        if (!StringUtils.isEmpty(name)) {
            CriteriaQuery criteriaQuery = new CriteriaQuery(HolidayInfoEntity.class);
            criteriaQuery.eq("name", name);
            criteriaQuery.add();
            try {
                holidayInfoEntityList = this.holidayInfoServiceI.getListByCriteriaQuery(criteriaQuery, false);
            } catch (Exception e) {
                logger.error(e);
            }
        }


        if (holidayInfoEntityList != null && holidayInfoEntityList.size() > 0 && !name.equals(oldName)) {
            v.setInfo("name is already existe");
            v.setStatus("n");
        }
        logger.info("add/update holidayInfo holidayName, result:" + v.getInfo());
        return v;
    }

    @RequestMapping(params = "toHolidayLog")
    public ModelAndView goToLogView() {
        return new ModelAndView("");
    }

    @RequestMapping(params = "logdatagrid")
    public void logdatagrid(HolidayLogEntity holidayLogEntity, HttpServletRequest request, HttpServletResponse response, DataGrid dataGrid) {

        CriteriaQuery cq = new CriteriaQuery(HolidayLogEntity.class, dataGrid);
        if (!"".equals(oConvertUtils.getString(request.getParameter("name")))) {
            cq.like("name", "%" + request.getParameter("name") + "%");
        }
        if (!"".equals(oConvertUtils.getString(request.getParameter("operType")))) {
            cq.eq("operType", request.getParameter("operType"));
        }
        cq.add();
        this.holidayInfoServiceI.getDataGridReturn(cq, true);
        TagUtil.datagrid(response, dataGrid);
    }
}
