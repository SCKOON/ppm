var checkItem;
function deleteDialog(id) {
    //提示框
    layer.confirm("Delete this email template？", function (r) {
        if (r) {
            var url = "emailController.do?doDel&id=" + id;
            $.ajax({
                url: url,
                type: "get",
                dataType: "json",
                success: function (data) {
                    alertTip(data.msg);
                    if (data.success) {
                        $("#emailList").datagrid('reload');
                        if(checkItem){
                            checkItem == id;
                            $("#ff").form('clear');
                        }
                    }
                }
            })
        }
    });
}

function fillData(rowIndex,rowData) {
    checkItem = rowData['id'];
    //清空表单
    $("#ff").form('clear');
    //填充数据
    for (var d in rowData) {
        if(d=='sendTimeFlag'){
            if(rowData[d] == '01'){
                $("#" + d).val('Disabled');
            }else if(rowData[d] == '02'){
                $("#" + d).val('Enabled');
            }
            continue;
        }
        $("#" + d).val(rowData[d]);
    }
    //处理特殊控件
}

function distributePerson(rowid){
    createdialog()
}