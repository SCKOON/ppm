function deleteDialog(id) {
    //提示框
    layer.confirm("Confirm to delete this record？", function (r) {
        if (r) {
            var url = "holidayController.do?doDel&id=" + id;
            $.ajax({
                url: url,
                type: "get",
                dataType: "json",
                success: function (data) {
                    alertTip(data.msg);
                    if (data.success) {
                        $("#holidayList").datagrid('reload');
                    }
                }
            })
        }
    });
}

function add(title, addurl, gname, width, height) {
    gridname = gname;
    createwindow(title, addurl, width, height);
}

function createwindow(title, addurl, width, height) {
    width = width ? width : 700;
    height = height ? height : 400;
    if (width == "100%" || height == "100%") {
        width = window.top.document.body.offsetWidth;
        height = window.top.document.body.offsetHeight - 100;
    }
    //--author：JueYue---------date：20140427---------for：弹出bug修改,设置了zindex()函数
    if (typeof(windowapi) == 'undefined') {
        $.dialog({
            content: 'url:' + addurl,
            lock: true,
            zIndex: getzIndex(),
            width: width,
            height: height,
            title: title,
            opacity: 0.3,
            cache: false,
            okVal: 'Submit',
            ok: function () {
                iframe = this.iframe.contentWindow;
                saveObj();
                // var subDlgIndex = null;
                // $(function () {
                //     $("#ff",iframe.document).Validform({
                //         tiptype: 4,
                //         btnSubmit: "#btn_sub",
                //         btnReset: "#btn_reset",
                //         ajaxPost: true,
                //         beforeSubmit: function (curform) {
                //             var tag = false;
                //             subDlgIndex = $.dialog({
                //                 content: '?????',
                //                 zIndex: 19910320,
                //                 lock: true,
                //                 width: 100,
                //                 height: 50,
                //                 opacity: 0.3,
                //                 title: '??',
                //                 cache: false
                //             });
                //             var infoTable = subDlgIndex.DOM.t.parent().parent().parent();
                //             infoTable.parent().append('<div id="infoTable-loading" style="text-align:center;"><img src="plug-in/layer/skin/default/loading-0.gif"/></div>');
                //             infoTable.css('display', 'none');
                //         },
                //         usePlugin: {},
                //         callback: function (data) {
                //             if (subDlgIndex && subDlgIndex != null) {
                //                 $('#infoTable-loading').hide();
                //                 subDlgIndex.close();
                //             }
                //             var win = frameElement.api.opener;
                //             if (data.success == true) {
                //                 frameElement.api.close();
                //                 win.alertTip(data.msg);
                //             } else {
                //                 $.messager.alert('Error', data.responseText);
                //                 $.Hidemsg();
                //                 return false;
                //             }
                //             win.reloadTable();
                //         }
                //     });
                // });
                return false;
            },
            cancelVal: 'Close',
            cancel: true /*为true等价于function(){}*/
        });
    } else {

        /*W.*/
        $.dialog({//使用W，即为使用顶级页面作为openner，造成打开的次级窗口获取不到关联的主窗口
            content: 'url:' + addurl,
            lock: true,
            width: width,
            zIndex: getzIndex(),
            height: height,
            parent: windowapi,
            title: title,
            opacity: 0.3,
            cache: false,
            ok: function () {
                iframe = this.iframe.contentWindow;
                saveObj();
                location.reload();
                return false;
            },
            cancelVal: 'Close',
            cancel: true /*为true等价于function(){}*/
        });

    }
    //--author：JueYue---------date：20140427---------for：弹出bug修改,设置了zindex()函数

}